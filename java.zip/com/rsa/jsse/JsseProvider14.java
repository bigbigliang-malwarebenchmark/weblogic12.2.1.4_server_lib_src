package com.rsa.jsse;

/**
 * @deprecated
 */
public class JsseProvider14
  extends JsseProvider
{}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jsse.JsseProvider14
 * JD-Core Version:    0.7.0.1
 */