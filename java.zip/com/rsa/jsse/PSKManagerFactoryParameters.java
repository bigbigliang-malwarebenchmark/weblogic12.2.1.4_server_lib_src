package com.rsa.jsse;

import com.rsa.sslj.x.cn;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.ManagerFactoryParameters;

public class PSKManagerFactoryParameters
  implements ManagerFactoryParameters
{
  private List a = Collections.synchronizedList(new ArrayList());
  
  public void addClientIDandKey(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    cn localcn = new cn(paramArrayOfByte1, paramArrayOfByte2);
    this.a.add(localcn);
  }
  
  public void deleteID(byte[] paramArrayOfByte)
  {
    synchronized (this.a)
    {
      Iterator localIterator = this.a.iterator();
      while (localIterator.hasNext())
      {
        Object localObject1 = localIterator.next();
        cn localcn = (cn)localObject1;
        if (Arrays.equals(paramArrayOfByte, localcn.a()))
        {
          this.a.remove(localcn);
          return;
        }
      }
    }
  }
  
  public List getList()
  {
    return this.a;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jsse.PSKManagerFactoryParameters
 * JD-Core Version:    0.7.0.1
 */