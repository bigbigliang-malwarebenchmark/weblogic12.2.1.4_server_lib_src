package com.rsa.jsse;

import com.rsa.jsafe.crypto.FIPS140Context;
import com.rsa.jsse.engine.util.l;
import com.rsa.sslj.x.aH;
import com.rsa.sslj.x.au;
import com.rsa.sslj.x.bg;
import com.rsa.sslj.x.cc;
import com.rsa.sslj.x.cd;
import com.rsa.sslj.x.ce;
import com.rsa.sslj.x.cf;
import com.rsa.sslj.x.cg;
import com.rsa.sslj.x.cj;
import com.rsa.sslj.x.cp;
import com.rsa.sslj.x.cq;
import java.security.AccessController;
import java.security.Provider.Service;

public class JsseProvider
  extends d
{
  private static final String d = l.e() + " JSSE Provider " + "supporting SSLv3, TLSv1, TLSv1.1, and TLSv1.2";
  public static final String NAME = "RsaJsse";
  static final double a = l.c();
  public static final String TLS = "TLS";
  public static final String TLS_V1 = "TLSv1";
  public static final String TLS_V11 = "TLSv1.1";
  public static final String TLS_V12 = "TLSv1.2";
  /**
   * @deprecated
   */
  public static final String SSL_V2 = "SSLv2";
  public static final String SSL_V3 = "SSLv3";
  public static final String X509 = "X509";
  public static final String PSK = "PSK";
  public static final String SUN_X509 = "SunX509";
  public static final String PKIX = "PKIX";
  public static final String PKIX_SUITEBTLS = "PKIX-SuiteBTLS";
  public static final String PKIX_SUITEB = "PKIX-SuiteB";
  static final cq b = cq.a;
  final bg c;
  
  public JsseProvider()
  {
    this(bg.a());
  }
  
  public JsseProvider(FIPS140Mode paramFIPS140Mode)
  {
    this(bg.a(paramFIPS140Mode));
  }
  
  public JsseProvider(SuiteBMode paramSuiteBMode)
  {
    this(bg.a(paramSuiteBMode));
  }
  
  public JsseProvider(FIPS140Mode paramFIPS140Mode, SuiteBMode paramSuiteBMode)
  {
    this(bg.a(paramFIPS140Mode, paramSuiteBMode));
  }
  
  public JsseProvider(FIPS140Mode paramFIPS140Mode, FIPS140Role paramFIPS140Role)
  {
    this(bg.a(paramFIPS140Mode, paramFIPS140Role));
  }
  
  public JsseProvider(FIPS140Mode paramFIPS140Mode, FIPS140Role paramFIPS140Role, SuiteBMode paramSuiteBMode)
  {
    this(bg.a(paramFIPS140Mode, paramFIPS140Role, paramSuiteBMode));
  }
  
  private JsseProvider(bg parambg)
  {
    super(parambg.d, a, d);
    this.c = parambg;
    AccessController.doPrivileged(new JsseProvider.1(this));
  }
  
  public FIPS140Mode getFIPS140Mode()
  {
    if (this.c.b == null) {
      return FIPS140Mode.NON_FIPS140_MODE;
    }
    return this.c.e;
  }
  
  public FIPS140Role getFIPS140Role()
  {
    if (this.c.b == null) {
      return FIPS140Role.USER_ROLE;
    }
    return FIPS140Role.lookup(this.c.b.getRoleValue());
  }
  
  public SuiteBMode getSuiteBMode()
  {
    return this.c.f;
  }
  
  private void a()
  {
    a("SSLContext", "TLS", aH.class, new String[] { "SSLv3", "SSL", "TLSv1", "TLSv1.1", "TLSv1.2" });
    a("SSLContext", "Default", au.class);
    a("KeyManagerFactory", "X509", cc.class, new String[] { "SunX509", "NewSunX509", "IbmX509", "NewIbmX509", "RsaX509" });
    a("KeyManagerFactory", "PSK", cg.class);
    a("TrustManagerFactory", "X509", cj.class, new String[] { "SunX509", "IbmX509", "X.509", "RsaX509" });
    a("TrustManagerFactory", "PKIX", cf.class, new String[] { "SunPKIX", "IbmPKIX" });
    a("TrustManagerFactory", "PKIX-SuiteB", ce.class);
    a("TrustManagerFactory", "PKIX-SuiteBTLS", cd.class);
  }
  
  private void a(String paramString1, String paramString2, Class paramClass)
  {
    a(paramString1, paramString2, paramClass, true);
  }
  
  private void a(String paramString1, String paramString2, Class paramClass, String[] paramArrayOfString)
  {
    a(paramString1, paramString2, paramClass, paramArrayOfString, true);
  }
  
  private void a(String paramString1, String paramString2, Class paramClass, boolean paramBoolean)
  {
    a(paramString1, paramString2, paramClass, new String[0], paramBoolean);
  }
  
  private void a(String paramString1, String paramString2, Class paramClass, String[] paramArrayOfString, boolean paramBoolean)
  {
    b.a(this, new cp(paramString1, paramString2, paramClass, paramArrayOfString, paramBoolean), this.c);
  }
  
  void a(Provider.Service paramService)
  {
    putService(paramService);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jsse.JsseProvider
 * JD-Core Version:    0.7.0.1
 */