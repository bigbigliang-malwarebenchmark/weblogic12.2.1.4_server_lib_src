package com.rsa.jsse;

import com.rsa.sslj.x.as;
import com.rsa.sslj.x.ci.b;
import com.rsa.sslj.x.cn;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.KeyManager;

public final class PSKKeyManager
  implements KeyManager
{
  private List a;
  
  public PSKKeyManager(List paramList)
  {
    this.a = new ArrayList(paramList);
  }
  
  public byte[] getKey(byte[] paramArrayOfByte)
  {
    Iterator localIterator = this.a.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      cn localcn = (cn)localObject;
      if (Arrays.equals(paramArrayOfByte, localcn.a())) {
        return localcn.b();
      }
    }
    return null;
  }
  
  public cn getPSKID(int paramInt)
  {
    return (cn)this.a.get(paramInt);
  }
  
  public ci.b selectCipherSuiteAndCertificateChain(List<as> paramList)
  {
    return new ci.b((as)paramList.get(0), null, null);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jsse.PSKKeyManager
 * JD-Core Version:    0.7.0.1
 */