package com.rsa.jsse;

import com.rsa.jsse.engine.util.Debug;

public final class LoggingConfig
{
  public static final String MULTITHREADED_PROP = "com.rsa.jsse.multithreaded";
  public static final String LOGFILE_PROP = "com.rsa.jsse.logFile";
  public static final String SPLIT_OPTION_PROP = "com.rsa.jsse.split";
  
  public static void reInitializeLogProperties() {}
  
  public static void closeLogStream() {}
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jsse.LoggingConfig
 * JD-Core Version:    0.7.0.1
 */