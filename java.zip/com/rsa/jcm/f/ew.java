package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.InvalidKeyException;
import com.rsa.crypto.KDF;
import com.rsa.crypto.Key;
import com.rsa.crypto.MAC;
import com.rsa.crypto.SecretKey;

public abstract class ew
  extends cl
  implements KDF
{
  private static final String KEY_ALG = "KDFTLS";
  
  public ew(ke paramke)
  {
    super(paramke);
  }
  
  public SecretKey generate(Key paramKey, AlgorithmParams paramAlgorithmParams)
    throws InvalidAlgorithmParameterException, InvalidKeyException
  {
    if (paramKey == null) {
      paramKey = new di(this.an, new byte[0], 0, 0);
    }
    if (!(paramKey instanceof SecretKey)) {
      throw new InvalidKeyException("Key invalid for algorithm. Expected SecretKey");
    }
    if (!(paramAlgorithmParams instanceof AlgInputParams)) {
      throw new InvalidAlgorithmParameterException("Parameters object invalid for algorithm.");
    }
    AlgInputParams localAlgInputParams = (AlgInputParams)paramAlgorithmParams;
    byte[] arrayOfByte1 = ij.a(localAlgInputParams, "label");
    byte[] arrayOfByte2 = ij.a(localAlgInputParams, "seed");
    int i = (ij.c((AlgInputParams)paramAlgorithmParams, "keyBits") + 7) / 8;
    byte[] arrayOfByte3 = new byte[i];
    a((SecretKey)paramKey, arrayOfByte1, arrayOfByte2, arrayOfByte3);
    di localdi = new di(this.an, arrayOfByte3, 0, arrayOfByte3.length, "KDFTLS");
    er.w(arrayOfByte3);
    return localdi;
  }
  
  abstract void a(SecretKey paramSecretKey, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);
  
  static void a(MAC paramMAC, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte1 = new byte[paramArrayOfByte2.length + paramArrayOfByte1.length];
    System.arraycopy(paramArrayOfByte1, 0, arrayOfByte1, 0, paramArrayOfByte1.length);
    System.arraycopy(paramArrayOfByte2, 0, arrayOfByte1, paramArrayOfByte1.length, paramArrayOfByte2.length);
    paramMAC.update(arrayOfByte1, 0, arrayOfByte1.length);
    byte[] arrayOfByte2 = new byte[paramMAC.getMacLength()];
    paramMAC.mac(arrayOfByte2, 0);
    int i = 0;
    byte[] arrayOfByte3 = new byte[arrayOfByte2.length];
    while (i < paramInt2)
    {
      paramMAC.update(arrayOfByte2, 0, arrayOfByte2.length);
      MAC localMAC = (MAC)paramMAC.clone();
      localMAC.update(arrayOfByte1, 0, arrayOfByte1.length);
      paramMAC.mac(arrayOfByte2, 0);
      localMAC.mac(arrayOfByte3, 0);
      i += arrayOfByte2.length;
      if (i < paramInt2)
      {
        System.arraycopy(arrayOfByte3, 0, paramArrayOfByte3, paramInt1, arrayOfByte2.length);
        paramInt1 += arrayOfByte2.length;
      }
      else
      {
        System.arraycopy(arrayOfByte3, 0, paramArrayOfByte3, paramInt1, paramInt2 - paramInt1);
      }
      er.w(arrayOfByte3);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ew
 * JD-Core Version:    0.7.0.1
 */