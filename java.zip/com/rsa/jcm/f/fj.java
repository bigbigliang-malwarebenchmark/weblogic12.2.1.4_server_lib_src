package com.rsa.jcm.f;

import com.rsa.crypto.BigNum;
import com.rsa.crypto.RSAPublicKey;
import com.rsa.crypto.SecureRandom;

public class fj
  extends cl
  implements RSAPublicKey
{
  private BigNum kr;
  private BigNum kt;
  
  public fj(ke paramke, BigNum paramBigNum1, BigNum paramBigNum2)
  {
    super(paramke);
    this.kr = paramBigNum1;
    this.kt = paramBigNum2;
  }
  
  public fj(ke paramke, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this(paramke, new id(paramArrayOfByte1), new id(paramArrayOfByte2));
  }
  
  public BigNum getN()
  {
    return this.kr;
  }
  
  public BigNum getE()
  {
    return this.kt;
  }
  
  public void clearSensitiveData()
  {
    er.a((id)this.kr);
    er.a((id)this.kt);
  }
  
  public String getAlg()
  {
    return "RSA";
  }
  
  public boolean isValid(SecureRandom paramSecureRandom)
  {
    return ft.a(this, paramSecureRandom);
  }
  
  public Object clone()
  {
    fj localfj = (fj)super.clone();
    localfj.kr = ((id)es.a((id)this.kr));
    localfj.kt = ((id)es.a((id)this.kt));
    return localfj;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fj
 * JD-Core Version:    0.7.0.1
 */