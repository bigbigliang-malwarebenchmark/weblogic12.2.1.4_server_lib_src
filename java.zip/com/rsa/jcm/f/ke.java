package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.AlgParamGenerator;
import com.rsa.crypto.Cipher;
import com.rsa.crypto.CryptoModule;
import com.rsa.crypto.KDF;
import com.rsa.crypto.KeyAgreement;
import com.rsa.crypto.KeyBuilder;
import com.rsa.crypto.KeyConfirmation;
import com.rsa.crypto.KeyGenerator;
import com.rsa.crypto.KeyPairGenerator;
import com.rsa.crypto.MAC;
import com.rsa.crypto.MessageDigest;
import com.rsa.crypto.ModuleOperations;
import com.rsa.crypto.NoSuchAlgorithmException;
import com.rsa.crypto.SecureRandom;
import com.rsa.crypto.Signature;
import com.rsa.crypto.SymmCipher;
import com.rsa.crypto.jcm.ModuleLoader;
import java.io.ObjectStreamException;

public class ke
  implements CryptoModule
{
  private static final long serialVersionUID = cz.ai() ? -3280137922208339705L : -5454450876211660033L;
  private transient KeyBuilder sz;
  
  public ke()
  {
    ModuleLoader.ensureSelfTestsPassed();
    this.sz = new v(this);
  }
  
  public String getDeviceType()
  {
    return "Java";
  }
  
  public MessageDigest newMessageDigest(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.b(paramString, this);
  }
  
  public MAC newMAC(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.a(im.split(paramString), this);
  }
  
  public KDF newKDF(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.c(im.split(paramString), this);
  }
  
  public Cipher newAsymmetricCipher(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.e(im.split(paramString), this);
  }
  
  public SymmCipher newSymmetricCipher(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.f(im.split(paramString), this);
  }
  
  public Cipher newKeyWrapCipher(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.e(paramString, this);
  }
  
  public Signature newSignature(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.d(im.split(paramString), this);
  }
  
  public KeyAgreement newKeyAgreement(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.a(paramString, this);
  }
  
  public KeyConfirmation newKeyConfirmation(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.h(im.split(paramString), this);
  }
  
  public SecureRandom newSecureRandom(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.b(im.split(paramString), this);
  }
  
  public KeyPairGenerator newKeyPairGenerator(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.c(paramString, this);
  }
  
  public KeyGenerator newKeyGenerator(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.d(paramString, this);
  }
  
  public AlgParamGenerator newAlgParamGenerator(String paramString)
    throws NoSuchAlgorithmException
  {
    return il.h(paramString, this);
  }
  
  public KeyBuilder getKeyBuilder()
  {
    return this.sz;
  }
  
  public AlgInputParams newAlgInputParams()
  {
    return new ii(this);
  }
  
  public ModuleOperations getModuleOperations()
  {
    return b.f;
  }
  
  private Object readResolve()
    throws ObjectStreamException
  {
    ModuleLoader.ensureSelfTestsPassed();
    this.sz = new v(this);
    return this;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ke
 * JD-Core Version:    0.7.0.1
 */