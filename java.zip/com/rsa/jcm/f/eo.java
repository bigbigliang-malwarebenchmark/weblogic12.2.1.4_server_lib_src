package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.CryptoModule;
import com.rsa.crypto.KDF;
import com.rsa.crypto.SecretKey;

abstract class eo
  extends ei
{
  static final byte[] jB = "master secret".getBytes();
  static final byte[] jC = "key expansion".getBytes();
  
  eo()
  {
    super(1);
  }
  
  protected boolean a(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5)
  {
    KDF localKDF = this.ip.newKDF(paramString);
    di localdi = new di(null, paramArrayOfByte1, 0, paramArrayOfByte1.length);
    AlgInputParams localAlgInputParams = a(paramArrayOfByte2, paramArrayOfByte3, paramArrayOfByte4, paramArrayOfByte5.length * 8);
    byte[] arrayOfByte = localKDF.generate(localdi, localAlgInputParams).getKeyData();
    return ja.f(paramArrayOfByte5, 0, paramArrayOfByte5.length, arrayOfByte, 0, arrayOfByte.length);
  }
  
  private AlgInputParams a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt)
  {
    byte[] arrayOfByte = new byte[paramArrayOfByte2.length + paramArrayOfByte3.length];
    System.arraycopy(paramArrayOfByte2, 0, arrayOfByte, 0, paramArrayOfByte2.length);
    System.arraycopy(paramArrayOfByte3, 0, arrayOfByte, paramArrayOfByte2.length, paramArrayOfByte3.length);
    AlgInputParams localAlgInputParams = this.ip.newAlgInputParams();
    localAlgInputParams.set("label", paramArrayOfByte1);
    localAlgInputParams.set("seed", arrayOfByte);
    localAlgInputParams.set("keyBits", Integer.valueOf(paramInt));
    return localAlgInputParams;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.eo
 * JD-Core Version:    0.7.0.1
 */