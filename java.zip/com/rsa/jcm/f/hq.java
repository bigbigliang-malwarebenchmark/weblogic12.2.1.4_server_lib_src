package com.rsa.jcm.f;

public class hq
  extends hn
{
  private static final int nN = 16;
  private static final int nO = 8;
  
  hq(gk paramgk)
  {
    super(paramgk);
  }
  
  hq(gk paramgk, id paramid)
  {
    super(paramgk, paramid);
  }
  
  public void l(id paramid)
  {
    int[] arrayOfInt1 = paramid.cM();
    int i = paramid.cJ();
    if (i <= 8)
    {
      if (i == 8)
      {
        int j = paramid.q(this.nM);
        switch (j)
        {
        case 0: 
          paramid.p(paramid);
          return;
        case -1: 
          return;
        }
        paramid.t(this.nM);
        return;
      }
      return;
    }
    int[] arrayOfInt2 = new int[16];
    System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, i);
    int k = arrayOfInt2[0];
    int m = 0;
    int n;
    k += (n = arrayOfInt2[8]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[9]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[11];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[12];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[13];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[14];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[0] = k;
    k = m + (n = arrayOfInt2[1]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[9]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[10]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[12];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[13];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[14];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[15];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[1] = k;
    k = m + (n = arrayOfInt2[2]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[10]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[11]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[13];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[14];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[15];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[2] = k;
    k = m + (n = arrayOfInt2[3]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[11]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[11]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[12]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[12]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[13]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[8];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[9];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[15];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[3] = k;
    k = m + (n = arrayOfInt2[4]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[12]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[12]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[13]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[13]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[14]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[9];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[10];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[4] = k;
    k = m + (n = arrayOfInt2[5]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[13]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[13]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[14]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[14]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[15]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[10];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[11];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[5] = k;
    k = m + (n = arrayOfInt2[6]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[13]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[14]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[14]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[14]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[15]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[15]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[8];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[9];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[6] = k;
    k = m + (n = arrayOfInt2[7]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[8]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[15]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[15]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = arrayOfInt2[15]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[10];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[11];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[12];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - arrayOfInt2[13];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[7] = k;
    if (m != 0)
    {
      int[] arrayOfInt3 = this.nM.cM();
      if (m < 0) {
        do
        {
          m += ih.b(arrayOfInt2, 8, arrayOfInt3, 8, arrayOfInt2);
        } while (m != 0);
      } else {
        do
        {
          m += ih.a(arrayOfInt2, 8, arrayOfInt3, 8, arrayOfInt2);
        } while (m != 0);
      }
    }
    paramid.a(arrayOfInt2, 8);
    if (paramid.q(this.nM) >= 0) {
      paramid.t(this.nM);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hq
 * JD-Core Version:    0.7.0.1
 */