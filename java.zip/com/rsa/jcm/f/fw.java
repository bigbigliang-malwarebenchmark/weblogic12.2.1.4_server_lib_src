package com.rsa.jcm.f;

import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.BigNum;
import com.rsa.crypto.CryptoException;
import com.rsa.crypto.ECParams;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.KeyPair;
import com.rsa.crypto.KeyPairGenerator;
import com.rsa.crypto.SecureRandom;

public class fw
  extends cl
  implements KeyPairGenerator
{
  private SecureRandom M;
  private boolean initialized;
  private ECParams ki;
  
  public fw(ke paramke)
  {
    super(paramke);
  }
  
  public void initialize(AlgorithmParams paramAlgorithmParams, SecureRandom paramSecureRandom)
    throws InvalidAlgorithmParameterException
  {
    this.ki = ((ECParams)paramAlgorithmParams);
    this.M = paramSecureRandom;
    this.initialized = true;
  }
  
  public KeyPair generate()
  {
    return generate(cz.ai());
  }
  
  public KeyPair generate(boolean paramBoolean)
  {
    if (!this.initialized) {
      throw new IllegalStateException("Object not initialized.");
    }
    id localid1 = new id();
    localid1.p((id)this.ki.getOrder());
    localid1.R(1);
    int i = (this.ki.getOrder().getBitLength() + 7) / 8;
    byte[] arrayOfByte = new byte[i];
    id localid2 = new id();
    int j = 255;
    int k = 8 - (this.ki.getOrder().getBitLength() & 0x7);
    if (k < 8) {
      j >>>= k;
    }
    fu localfu1 = null;
    try
    {
      do
      {
        this.M.nextBytes(arrayOfByte);
        int tmp139_138 = 0;
        byte[] tmp139_136 = arrayOfByte;
        tmp139_136[tmp139_138] = ((byte)(tmp139_136[tmp139_138] & j));
        localid2.t(arrayOfByte, 0, arrayOfByte.length);
      } while ((localid2.isZero()) || (localid2.q(localid1) >= 0));
      localid2.Q(1);
      gi localgi = ((gi)this.ki.getBase()).g(localid2);
      localfu1 = new fu("EC", new fe(this.an, localid2, this.ki), new ff(this.an, localgi, this.ki));
      if (paramBoolean) {
        dm.b(localfu1, this.M);
      }
      fu localfu2 = localfu1;
      return localfu2;
    }
    catch (SecurityException localSecurityException)
    {
      er.a(localfu1);
      throw localSecurityException;
    }
    catch (CryptoException localCryptoException)
    {
      er.a(localfu1);
      throw new CryptoException("Generated key pair invalid.");
    }
    finally
    {
      er.w(arrayOfByte);
      localid1.clearSensitiveData();
    }
  }
  
  public void clearSensitiveData()
  {
    this.M = null;
    this.ki = null;
    this.initialized = false;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fw
 * JD-Core Version:    0.7.0.1
 */