package com.rsa.jcm.f;

public class iy
{
  private static final byte[] pV = jf.g("DESUtil.bin")[0];
  
  public static boolean C(byte[] paramArrayOfByte)
  {
    return z(paramArrayOfByte, 0);
  }
  
  public static boolean z(byte[] paramArrayOfByte, int paramInt)
  {
    for (int i = 0; i < pV.length / 8; i++)
    {
      int k = i * 8;
      for (int j = 0; (j < 8) && (paramArrayOfByte[(paramInt + j)] == pV[(k + j)]); j++) {}
      if (j == 8) {
        return true;
      }
    }
    return false;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.iy
 * JD-Core Version:    0.7.0.1
 */