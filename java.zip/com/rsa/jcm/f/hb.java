package com.rsa.jcm.f;

import java.util.Arrays;

public class hb
  implements gm
{
  private static final int mV = 1;
  private static final int mW = 2;
  private static final int mX = 3;
  private static final int mY = 4;
  private static final int mZ = 5;
  private final hc mR;
  private final int na;
  
  hb(hc paramhc)
  {
    this.mR = paramhc;
    if (this.mR.ci() == hc.a.nt) {
      this.na = (this.mR.cf() <= this.mR.getFieldSize() / 2 ? 3 : 2);
    } else if (this.mR.ci() == hc.a.nu) {
      this.na = 4;
    } else {
      this.na = 1;
    }
  }
  
  hb(hc paramhc, boolean paramBoolean)
  {
    this.mR = paramhc;
    if (paramBoolean) {
      this.na = 5;
    } else if (this.mR.ci() == hc.a.nt) {
      this.na = (this.mR.cf() <= this.mR.getFieldSize() / 2 ? 3 : 2);
    } else if (this.mR.ci() == hc.a.nu) {
      this.na = 4;
    } else {
      this.na = 1;
    }
  }
  
  public gl bW()
  {
    return a(ic.cL());
  }
  
  public gl bX()
  {
    int i = gn.s(this.mR.getFieldSize());
    ic localic = ic.N(i);
    if (this.na == 1)
    {
      int[] arrayOfInt = localic.cH();
      int j = gn.u(this.mR.getFieldSize());
      Arrays.fill(arrayOfInt, -1);
      int tmp51_50 = (arrayOfInt.length - 1);
      int[] tmp51_46 = arrayOfInt;
      tmp51_46[tmp51_50] = ((int)(tmp51_46[tmp51_50] & (-4294967296L >> 32 - j ^ 0xFFFFFFFF)));
      localic.D(i);
    }
    else
    {
      localic.setValue(1);
    }
    return a(localic);
  }
  
  public gl j(id paramid)
  {
    return a(ic.d(paramid.toIntArray()));
  }
  
  public gl s(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return a(ic.x(paramArrayOfByte, paramInt1, paramInt2));
  }
  
  public gl a(ic paramic)
  {
    switch (this.na)
    {
    case 2: 
      return new gz(this.mR, paramic);
    case 3: 
      return new ha(this.mR, paramic);
    case 4: 
      return new gx(this.mR, paramic);
    case 1: 
      return new gw(this.mR, paramic);
    }
    return new gv(this.mR, paramic);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hb
 * JD-Core Version:    0.7.0.1
 */