package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;

class gz
  extends gy
{
  gz(gk paramgk, ic paramic)
  {
    super(paramgk, paramic);
  }
  
  public gl bU()
  {
    if (isZero()) {
      throw new CryptoException("Inversion of zero is not valid.");
    }
    Object localObject1 = this.mR.getFieldSize();
    Object localObject2 = this.mR.cc();
    Object localObject3 = this.mR.cf();
    int i = localObject3 % 32;
    int j = 32 - i;
    int k = localObject1 % 32;
    int m = 32 - k;
    int n = localObject3 >>> 5;
    Object localObject4 = new int[localObject2 * 3];
    localObject4[0] = 1;
    Object localObject5 = 0;
    Object localObject6 = 0;
    Object localObject7 = new int[localObject2 * 3];
    Object localObject8 = -1;
    Object localObject9 = 0;
    Object localObject10 = this.mS.B(localObject2);
    Object localObject11 = this.mS.getBitLength();
    Object localObject12 = gn.s(localObject11) - 1;
    Object localObject13 = this.mR.ck().B(localObject2);
    Object localObject14 = localObject1;
    Object localObject15 = localObject2 - 1;
    int i1 = 0;
    int i3;
    Object localObject16;
    Object localObject19;
    int i6;
    for (;;)
    {
      if (localObject10[0] == 0)
      {
        i1 += 32;
        System.arraycopy(localObject10, 1, localObject10, 0, localObject12);
        localObject11 -= 32;
        localObject12--;
        if (localObject8 >= 0)
        {
          localObject8 += 32;
          System.arraycopy(localObject7, 0, localObject7, 1, localObject9 + 1);
          localObject7[0] = 0;
          localObject9++;
        }
      }
      else
      {
        i2 = localObject10[0];
        i3 = 0;
        while ((i2 & 0x1) == 0)
        {
          i3++;
          i2 >>>= 1;
        }
        i1 += i3;
        localObject11 -= i3;
        if (localObject11 == 0) {
          break;
        }
        if (i3 != 0) {
          ih.c((int[])localObject10, localObject12, i3, (int[])localObject10);
        }
        if (localObject8 >= 0)
        {
          localObject8 += i3;
          localObject9 = localObject8 >>> 5;
          if (i3 != 0) {
            ih.b((int[])localObject7, localObject9, i3, (int[])localObject7);
          }
        }
        localObject12 = localObject11 >>> 5;
        if (localObject11 < localObject14)
        {
          localObject16 = localObject10;
          localObject10 = localObject13;
          localObject13 = localObject16;
          localObject19 = localObject12;
          localObject12 = localObject15;
          localObject15 = localObject19;
          localObject19 = localObject11;
          localObject11 = localObject14;
          localObject14 = localObject19;
          localObject16 = localObject4;
          localObject4 = localObject7;
          localObject7 = localObject16;
          localObject19 = localObject9;
          localObject9 = localObject6;
          localObject6 = localObject19;
          localObject19 = localObject8;
          localObject8 = localObject5;
          localObject5 = localObject19;
        }
        for (localObject16 = localObject15; localObject16 >= 0; localObject16--) {
          localObject10[localObject16] ^= localObject13[localObject16];
        }
        if (localObject11 == localObject14)
        {
          for (localObject16 = localObject12; (localObject16 > 0) && (localObject10[localObject16] == 0); localObject16--) {}
          localObject19 = localObject10[localObject16];
          for (i6 = 24; localObject19 >>> i6 == 0; i6 -= 8) {}
          localObject11 = localObject16 << 5 | i6 | gn.mI[(localObject19 >>> i6)];
          localObject12 = localObject16;
        }
        for (localObject16 = localObject9; localObject16 >= 0; localObject16--) {
          localObject4[localObject16] ^= localObject7[localObject16];
        }
        if (localObject8 > localObject5)
        {
          localObject5 = localObject8;
          localObject6 = localObject9;
        }
        else if (localObject8 == localObject5)
        {
          for (localObject16 = localObject6; (localObject16 > 0) && (localObject4[localObject16] == 0); localObject16--) {}
          localObject19 = localObject4[localObject16];
          for (i6 = 24; localObject19 >>> i6 == 0; i6 -= 8) {}
          localObject5 = localObject16 << 5 | i6 | gn.mI[(localObject19 >>> i6)];
          localObject6 = localObject16;
        }
      }
    }
    if (localObject6 < localObject2) {
      localObject6 = localObject2;
    }
    int i2 = 0;
    while (i1 >= 32)
    {
      i3 = localObject4[i2];
      localObject4[i2] = 0;
      localObject4[(i2 + n)] ^= i3 << i;
      if (i != 0) {
        localObject4[(i2 + n + 1)] ^= i3 >>> j;
      }
      localObject4[(i2 + localObject2 - 1)] ^= i3 << k;
      if (k != 0) {
        localObject4[(i2 + localObject2)] ^= i3 >>> m;
      }
      if (localObject3 < 32)
      {
        localObject16 = localObject3;
        int i4;
        do
        {
          i3 = localObject4[i2] >>> localObject16;
          localObject4[i2] = 0;
          i6 = (localObject16 + localObject3) % 32;
          localObject19 = localObject16 + localObject3 >>> 5;
          localObject4[(i2 + localObject19)] ^= i3 << i6;
          if (i6 != 0) {
            localObject4[(i2 + localObject19 + 1)] ^= i3 >>> 32 - i6;
          }
          i6 = (localObject16 + localObject1) % 32;
          localObject19 = localObject16 + localObject1 >>> 5;
          localObject4[(i2 + localObject19)] ^= i3 << i6;
          if (i6 != 0) {
            localObject4[(i2 + localObject19 + 1)] ^= i3 >>> 32 - i6;
          }
          localObject16 += localObject3;
        } while (i4 < 32);
      }
      i2++;
      i1 -= 32;
    }
    if (i1 != 0)
    {
      if (localObject3 < i1) {
        i3 = localObject4[i2] & (1 << i) - 1;
      } else {
        i3 = localObject4[i2] & (1 << i1) - 1;
      }
      localObject4[(i2 + n)] ^= i3 << i;
      if (i != 0) {
        localObject4[(i2 + n + 1)] ^= i3 >>> j;
      }
      localObject4[(i2 + localObject2 - 1)] ^= i3 << k;
      if (k != 0) {
        localObject4[(i2 + localObject2)] ^= i3 >>> m;
      }
      if (localObject3 < i1)
      {
        Object localObject17 = localObject3;
        int i5;
        do
        {
          i3 = localObject4[i2] >>> localObject17;
          if (localObject3 < i1 - localObject17) {
            i3 &= (1 << localObject3) - 1;
          } else {
            i3 &= (1 << i1 - localObject17) - 1;
          }
          localObject19 = (localObject17 + localObject3) % 32;
          i6 = localObject17 + localObject3 >>> 5;
          localObject4[(i2 + i6)] ^= i3 << localObject19;
          if (localObject19 != 0) {
            localObject4[(i2 + i6 + 1)] ^= i3 >>> 32 - localObject19;
          }
          localObject19 = (localObject17 + localObject1) % 32;
          i6 = localObject17 + localObject1 >>> 5;
          localObject4[(i2 + i6)] ^= i3 << localObject19;
          if ((i2 + i6 + 1 < localObject4.length) && (localObject19 != 0)) {
            localObject4[(i2 + i6 + 1)] ^= i3 >>> 32 - localObject19;
          }
          localObject17 += localObject3;
        } while (i5 < i1);
      }
      Object localObject18 = localObject4;
      localObject4 = new int[localObject18.length];
      ih.a(localObject18, i2, localObject2, i1, (int[])localObject4);
      i2 = 0;
    }
    gn.a((int[])localObject4, localObject2 + i2, localObject1 % 32);
    ic localic = ic.d((int[])localObject4, i2, localObject2);
    return this.mR.bf().a(localic);
  }
  
  void b(ic paramic)
  {
    int i = this.mR.getFieldSize();
    int j = 2 * i - 2;
    int[] arrayOfInt1 = paramic.B(gn.s(i) * 2);
    int k = this.mR.cf();
    int[] arrayOfInt2 = new int[gn.s(i) + 2];
    int[] arrayOfInt3 = new int[gn.s(i) + 2];
    int m = i - k;
    do
    {
      int n = j - i;
      int i1 = n + 1;
      int i2 = i1 >= m ? m : i1;
      int i3 = j - i2 + 1 >>> 5;
      int i4 = j >>> 5;
      int i5 = i4 - i3 + 1;
      int i6 = (j - i2 + 1) % 32;
      arrayOfInt2[i5] = 0;
      System.arraycopy(arrayOfInt1, i3, arrayOfInt2, 0, i5);
      arrayOfInt2[0] = (arrayOfInt2[0] >>> i6 << i6);
      i3 = i1 + k - i2 >>> 5;
      i4 = n + k >>> 5;
      int i7 = (i1 + k - i2) % 32;
      arrayOfInt3[i5] = 0;
      if (i6 >= i7)
      {
        ih.d(arrayOfInt2, i5, i6 - i7, arrayOfInt3);
      }
      else
      {
        i8 = ih.a(arrayOfInt2, i5, i7 - i6, arrayOfInt3);
        if (i8 != 0) {
          arrayOfInt3[i5] = i8;
        }
      }
      for (int i8 = i4 - i3; i8 >= 0; i8--) {
        arrayOfInt1[(i3 + i8)] ^= arrayOfInt3[i8];
      }
      i3 = i1 - i2 >>> 5;
      i4 = n >>> 5;
      i7 = (i1 - i2) % 32;
      arrayOfInt3[i5] = 0;
      if (i6 >= i7)
      {
        ih.d(arrayOfInt2, i5, i6 - i7, arrayOfInt3);
      }
      else
      {
        i8 = ih.a(arrayOfInt2, i5, i7 - i6, arrayOfInt3);
        if (i8 != 0) {
          arrayOfInt3[i5] = i8;
        }
      }
      for (i8 = i4 - i3; i8 >= 0; i8--) {
        arrayOfInt1[(i3 + i8)] ^= arrayOfInt3[i8];
      }
      j -= i2;
      i8 = (j + 1) % 32;
      if (i8 != 0) {
        gn.a(arrayOfInt1, (j + 1 >>> 5) + 1, i8);
      }
    } while (j >= i);
    paramic.a(arrayOfInt1, arrayOfInt1.length);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gz
 * JD-Core Version:    0.7.0.1
 */