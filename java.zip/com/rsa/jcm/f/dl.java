package com.rsa.jcm.f;

public final class dl
{
  private dk ik = dk.NOT_INITIALIZED;
  
  public synchronized dl b(dk paramdk)
  {
    if (this.ik.a(paramdk))
    {
      this.ik = paramdk;
      return this;
    }
    throw new SecurityException("Invalid state transition");
  }
  
  private synchronized dk ay()
  {
    return this.ik;
  }
  
  public boolean c(dk paramdk)
  {
    return ay() == paramdk;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dl
 * JD-Core Version:    0.7.0.1
 */