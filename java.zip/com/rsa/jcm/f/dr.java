package com.rsa.jcm.f;

import java.util.concurrent.Callable;

public abstract interface dr
  extends Callable<dr>
{
  public abstract String getName();
  
  public abstract boolean aC();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dr
 * JD-Core Version:    0.7.0.1
 */