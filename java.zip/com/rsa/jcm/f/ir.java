package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.MessageDigest;
import com.rsa.crypto.SignatureException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class ir
{
  private static final byte[] pg = { 48, 32, 48, 12, 6, 8, 42, -122, 72, -122, -9, 13, 2, 2, 5, 0, 4, 16 };
  private static final byte[] ph = { 48, 32, 48, 12, 6, 8, 42, -122, 72, -122, -9, 13, 2, 2, 4, 16 };
  private static final byte[] pi = { 48, 32, 48, 12, 6, 8, 42, -122, 72, -122, -9, 13, 2, 5, 5, 0, 4, 16 };
  private static final byte[] pj = { 48, 30, 48, 10, 6, 8, 42, -122, 72, -122, -9, 13, 2, 5, 4, 16 };
  private static final byte[] pk = { 48, 33, 48, 9, 6, 5, 43, 14, 3, 2, 26, 5, 0, 4, 20 };
  private static final byte[] pl = { 48, 31, 48, 7, 6, 5, 43, 14, 3, 2, 26, 4, 20 };
  private static final byte[] pm = { 48, 45, 48, 13, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 4, 5, 0, 4, 28 };
  private static final byte[] pn = { 48, 43, 48, 11, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 4, 4, 28 };
  private static final byte[] po = { 48, 49, 48, 13, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 1, 5, 0, 4, 32 };
  private static final byte[] pp = { 48, 47, 48, 11, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 1, 4, 32 };
  private static final byte[] pq = { 48, 65, 48, 13, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 2, 5, 0, 4, 48 };
  private static final byte[] pr = { 48, 63, 48, 11, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 2, 4, 48 };
  private static final byte[] ps = { 48, 81, 48, 13, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 3, 5, 0, 4, 64 };
  private static final byte[] pt = { 48, 79, 48, 11, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 3, 4, 64 };
  private static final byte[] pu = { 48, 45, 48, 13, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 5, 5, 0, 4, 28 };
  private static final byte[] pv = { 48, 79, 48, 11, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 5, 4, 28 };
  private static final byte[] pw = { 48, 49, 48, 13, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 6, 5, 0, 4, 32 };
  private static final byte[] px = { 48, 79, 48, 11, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 6, 4, 32 };
  private static final byte[] py = { 48, 33, 48, 9, 6, 5, 43, 36, 3, 2, 1, 5, 0, 4, 20 };
  private static final byte[] pz = { 48, 33, 48, 9, 6, 5, 43, 36, 3, 2, 1, 4, 20 };
  private static final Map<String, ir.a> pA = cP();
  
  private static Map<String, ir.a> cP()
  {
    HashMap localHashMap = new HashMap();
    localHashMap.put("MD2", new ir.a(pg, ph));
    localHashMap.put("MD5", new ir.a(pi, pj));
    localHashMap.put("SHA1", new ir.a(pk, pl));
    localHashMap.put("SHA224", new ir.a(pm, pn));
    localHashMap.put("SHA256", new ir.a(po, pp));
    localHashMap.put("SHA384", new ir.a(pq, pr));
    localHashMap.put("SHA512", new ir.a(ps, pt));
    localHashMap.put("SHA512-224", new ir.a(pu, pv));
    localHashMap.put("SHA512-256", new ir.a(pw, px));
    localHashMap.put("RIPEMD160", new ir.a(py, pz));
    return Collections.unmodifiableMap(localHashMap);
  }
  
  public static int a(MessageDigest paramMessageDigest, byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    String str = paramMessageDigest.getAlg();
    byte[] arrayOfByte;
    if (str.equals("NoDigest"))
    {
      arrayOfByte = new byte[0];
    }
    else
    {
      ir.a locala = (ir.a)pA.get(str);
      if (locala == null) {
        throw new CryptoException();
      }
      arrayOfByte = locala.cQ();
    }
    System.arraycopy(arrayOfByte, 0, paramArrayOfByte2, paramInt3, arrayOfByte.length);
    System.arraycopy(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt3 + arrayOfByte.length, paramInt2);
    return arrayOfByte.length + paramInt2;
  }
  
  private static boolean b(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2)
  {
    return ja.e(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, 0, paramArrayOfByte2.length);
  }
  
  public static int a(byte[] paramArrayOfByte, int paramInt1, int paramInt2, MessageDigest paramMessageDigest)
    throws SignatureException
  {
    int i = paramInt2 - paramMessageDigest.getDigestSize();
    String str = paramMessageDigest.getAlg();
    ir.a locala = (ir.a)pA.get(str);
    if (locala == null) {
      return paramInt1;
    }
    if ((i > 0) && ((b(paramArrayOfByte, paramInt1, i, locala.cQ())) || (b(paramArrayOfByte, paramInt1, i, locala.cR())))) {
      return paramInt1 + i;
    }
    throw new SignatureException("Signature verify failed.");
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ir
 * JD-Core Version:    0.7.0.1
 */