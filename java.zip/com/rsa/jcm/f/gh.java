package com.rsa.jcm.f;

import java.io.Serializable;

public class gh
  implements Serializable
{
  private ge lY;
  
  public gh(ge paramge)
  {
    this.lY = paramge;
  }
  
  public gi bk()
  {
    return new gi(this.lY);
  }
  
  public gi a(gl paramgl1, gl paramgl2)
  {
    return new gi(this.lY, paramgl1, paramgl2);
  }
  
  public gi a(gl paramgl1, gl paramgl2, gl paramgl3)
  {
    return new gi(this.lY, paramgl1, paramgl2, paramgl3);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gh
 * JD-Core Version:    0.7.0.1
 */