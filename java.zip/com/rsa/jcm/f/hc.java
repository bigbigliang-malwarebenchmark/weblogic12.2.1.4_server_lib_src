package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import java.util.Arrays;

public class hc
  implements gk
{
  private final hc.a nb;
  private final int nc;
  private final int nd;
  private final int ne;
  private final int nf;
  private final int ng;
  private final int nh;
  private final ic ni;
  private final int[] nj;
  private final int[][] nk;
  private final int nl;
  private final gf nm;
  private final hb nn;
  private final hb no;
  
  hc(int paramInt)
  {
    this(paramInt, true);
  }
  
  hc(int paramInt, boolean paramBoolean)
  {
    this(hc.a.ns, paramInt, 0, 0, 0, paramBoolean);
  }
  
  hc(int paramInt1, int paramInt2)
  {
    this(paramInt1, paramInt2, false);
  }
  
  hc(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    this(hc.a.nt, paramInt1, paramInt2, 0, 0, paramBoolean);
  }
  
  hc(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this(paramInt1, paramInt2, paramInt3, paramInt4, true);
  }
  
  hc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    this(hc.a.nu, paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean);
  }
  
  private hc(hc.a parama, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    this.nc = paramInt1;
    this.nd = gn.r(this.nc);
    this.ne = gn.s(this.nc);
    this.nb = parama;
    if (this.nb == hc.a.nu)
    {
      int[] arrayOfInt = { paramInt2, paramInt3, paramInt4 };
      Arrays.sort(arrayOfInt);
      this.nf = arrayOfInt[0];
      this.ng = arrayOfInt[1];
      this.nh = arrayOfInt[2];
    }
    else
    {
      this.nf = paramInt2;
      this.ng = paramInt3;
      this.nh = paramInt4;
    }
    this.no = new hb(this, true);
    this.nn = new hb(this);
    this.nm = (paramBoolean ? new gt(this) : new gs(this));
    this.ni = cl();
    this.nl = cp();
    this.nk = hd.a(this);
    this.nj = (this.nb == hc.a.ns ? he.b(this) : null);
    if ((!this.nb.equals(hc.a.ns)) && (!cb())) {
      throw new CryptoException("Using an invalid Elliptic Curve: reduction polynomial is not irreducible.");
    }
  }
  
  private boolean cb()
  {
    if (this.nb.equals(hc.a.nt))
    {
      if (((this.nc == 233) && (this.nf == 74)) || ((this.nc == 409) && (this.nf == 87)) || ((this.nc == 113) && (this.nf == 9)) || ((this.nc == 193) && (this.nf == 15)) || ((this.nc == 239) && (this.nf == 36)) || ((this.nc == 239) && (this.nf == 158))) {
        return true;
      }
    }
    else if ((this.nb.equals(hc.a.nu)) && (((this.nc == 163) && (this.nf == 3) && (this.ng == 6) && (this.nh == 7)) || ((this.nc == 283) && (this.nf == 5) && (this.ng == 7) && (this.nh == 12)) || ((this.nc == 571) && (this.nf == 2) && (this.ng == 5) && (this.nh == 10)) || ((this.nc == 131) && (this.nf == 2) && (this.ng == 3) && (this.nh == 8)))) {
      return true;
    }
    ic localic = ic.cL();
    localic.i(1, 1);
    gy localgy = (gy)bf().a(localic);
    for (int i = 1; i < this.nc / 2; i++)
    {
      localgy = (gy)localgy.bT();
      if (!localgy.ca()) {
        return false;
      }
    }
    return true;
  }
  
  public int getType()
  {
    return 1;
  }
  
  public int getFieldSize()
  {
    return this.nc;
  }
  
  public int bO()
  {
    return this.nd;
  }
  
  public int cc()
  {
    return this.ne;
  }
  
  public int[] cd()
  {
    if (this.nb == hc.a.nt) {
      return new int[] { this.nf };
    }
    if (this.nb == hc.a.nu) {
      return new int[] { this.nf, this.ng, this.nh };
    }
    return null;
  }
  
  public int[] ce()
  {
    if (this.nb == hc.a.nt) {
      return new int[] { this.nf };
    }
    if (this.nb == hc.a.nu) {
      return new int[] { this.nh, this.ng, this.nf };
    }
    return null;
  }
  
  public int cf()
  {
    return this.nf;
  }
  
  public int cg()
  {
    return this.ng;
  }
  
  public int ch()
  {
    return this.nh;
  }
  
  public gf bP()
  {
    return this.nm;
  }
  
  public hc.a ci()
  {
    return this.nb;
  }
  
  public gm bf()
  {
    return this.nn;
  }
  
  public gm cj()
  {
    return this.no;
  }
  
  public gh b(ge paramge)
  {
    return new gh(paramge);
  }
  
  public ic ck()
  {
    return (ic)this.ni.clone();
  }
  
  private ic cl()
  {
    if (ci() == hc.a.ns) {
      return hg.d(this);
    }
    ic localic = ic.cL();
    localic.i(0, 1);
    localic.i(getFieldSize(), 1);
    if (ci() == hc.a.nt)
    {
      localic.i(cf(), 1);
    }
    else if (ci() == hc.a.nu)
    {
      localic.i(cf(), 1);
      localic.i(cg(), 1);
      localic.i(ch(), 1);
    }
    return localic;
  }
  
  public int[] cm()
  {
    return this.nj;
  }
  
  public int[][] cn()
  {
    return this.nk;
  }
  
  public int co()
  {
    return this.nl;
  }
  
  private int cp()
  {
    int i = this.nc / 4;
    int j = i * 4;
    return (2 * this.nc - 1 - j) / 4;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof hc)) {
      return false;
    }
    hc localhc = (hc)paramObject;
    return (this.nc == localhc.nc) && (this.nf == localhc.nf) && (this.ng == localhc.ng) && (this.nh == localhc.nh) && (this.nb == localhc.nb);
  }
  
  public int hashCode()
  {
    return this.nf ^ this.ng ^ this.nh ^ this.nc ^ this.nb.hashCode();
  }
  
  public static hc a(int paramInt, int[] paramArrayOfInt)
  {
    if (paramArrayOfInt == null) {
      return new hc(paramInt);
    }
    if (paramArrayOfInt.length == 1) {
      return new hc(paramInt, paramArrayOfInt[0]);
    }
    if (paramArrayOfInt.length == 3) {
      return new hc(paramInt, paramArrayOfInt[0], paramArrayOfInt[1], paramArrayOfInt[2]);
    }
    return new hc(paramInt);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hc
 * JD-Core Version:    0.7.0.1
 */