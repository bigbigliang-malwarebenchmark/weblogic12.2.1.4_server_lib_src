package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.MessageDigest;
import com.rsa.crypto.SecureRandom;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public final class da
{
  private static final String d = "Invalid use of the FIPS140 security level APIs";
  private static SecureRandom hz;
  private static SecureRandom hA;
  private static final int hB = 64;
  private static final String TRUE = "true";
  private static final String hC = "com.rsa.jcm.testmode";
  private static int hD = 1;
  private static String hE = System.getProperty("com.rsa.jcm.testmode");
  private static List<String> hF = new ArrayList();
  
  public static void a(List<String> paramList)
  {
    hF = paramList == null ? new ArrayList() : paramList;
  }
  
  public static List<String> getAdditionalAlgorithms()
  {
    return hF;
  }
  
  public static boolean aj()
  {
    return (hE != null) && (hE.equals("true"));
  }
  
  public static void j(int paramInt)
  {
    if ((paramInt != 1) && (paramInt != 2)) {
      throw new CryptoException("Invalid Security Level specified");
    }
    hD = paramInt;
  }
  
  public static int getSecurityLevel()
  {
    return hD;
  }
  
  public static byte[][] initFIPS140RolePINs(Calendar paramCalendar1, Calendar paramCalendar2, File paramFile)
    throws CryptoException
  {
    a(paramCalendar1, paramCalendar2, paramFile, null, 10);
    byte[][] arrayOfByte = new byte[2][64];
    ak().nextBytes(arrayOfByte[0]);
    ak().nextBytes(arrayOfByte[1]);
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(a(arrayOfByte[0], paramCalendar1, 10));
    localArrayList.add(a(arrayOfByte[1], paramCalendar2, 11));
    df localdf = new df(localArrayList);
    localdf.b(paramFile);
    return arrayOfByte;
  }
  
  public static byte[] resetFIPS140RolePIN(byte[] paramArrayOfByte, int paramInt, Calendar paramCalendar, File paramFile)
    throws CryptoException
  {
    byte[] arrayOfByte = new byte[64];
    ak().nextBytes(arrayOfByte);
    setFIPS140RolePIN(paramArrayOfByte, paramInt, arrayOfByte, paramCalendar, paramFile);
    return arrayOfByte;
  }
  
  public static void setFIPS140RolePIN(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2, Calendar paramCalendar, File paramFile)
  {
    if ((paramArrayOfByte2 == null) || (paramArrayOfByte2.length != 64)) {
      throw new CryptoException("Invalid use of the FIPS140 security level APIs");
    }
    df localdf1 = a(paramCalendar, null, paramFile, paramArrayOfByte1, paramInt);
    de localde1 = a(paramArrayOfByte2, paramCalendar, paramInt);
    List localList = localdf1.as();
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < localList.size(); i++)
    {
      de localde2 = (de)localList.get(i);
      if (localde2.getValue() == paramInt)
      {
        byte[] arrayOfByte = b(localde2.getSalt(), paramArrayOfByte2);
        if (Arrays.equals(localde2.ap(), arrayOfByte)) {
          throw new CryptoException("Invalid use of the FIPS140 security level APIs");
        }
        localArrayList.add(localde1);
      }
      else
      {
        localArrayList.add(localde2);
      }
    }
    df localdf2 = new df(localArrayList);
    localdf2.b(paramFile);
  }
  
  public static void a(byte[] paramArrayOfByte, int paramInt, File paramFile)
    throws CryptoException
  {
    if (getSecurityLevel() != 2) {
      throw new CryptoException("Invalid use of the FIPS140 security level APIs");
    }
    if (paramArrayOfByte == null) {
      throw new CryptoException("Invalid use of the FIPS140 security level APIs");
    }
    df localdf = dd.a(paramFile);
    List localList = localdf.as();
    for (int i = 0; i < localList.size(); i++)
    {
      de localde = (de)localList.get(i);
      if (localde.getValue() == paramInt)
      {
        byte[] arrayOfByte = b(localde.getSalt(), paramArrayOfByte);
        if (!Arrays.equals(localde.ap(), arrayOfByte)) {
          throw new CryptoException("Invalid use of the FIPS140 security level APIs");
        }
        a(localde.aq());
        return;
      }
    }
  }
  
  private static void a(Calendar paramCalendar)
  {
    if (paramCalendar != null)
    {
      Calendar localCalendar = Calendar.getInstance();
      if (localCalendar.after(paramCalendar)) {
        throw new CryptoException("Invalid use of the FIPS140 security level APIs");
      }
    }
  }
  
  private static de a(byte[] paramArrayOfByte, Calendar paramCalendar, int paramInt)
  {
    byte[] arrayOfByte = new byte[64];
    al().nextBytes(arrayOfByte);
    return de.a(paramInt, arrayOfByte, b(arrayOfByte, paramArrayOfByte), paramCalendar);
  }
  
  private static df a(Calendar paramCalendar1, Calendar paramCalendar2, File paramFile, byte[] paramArrayOfByte, int paramInt)
  {
    df localdf = null;
    Calendar localCalendar = Calendar.getInstance();
    if ((getSecurityLevel() == 1) || ((paramInt != 10) && (paramInt != 11))) {
      throw new CryptoException("Invalid use of the FIPS140 security level APIs");
    }
    if (((paramCalendar1 != null) && (localCalendar.after(paramCalendar1))) || ((paramCalendar2 != null) && (localCalendar.after(paramCalendar2)))) {
      throw new CryptoException("Invalid use of the FIPS140 security level APIs");
    }
    if (paramFile == null) {
      throw new CryptoException("Invalid use of the FIPS140 security level APIs");
    }
    if (paramArrayOfByte != null) {
      try
      {
        if (!paramFile.exists()) {
          throw new CryptoException("Invalid use of the FIPS140 security level APIs");
        }
        localdf = dd.a(paramFile);
        de localde = localdf.at();
        byte[] arrayOfByte = b(localde.getSalt(), paramArrayOfByte);
        if (!Arrays.equals(localde.ap(), arrayOfByte)) {
          throw new CryptoException("Invalid use of the FIPS140 security level APIs");
        }
        a(localde.aq());
      }
      catch (CryptoException localCryptoException)
      {
        throw new CryptoException(localCryptoException);
      }
    } else {
      try
      {
        if (!paramFile.createNewFile()) {
          throw new CryptoException("Invalid use of the FIPS140 security level APIs");
        }
      }
      catch (IOException localIOException)
      {
        throw new CryptoException(localIOException);
      }
    }
    return localdf;
  }
  
  private static byte[] b(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    ca localca = new ca(null);
    try
    {
      localca.update(paramArrayOfByte1, 0, paramArrayOfByte1.length);
      localca.update(paramArrayOfByte2, 0, paramArrayOfByte2.length);
      byte[] arrayOfByte1 = new byte[64];
      localca.digest(arrayOfByte1, 0);
      byte[] arrayOfByte2 = arrayOfByte1;
      return arrayOfByte2;
    }
    finally
    {
      localca.clearSensitiveData();
    }
  }
  
  private static synchronized SecureRandom ak()
  {
    if (hz == null) {
      hz = new cr(null, 128, new by(null));
    }
    return hz;
  }
  
  private static synchronized SecureRandom al()
  {
    if (hA == null) {
      hA = new cr(null, 128, new by(null));
    }
    return hA;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.da
 * JD-Core Version:    0.7.0.1
 */