package com.rsa.jcm.f;

import com.rsa.crypto.SecretKey;
import java.util.Arrays;

public class di
  extends cl
  implements SecretKey
{
  protected byte[] gd;
  protected String fB;
  
  public di(ke paramke, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this(paramke, paramArrayOfByte, paramInt1, paramInt2, "");
  }
  
  public di(ke paramke, byte[] paramArrayOfByte, int paramInt1, int paramInt2, String paramString)
  {
    super(paramke);
    this.gd = (paramArrayOfByte == null ? null : Arrays.copyOfRange(paramArrayOfByte, paramInt1, paramInt1 + paramInt2));
    this.fB = paramString;
  }
  
  public byte[] getKeyData()
  {
    return es.x(this.gd);
  }
  
  public String getAlg()
  {
    return this.fB;
  }
  
  public void clearSensitiveData()
  {
    er.w(this.gd);
    this.fB = null;
  }
  
  public Object clone()
  {
    di localdi = (di)super.clone();
    localdi.gd = es.x(this.gd);
    return localdi;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.di
 * JD-Core Version:    0.7.0.1
 */