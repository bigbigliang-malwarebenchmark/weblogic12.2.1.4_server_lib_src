package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;

class hk
  implements gf
{
  public static final String nJ = "Operation not supported for this type of ECPoint.";
  hu nI;
  
  hk(hu paramhu)
  {
    this.nI = paramhu;
  }
  
  public boolean b(gi paramgi)
  {
    throw new CryptoException("Operation not supported for this type of ECPoint.");
  }
  
  public boolean a(gi paramgi, boolean paramBoolean)
  {
    throw new CryptoException("Operation not supported for this type of ECPoint.");
  }
  
  public gi a(gi paramgi1, gi paramgi2)
  {
    throw new CryptoException("Operation not supported for this type of ECPoint.");
  }
  
  public gi c(gi paramgi)
  {
    throw new CryptoException("Operation not supported for this type of ECPoint.");
  }
  
  public gi d(gi paramgi)
  {
    throw new CryptoException("Operation not supported for this type of ECPoint.");
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hk
 * JD-Core Version:    0.7.0.1
 */