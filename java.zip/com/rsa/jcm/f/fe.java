package com.rsa.jcm.f;

import com.rsa.crypto.BigNum;
import com.rsa.crypto.ECParams;
import com.rsa.crypto.ECPrivateKey;

public class fe
  extends cl
  implements ECPrivateKey
{
  private final ECParams ki;
  private final BigNum kj;
  
  public fe(ke paramke, BigNum paramBigNum, ECParams paramECParams)
  {
    super(paramke);
    this.kj = paramBigNum;
    this.ki = paramECParams;
  }
  
  public fe(ke paramke, byte[] paramArrayOfByte, ECParams paramECParams)
  {
    this(paramke, new id(paramArrayOfByte), paramECParams);
  }
  
  public BigNum getD()
  {
    return this.kj;
  }
  
  public boolean isValid()
  {
    return ft.b(this);
  }
  
  public ECParams getParams()
  {
    return this.ki;
  }
  
  public void clearSensitiveData()
  {
    er.a((id)this.kj);
  }
  
  public String getAlg()
  {
    return "EC";
  }
  
  public Object clone()
  {
    return new fe(this.an, (id)es.a((id)this.kj), this.ki);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fe
 * JD-Core Version:    0.7.0.1
 */