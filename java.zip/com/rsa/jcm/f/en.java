package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.Cipher;
import com.rsa.crypto.CryptoModule;
import com.rsa.crypto.KeyBuilder;
import com.rsa.crypto.SecretKey;
import com.rsa.crypto.SymmCipher;

abstract class en
  extends ei
{
  private en.a[] jv;
  
  static AlgInputParams v(byte[] paramArrayOfByte)
  {
    ii localii = new ii(null);
    localii.set("iv", paramArrayOfByte);
    return localii;
  }
  
  en(en.a[] paramArrayOfa)
  {
    super(paramArrayOfa.length);
    this.jv = paramArrayOfa;
  }
  
  public boolean test(int paramInt)
    throws Exception
  {
    return a(this.jv[paramInt]);
  }
  
  private boolean a(en.a parama)
  {
    byte[] arrayOfByte = parama.gd == null ? new byte[parama.jw] : parama.gd;
    AlgInputParams localAlgInputParams = parama.jx;
    SymmCipher localSymmCipher = this.ip.newSymmetricCipher(parama.algorithm);
    SecretKey localSecretKey = this.ip.getKeyBuilder().newSecretKey(arrayOfByte, 0, arrayOfByte.length);
    try
    {
      boolean bool = (a(1, localSecretKey, localSymmCipher, localAlgInputParams, parama.jy, parama.jz, parama.jA)) && (a(2, localSecretKey, localSymmCipher, localAlgInputParams, parama.jz, parama.jy, parama.jA));
      return bool;
    }
    finally
    {
      localSymmCipher.clearSensitiveData();
      localSecretKey.clearSensitiveData();
    }
  }
  
  private boolean a(int paramInt, SecretKey paramSecretKey, Cipher paramCipher, AlgorithmParams paramAlgorithmParams, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    byte[] arrayOfByte = new byte[paramCipher.getOutputSize(paramArrayOfByte1.length)];
    paramCipher.init(paramInt, paramSecretKey, paramAlgorithmParams, null);
    if (paramArrayOfByte3 != null) {
      paramCipher.updateAAD(paramArrayOfByte3, 0, paramArrayOfByte3.length);
    }
    int i = paramCipher.update(paramArrayOfByte1, 0, paramArrayOfByte1.length, arrayOfByte, 0);
    i += paramCipher.doFinal(arrayOfByte, i);
    return ja.f(paramArrayOfByte2, 0, paramArrayOfByte2.length, arrayOfByte, 0, i);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.en
 * JD-Core Version:    0.7.0.1
 */