package com.rsa.jcm.f;

class gv
  extends gy
{
  gv(hc paramhc, ic paramic)
  {
    super(paramhc, paramic);
    this.mT = paramhc.cj();
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gv
 * JD-Core Version:    0.7.0.1
 */