package com.rsa.jcm.f;

import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.CryptoException;
import com.rsa.crypto.InvalidKeyException;
import com.rsa.crypto.KeyPair;
import com.rsa.crypto.PrivateKey;
import com.rsa.crypto.PublicKey;
import com.rsa.crypto.SecureRandom;

public class fu
  implements KeyPair
{
  private final String fB;
  private PrivateKey ju;
  private PublicKey jt;
  
  public fu(String paramString, PrivateKey paramPrivateKey, PublicKey paramPublicKey)
  {
    this.fB = paramString;
    this.ju = paramPrivateKey;
    this.jt = paramPublicKey;
  }
  
  public String getAlgorithm()
  {
    return this.fB;
  }
  
  public PrivateKey getPrivate()
  {
    return this.ju;
  }
  
  public PublicKey getPublic()
  {
    return this.jt;
  }
  
  public void validate(SecureRandom paramSecureRandom)
    throws InvalidKeyException
  {
    validate(null, paramSecureRandom);
  }
  
  public void validate(AlgorithmParams paramAlgorithmParams, SecureRandom paramSecureRandom)
    throws InvalidKeyException
  {
    try
    {
      c(this, paramSecureRandom);
    }
    catch (SecurityException localSecurityException)
    {
      throw new InvalidKeyException("Pairwise consistency test of key pair failed.");
    }
    fv.d(getAlgorithm()).a(paramAlgorithmParams, this, paramSecureRandom);
  }
  
  public static void c(KeyPair paramKeyPair, SecureRandom paramSecureRandom)
  {
    dh.a(paramKeyPair, paramSecureRandom);
  }
  
  public void clearSensitiveData()
  {
    this.jt.clearSensitiveData();
    this.ju.clearSensitiveData();
  }
  
  public Object clone()
  {
    fu localfu;
    try
    {
      localfu = (fu)super.clone();
      localfu.ju = ((PrivateKey)es.a(this.ju));
      localfu.jt = ((PublicKey)es.a(this.jt));
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new CryptoException("Object.clone() unexpectedly threw CloneNotSupportedException.");
    }
    return localfu;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fu
 * JD-Core Version:    0.7.0.1
 */