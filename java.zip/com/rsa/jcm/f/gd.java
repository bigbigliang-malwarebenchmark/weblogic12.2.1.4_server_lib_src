package com.rsa.jcm.f;

public enum gd
{
  PRIME_WEIERSTRASS,  F2M,  PRIME_MONTGOMERY,  PRIME_EDWARDS;
  
  private gd() {}
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gd
 * JD-Core Version:    0.7.0.1
 */