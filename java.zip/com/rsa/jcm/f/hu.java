package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import java.util.Arrays;

public class hu
  implements gk
{
  static final int nY = 0;
  static final int nZ = 192;
  static final int oa = 224;
  static final int ob = 256;
  static final int oc = 384;
  static final int od = 521;
  private final id nM;
  private final int oe;
  private final int nd;
  private final hn of;
  private final int og;
  private final gf nm;
  private final hm oh;
  private final int nK;
  
  hu(id paramid)
  {
    this(paramid, true);
  }
  
  hu(id paramid, boolean paramBoolean)
  {
    this(paramid, paramBoolean, gd.PRIME_WEIERSTRASS);
  }
  
  hu(id paramid, boolean paramBoolean, gd paramgd)
  {
    this.nM = ((id)paramid.clone());
    this.nK = cx();
    this.oe = paramid.getBitLength();
    this.nd = gn.r(this.oe);
    this.oh = new hm(this);
    if (paramgd == gd.PRIME_MONTGOMERY)
    {
      if (paramBoolean) {
        throw new CryptoException("not supported");
      }
      this.nm = new hk(this);
    }
    else
    {
      this.nm = (paramBoolean ? new hl(this) : new hj(this));
    }
    id localid1 = id.oq;
    id localid2 = new id();
    paramid.g(localid1, localid2);
    this.of = ((hn)bf().j(localid2));
    this.og = (cz() ? 0 : this.nM.cN());
  }
  
  private int cx()
  {
    byte[] arrayOfByte = this.nM.toOctetString();
    if (Arrays.equals(arrayOfByte, z(192))) {
      return 192;
    }
    if (Arrays.equals(arrayOfByte, z(224))) {
      return 224;
    }
    if (Arrays.equals(arrayOfByte, z(256))) {
      return 256;
    }
    if (Arrays.equals(arrayOfByte, z(384))) {
      return 384;
    }
    if (Arrays.equals(arrayOfByte, z(521))) {
      return 521;
    }
    return 0;
  }
  
  private byte[] z(int paramInt)
  {
    switch (paramInt)
    {
    case 192: 
      return jb.hexStringToByteArray("fffffffffffffffffffffffffffffffeffffffffffffffff");
    case 224: 
      return jb.hexStringToByteArray("ffffffffffffffffffffffffffffffff000000000000000000000001");
    case 256: 
      return jb.hexStringToByteArray("ffffffff00000001000000000000000000000000ffffffffffffffffffffffff");
    case 384: 
      return jb.hexStringToByteArray("fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffeffffffff0000000000000000ffffffff");
    case 521: 
      return jb.hexStringToByteArray("01ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
    }
    return new byte[0];
  }
  
  int cy()
  {
    return this.nK;
  }
  
  private boolean cz()
  {
    return this.nK != 0;
  }
  
  public int getType()
  {
    return 0;
  }
  
  public int getFieldSize()
  {
    return this.oe;
  }
  
  public int bO()
  {
    return this.nd;
  }
  
  public id cA()
  {
    return this.nM;
  }
  
  public hn cB()
  {
    return this.of;
  }
  
  public int cC()
  {
    return this.og;
  }
  
  public gf bP()
  {
    return this.nm;
  }
  
  public gm bf()
  {
    return this.oh;
  }
  
  public gh b(ge paramge)
  {
    return new gh(paramge);
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof hu)) {
      return false;
    }
    hu localhu = (hu)paramObject;
    return this.nM.equals(localhu.nM);
  }
  
  public int hashCode()
  {
    return this.nM.hashCode();
  }
  
  public static hu a(id paramid, boolean paramBoolean, gd paramgd)
  {
    return new hu(paramid, paramBoolean, paramgd);
  }
  
  public static hu o(id paramid)
  {
    return new hu(paramid);
  }
  
  public static hu a(boolean paramBoolean, id paramid)
  {
    return new hu(paramid, paramBoolean);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hu
 * JD-Core Version:    0.7.0.1
 */