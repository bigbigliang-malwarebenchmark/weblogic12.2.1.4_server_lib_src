package com.rsa.jcm.f;

import com.rsa.crypto.MAC;
import com.rsa.crypto.SecretKey;

public class ey
  extends ew
{
  private MAC cy;
  
  public ey(ke paramke, MAC paramMAC)
  {
    super(paramke);
    this.cy = paramMAC;
  }
  
  void a(SecretKey paramSecretKey, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    this.cy.init(paramSecretKey);
    a(this.cy, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, 0, paramArrayOfByte3.length);
  }
  
  public void clearSensitiveData()
  {
    this.cy.clearSensitiveData();
  }
  
  public Object clone()
  {
    ey localey = (ey)super.clone();
    localey.cy = ((MAC)es.a(this.cy));
    return localey;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ey
 * JD-Core Version:    0.7.0.1
 */