package com.rsa.jcm.f;

import com.rsa.crypto.ECParams;

public class fn
  extends fm
{
  public fn(ke paramke)
  {
    super(paramke);
  }
  
  protected gi a(gi paramgi)
  {
    gi localgi = paramgi.g(this.kL);
    if (this.ki.getCofactor() == 1) {
      return localgi;
    }
    return localgi.g(new id(this.ki.getCofactor()));
  }
  
  public String getAlg()
  {
    return "ECDHC";
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fn
 * JD-Core Version:    0.7.0.1
 */