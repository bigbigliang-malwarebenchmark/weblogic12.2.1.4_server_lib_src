package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.BadPaddingException;
import com.rsa.crypto.CryptoException;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.MessageDigest;
import com.rsa.crypto.SecureRandom;
import com.rsa.crypto.SignatureException;
import java.util.Arrays;

public class iu
  extends g
{
  public static final int pH = 1;
  public static final int pI = 2;
  private static final String pJ = "Cannot perform padding: not enough space";
  private static final String pK = "Digest is not supported with Trailer Field option 2: ";
  private static final String pL = "Cannot perform padding: not enough space for salt";
  private static final byte[] pM = { 0, 0, 0, 0, 0, 0, 0, 0 };
  private MessageDigest pG;
  private ib cm;
  private int pN = -1;
  private byte[] cB;
  private int pO = 1;
  private boolean pP;
  private AlgInputParams jx;
  
  public iu(ke paramke, MessageDigest paramMessageDigest1, MessageDigest paramMessageDigest2)
  {
    super(paramke);
    this.cm = new ia(paramMessageDigest2);
    this.pG = paramMessageDigest1;
  }
  
  public void setAlgorithmParams(AlgorithmParams paramAlgorithmParams)
    throws InvalidAlgorithmParameterException
  {
    if (paramAlgorithmParams == null) {
      return;
    }
    if (!(paramAlgorithmParams instanceof AlgInputParams)) {
      throw new InvalidAlgorithmParameterException("Parameters object invalid for algorithm.");
    }
    this.jx = ((AlgInputParams)paramAlgorithmParams);
    this.pO = ij.a(this.jx, "tfOption", 1);
    this.cB = ij.b(this.jx, "salt", null);
    if (this.cB != null) {
      this.pN = this.cB.length;
    } else {
      this.pN = ij.a(this.jx, "saltLen", this.pG.getDigestSize());
    }
    this.pP = ij.a(this.jx, "userSpecified", false);
  }
  
  private byte[] B(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws SignatureException
  {
    byte[] arrayOfByte1 = new byte[this.K];
    int i = this.K * 8 - 1;
    int j = this.K;
    if (this.pN < 0) {
      this.pN = paramInt2;
    }
    if (j < paramInt2 + this.pO + 1) {
      throw new SignatureException("Cannot perform padding: not enough space");
    }
    if (j - paramInt2 - this.pO - 1 < this.pN)
    {
      if (this.pP) {
        throw new SignatureException("Cannot perform padding: not enough space for salt");
      }
      this.pN = 0;
      if (this.jx != null) {
        this.jx.set("saltLen", Integer.valueOf(this.pN));
      }
    }
    if ((this.cB == null) || (!this.pP))
    {
      byte[] arrayOfByte2 = new byte[this.pN];
      this.M.nextBytes(arrayOfByte2);
      B(arrayOfByte2);
    }
    try
    {
      this.pG.reset();
      this.pG.update(pM, 0, pM.length);
      this.pG.update(paramArrayOfByte, paramInt1, paramInt2);
      this.pG.update(this.cB, 0, this.pN);
      this.pG.digest(paramArrayOfByte, paramInt1);
    }
    catch (Exception localException)
    {
      throw new SignatureException("Cannot perform padding: not enough space");
    }
    int k = j - this.pN - paramInt2 - this.pO - 1;
    int m = k + 1 + this.pN;
    byte[] arrayOfByte3 = new byte[m];
    arrayOfByte3[k] = 1;
    System.arraycopy(this.cB, 0, arrayOfByte3, k + 1, this.pN);
    this.cm.d(paramArrayOfByte, paramInt1, paramInt2, arrayOfByte3, 0, m);
    int tmp326_325 = 0;
    byte[] tmp326_323 = arrayOfByte3;
    tmp326_323[tmp326_325] = ((byte)(tmp326_323[tmp326_325] & 255 >> 8 * j - i));
    System.arraycopy(arrayOfByte3, 0, arrayOfByte1, 0, m);
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte1, m, paramInt2);
    if (this.pO == 1)
    {
      arrayOfByte1[(j - 1)] = -68;
    }
    else
    {
      int n;
      if ((this.pG instanceof cd)) {
        n = ((cd)this.pG).R();
      } else {
        throw new SignatureException("Digest is not supported with Trailer Field option 2: " + this.pG.getAlg());
      }
      arrayOfByte1[(j - 2)] = n;
      arrayOfByte1[(j - 1)] = -52;
    }
    return arrayOfByte1;
  }
  
  private void y(byte[] paramArrayOfByte, int paramInt)
    throws SignatureException
  {
    int i = this.K * 8 - 1;
    int j = this.K;
    int k = this.pG.getDigestSize();
    if (this.pO == 1)
    {
      if (paramArrayOfByte[(j - 1)] != -68) {
        throw new SignatureException("Signature verify failed.");
      }
    }
    else
    {
      if (paramArrayOfByte[(j - 1)] != -52) {
        throw new SignatureException("Signature verify failed.");
      }
      if ((this.pG instanceof cd)) {
        m = ((cd)this.pG).R();
      } else {
        m = 51;
      }
      if ((paramArrayOfByte[(j - 2)] != m) && (paramArrayOfByte[(j - 2)] != 51)) {
        throw new SignatureException("Signature verify failed.");
      }
    }
    if (this.pN < 0) {
      ag(k);
    }
    if (j - k - 2 < this.pN)
    {
      if (this.cB != null) {
        throw new SignatureException("Signature verify failed.");
      }
      ag(0);
    }
    int m = j - k - this.pO;
    byte[] arrayOfByte1 = new byte[m];
    System.arraycopy(paramArrayOfByte, paramInt, arrayOfByte1, 0, m);
    int n = (byte)(255 >> 8 * j - i);
    if ((arrayOfByte1[0] | n) != n) {
      throw new SignatureException("Signature verify failed.");
    }
    this.cm.d(paramArrayOfByte, paramInt + m, k, arrayOfByte1, 0, m);
    int tmp277_276 = 0;
    byte[] tmp277_274 = arrayOfByte1;
    tmp277_274[tmp277_276] = ((byte)(tmp277_274[tmp277_276] & 255 >> 8 * j - i));
    for (int i1 = 0; arrayOfByte1[i1] == 0; i1++) {}
    if (arrayOfByte1[i1] != 1) {
      throw new SignatureException("Signature verify failed.");
    }
    int i2 = i1 + 1;
    int i3 = m - i2;
    if ((this.pP) && (i3 != this.pN)) {
      throw new SignatureException("Signature verify failed.");
    }
    ag(i3);
    if (this.pN >= 0)
    {
      int i4 = j - k - this.pO;
      byte[] arrayOfByte2 = Arrays.copyOfRange(arrayOfByte1, i4 - this.pN, i4);
      B(arrayOfByte2);
    }
    System.arraycopy(arrayOfByte1, 0, paramArrayOfByte, 0, m);
  }
  
  private boolean a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2)
    throws SignatureException
  {
    int i;
    byte[] arrayOfByte;
    try
    {
      i = this.pG.getDigestSize();
      arrayOfByte = new byte[i];
      this.pG.reset();
      this.pG.update(pM, 0, pM.length);
      this.pG.update(paramArrayOfByte2, paramInt1, paramInt2);
      this.pG.update(paramArrayOfByte1, this.K - this.pN - i - this.pO, this.pN);
      this.pG.digest(arrayOfByte, 0);
    }
    catch (Exception localException)
    {
      throw new SignatureException("Signature verify failed.");
    }
    return ja.f(paramArrayOfByte1, this.K - this.pO - i, i, arrayOfByte, 0, i);
  }
  
  public int d(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws SignatureException
  {
    byte[] arrayOfByte = B(paramArrayOfByte1, paramInt1, paramInt2);
    try
    {
      return a(arrayOfByte, 0, paramArrayOfByte2, paramInt3);
    }
    catch (CryptoException localCryptoException)
    {
      throw new SignatureException("Signature generation failed: " + localCryptoException.getMessage());
    }
  }
  
  public boolean a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4)
    throws SignatureException
  {
    if (paramInt4 != this.K) {
      return false;
    }
    byte[] arrayOfByte = new byte[this.K];
    try
    {
      c(paramArrayOfByte2, paramInt3, this.K, arrayOfByte, 0);
    }
    catch (BadPaddingException localBadPaddingException)
    {
      return false;
    }
    y(arrayOfByte, 0);
    return a(arrayOfByte, paramArrayOfByte1, paramInt1, paramInt2);
  }
  
  public void clearSensitiveData()
  {
    super.clearSensitiveData();
    er.a(this.pG);
    er.w(this.cB);
    this.pN = 0;
    this.pP = false;
  }
  
  public String getAlg()
  {
    return "RSAPSS/" + this.cm.getAlg();
  }
  
  public int getSignatureSize()
  {
    return getBlockSize();
  }
  
  public Object clone()
  {
    iu localiu = (iu)super.clone();
    localiu.pG = ((MessageDigest)es.a(this.pG));
    localiu.cm = new ia(this.cm.cG());
    localiu.cB = es.x(this.cB);
    return localiu;
  }
  
  private void ag(int paramInt)
  {
    this.pN = paramInt;
    if (this.jx != null) {
      this.jx.set("saltLen", Integer.valueOf(this.pN));
    }
  }
  
  private void B(byte[] paramArrayOfByte)
  {
    this.cB = paramArrayOfByte;
    if (this.jx != null) {
      this.jx.set("salt", this.cB);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.iu
 * JD-Core Version:    0.7.0.1
 */