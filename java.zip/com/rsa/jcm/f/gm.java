package com.rsa.jcm.f;

import java.io.Serializable;

public abstract interface gm
  extends Serializable
{
  public abstract gl bW();
  
  public abstract gl j(id paramid);
  
  public abstract gl a(ic paramic);
  
  public abstract gl s(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  public abstract gl bX();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gm
 * JD-Core Version:    0.7.0.1
 */