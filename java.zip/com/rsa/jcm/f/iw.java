package com.rsa.jcm.f;

import com.rsa.crypto.SignatureException;

public abstract interface iw
  extends d
{
  public abstract int getSignatureSize();
  
  public abstract int d(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws SignatureException;
  
  public abstract boolean a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4)
    throws SignatureException;
  
  public abstract String getAlg();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.iw
 * JD-Core Version:    0.7.0.1
 */