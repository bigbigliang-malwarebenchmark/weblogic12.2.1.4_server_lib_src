package com.rsa.jcm.f;

public class hp
  extends hn
{
  private static final int nQ = 3;
  private static final int nR = 7;
  private static final int nS = 11;
  private static final int nT = 14;
  private static final int nO = 7;
  private static final long nP = 4294967295L;
  private static final int nU = -1;
  
  hp(gk paramgk)
  {
    super(paramgk);
  }
  
  hp(gk paramgk, id paramid)
  {
    super(paramgk, paramid);
  }
  
  public void l(id paramid)
  {
    int[] arrayOfInt = paramid.toIntArray();
    int i = arrayOfInt.length;
    if (i <= 7)
    {
      if (i == 7)
      {
        m = paramid.q(this.nM);
        switch (m)
        {
        case 0: 
          paramid.setValue(0);
          return;
        case -1: 
          return;
        }
        paramid.t(this.nM);
        return;
      }
      return;
    }
    int m = 7;
    int n = 11;
    int i1 = i < 14 ? i : 14;
    int i2 = 0;
    int k = 0;
    int j;
    while (n < i1)
    {
      j = arrayOfInt[m] + k;
      if ((0xFFFFFFFF & j) >= (0xFFFFFFFF & k)) {
        k = 0;
      }
      arrayOfInt[m] = (j + arrayOfInt[n]);
      if ((0xFFFFFFFF & arrayOfInt[m]) < (0xFFFFFFFF & j)) {
        k = 1;
      }
      m++;
      n++;
    }
    while ((m < 14) && (k != 0))
    {
      arrayOfInt[m] += 1;
      if (arrayOfInt[(m++)] != 0) {
        k = 0;
      }
    }
    i2 += k;
    if (i2 == 1) {
      i2 = -1;
    }
    m = 3;
    n = 7;
    i1 = 11;
    if ((0xFFFFFFFF & i) < (0xFFFFFFFF & i1)) {
      i1 = i;
    }
    k = 0;
    while (n < i1)
    {
      j = arrayOfInt[m] + k;
      if ((0xFFFFFFFF & j) >= (0xFFFFFFFF & k)) {
        k = 0;
      }
      arrayOfInt[m] = (j + arrayOfInt[n]);
      if ((0xFFFFFFFF & arrayOfInt[m]) < (0xFFFFFFFF & j)) {
        k = 1;
      }
      m++;
      n++;
    }
    while ((m < 7) && (k != 0))
    {
      arrayOfInt[m] += 1;
      if (arrayOfInt[(m++)] != 0) {
        k = 0;
      }
    }
    i2 += k;
    m = 0;
    n = 7;
    i1 = 14;
    if (i < i1) {
      i1 = i;
    }
    k = 0;
    while (n < i1)
    {
      j = arrayOfInt[n] + k;
      if ((0xFFFFFFFF & j) >= (0xFFFFFFFF & k))
      {
        k = 0;
        if ((0xFFFFFFFF & arrayOfInt[m]) < (0xFFFFFFFF & j)) {
          k = 1;
        }
        arrayOfInt[m] -= j;
      }
      m++;
      n++;
    }
    while ((m < 7) && (k != 0))
    {
      arrayOfInt[m] -= 1;
      if (arrayOfInt[(m++)] != -1) {
        k = 0;
      }
    }
    i2 -= k;
    if (i2 == -1)
    {
      paramid.a(arrayOfInt, 7);
      paramid.s(this.nM);
      paramid.i(224, 0);
      return;
    }
    if (i2 > 0)
    {
      if ((0xFFFFFFFF & arrayOfInt[0]) >= (0xFFFFFFFF & i2))
      {
        arrayOfInt[0] -= i2;
      }
      else
      {
        arrayOfInt[0] -= i2;
        m = 1;
        arrayOfInt[m] -= 1;
        while (arrayOfInt[m] == -1) {
          arrayOfInt[(++m)] -= 1;
        }
      }
      arrayOfInt[3] += i2;
      if ((0xFFFFFFFF & arrayOfInt[3]) < (0xFFFFFFFF & i2))
      {
        m = 4;
        arrayOfInt[m] += 1;
        while (arrayOfInt[m] == 0) {
          arrayOfInt[(++m)] += 1;
        }
      }
    }
    paramid.a(arrayOfInt, 7);
    if (paramid.q(this.nM) >= 0) {
      paramid.t(this.nM);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hp
 * JD-Core Version:    0.7.0.1
 */