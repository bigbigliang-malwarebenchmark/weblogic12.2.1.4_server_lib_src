package com.rsa.jcm.f;

public class hv
  implements hw
{
  private boolean oi;
  
  public hv(boolean paramBoolean)
  {
    this.oi = paramBoolean;
  }
  
  public gi a(gi paramgi, id paramid)
  {
    if (paramgi.isInfinite()) {
      return paramgi;
    }
    if (paramid.isZero()) {
      return paramgi.aS().bg().bk();
    }
    id localid1;
    if (this.oi)
    {
      localid1 = new id();
      paramid.j(paramgi.aS().be(), localid1);
    }
    else
    {
      localid1 = (id)paramid.clone();
    }
    if (localid1.isZero()) {
      return paramgi.aS().bg().bk();
    }
    id localid2 = new id();
    id localid3 = new id();
    localid1.f(localid1, localid2);
    localid2.f(localid1, localid3);
    gi localgi1 = paramgi.bA();
    gi localgi2 = (gi)paramgi.clone();
    gi localgi3 = (gi)paramgi.clone();
    int i = localid3.getBitLength();
    try
    {
      for (int j = i - 2; j > 0; j--)
      {
        gi localgi5 = localgi3;
        localgi3 = localgi5.bz();
        localgi5.clearSensitiveData();
        if ((localid3.testBit(j)) && (!localid1.testBit(j)))
        {
          localgi5 = localgi3;
          localgi3 = localgi5.f(localgi2);
          localgi5.clearSensitiveData();
        }
        if ((!localid3.testBit(j)) && (localid1.testBit(j)))
        {
          localgi5 = localgi3;
          localgi3 = localgi5.f(localgi1);
          localgi5.clearSensitiveData();
        }
      }
      gi localgi4 = localgi3;
      return localgi4;
    }
    finally
    {
      er.a(localid1);
      er.a(localid2);
      er.a(localid3);
      er.a(localgi1);
      er.a(localgi2);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hv
 * JD-Core Version:    0.7.0.1
 */