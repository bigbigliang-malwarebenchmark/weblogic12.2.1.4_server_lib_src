package com.rsa.jcm.f;

import com.rsa.crypto.InvalidAlgorithmParameterException;
import java.io.Serializable;

public class ge
  implements Serializable
{
  private gj lI;
  gi lJ;
  private id lK;
  private int lL;
  private gh lM;
  private boolean lN;
  private byte[] lO;
  private String lP;
  
  public ge(gk paramgk, gl paramgl1, gl paramgl2, byte[] paramArrayOfByte1, String paramString1, gl paramgl3, gl paramgl4, id paramid, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, String paramString2)
    throws InvalidAlgorithmParameterException
  {
    this(new gj(paramgk, paramgl1, paramgl2, paramArrayOfByte1, paramString1), paramgl3, paramgl4, paramid, paramInt1, paramArrayOfByte2, paramString2);
  }
  
  public ge(gk paramgk, gl paramgl1, gl paramgl2, byte[] paramArrayOfByte, String paramString, gl paramgl3, gl paramgl4, id paramid, int paramInt)
    throws InvalidAlgorithmParameterException
  {
    this(new gj(paramgk, paramgl1, paramgl2, paramArrayOfByte, paramString), paramgl3, paramgl4, paramid, paramInt, null, null);
  }
  
  public ge(gj paramgj, gl paramgl1, gl paramgl2, id paramid, int paramInt, byte[] paramArrayOfByte, String paramString)
    throws InvalidAlgorithmParameterException
  {
    this.lI = paramgj;
    this.lM = this.lI.ba().b(this);
    this.lK = paramid;
    this.lL = paramInt;
    this.lJ = bg().a(paramgl1, paramgl2);
    this.lJ.bF();
    this.lO = paramArrayOfByte;
    this.lP = paramString;
    this.lN = (paramArrayOfByte != null);
    if (!(this instanceof go)) {
      this.lJ.bC();
    }
  }
  
  public gk ba()
  {
    return this.lI.ba();
  }
  
  public gj bb()
  {
    return this.lI;
  }
  
  public boolean bc()
  {
    return this.lN;
  }
  
  public gi bd()
  {
    return this.lJ;
  }
  
  public id be()
  {
    return this.lK;
  }
  
  public int getCofactor()
  {
    return this.lL;
  }
  
  public gm bf()
  {
    return this.lI.ba().bf();
  }
  
  public gh bg()
  {
    return this.lM;
  }
  
  public int bh()
  {
    return 2 * this.lI.ba().bO() + 1;
  }
  
  public int hashCode()
  {
    return this.lI.hashCode() ^ this.lJ.hashCode() ^ this.lK.hashCode() ^ this.lL;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == null) {
      return false;
    }
    if (!(paramObject instanceof ge)) {
      return false;
    }
    ge localge = (ge)paramObject;
    return (this.lI.equals(localge.lI)) && (this.lJ.equals(localge.lJ)) && (this.lK.equals(localge.lK)) && (this.lL == localge.lL);
  }
  
  public String getDigest()
  {
    return this.lI.getDigest();
  }
  
  public byte[] getSeed()
  {
    return this.lI.getSeed();
  }
  
  public byte[] getBaseSeed()
  {
    return this.lO;
  }
  
  public String getBaseDigest()
  {
    return this.lP;
  }
  
  public int getVersion()
  {
    if ((bc()) && (this.lI.bK())) {
      return 2;
    }
    if ((bc()) && (!this.lI.bK())) {
      return 3;
    }
    return 1;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ge
 * JD-Core Version:    0.7.0.1
 */