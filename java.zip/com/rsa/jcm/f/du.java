package com.rsa.jcm.f;

public final class du
  extends en
{
  private static final String iA = "AES/ECB/NoPad";
  private static final String iB = "AES/CCM/NoPad";
  private static final String iC = "AES/GCM/NoPad";
  private static final byte[][] iD = { new byte[16], null, jb.hexStringToByteArray("80000000000000000000000000000000"), jb.hexStringToByteArray("3ad78e726c1ec02b7ebfe92b23d9ec34") };
  private static final byte[][] iE = { jb.hexStringToByteArray("9446c37ee46191fbfcae2ddf6b4ccade"), jb.hexStringToByteArray("1000000000000000000000000000000020c1b9fba1996695"), jb.hexStringToByteArray("7167442313c59c04f5d1a3ac04d351c492e42d49fcff103d8a5b2c9c96f84c91"), jb.hexStringToByteArray("742874458c8e0b13ba07887490dd2374c74cca99e7bb3614afc03ef9308e80ac4b3b194b77d9777f98676a3fe8504c03") };
  private static final byte[][] iF = { jb.hexStringToByteArray("00000000000000000000000000000000"), jb.hexStringToByteArray("10000000000000000000000000"), jb.hexStringToByteArray("00000000000000000000000000000000"), jb.hexStringToByteArray("0388dace60b6a392f328c2b971b2fe78ab6e47d42cec13bdf53a67b21257bddf") };
  private static final en.a[] iG = { new en.a("AES/ECB/NoPad", 128, iD[0], null, iD[2], iD[3]), new en.a("AES/CCM/NoPad", 128, iE[0], v(iE[1]), iE[2], iE[3]), new en.a("AES/GCM/NoPad", 128, iF[0], v(iF[1]), iF[2], iF[3]) };
  
  public du()
  {
    super(iG);
  }
  
  public String getName()
  {
    return "AES";
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.du
 * JD-Core Version:    0.7.0.1
 */