package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.MessageDigest;

public final class ia
  implements ib
{
  private MessageDigest cl;
  private byte[] ok = new byte[4];
  private byte[] ol;
  
  public ia(MessageDigest paramMessageDigest)
  {
    a(paramMessageDigest);
  }
  
  public void a(MessageDigest paramMessageDigest)
  {
    this.cl = paramMessageDigest;
    this.ol = new byte[this.cl.getDigestSize()];
  }
  
  public void d(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4)
  {
    try
    {
      int i = this.cl.getDigestSize();
      this.cl.reset();
      int j;
      while (paramInt4 >= i)
      {
        this.cl.update(paramArrayOfByte1, paramInt1, paramInt2);
        this.cl.update(this.ok, 0, this.ok.length);
        this.cl.digest(this.ol, 0);
        j = 0;
        while (j < i)
        {
          int tmp87_85 = paramInt3;
          byte[] tmp87_83 = paramArrayOfByte2;
          tmp87_83[tmp87_85] = ((byte)(tmp87_83[tmp87_85] ^ this.ol[j]));
          j++;
          paramInt3++;
        }
        cF();
        paramInt4 -= i;
      }
      if (paramInt4 > 0)
      {
        this.cl.update(paramArrayOfByte1, paramInt1, paramInt2);
        this.cl.update(this.ok, 0, this.ok.length);
        this.cl.digest(this.ol, 0);
        j = 0;
        while (paramInt4 > 0)
        {
          int tmp185_183 = paramInt3;
          byte[] tmp185_181 = paramArrayOfByte2;
          tmp185_181[tmp185_183] = ((byte)(tmp185_181[tmp185_183] ^ this.ol[j]));
          j++;
          paramInt3++;
          paramInt4--;
        }
      }
    }
    catch (Exception localException)
    {
      throw new CryptoException("Digest error: " + localException.getMessage());
    }
    finally
    {
      er.a(this.cl);
      er.w(this.ol);
      cE();
    }
  }
  
  private void cE()
  {
    this.ok[3] = 0;
  }
  
  private void cF()
  {
    int tmp5_4 = 3;
    byte[] tmp5_1 = this.ok;
    tmp5_1[tmp5_4] = ((byte)(tmp5_1[tmp5_4] + 1));
  }
  
  public String getAlg()
  {
    return "MGF1/" + this.cl.getAlg();
  }
  
  public MessageDigest cG()
  {
    return this.cl;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ia
 * JD-Core Version:    0.7.0.1
 */