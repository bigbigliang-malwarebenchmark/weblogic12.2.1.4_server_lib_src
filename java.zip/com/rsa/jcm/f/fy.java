package com.rsa.jcm.f;

import com.rsa.crypto.InvalidKeyException;
import com.rsa.crypto.SecureRandom;
import com.rsa.crypto.SensitiveData;

public class fy
  implements SensitiveData
{
  private static final String lq = "Invalid public exponent.";
  private static final String lr = "Invalid key pair.";
  private id ls = new id();
  private id lt = new id();
  private id lu = new id();
  
  void h(int paramInt1, int paramInt2)
  {
    if (paramInt1 == 112)
    {
      if (paramInt2 != 2048) {
        throw new InvalidKeyException("Only keySize of 2048 allowed with securityStrength of 112");
      }
    }
    else if (paramInt1 == 128)
    {
      if (paramInt2 != 3072) {
        throw new InvalidKeyException("Only keySize of 3072 allowed with securityStrength of 128");
      }
    }
    else if (paramInt1 != -1) {
      throw new InvalidKeyException("Only security strength 112 and 128 allowed.");
    }
  }
  
  void a(id paramid1, id paramid2, id paramid3, id paramid4, id paramid5)
  {
    if ((paramid1 != null) && (!paramid1.equals(paramid4))) {
      throw new InvalidKeyException("Invalid public exponent.: out of range");
    }
    if (!paramid4.equals(paramid2)) {
      throw new InvalidKeyException("Invalid key pair.");
    }
    if ((paramid4.getBitLength() < 17) || (paramid4.getBitLength() > 256) || (!paramid4.cI())) {
      throw new InvalidKeyException("Invalid public exponent.: out of range");
    }
    if (!paramid5.equals(paramid3)) {
      throw new InvalidKeyException("Invalid key pair.");
    }
  }
  
  void a(int paramInt, id paramid1, id paramid2, id paramid3)
  {
    paramid1.i(paramid2, this.ls);
    if (!this.ls.equals(paramid3)) {
      throw new InvalidKeyException("Invalid key pair.");
    }
    if (paramid3.getBitLength() != paramInt) {
      throw new InvalidKeyException("Invalid key pair.");
    }
  }
  
  void a(int paramInt, id paramid1, id paramid2)
  {
    id localid1 = paramid1.q(paramid2) > 0 ? paramid1 : paramid2;
    id localid2 = localid1 == paramid1 ? paramid2 : paramid1;
    localid1.g(localid2, this.ls);
    if (this.ls.getBitLength() <= paramInt / 2 - 100) {
      throw new InvalidKeyException("Invalid key pair.");
    }
  }
  
  void a(id paramid1, id paramid2, id paramid3, id paramid4, id paramid5, id paramid6)
  {
    this.ls.p(paramid2);
    this.ls.R(1);
    if ((paramid4.q(id.oo) < 1) || (paramid4.q(this.ls) >= 0)) {
      throw new InvalidKeyException("Invalid key pair.");
    }
    this.lt.p(paramid3);
    this.lt.R(1);
    if ((paramid5.q(id.oo) < 1) || (paramid5.q(this.lt) >= 0)) {
      throw new InvalidKeyException("Invalid key pair.");
    }
    if ((paramid6.q(id.oo) < 1) || (paramid6.q(paramid2) >= 0)) {
      throw new InvalidKeyException("Invalid key pair.");
    }
    paramid4.e(paramid1, this.ls, this.lu);
    if (!this.lu.equals(id.oo)) {
      throw new InvalidKeyException("Invalid key pair.");
    }
    paramid5.e(paramid1, this.lt, this.lu);
    if (!this.lu.equals(id.oo)) {
      throw new InvalidKeyException("Invalid key pair.");
    }
    paramid6.e(paramid3, paramid2, this.ls);
    if (!this.ls.equals(id.oo)) {
      throw new InvalidKeyException("Invalid key pair.");
    }
  }
  
  void a(int paramInt, id paramid1, id paramid2, id paramid3, id paramid4)
  {
    this.ls.O(paramInt / 2);
    if (paramid1.q(this.ls) != 1) {
      throw new InvalidKeyException("Invalid key pair.");
    }
    this.ls.p(paramid3);
    this.ls.R(1);
    this.lt.p(paramid4);
    this.lt.R(1);
    this.ls.p(this.lt, this.lu);
    if (this.lu.q(paramid1) < 0) {
      throw new InvalidKeyException("Invalid key pair.");
    }
    paramid1.e(paramid2, this.lu, this.ls);
    if (!this.ls.equals(id.oo)) {
      throw new InvalidKeyException("Invalid key pair.");
    }
  }
  
  void a(int paramInt, id paramid1, id paramid2, SecureRandom paramSecureRandom)
  {
    if (!if.a(0, paramid1, paramSecureRandom, this.ls, this.lt, this.lu)) {
      throw new InvalidKeyException("Invalid key pair.");
    }
    if ((paramid1.getBitLength() != paramInt / 2) || (!fx.y(paramid1.toOctetString()))) {
      throw new InvalidKeyException("Invalid key pair.");
    }
    this.lt.p(paramid1);
    this.lt.R(1);
    this.lt.q(paramid2, this.lu);
    if (!this.lu.equals(id.oo)) {
      throw new InvalidKeyException("Invalid key pair.");
    }
  }
  
  public void clearSensitiveData()
  {
    er.a(new SensitiveData[] { this.ls, this.lt, this.lu });
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fy
 * JD-Core Version:    0.7.0.1
 */