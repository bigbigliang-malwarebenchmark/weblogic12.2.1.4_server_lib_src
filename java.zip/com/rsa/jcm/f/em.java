package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.PrivateKey;
import com.rsa.crypto.PublicKey;
import com.rsa.crypto.Signature;
import java.util.Arrays;

public abstract class em
  extends ei
{
  protected PublicKey jt;
  protected PrivateKey ju;
  
  public em(int paramInt)
  {
    super(paramInt);
  }
  
  protected abstract Signature l(int paramInt)
    throws Exception;
  
  protected abstract void m(int paramInt)
    throws Exception;
  
  protected abstract String aH();
  
  protected AlgInputParams o(int paramInt)
  {
    return null;
  }
  
  protected abstract byte[] aI();
  
  protected abstract byte[] aJ();
  
  public boolean test(int paramInt)
    throws Exception
  {
    try
    {
      m(paramInt);
      boolean bool = a(paramInt, aI(), aJ());
      return bool;
    }
    finally
    {
      er.a(this.jt);
      er.a(this.ju);
    }
  }
  
  boolean a(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws Exception
  {
    Signature localSignature1 = null;
    Signature localSignature2 = null;
    boolean bool1 = true;
    try
    {
      localSignature1 = l(paramInt);
      localSignature1.initSign(this.ju, aM());
      localSignature1.update(paramArrayOfByte1, 0, paramArrayOfByte1.length);
      byte[] arrayOfByte = localSignature1.sign();
      if (paramArrayOfByte2 != null) {
        bool1 = Arrays.equals(arrayOfByte, paramArrayOfByte2);
      }
      localSignature2 = l(paramInt);
      localSignature2.initVerify(this.jt);
      localSignature2.update(paramArrayOfByte1, 0, paramArrayOfByte1.length);
      bool1 &= localSignature2.verify(arrayOfByte, 0, arrayOfByte.length);
      boolean bool2 = bool1;
      return bool2;
    }
    finally
    {
      er.a(localSignature1);
      er.a(localSignature2);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.em
 * JD-Core Version:    0.7.0.1
 */