package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.InvalidAlgorithmParameterException;

public class ij
{
  public static int a(AlgInputParams paramAlgInputParams, String paramString, int paramInt)
  {
    Integer localInteger = (Integer)paramAlgInputParams.get(paramString);
    return localInteger == null ? paramInt : localInteger.intValue();
  }
  
  public static byte[] a(AlgInputParams paramAlgInputParams, String paramString, byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = (byte[])paramAlgInputParams.get(paramString);
    return arrayOfByte == null ? paramArrayOfByte : arrayOfByte;
  }
  
  public static byte[] b(AlgInputParams paramAlgInputParams, String paramString, byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = (byte[])paramAlgInputParams.get(paramString);
    return arrayOfByte == null ? paramArrayOfByte : es.x(arrayOfByte);
  }
  
  public static byte[] a(AlgInputParams paramAlgInputParams, String paramString)
  {
    byte[] arrayOfByte = (byte[])paramAlgInputParams.get(paramString);
    if (arrayOfByte == null) {
      throw new InvalidAlgorithmParameterException("Expected " + paramString + " parameter not present.");
    }
    return arrayOfByte;
  }
  
  public static byte[] b(AlgInputParams paramAlgInputParams, String paramString)
  {
    byte[] arrayOfByte = (byte[])paramAlgInputParams.get(paramString);
    if (arrayOfByte == null) {
      throw new InvalidAlgorithmParameterException("Expected " + paramString + " parameter not present.");
    }
    return es.x(arrayOfByte);
  }
  
  public static long a(AlgInputParams paramAlgInputParams, String paramString, long paramLong)
  {
    Object localObject = paramAlgInputParams.get(paramString);
    if (localObject != null)
    {
      if ((localObject instanceof Integer)) {
        return ((Integer)localObject).longValue();
      }
      if ((localObject instanceof Long)) {
        return ((Long)localObject).longValue();
      }
    }
    return paramLong;
  }
  
  public static int c(AlgInputParams paramAlgInputParams, String paramString)
  {
    Integer localInteger = (Integer)paramAlgInputParams.get(paramString);
    if (localInteger == null) {
      throw new InvalidAlgorithmParameterException("Expected " + paramString + " parameter not present.");
    }
    return localInteger.intValue();
  }
  
  public static long d(AlgInputParams paramAlgInputParams, String paramString)
  {
    Long localLong = (Long)paramAlgInputParams.get(paramString);
    if (localLong == null) {
      throw new InvalidAlgorithmParameterException("Expected " + paramString + " parameter not present.");
    }
    return localLong.longValue();
  }
  
  public static String a(AlgInputParams paramAlgInputParams, String paramString1, String paramString2)
  {
    String str = (String)paramAlgInputParams.get(paramString1);
    return str == null ? paramString2 : str;
  }
  
  public static String e(AlgInputParams paramAlgInputParams, String paramString)
  {
    String str = (String)paramAlgInputParams.get(paramString);
    if (str == null) {
      throw new InvalidAlgorithmParameterException("Expected " + paramString + " parameter not present.");
    }
    return str;
  }
  
  public static boolean a(AlgInputParams paramAlgInputParams, String paramString, boolean paramBoolean)
  {
    Boolean localBoolean = (Boolean)paramAlgInputParams.get(paramString);
    return localBoolean == null ? paramBoolean : localBoolean.booleanValue();
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ij
 * JD-Core Version:    0.7.0.1
 */