package com.rsa.jcm.f;

import java.util.Calendar;
import java.util.TimeZone;

public final class de
{
  private static final long serialVersionUID = -3688416813680772520L;
  private static final int hV = 64;
  private static final long hW = 0L;
  public static final int hX = 137;
  private final byte[] cB;
  private final byte[] hY;
  private final Calendar hZ;
  private final int ia;
  
  private de(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, Calendar paramCalendar)
  {
    this.ia = paramInt;
    this.cB = es.x(paramArrayOfByte1);
    this.hY = es.x(paramArrayOfByte2);
    this.hZ = paramCalendar;
  }
  
  private de(byte[] paramArrayOfByte, int paramInt)
  {
    this.ia = paramArrayOfByte[(paramInt++)];
    this.cB = new byte[64];
    System.arraycopy(paramArrayOfByte, paramInt, this.cB, 0, this.cB.length);
    paramInt += 64;
    this.hY = new byte[64];
    System.arraycopy(paramArrayOfByte, paramInt, this.hY, 0, this.hY.length);
    paramInt += 64;
    long l = jb.E(paramArrayOfByte, paramInt, 8);
    if (l != 0L)
    {
      this.hZ = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
      this.hZ.setTimeInMillis(l);
    }
    else
    {
      this.hZ = null;
    }
  }
  
  public static de a(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, Calendar paramCalendar)
  {
    return new de(paramInt, paramArrayOfByte1, paramArrayOfByte2, paramCalendar);
  }
  
  public static de u(byte[] paramArrayOfByte, int paramInt)
  {
    return new de(paramArrayOfByte, paramInt);
  }
  
  public int v(byte[] paramArrayOfByte, int paramInt)
  {
    paramArrayOfByte[(paramInt++)] = ((byte)(this.ia & 0xFF));
    System.arraycopy(this.cB, 0, paramArrayOfByte, paramInt, this.cB.length);
    paramInt += this.cB.length;
    System.arraycopy(this.hY, 0, paramArrayOfByte, paramInt, this.hY.length);
    paramInt += this.hY.length;
    if (this.hZ != null) {
      jb.a(this.hZ.getTimeInMillis(), paramArrayOfByte, paramInt);
    } else {
      jb.a(0L, paramArrayOfByte, paramInt);
    }
    return 137;
  }
  
  public int getValue()
  {
    return this.ia;
  }
  
  public byte[] getSalt()
  {
    return es.x(this.cB);
  }
  
  public byte[] ap()
  {
    return es.x(this.hY);
  }
  
  public Calendar aq()
  {
    return this.hZ;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.de
 * JD-Core Version:    0.7.0.1
 */