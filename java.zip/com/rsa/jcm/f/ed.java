package com.rsa.jcm.f;

public final class ed
  extends dw
{
  public ed()
  {
    super(1);
  }
  
  public String getName()
  {
    return "HMACDRBG";
  }
  
  protected boolean test(int paramInt)
    throws Exception
  {
    byte[] arrayOfByte = jb.hexStringToByteArray("80f8a89574508c0b527151ca58063096eee45335");
    return a("HMACDRBG/128/SHA1", 128, 1, arrayOfByte);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ed
 * JD-Core Version:    0.7.0.1
 */