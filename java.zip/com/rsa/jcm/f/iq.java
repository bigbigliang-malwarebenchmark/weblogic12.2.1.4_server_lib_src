package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.DSAPrivateKey;
import com.rsa.crypto.DSAPublicKey;
import com.rsa.crypto.InvalidKeyException;
import com.rsa.crypto.KeyPairGenerator;
import com.rsa.crypto.PQGParams;
import com.rsa.crypto.PrivateKey;
import com.rsa.crypto.PublicKey;

public class iq
  extends ip
{
  private DSAPrivateKey pe;
  private DSAPublicKey pf;
  
  protected id c(PrivateKey paramPrivateKey)
  {
    return (id)((DSAPrivateKey)paramPrivateKey).getX();
  }
  
  protected id c(PublicKey paramPublicKey)
  {
    return (id)((DSAPublicKey)paramPublicKey).getY();
  }
  
  public int getSignatureSize()
  {
    if (!this.initialized) {
      throw new IllegalStateException("Object has not been initialized.");
    }
    return (this.pc.getBitLength() + 7) / 8 * 2 + 8;
  }
  
  KeyPairGenerator cO()
  {
    fr localfr = new fr(null, "DSA");
    localfr.initialize(this.pe.getParams(), this.M);
    return localfr;
  }
  
  id t(id paramid1, id paramid2)
    throws CryptoException
  {
    id localid1 = new id();
    id localid2 = new id();
    id localid3 = new id();
    try
    {
      id localid4 = (id)this.pf.getParams().getP();
      ((id)this.pf.getParams().getG()).g(paramid1, localid4, localid1);
      ((id)this.pf.getY()).g(paramid2, localid4, localid2);
      localid1.e(localid2, localid4, localid3);
      id localid5 = localid3;
      return localid5;
    }
    finally
    {
      er.a(localid2);
      er.a(localid1);
    }
  }
  
  public void a(PrivateKey paramPrivateKey)
    throws InvalidKeyException
  {
    if (!(paramPrivateKey instanceof DSAPrivateKey)) {
      throw new InvalidKeyException("Expected private key of type DSA.");
    }
    this.pe = ((DSAPrivateKey)paramPrivateKey);
    PQGParams localPQGParams = this.pe.getParams();
    if (localPQGParams == null) {
      throw new InvalidKeyException("DSA key did not contain parameters.");
    }
    this.pd = ((id)this.pe.getX());
    this.pc = ((id)localPQGParams.getQ());
    this.initialized = true;
    this.pb = true;
  }
  
  public void a(PublicKey paramPublicKey)
    throws InvalidKeyException
  {
    if (!(paramPublicKey instanceof DSAPublicKey)) {
      throw new InvalidKeyException("Expected public key of type DSA.");
    }
    this.pf = ((DSAPublicKey)paramPublicKey);
    PQGParams localPQGParams = this.pf.getParams();
    if (localPQGParams == null) {
      throw new InvalidKeyException("DSA key did not contain parameters.");
    }
    this.pc = ((id)localPQGParams.getQ());
    this.initialized = true;
    this.pb = false;
  }
  
  public void clearSensitiveData()
  {
    super.clearSensitiveData();
    this.pe = null;
    this.pf = null;
  }
  
  public String getAlg()
  {
    return "DSA";
  }
  
  public Object clone()
  {
    iq localiq = (iq)super.clone();
    localiq.pe = ((DSAPrivateKey)es.a(this.pe));
    localiq.pf = ((DSAPublicKey)es.a(this.pf));
    return localiq;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.iq
 * JD-Core Version:    0.7.0.1
 */