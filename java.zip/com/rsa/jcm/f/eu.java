package com.rsa.jcm.f;

public final class eu
{
  static final String jR = "6.2.4";
  static final double jS = 6.24D;
  static final String jT = "20180102";
  static final String jU = "1224";
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.eu
 * JD-Core Version:    0.7.0.1
 */