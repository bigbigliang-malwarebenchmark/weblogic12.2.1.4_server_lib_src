package com.rsa.jcm.f;

import com.rsa.crypto.SensitiveData;

public final class er
{
  public static void a(SensitiveData paramSensitiveData)
  {
    if (paramSensitiveData != null) {
      paramSensitiveData.clearSensitiveData();
    }
  }
  
  public static void a(SensitiveData... paramVarArgs)
  {
    if (paramVarArgs != null) {
      for (int i = 0; i < paramVarArgs.length; i++) {
        if (paramVarArgs[i] != null) {
          paramVarArgs[i].clearSensitiveData();
        }
      }
    }
  }
  
  public static void w(byte[] paramArrayOfByte)
  {
    jd.K(paramArrayOfByte);
  }
  
  public static void a(byte[][] paramArrayOfByte)
  {
    jd.d(paramArrayOfByte);
  }
  
  public static void a(int[] paramArrayOfInt)
  {
    jd.f(paramArrayOfInt);
  }
  
  public static void a(long[] paramArrayOfLong)
  {
    jd.c(paramArrayOfLong);
  }
  
  public static void a(char[] paramArrayOfChar)
  {
    jd.c(paramArrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.er
 * JD-Core Version:    0.7.0.1
 */