package com.rsa.jcm.f;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

public final class dn
  implements dr
{
  private File in;
  private boolean io;
  
  public dn(File paramFile)
  {
    this.in = paramFile;
  }
  
  public String getName()
  {
    return "JarVerify";
  }
  
  public dr aB()
    throws Exception
  {
    this.io = aD();
    return this;
  }
  
  public boolean aC()
  {
    return this.io;
  }
  
  public boolean aD()
  {
    if (!cz.ai()) {
      return true;
    }
    ds localds = new ds(0, getName());
    dt.a(localds);
    try
    {
      dp localdp = c(this.in);
      if (!localdp.verify())
      {
        dt.d(localds);
        bool = false;
        return bool;
      }
      dt.c(localds);
      bool = true;
      return bool;
    }
    catch (Throwable localThrowable)
    {
      dt.d(localds);
      boolean bool = false;
      return bool;
    }
    finally
    {
      dt.b(localds);
    }
  }
  
  private dp c(File paramFile)
  {
    JarFile localJarFile = d(paramFile);
    if (localJarFile == null) {
      throw new SecurityException("Toolkit not encapsulated by a jar.");
    }
    try
    {
      Manifest localManifest = localJarFile.getManifest();
      if (localManifest == null) {
        throw new SecurityException("The jar does not contain a manifest.");
      }
      dp localdp = new dp(localJarFile, localManifest);
      Enumeration localEnumeration = localJarFile.entries();
      while (localEnumeration.hasMoreElements())
      {
        localObject1 = (JarEntry)localEnumeration.nextElement();
        if (!((JarEntry)localObject1).isDirectory()) {
          localdp.a((JarEntry)localObject1);
        }
      }
      Object localObject1 = localdp;
      return localObject1;
    }
    catch (Throwable localThrowable)
    {
      throw new SecurityException(localThrowable.getMessage());
    }
    finally
    {
      close(localJarFile);
    }
  }
  
  private void close(JarFile paramJarFile)
  {
    if (paramJarFile != null) {
      try
      {
        paramJarFile.close();
      }
      catch (IOException localIOException) {}
    }
  }
  
  public JarFile d(File paramFile)
  {
    if (paramFile == null) {
      return null;
    }
    try
    {
      return new JarFile(paramFile);
    }
    catch (IOException localIOException) {}
    return null;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dn
 * JD-Core Version:    0.7.0.1
 */