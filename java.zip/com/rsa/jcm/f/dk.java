package com.rsa.jcm.f;

import java.util.Arrays;
import java.util.List;

public enum dk
{
  FAILED(new dk[0]),  OPERATIONAL(new dk[] { FAILED }),  UNDER_SELF_TEST(new dk[] { OPERATIONAL, FAILED }),  NOT_INITIALIZED(new dk[] { UNDER_SELF_TEST, FAILED });
  
  private List<dk> allowableNexts;
  
  private dk(dk... paramVarArgs)
  {
    this.allowableNexts = Arrays.asList(paramVarArgs);
  }
  
  boolean a(dk paramdk)
  {
    return (this == paramdk) || (this.allowableNexts.contains(paramdk));
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dk
 * JD-Core Version:    0.7.0.1
 */