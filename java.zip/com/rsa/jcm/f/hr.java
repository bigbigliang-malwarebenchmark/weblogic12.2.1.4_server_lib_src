package com.rsa.jcm.f;

public class hr
  extends hn
{
  private static final int nN = 24;
  private static final int nO = 12;
  
  hr(gk paramgk)
  {
    super(paramgk);
  }
  
  hr(gk paramgk, id paramid)
  {
    super(paramgk, paramid);
  }
  
  public void l(id paramid)
  {
    int[] arrayOfInt1 = paramid.cM();
    int i = paramid.cJ();
    if (i <= 12)
    {
      if (i == 12)
      {
        int j = paramid.q(this.nM);
        switch (j)
        {
        case 0: 
          paramid.p(paramid);
          return;
        case -1: 
          return;
        }
        paramid.t(this.nM);
        return;
      }
      return;
    }
    Object localObject1 = new int[24];
    System.arraycopy(arrayOfInt1, 0, localObject1, 0, i);
    int k = localObject1[0];
    int m = 0;
    int n;
    k += (n = localObject1[12]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[20]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[21]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[23];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    localObject1[0] = k;
    k = m + (n = localObject1[1]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[13]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[22]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[23]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[12];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[20];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    localObject1[1] = k;
    k = m + (n = localObject1[2]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[14]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[23]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[13];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[21];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    localObject1[2] = k;
    k = m + (n = localObject1[3]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[12]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[15]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[20]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[21]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[14];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[22];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[23];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    localObject1[3] = k;
    k = m + (n = localObject1[4]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[12]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[13]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[16]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[20]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[21]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[21]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[22]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[15];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[23];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[23];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    localObject1[4] = k;
    k = m + (n = localObject1[5]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[13]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[14]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[17]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[21]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[22]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[22]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[23]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[16];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    localObject1[5] = k;
    k = m + (n = localObject1[6]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[14]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[15]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[18]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[22]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[23]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[23]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[17];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    localObject1[6] = k;
    k = m + (n = localObject1[7]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[15]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[16]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[19]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[23]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[18];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    localObject1[7] = k;
    k = m + (n = localObject1[8]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[16]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[17]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[20]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[19];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    localObject1[8] = k;
    k = m + (n = localObject1[9]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[17]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[18]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[21]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[20];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    localObject1[9] = k;
    k = m + (n = localObject1[10]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[18]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[19]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[22]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[21];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    localObject1[10] = k;
    k = m + (n = localObject1[11]);
    m = (m >> 31) + ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[19]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[20]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k += (n = localObject1[23]);
    m += ((n & (n ^ k) | (k & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ k ^ 0xFFFFFFFF)) >>> 31);
    k = (n = k) - localObject1[22];
    m -= ((k & (k ^ n) | (n & 0x7FFFFFFF) - (k & 0x7FFFFFFF) & (k ^ n ^ 0xFFFFFFFF)) >>> 31);
    localObject1[11] = k;
    if (m != 0)
    {
      int[] arrayOfInt2 = this.nM.cM();
      if (m < 0)
      {
        do
        {
          m += ih.b((int[])localObject1, 12, arrayOfInt2, 12, (int[])localObject1);
        } while (m != 0);
      }
      else
      {
        int[] arrayOfInt3 = new int[localObject1.length];
        Object localObject2 = localObject1;
        do
        {
          m += ih.a((int[])localObject1, 12, arrayOfInt2, 12, arrayOfInt3);
          localObject1 = arrayOfInt3;
        } while (m != 0);
        er.a(localObject2);
      }
    }
    paramid.a((int[])localObject1, 12);
    if (paramid.q(this.nM) >= 0) {
      paramid.t(this.nM);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hr
 * JD-Core Version:    0.7.0.1
 */