package com.rsa.jcm.f;

import com.rsa.crypto.MAC;
import com.rsa.crypto.SecretKey;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

final class dp
{
  private static final String ir = "fips140/module.files";
  private final MAC is = new bp(null, new bw(null));
  private final String it;
  private final JarFile iu;
  private final Map<String, byte[]> iv = new HashMap();
  private final List<String> iw = new ArrayList();
  
  dp(JarFile paramJarFile, Manifest paramManifest)
    throws Exception
  {
    SecretKey localSecretKey = dq.aG();
    this.is.init(localSecretKey);
    Attributes localAttributes = paramManifest.getMainAttributes();
    this.it = localAttributes.getValue("Jar-Digest");
    this.iu = paramJarFile;
  }
  
  public void a(JarEntry paramJarEntry)
    throws IOException
  {
    String str = paramJarEntry.getName();
    if (c(str))
    {
      if (str.equals("fips140/module.files")) {
        b(paramJarEntry);
      }
      c(paramJarEntry);
    }
  }
  
  private void b(JarEntry paramJarEntry)
    throws IOException
  {
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(this.iu.getInputStream(paramJarEntry), "UTF-8"));
    try
    {
      String str;
      while ((str = localBufferedReader.readLine()) != null) {
        this.iw.add(str);
      }
    }
    finally
    {
      localBufferedReader.close();
    }
  }
  
  private void c(JarEntry paramJarEntry)
    throws IOException
  {
    InputStream localInputStream = this.iu.getInputStream(paramJarEntry);
    try
    {
      String str = paramJarEntry.getName();
      if (this.iv.containsKey(str)) {
        throw new Error("Unexpected duplicate Jar entry name");
      }
      byte[] arrayOfByte = a(localInputStream);
      this.iv.put(str, arrayOfByte);
    }
    finally
    {
      localInputStream.close();
    }
  }
  
  private byte[] a(InputStream paramInputStream)
    throws IOException
  {
    byte[] arrayOfByte1 = new byte[8192];
    int i;
    while ((i = paramInputStream.read(arrayOfByte1, 0, arrayOfByte1.length)) != -1) {
      this.is.update(arrayOfByte1, 0, i);
    }
    byte[] arrayOfByte2 = new byte[this.is.getMacLength()];
    this.is.mac(arrayOfByte2, 0);
    return arrayOfByte2;
  }
  
  private static boolean c(String paramString)
  {
    return (paramString.equals("fips140/module.files")) || (paramString.equals("classes.dex")) || (paramString.startsWith("com/rsa/"));
  }
  
  private boolean aF()
  {
    if (!this.iv.containsKey("fips140/module.files")) {
      return false;
    }
    if (!this.iv.keySet().equals(new HashSet(this.iw))) {
      return false;
    }
    Iterator localIterator = this.iw.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      byte[] arrayOfByte = (byte[])this.iv.get(str);
      this.is.update(arrayOfByte, 0, arrayOfByte.length);
    }
    return true;
  }
  
  public boolean verify()
  {
    if (!aF()) {
      return false;
    }
    byte[] arrayOfByte = jb.hexStringToByteArray(this.it);
    return this.is.verify(arrayOfByte, 0, arrayOfByte.length);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dp
 * JD-Core Version:    0.7.0.1
 */