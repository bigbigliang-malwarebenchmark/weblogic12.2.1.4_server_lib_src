package com.rsa.jcm.f;

public final class ev
{
  public static String getVersionString()
  {
    return "6.2.4";
  }
  
  public static double getVersionDouble()
  {
    return 6.24D;
  }
  
  public static String aQ()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("BSAFE Java Crypto Module ");
    localStringBuffer.append("6.2.4");
    localStringBuffer.append(" ");
    localStringBuffer.append("20180102");
    localStringBuffer.append(" ");
    localStringBuffer.append("1224");
    return localStringBuffer.toString();
  }
  
  public static String aR()
  {
    if (cz.ai()) {
      return "Java Crypto Module FIPS140";
    }
    return "Java Crypto Module";
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ev
 * JD-Core Version:    0.7.0.1
 */