package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.SensitiveData;

public class gc
  extends fz
{
  private static final byte[] lE = { 1, 5, 7, 8, 9, 11, 13, 17, 19, 29, 0 };
  private static final byte[] lF = { 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1 };
  private static final byte[] lA = { 0, 1, 2, 3, 4, 1, 2, 1, 1, 1, 2, 1, 4, 1, 2, 3, 2, 1, 2, 1, 4, 3, 2, 3, 3, 3, 2, 3, 4, 1, 2, 3, 4, 3, 2, 1, 4, 3, 2, 3, 3, 3, 2, 3, 4, 1, 2, 1, 2, 3, 2, 1, 4, 1, 2, 1, 1, 1, 2, 1, 4, 3, 2, 1 };
  private static final byte[] lG = { -1, 0, 0, 0, 0, 1, 9, 2, 3, 4, 1, 5, 6, 6, 2, 1, 3, 7, 4, 8, 1, 2, 5, 9, 3, 6, 6, 4, 2, 9, 7, 5, 3, 5, 7, 9, 2, 4, 6, 6, 3, 9, 5, 2, 1, 8, 4, 7, 3, 1, 2, 6, 6, 5, 1, 4, 3, 2, 9, 1, 0, 0, 0, 0 };
  private static final int lB = 4;
  private static final int lH = 10;
  private static final int lC = 6;
  private static final int lD = 64;
  
  public gc(gi paramgi)
  {
    super(paramgi);
  }
  
  public void z(byte[] paramArrayOfByte)
  {
    setParams();
    this.lw = new gi[this.lz * this.ly + 1];
    int i = (this.lx.ba().getFieldSize() + 7) / 8;
    gl localgl1 = this.lx.bf().bX();
    for (int j = 0; j < this.lw.length; j++)
    {
      gl localgl2 = this.lx.bf().s(paramArrayOfByte, j * i * 2, i);
      gl localgl3 = this.lx.bf().s(paramArrayOfByte, i * (j * 2 + 1), i);
      this.lw[j] = this.lx.bg().a(localgl2, localgl3, localgl1);
    }
  }
  
  public gi d(id paramid)
  {
    if (this.lw == null) {
      throw new CryptoException("Acceleration Table has not been set");
    }
    id localid = new id();
    Object localObject1 = null;
    try
    {
      if (paramid.q(this.lx.be()) > -1) {
        paramid.j(this.lv.aS().be(), localid);
      } else {
        localid.p(paramid);
      }
      if (localid.isZero())
      {
        localObject2 = this.lv.aS().bg().bk();
        return localObject2;
      }
      Object localObject2 = f(localid);
      localObject1 = new gi[4];
      for (int i = 0; i < localObject1.length; i++) {
        localObject1[i] = this.lv.aS().bg().bk();
      }
      for (i = 0; i < localObject2.length; i++)
      {
        int j = 0;
        gi localgi2 = null;
        SensitiveData localSensitiveData = null;
        try
        {
          if (localObject2[i] > 0)
          {
            j = localObject2[i];
            localgi2 = (gi)this.lw[(i * this.lz + lG[j])].clone();
          }
          else if (localObject2[i] < 0)
          {
            j = -localObject2[i];
            localgi2 = this.lw[(i * this.lz + lG[j])].bA();
          }
          int k = lA[j];
          if (k > 0)
          {
            localSensitiveData = localObject1[(k - 1)];
            localObject1[(k - 1)] = localObject1[(k - 1)].f(localgi2);
          }
        }
        finally
        {
          er.a(localgi2);
          er.a(localSensitiveData);
        }
      }
      gi localgi1 = b((gi[])localObject1);
      return localgi1;
    }
    finally
    {
      er.a((SensitiveData[])localObject1);
      er.a(localid);
    }
  }
  
  private gi b(gi[] paramArrayOfgi)
  {
    Object localObject = paramArrayOfgi[3].bz();
    gi localgi = ((gi)localObject).f(paramArrayOfgi[1]);
    er.a((SensitiveData)localObject);
    localObject = localgi;
    localgi = ((gi)localObject).f(paramArrayOfgi[2]);
    er.a((SensitiveData)localObject);
    localObject = localgi;
    localgi = ((gi)localObject).bz();
    er.a((SensitiveData)localObject);
    localObject = localgi;
    localgi = ((gi)localObject).f(paramArrayOfgi[2]);
    er.a((SensitiveData)localObject);
    localObject = localgi;
    localgi = ((gi)localObject).f(paramArrayOfgi[0]);
    er.a((SensitiveData)localObject);
    localObject = localgi;
    return localObject;
  }
  
  private int[] f(id paramid)
  {
    int i = (paramid.getBitLength() + 5) / 6 + 1;
    int[] arrayOfInt = new int[i];
    for (int j = 0; j < i; j++)
    {
      arrayOfInt[j] += b(paramid, j * 6);
      if (arrayOfInt[j] > 63)
      {
        arrayOfInt[(j + 1)] += 1;
        arrayOfInt[j] -= 64;
      }
      else if (arrayOfInt[j] >= 0)
      {
        int k;
        if ((k = lF[arrayOfInt[j]]) > 0)
        {
          arrayOfInt[(j + 1)] += k;
          arrayOfInt[j] = (-(64 - arrayOfInt[j]));
        }
        else if (lF[arrayOfInt[j]] == -1)
        {
          arrayOfInt[(j + 1)] -= 1;
        }
      }
    }
    return arrayOfInt;
  }
  
  private int b(id paramid, int paramInt)
  {
    int i = 1;
    int j = paramid.E(paramInt);
    while (i < 6)
    {
      j += (paramid.E(paramInt + i) << i);
      i++;
    }
    return j;
  }
  
  public void aZ()
  {
    setParams();
    this.lw = new gi[this.lz * this.ly + 1];
    int i = 0;
    gi localgi1 = (gi)this.lv.clone();
    for (int j = 1; j <= 32; j++)
    {
      if (j != 1) {
        localgi1 = localgi1.f(this.lv);
      }
      if (lE[i] == j)
      {
        this.lw[i] = ((gi)localgi1.clone());
        gi localgi2 = (gi)localgi1.clone();
        int k = this.ly;
        if (i == 0) {
          k++;
        }
        for (int m = 1; m < k; m++)
        {
          for (int n = 0; n < 6; n++) {
            localgi2 = localgi2.bz();
          }
          this.lw[(m * this.lz + i)] = ((gi)localgi2.clone());
        }
        i++;
      }
    }
  }
  
  private void setParams()
  {
    this.ly = ((this.lv.aS().be().getBitLength() + 6 - 1) / 6);
    this.lz = 10;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gc
 * JD-Core Version:    0.7.0.1
 */