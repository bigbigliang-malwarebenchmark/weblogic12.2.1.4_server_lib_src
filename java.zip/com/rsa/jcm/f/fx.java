package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.CryptoException;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.InvalidKeyException;
import com.rsa.crypto.KeyPair;
import com.rsa.crypto.KeyPairGenerator;
import com.rsa.crypto.PrivateKey;
import com.rsa.crypto.SecureRandom;
import com.rsa.crypto.SensitiveData;

public final class fx
  extends cl
  implements KeyPairGenerator
{
  public static final int la = 0;
  public static final int lb = 1;
  public static final int lc = 2;
  private static final int[] ld = { 181, 4, 243, 51 };
  private static final int le = 65537;
  static final int lf = 1000;
  private static final String lg = "Could not generate the key pair, try reseeding.";
  int lh = 2;
  private id li;
  private id G;
  private id lj;
  private id lk;
  private byte[][] ll;
  private id[] lm;
  private boolean initialized;
  private SecureRandom M;
  private int ln;
  private int lo;
  private int lp;
  
  public fx(ke paramke)
  {
    super(paramke);
  }
  
  public KeyPair generate(boolean paramBoolean)
  {
    if (!this.initialized) {
      throw new IllegalStateException("Object has not been initialized.");
    }
    if (this.ll != null) {
      this.lm = new id[4];
    }
    return b(paramBoolean);
  }
  
  public KeyPair generate()
  {
    return generate(cz.ai());
  }
  
  public void initialize(AlgorithmParams paramAlgorithmParams, SecureRandom paramSecureRandom)
    throws InvalidAlgorithmParameterException
  {
    if (!(paramAlgorithmParams instanceof AlgInputParams)) {
      throw new InvalidAlgorithmParameterException("Parameters object invalid for algorithm.");
    }
    AlgInputParams localAlgInputParams = (AlgInputParams)paramAlgorithmParams;
    int i = ij.c(localAlgInputParams, "keyBits");
    int j = ij.a(localAlgInputParams, "keyType", i >= 1024 ? 0 : 1);
    int k = ij.a(localAlgInputParams, "securityStrength", -1);
    byte[] arrayOfByte = (byte[])localAlgInputParams.get("pubExp");
    id localid = arrayOfByte == null ? new id(65537) : new id(arrayOfByte);
    a(i, k, localid, j, paramSecureRandom);
    this.ll = ((byte[][])localAlgInputParams.get("startVals"));
  }
  
  private void a(int paramInt1, int paramInt2, id paramid, int paramInt3, SecureRandom paramSecureRandom)
    throws InvalidAlgorithmParameterException
  {
    if ((paramInt3 != 1) && (paramInt1 < 1024)) {
      throw new InvalidAlgorithmParameterException("Strong key gen and multiprime gen require at least 1024-bit keysize.");
    }
    if ((paramInt3 == 0) && (paramInt1 % 256 != 0)) {
      throw new InvalidAlgorithmParameterException("RSA key sizes greater than 1024 must be a multiple of 256 for strong gen.");
    }
    if (!paramid.cI()) {
      throw new InvalidAlgorithmParameterException("Public exponent must be odd.");
    }
    f(paramInt2, paramInt1);
    this.lp = paramInt3;
    this.lh = (this.lp == 2 ? 3 : 2);
    this.lo = paramInt2;
    this.M = paramSecureRandom;
    this.ln = paramInt1;
    this.li = paramid;
    this.initialized = true;
  }
  
  private void f(int paramInt1, int paramInt2)
  {
    if (paramInt1 == 112)
    {
      if (paramInt2 != 2048) {
        throw new InvalidAlgorithmParameterException("Only keySize of 2048 allowed with securityStrength of 112");
      }
    }
    else if (paramInt1 == 128)
    {
      if (paramInt2 != 3072) {
        throw new InvalidAlgorithmParameterException("Only keySize of 3072 allowed with securityStrength of 128");
      }
    }
    else if (paramInt1 != -1) {
      throw new InvalidAlgorithmParameterException("Only security strength 112 and 128 allowed.");
    }
  }
  
  private KeyPair b(boolean paramBoolean)
    throws CryptoException
  {
    this.G = new id();
    this.lk = new id();
    this.lj = new id();
    id[] arrayOfid1 = new id[this.lh];
    id[] arrayOfid2 = new id[this.lh];
    for (int i = 0; i < this.lh; i++)
    {
      arrayOfid1[i] = new id();
      arrayOfid2[i] = new id();
    }
    fu localfu = null;
    try
    {
      a(arrayOfid1, arrayOfid2);
      PrivateKey localPrivateKey = b(arrayOfid1, arrayOfid2);
      fj localfj = new fj(this.an, this.G, this.li);
      localfu = new fu("RSA", localPrivateKey, localfj);
    }
    catch (CryptoException localCryptoException)
    {
      throw new CryptoException("Could not generate the key pair, try reseeding.");
    }
    finally
    {
      er.a(this.lj);
      er.a(arrayOfid2);
    }
    if ((paramBoolean) && (cz.ai())) {
      try
      {
        AlgInputParams localAlgInputParams = this.an.newAlgInputParams();
        localAlgInputParams.set("keyBits", Integer.valueOf(this.ln));
        localAlgInputParams.set("securityStrength", Integer.valueOf(this.lo));
        localfu.validate(localAlgInputParams, this.M);
      }
      catch (InvalidKeyException localInvalidKeyException)
      {
        er.a(localfu);
        throw new SecurityException("Generated key pair did not pass validation. Check inputs.", localInvalidKeyException);
      }
    }
    return localfu;
  }
  
  private void a(id[] paramArrayOfid1, id[] paramArrayOfid2)
  {
    byte[][] arrayOfByte = { null };
    try
    {
      int[] arrayOfInt = g(this.ln, this.lh);
      boolean bool;
      do
      {
        bool = a(paramArrayOfid1, paramArrayOfid2, arrayOfByte, arrayOfInt);
      } while (!bool);
    }
    finally
    {
      er.a(arrayOfByte);
    }
  }
  
  private boolean a(id[] paramArrayOfid1, id[] paramArrayOfid2, byte[][] paramArrayOfByte, int[] paramArrayOfInt)
    throws CryptoException
  {
    b(paramArrayOfid1, paramArrayOfid2, paramArrayOfByte, paramArrayOfInt);
    if ((this.ll == null) && (!c(paramArrayOfid1, paramArrayOfid2))) {
      return false;
    }
    if (this.lp != 0)
    {
      if (!a(paramArrayOfid2)) {
        return false;
      }
    }
    else if (!b(paramArrayOfid2)) {
      return false;
    }
    paramArrayOfid1[0].i(paramArrayOfid1[1], this.G);
    for (int i = 2; i < this.lh; i++)
    {
      paramArrayOfid1[i].i(this.G, this.lj);
      this.G.p(this.lj);
    }
    return true;
  }
  
  private void b(id[] paramArrayOfid1, id[] paramArrayOfid2, byte[][] paramArrayOfByte, int[] paramArrayOfInt)
    throws CryptoException
  {
    int i = 0;
    int j = 0;
    while (i < this.lh)
    {
      j++;
      if (a(i, paramArrayOfid1, paramArrayOfid2, paramArrayOfInt, paramArrayOfByte))
      {
        i++;
        j = 0;
      }
      else if (j > 1000)
      {
        throw new SecurityException("Could not generate a valid prime in 1000 attempts with supplied random.");
      }
    }
  }
  
  private boolean a(int paramInt, id[] paramArrayOfid1, id[] paramArrayOfid2, int[] paramArrayOfInt, byte[][] paramArrayOfByte)
    throws CryptoException
  {
    if (!a(paramInt, paramArrayOfid1, paramArrayOfInt, paramArrayOfByte)) {
      return false;
    }
    paramArrayOfid1[paramInt].g(id.oo, paramArrayOfid2[paramInt]);
    return true;
  }
  
  private boolean a(int paramInt, id[] paramArrayOfid, int[] paramArrayOfInt, byte[][] paramArrayOfByte)
    throws CryptoException
  {
    switch (this.lp)
    {
    case 0: 
      return b(paramInt, paramArrayOfid, paramArrayOfInt, paramArrayOfByte);
    case 1: 
      return paramArrayOfid[paramInt].a(paramArrayOfInt[paramInt], this.M);
    case 2: 
      c(paramArrayOfid[paramInt]);
      return if.a(paramArrayOfid[paramInt], this.M, 0);
    }
    return false;
  }
  
  private boolean a(id[] paramArrayOfid)
    throws CryptoException
  {
    id localid = new id();
    try
    {
      paramArrayOfid[0].i(paramArrayOfid[1], localid);
      for (int i = 2; i < this.lh; i++)
      {
        paramArrayOfid[i].i(localid, this.lj);
        localid.p(this.lj);
      }
      if (!this.li.k(localid, this.lk))
      {
        i = 0;
        return i;
      }
      boolean bool = this.lk.q(id.on) > 0;
      return bool;
    }
    finally
    {
      er.a(localid);
    }
  }
  
  private boolean b(id[] paramArrayOfid)
    throws CryptoException
  {
    try
    {
      paramArrayOfid[0].p(paramArrayOfid[1], this.lj);
      if (!this.li.k(this.lj, this.lk))
      {
        bool = false;
        return bool;
      }
      this.lj.p(this.lk);
      this.lj.R(1);
      boolean bool = this.lj.getBitLength() > this.ln / 2;
      return bool;
    }
    finally
    {
      er.a(this.lj);
    }
  }
  
  private boolean b(int paramInt, id[] paramArrayOfid, int[] paramArrayOfInt, byte[][] paramArrayOfByte)
    throws CryptoException
  {
    if (paramInt == 0) {
      return a(paramArrayOfid, paramArrayOfInt, paramArrayOfByte);
    }
    return b(paramArrayOfid, paramArrayOfInt, paramArrayOfByte);
  }
  
  private boolean a(id[] paramArrayOfid, int[] paramArrayOfInt, byte[][] paramArrayOfByte)
    throws CryptoException
  {
    if (this.ll == null) {
      return a(paramArrayOfid[0], paramArrayOfInt[0], this.li, this.M, null, paramArrayOfByte, this.ln, true);
    }
    return a(paramArrayOfid[0], paramArrayOfInt[0], this.M, this.ll[0], this.ll[1], this.ll[2], this.ln, true);
  }
  
  private boolean a(id paramid1, int paramInt1, id paramid2, SecureRandom paramSecureRandom, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1, int paramInt2, boolean paramBoolean)
    throws CryptoException
  {
    int i = (paramInt1 + 7) / 8;
    int j = 16;
    int k = 31;
    int m = p(paramInt2);
    byte[] arrayOfByte2 = new byte[m];
    byte[] arrayOfByte3 = new byte[m];
    int n = 128;
    int i1 = 0;
    int i2 = paramInt1 % 8;
    int i3 = 255 >>> i2;
    byte[] arrayOfByte1;
    if (paramArrayOfByte != null)
    {
      arrayOfByte1 = es.x(paramArrayOfByte);
    }
    else
    {
      arrayOfByte1 = new byte[i];
      paramSecureRandom.nextBytes(arrayOfByte1);
      if (paramArrayOfByte1[0] == null) {
        paramArrayOfByte1[0] = es.x(arrayOfByte1);
      }
      int tmp107_106 = 0;
      byte[] tmp107_104 = arrayOfByte1;
      tmp107_104[tmp107_106] = ((byte)(tmp107_104[tmp107_106] & i3));
      int tmp117_116 = 0;
      byte[] tmp117_114 = arrayOfByte1;
      tmp117_114[tmp117_116] = ((byte)(tmp117_114[tmp117_116] | n));
      int tmp127_126 = 1;
      byte[] tmp127_124 = arrayOfByte1;
      tmp127_124[tmp127_126] = ((byte)(tmp127_124[tmp127_126] | i1));
      int tmp141_140 = (arrayOfByte1.length - 1);
      byte[] tmp141_134 = arrayOfByte1;
      tmp141_134[tmp141_140] = ((byte)(tmp141_134[tmp141_140] | 0x1));
      int tmp150_149 = 0;
      byte[] tmp150_147 = arrayOfByte1;
      tmp150_147[tmp150_149] = ((byte)(tmp150_147[tmp150_149] | 0xFFFFFF80));
      if (!y(arrayOfByte1))
      {
        int tmp168_167 = 0;
        byte[] tmp168_165 = arrayOfByte1;
        tmp168_165[tmp168_167] = ((byte)(tmp168_165[tmp168_167] | 0x40));
      }
      int i4 = (paramInt1 - 25) / 8;
      paramSecureRandom.nextBytes(arrayOfByte1, 4, i4);
    }
    paramSecureRandom.nextBytes(arrayOfByte2);
    paramSecureRandom.nextBytes(arrayOfByte3);
    int tmp217_216 = 0;
    byte[] tmp217_214 = arrayOfByte2;
    tmp217_214[tmp217_216] = ((byte)(tmp217_214[tmp217_216] & k));
    int tmp227_226 = 0;
    byte[] tmp227_224 = arrayOfByte2;
    tmp227_224[tmp227_226] = ((byte)(tmp227_224[tmp227_226] | j));
    int tmp241_240 = (arrayOfByte2.length - 1);
    byte[] tmp241_234 = arrayOfByte2;
    tmp241_234[tmp241_240] = ((byte)(tmp241_234[tmp241_240] | 0x1));
    int tmp250_249 = 0;
    byte[] tmp250_247 = arrayOfByte3;
    tmp250_247[tmp250_249] = ((byte)(tmp250_247[tmp250_249] & k));
    int tmp260_259 = 0;
    byte[] tmp260_257 = arrayOfByte3;
    tmp260_257[tmp260_259] = ((byte)(tmp260_257[tmp260_259] | j));
    int tmp274_273 = (arrayOfByte3.length - 1);
    byte[] tmp274_267 = arrayOfByte3;
    tmp274_267[tmp274_273] = ((byte)(tmp274_267[tmp274_273] | 0x1));
    return a(paramid1, paramInt1, paramSecureRandom, arrayOfByte2, arrayOfByte3, arrayOfByte1, paramInt2, paramBoolean);
  }
  
  private boolean a(id paramid, int paramInt1, SecureRandom paramSecureRandom, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt2, boolean paramBoolean)
    throws CryptoException
  {
    int i = (paramInt1 + 7) / 8;
    if (!y(paramArrayOfByte3)) {
      return false;
    }
    id localid1 = new id(paramArrayOfByte1, 0, paramArrayOfByte1.length);
    id localid2 = new id(paramArrayOfByte2, 0, paramArrayOfByte2.length);
    try
    {
      if ((localid1.getBitLength() < 101) || (localid2.getBitLength() < 101)) {
        throw new CryptoException("Start values xp1, xp2 too small");
      }
      if (!if.a(localid1, paramSecureRandom))
      {
        bool = false;
        return bool;
      }
      if (!if.a(localid2, paramSecureRandom))
      {
        bool = false;
        return bool;
      }
      paramid.t(paramArrayOfByte3, 0, i);
      if (this.lm != null)
      {
        this.lm[(paramBoolean ? 0 : 2)] = ((id)localid1.clone());
        this.lm[(paramBoolean ? 1 : 3)] = ((id)localid2.clone());
      }
      boolean bool = if.a(paramid, localid1, localid2, paramInt2, paramSecureRandom, this.li);
      return bool;
    }
    finally
    {
      localid1.clearSensitiveData();
      localid2.clearSensitiveData();
    }
  }
  
  private boolean b(id[] paramArrayOfid, int[] paramArrayOfInt, byte[][] paramArrayOfByte)
    throws CryptoException
  {
    if (this.ll == null)
    {
      localObject1 = a(paramArrayOfInt[1], paramArrayOfByte[0]);
      if (!a(paramArrayOfid[1], paramArrayOfInt[1], this.li, this.M, (byte[])localObject1, (byte[][])null, this.ln, false)) {
        return false;
      }
    }
    else if (!a(paramArrayOfid[1], paramArrayOfInt[1], this.M, this.ll[3], this.ll[4], this.ll[5], this.ln, false))
    {
      return false;
    }
    Object localObject1 = new id();
    try
    {
      boolean bool = b(paramArrayOfid[0], paramArrayOfid[1], (id)localObject1);
      return bool;
    }
    finally
    {
      er.a((SensitiveData)localObject1);
    }
  }
  
  private boolean b(id paramid1, id paramid2, id paramid3)
  {
    if (paramid1.q(paramid2) > 0) {
      paramid1.g(paramid2, paramid3);
    } else {
      paramid2.g(paramid1, paramid3);
    }
    return paramid3.getBitLength() > this.ln / 2 - 100;
  }
  
  private byte[] a(int paramInt, byte[] paramArrayOfByte)
    throws CryptoException
  {
    id localid1 = new id();
    id localid2 = new id();
    id localid3 = new id(paramArrayOfByte);
    byte[] arrayOfByte1 = new byte[(paramInt + 7) / 8];
    try
    {
      do
      {
        this.M.nextBytes(arrayOfByte1);
        localid2.t(arrayOfByte1, 0, arrayOfByte1.length);
      } while (!b(localid3, localid2, localid1));
      byte[] arrayOfByte2 = arrayOfByte1;
      return arrayOfByte2;
    }
    finally
    {
      er.a(localid3);
      er.a(localid2);
      er.a(localid1);
    }
  }
  
  private void c(id paramid)
  {
    int i = this.ln / 3;
    byte[] arrayOfByte1 = new byte[(i + 7) / 8];
    this.M.nextBytes(arrayOfByte1);
    int j = arrayOfByte1.length * 8 - i;
    arrayOfByte1[0] = ((byte)((arrayOfByte1[0] & 0xFF) >> j));
    paramid.t(arrayOfByte1, 0, arrayOfByte1.length);
    id localid1 = new id();
    id localid2 = new id();
    id localid3 = new id();
    try
    {
      switch (this.ln % 3)
      {
      case 2: 
        byte[] arrayOfByte2 = { 80, -94, -117, -25 };
        byte[] arrayOfByte3 = { 20, -11, 110, -82 };
        localid1.t(arrayOfByte2, 0, arrayOfByte2.length);
        localid2.t(arrayOfByte3, 0, arrayOfByte3.length);
        break;
      case 1: 
        byte[] arrayOfByte4 = { 64, 0, 0, 0 };
        byte[] arrayOfByte5 = { 16, -94, -117, -25 };
        localid1.t(arrayOfByte4, 0, arrayOfByte4.length);
        localid2.t(arrayOfByte5, 0, arrayOfByte5.length);
        break;
      case 0: 
      default: 
        byte[] arrayOfByte6 = { 50, -53, -3, 75 };
        byte[] arrayOfByte7 = { 13, 52, 2, -75 };
        localid1.t(arrayOfByte6, 0, arrayOfByte6.length);
        localid2.t(arrayOfByte7, 0, arrayOfByte7.length);
      }
      localid1.H(i);
      paramid.i(localid2, localid3);
      localid3.f(localid1, paramid);
      paramid.G(30);
      paramid.i(0, 1);
    }
    finally
    {
      er.w(arrayOfByte1);
      er.a(localid1);
      er.a(localid2);
      er.a(localid3);
    }
  }
  
  private PrivateKey b(id[] paramArrayOfid1, id[] paramArrayOfid2)
    throws CryptoException
  {
    id[] arrayOfid = new id[this.lh];
    id localid1 = new id();
    this.lk.j(paramArrayOfid2[0], localid1);
    id localid2 = new id();
    this.lk.j(paramArrayOfid2[1], localid2);
    arrayOfid[1] = paramArrayOfid1[0];
    arrayOfid[0] = paramArrayOfid1[1];
    System.arraycopy(paramArrayOfid1, 2, arrayOfid, 2, this.lh - 2);
    id localid3 = new id();
    arrayOfid[0].j(arrayOfid[1], this.lj);
    this.lj.k(arrayOfid[1], localid3);
    if (this.lh == 2)
    {
      localObject = new fi(this.an, this.G, this.li, this.lk, paramArrayOfid1[0], paramArrayOfid1[1], localid1, localid2, localid3);
      if (this.lm != null) {
        return new fi.a(this.an, (fi)localObject, this.lm);
      }
      return localObject;
    }
    Object localObject = new id();
    this.lk.j(paramArrayOfid2[2], (id)localObject);
    id localid4 = new id();
    arrayOfid[0].i(arrayOfid[1], localid4);
    localid4.j(arrayOfid[2], this.lj);
    this.lj.k(arrayOfid[2], localid4);
    return new fi(this.an, this.G, this.li, this.lk, paramArrayOfid1[0], paramArrayOfid1[1], localid1, localid2, localid3, new id[] { paramArrayOfid1[2], localObject, localid4 });
  }
  
  private static boolean c(id[] paramArrayOfid1, id[] paramArrayOfid2)
  {
    for (int i = 0; i < paramArrayOfid1.length - 1; i++)
    {
      int j = i;
      for (int k = i + 1; k < paramArrayOfid1.length; k++)
      {
        int m = paramArrayOfid1[j].q(paramArrayOfid1[k]);
        if (m == 0) {
          return false;
        }
        if (m < 0) {
          j = k;
        }
      }
      if (j != i)
      {
        id localid = paramArrayOfid1[i];
        paramArrayOfid1[i] = paramArrayOfid1[j];
        paramArrayOfid1[j] = localid;
        localid = paramArrayOfid2[i];
        paramArrayOfid2[i] = paramArrayOfid2[j];
        paramArrayOfid2[j] = localid;
      }
    }
    return true;
  }
  
  private static int p(int paramInt)
  {
    if (paramInt >= 3072) {
      return 22;
    }
    if (paramInt >= 2048) {
      return 18;
    }
    return 13;
  }
  
  static boolean y(byte[] paramArrayOfByte)
  {
    for (int i = 0; (i < 4) && ((paramArrayOfByte[i] & 0xFF) >= ld[i]); i++) {
      if ((paramArrayOfByte[i] & 0xFF) > ld[i]) {
        return true;
      }
    }
    return false;
  }
  
  private static int[] g(int paramInt1, int paramInt2)
  {
    int i = paramInt1 / paramInt2;
    int j = paramInt1 % paramInt2;
    int[] arrayOfInt = new int[paramInt2];
    for (int k = 0; k < paramInt2; k++)
    {
      arrayOfInt[k] = i;
      if (j > 0)
      {
        arrayOfInt[k] += 1;
        j--;
      }
    }
    return arrayOfInt;
  }
  
  public void clearSensitiveData()
  {
    er.a(this.lj);
    er.a(this.ll);
    er.a(this.lm);
    this.initialized = false;
    this.ln = 0;
    this.lh = 2;
    this.lp = 0;
    this.M = null;
    this.G = null;
    this.li = null;
    this.lk = null;
  }
  
  public Object clone()
  {
    fx localfx = (fx)super.clone();
    localfx.ll = es.b(this.ll);
    localfx.G = ((id)es.a(this.G));
    localfx.li = ((id)es.a(this.li));
    localfx.lk = ((id)es.a(this.lk));
    localfx.lj = ((id)es.a(this.lj));
    if (this.lm != null)
    {
      localfx.lm = new id[4];
      es.a(this.lm, localfx.lm);
    }
    return localfx;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fx
 * JD-Core Version:    0.7.0.1
 */