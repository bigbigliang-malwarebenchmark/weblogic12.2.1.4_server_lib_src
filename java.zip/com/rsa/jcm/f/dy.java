package com.rsa.jcm.f;

import com.rsa.crypto.SensitiveData;

public final class dy
  extends eh
{
  private static final String iH = "DiffieHellman KAT failed";
  private static final byte[][] iO = { jb.hexStringToByteArray("80dc12b5f66f912aa3ab114a94e38ea1be07d57cbc16f39bf8a9deb16cbc0ab541714a81c7862bfba4fc850ced4ff7b876a6de73d9f3ab284d95baabee8d8bac06b3f6de93330b018fb16cf0c717f8dfbdb748658b726b12fef8717cfcf9db52898143261bd6316972d55315c262f3bfa3a6b695add7a20e50af275dbddd358bdb2e7107f9ea2a88e074df3b00241d12d00ff44ded0827aa56e1462a71b2425115cf46f8ce328a8f1e4e6db7ebc01b934d6cb2621c8e72ccadd1f9f771a7aa14b802339b203834a899b6b197650cf1d5be69cd18e7d5af66f7b149f34a1725011aaaab97180cf7693facb68dd0495576f787791df4b7204a7ad9cf9bd2b8e4cb"), jb.hexStringToByteArray("0098988255cdf1256eee7f2e08ace2c0c957f6a62a42d2e865a998d927ac101aaa95c8bace1b1861d3a8d0855d037c98b9c364c50a5003e7eedca88607a5aa780926b6c2d1ef39a505549824b67e07151a309d7ff2a782268690424b966b0806470fbf49895d672bb24b00209c0bad23f2c677ff15bb62de7dce20bb1e060455d92f767857f430dd82d6f932edcae52d86517a405f043ca00ce7cc0e2c7d591fd5471c75bc889b5deef90b91c221d578ca256094233c909f9dae704f4860e1ef7bd226afcc811cb2fea3e87bc209671b0f70c087e9093c6438f2259cc1aa8adcc07fc2870e6356948f9089bf155c9166b9b5fbd1e68b4a356ac1690705223147"), jb.hexStringToByteArray("03"), jb.hexStringToByteArray("40a9d194b3dbec5ecacd961ff34f43dde2fca1614bbc2c1a913bb72e6187c7cccf809cdb648bd9689acb3635d96538a47788cc3e46ad7c990c0299f984f2110c11842d2a42d9f5f413b96672bc2d6439ec46b31493b1df3539bd360bebfe30d0b1550dad57d29463061cc3ec5617beaff55b18e81a2d8e2bc30b1096aa546ee62f09083e1d3cdb23d5cd8d7d86237e13e562e88b89c117bdd646b4c9af13b9daccc755a16f449e28f1aefc7d2dc198ade91905c80a72b60db7e5b54ef258099ed7d9d346925bf1c9a338d5955012eac9452a9a8765b9672f1f413c84e6f88b49065e60c020dfb3c60c9316db2ebd26d590359d43873f66bf222352c5e9cf8d6d") };
  
  public dy()
  {
    super(1);
  }
  
  public String getName()
  {
    return "DH";
  }
  
  public String aH()
  {
    return "DiffieHellman KAT failed";
  }
  
  boolean n(int paramInt)
    throws Exception
  {
    id localid1 = null;
    id localid2 = null;
    id localid3 = null;
    id localid4 = new id();
    try
    {
      localid1 = new id(iO[2]);
      localid2 = new id(iO[0]);
      localid3 = new id(iO[1]);
      localid3.g(localid1, localid2, localid4);
      boolean bool = ja.c(iO[3], localid4.toOctetString());
      return bool;
    }
    finally
    {
      er.a(new SensitiveData[] { localid1, localid2, localid3, localid4 });
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dy
 * JD-Core Version:    0.7.0.1
 */