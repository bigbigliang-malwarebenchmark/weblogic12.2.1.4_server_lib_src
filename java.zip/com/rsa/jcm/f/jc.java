package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;

public class jc
{
  public static int mod(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0) {
      throw new CryptoException("Cannot divide by zero.");
    }
    int i;
    return (i = paramInt1 % paramInt2) < 0 ? i + paramInt2 : i;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.jc
 * JD-Core Version:    0.7.0.1
 */