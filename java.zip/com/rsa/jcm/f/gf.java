package com.rsa.jcm.f;

import java.io.Serializable;

public abstract interface gf
  extends Serializable
{
  public abstract boolean a(gi paramgi, boolean paramBoolean);
  
  public abstract boolean b(gi paramgi);
  
  public abstract gi a(gi paramgi1, gi paramgi2);
  
  public abstract gi c(gi paramgi);
  
  public abstract gi d(gi paramgi);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gf
 * JD-Core Version:    0.7.0.1
 */