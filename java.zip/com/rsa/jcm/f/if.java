package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.SecureRandom;
import com.rsa.crypto.SensitiveData;

public final class if
{
  public static final int ov = 101;
  public static final int ow = 2048;
  public static final int ox = 0;
  public static final int oy = 1;
  public static final int oz = 2;
  public static final int oA = 3;
  public static final int oB = 4;
  private static final int[] oC = { 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251 };
  private static final int oD = 1;
  public static final int oE = 2;
  private static final int oF = 3;
  
  private static int V(int paramInt)
  {
    return paramInt >= 512 ? 8 : 27;
  }
  
  private static int W(int paramInt)
  {
    if (paramInt > 170) {
      return 27;
    }
    if (paramInt > 140) {
      return 32;
    }
    return 38;
  }
  
  public static int X(int paramInt)
  {
    if (paramInt >= 1536) {
      return 3;
    }
    if (paramInt >= 1024) {
      return 4;
    }
    return 7;
  }
  
  /* Error */
  public static boolean a(id paramid, SecureRandom paramSecureRandom, int paramInt)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 40	com/rsa/jcm/f/id:getBitLength	()I
    //   4: istore_3
    //   5: iload_3
    //   6: bipush 101
    //   8: if_icmplt +10 -> 18
    //   11: iload_3
    //   12: sipush 2048
    //   15: if_icmple +13 -> 28
    //   18: new 13	com/rsa/crypto/CryptoException
    //   21: dup
    //   22: ldc 9
    //   24: invokespecial 25	com/rsa/crypto/CryptoException:<init>	(Ljava/lang/String;)V
    //   27: athrow
    //   28: new 17	com/rsa/jcm/f/id
    //   31: dup
    //   32: invokespecial 29	com/rsa/jcm/f/id:<init>	()V
    //   35: astore 4
    //   37: new 17	com/rsa/jcm/f/id
    //   40: dup
    //   41: invokespecial 29	com/rsa/jcm/f/id:<init>	()V
    //   44: astore 5
    //   46: new 17	com/rsa/jcm/f/id
    //   49: dup
    //   50: invokespecial 29	com/rsa/jcm/f/id:<init>	()V
    //   53: astore 6
    //   55: aload_0
    //   56: iconst_0
    //   57: iconst_1
    //   58: invokevirtual 41	com/rsa/jcm/f/id:i	(II)V
    //   61: aload_0
    //   62: aload 4
    //   64: aload 5
    //   66: aload 6
    //   68: aconst_null
    //   69: invokestatic 73	com/rsa/jcm/f/ig:d	(Lcom/rsa/jcm/f/id;Lcom/rsa/jcm/f/id;Lcom/rsa/jcm/f/id;Lcom/rsa/jcm/f/id;Lcom/rsa/jcm/f/id;)Lcom/rsa/jcm/f/ig;
    //   72: astore 7
    //   74: iconst_0
    //   75: istore 8
    //   77: iconst_0
    //   78: istore 9
    //   80: iload 9
    //   82: aload 7
    //   84: invokevirtual 76	com/rsa/jcm/f/ig:length	()I
    //   87: if_icmpge +72 -> 159
    //   90: aload 7
    //   92: iload 9
    //   94: invokevirtual 75	com/rsa/jcm/f/ig:isSet	(I)Z
    //   97: ifeq +9 -> 106
    //   100: iinc 8 1
    //   103: goto +50 -> 153
    //   106: aload_0
    //   107: iload 8
    //   109: iconst_1
    //   110: ishl
    //   111: invokevirtual 33	com/rsa/jcm/f/id:Q	(I)V
    //   114: iconst_1
    //   115: istore 8
    //   117: iload_2
    //   118: aload_0
    //   119: aload_1
    //   120: aload 4
    //   122: aload 5
    //   124: aload 6
    //   126: invokestatic 58	com/rsa/jcm/f/if:a	(ILcom/rsa/jcm/f/id;Lcom/rsa/crypto/SecureRandom;Lcom/rsa/jcm/f/id;Lcom/rsa/jcm/f/id;Lcom/rsa/jcm/f/id;)Z
    //   129: ifeq +24 -> 153
    //   132: iconst_1
    //   133: istore 10
    //   135: aload 4
    //   137: invokestatic 27	com/rsa/jcm/f/er:a	(Lcom/rsa/crypto/SensitiveData;)V
    //   140: aload 5
    //   142: invokestatic 27	com/rsa/jcm/f/er:a	(Lcom/rsa/crypto/SensitiveData;)V
    //   145: aload 6
    //   147: invokestatic 27	com/rsa/jcm/f/er:a	(Lcom/rsa/crypto/SensitiveData;)V
    //   150: iload 10
    //   152: ireturn
    //   153: iinc 9 1
    //   156: goto -76 -> 80
    //   159: goto -98 -> 61
    //   162: astore 11
    //   164: aload 4
    //   166: invokestatic 27	com/rsa/jcm/f/er:a	(Lcom/rsa/crypto/SensitiveData;)V
    //   169: aload 5
    //   171: invokestatic 27	com/rsa/jcm/f/er:a	(Lcom/rsa/crypto/SensitiveData;)V
    //   174: aload 6
    //   176: invokestatic 27	com/rsa/jcm/f/er:a	(Lcom/rsa/crypto/SensitiveData;)V
    //   179: aload 11
    //   181: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	182	0	paramid	id
    //   0	182	1	paramSecureRandom	SecureRandom
    //   0	182	2	paramInt	int
    //   4	12	3	i	int
    //   35	130	4	localid1	id
    //   44	126	5	localid2	id
    //   53	122	6	localid3	id
    //   72	19	7	localig	ig
    //   75	41	8	j	int
    //   78	76	9	k	int
    //   133	18	10	bool	boolean
    //   162	18	11	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   55	135	162	finally
    //   153	164	162	finally
  }
  
  public static boolean a(id paramid, SecureRandom paramSecureRandom)
  {
    return a(paramid, paramSecureRandom, 1);
  }
  
  private static int Y(int paramInt)
    throws InvalidAlgorithmParameterException
  {
    switch (paramInt)
    {
    case 1024: 
    case 2048: 
      return 3;
    case 160: 
      return 19;
    case 224: 
      return 24;
    case 256: 
      return 27;
    case 3072: 
      return 2;
    }
    throw new InvalidAlgorithmParameterException("len bits for FIPS186-3 " + paramInt);
  }
  
  public static boolean a(int paramInt, id paramid, SecureRandom paramSecureRandom)
  {
    id localid1 = new id();
    id localid2 = new id();
    id localid3 = new id();
    try
    {
      boolean bool = a(paramInt, paramid, paramSecureRandom, localid1, localid2, localid3);
      return bool;
    }
    finally
    {
      er.a(localid1);
      er.a(localid2);
      er.a(localid3);
    }
  }
  
  public static boolean a(int paramInt, id paramid1, SecureRandom paramSecureRandom, id paramid2, id paramid3, id paramid4)
  {
    int i;
    switch (paramInt)
    {
    case 1: 
      i = W(paramid1.getBitLength());
      return a(paramid1, paramid2, paramid3, paramid4, paramSecureRandom, i);
    case 0: 
      i = X(paramid1.getBitLength());
      return a(paramid1, paramid2, paramid3, paramid4, paramSecureRandom, i);
    case 2: 
      i = Y(paramid1.getBitLength());
      return (a(paramid1, paramid2, paramid3, paramid4, paramSecureRandom, i)) && (b(paramid1, paramid2, paramid3, paramid4));
    case 3: 
      i = V(paramid1.getBitLength());
      return a(paramid1, paramid2, paramid3, paramid4, paramSecureRandom, i);
    case 4: 
      return a(paramid1, paramid2, paramid3, paramid4, paramSecureRandom, 50);
    }
    throw new CryptoException("Invalid primality test type.");
  }
  
  private static boolean b(id paramid1, id paramid2, id paramid3, id paramid4, id paramid5, id paramid6)
    throws CryptoException
  {
    if (!a(paramid4, paramid2, paramid3, paramid5)) {
      return false;
    }
    paramid1.j(paramid4, paramid6);
    paramid5.s(paramid1);
    paramid5.t(paramid6);
    if (paramid1.q(paramid5) > 0) {
      paramid5.f(paramid4, paramid1);
    } else {
      paramid1.p(paramid5);
    }
    return true;
  }
  
  public static boolean a(id paramid1, id paramid2, id paramid3, int paramInt, SecureRandom paramSecureRandom, id paramid4)
    throws CryptoException
  {
    int i = paramid1.getBitLength();
    if ((i < 101) || (i > 2048)) {
      throw new CryptoException("Cannot build a prime, the length is inappropriate.");
    }
    id localid1 = new id();
    id localid2 = new id();
    id localid3 = new id();
    id localid4 = new id();
    try
    {
      paramid1.i(0, 1);
      if (!b(paramid1, paramid2, paramid3, localid4, localid3, localid1))
      {
        boolean bool1 = false;
        return bool1;
      }
      int j = paramInt / 2;
      int k = j * 5;
      int m = 0;
      do
      {
        if (paramid1.getBitLength() > j)
        {
          boolean bool2 = false;
          return bool2;
        }
        ig localig = ig.d(paramid1, localid2, localid1, localid3, localid4);
        int n = 0;
        while (n < localig.length())
        {
          if (!localig.isSet(n))
          {
            paramid1.g(id.oo, localid1);
            localid1.q(paramid4, localid2);
            if ((localid2.C(1)) && (a(0, paramid1, paramSecureRandom, localid1, localid2, localid3)))
            {
              boolean bool4 = true;
              return bool4;
            }
          }
          n++;
          paramid1.s(localid4);
        }
        m += localig.length();
      } while (m < k);
      boolean bool3 = false;
      return bool3;
    }
    finally
    {
      er.a(localid1);
      er.a(localid2);
      er.a(localid3);
      er.a(localid4);
    }
  }
  
  public static void e(int[] paramArrayOfInt)
  {
    ig.e(paramArrayOfInt);
  }
  
  public static boolean i(id paramid1, id paramid2, id paramid3)
  {
    if (paramid1 == null) {
      throw new CryptoException("Candidate prime is null");
    }
    if (paramid1.isZero()) {
      return false;
    }
    for (int i = 0; i < 4; i++)
    {
      paramid2.setValue(oC[i]);
      paramid2.g(paramid1, paramid1, paramid3);
      if (!paramid3.C(oC[i])) {
        return false;
      }
    }
    return true;
  }
  
  private static boolean a(id paramid1, id paramid2, id paramid3, id paramid4)
  {
    id localid1 = new id();
    id localid2 = new id();
    id localid3 = new id();
    try
    {
      paramid2.i(paramid3, paramid1);
      paramid1.s(paramid1);
      paramid2.f(paramid2, localid3);
      k(paramid3, localid3, localid1);
      k(localid3, paramid3, localid2);
      if (localid1.q(localid2) < 0) {
        localid1.s(paramid1);
      }
      localid1.g(localid2, paramid4);
      boolean bool1 = true;
      return bool1;
    }
    catch (CryptoException localCryptoException)
    {
      boolean bool2 = false;
      return bool2;
    }
    finally
    {
      er.a(localid1);
      er.a(localid2);
      er.a(localid3);
    }
  }
  
  public static boolean a(id paramid1, id paramid2, id paramid3, id paramid4, SecureRandom paramSecureRandom, int paramInt)
  {
    byte[] arrayOfByte = null;
    try
    {
      int i = paramid1.getBitLength();
      i %= 8;
      if (i != 0) {
        i = 8 - i;
      }
      int j = 255 >> i;
      int k = r(paramid1, paramid2);
      if (k < 0)
      {
        m = 0;
        return m;
      }
      arrayOfByte = paramid1.toOctetString();
      for (int m = 0; m < paramInt; m++)
      {
        do
        {
          paramSecureRandom.nextBytes(arrayOfByte);
          int tmp95_94 = 0;
          byte[] tmp95_92 = arrayOfByte;
          tmp95_92[tmp95_94] = ((byte)(tmp95_92[tmp95_94] & j));
          paramid3.t(arrayOfByte, 0, arrayOfByte.length);
        } while ((paramid3.q(paramid1) >= 0) || (paramid3.getBitLength() < 2));
        if (!a(paramid1, paramid2, paramid3, paramid4, k))
        {
          boolean bool = false;
          return bool;
        }
      }
      m = 1;
      return m;
    }
    finally
    {
      er.w(arrayOfByte);
      er.a(paramid2);
      er.a(paramid3);
    }
  }
  
  public static int b(id paramid1, id paramid2, id paramid3, id paramid4, SecureRandom paramSecureRandom, int paramInt)
  {
    byte[] arrayOfByte = null;
    id localid = new id();
    try
    {
      int i = paramid1.getBitLength();
      i %= 8;
      if (i != 0) {
        i = 8 - i;
      }
      int j = 255 >> i;
      int k = r(paramid1, paramid2);
      if (k < 0)
      {
        m = -1;
        return m;
      }
      arrayOfByte = new byte[(paramid1.getBitLength() + 7) / 8];
      for (int m = 0; m < paramInt; m++)
      {
        do
        {
          paramSecureRandom.nextBytes(arrayOfByte);
          int tmp117_116 = 0;
          byte[] tmp117_114 = arrayOfByte;
          tmp117_114[tmp117_116] = ((byte)(tmp117_114[tmp117_116] & j));
          paramid3.t(arrayOfByte, 0, arrayOfByte.length);
        } while ((paramid3.getBitLength() < 2) || (paramid3.q(paramid1) >= 0));
        int n = a(paramid1, paramid2, paramid3, localid, paramid4, k);
        if (n != -1)
        {
          int i1 = n;
          return i1;
        }
      }
      m = 3;
      return m;
    }
    finally
    {
      er.w(arrayOfByte);
      er.a(paramid2);
      er.a(paramid3);
      er.a(localid);
    }
  }
  
  private static boolean a(id paramid1, id paramid2, id paramid3, id paramid4, int paramInt)
  {
    try
    {
      paramid3.g(paramid2, paramid1, paramid4);
      int i = 0;
      for (;;)
      {
        if (paramid4.C(1))
        {
          bool = i == 0;
          return bool;
        }
        paramid4.Q(1);
        if (paramid4.equals(paramid1))
        {
          bool = true;
          return bool;
        }
        i++;
        if (i >= paramInt) {
          break;
        }
        paramid4.R(1);
        paramid4.e(paramid4, paramid1, paramid3);
        paramid4.p(paramid3);
      }
      bool = false;
      return bool;
    }
    catch (CryptoException localCryptoException)
    {
      boolean bool = false;
      return bool;
    }
    finally
    {
      er.a(paramid4);
    }
  }
  
  private static int a(id paramid1, id paramid2, id paramid3, id paramid4, id paramid5, int paramInt)
  {
    paramid3.q(paramid1, paramid5);
    if (paramid5.getBitLength() > 1) {
      return 1;
    }
    paramid3.g(paramid2, paramid1, paramid4);
    if (paramid4.C(1)) {
      return -1;
    }
    paramid4.Q(1);
    if (paramid4.equals(paramid1)) {
      return -1;
    }
    paramid4.R(1);
    for (int i = 0; i < paramInt - 1; i++)
    {
      paramid5 = paramid4;
      paramid5.e(paramid5, paramid1, paramid4);
      paramid4.Q(1);
      if (paramid4.equals(paramid1)) {
        return -1;
      }
      paramid4.R(1);
      if (paramid4.C(1)) {
        return j(paramid5, paramid1, paramid4);
      }
    }
    paramid5 = paramid4;
    paramid5.e(paramid5, paramid1, paramid4);
    if (!paramid4.C(1)) {
      paramid5 = paramid4;
    }
    return j(paramid5, paramid1, paramid4);
  }
  
  private static int j(id paramid1, id paramid2, id paramid3)
  {
    paramid1.R(1);
    paramid1.q(paramid2, paramid3);
    if (paramid3.getBitLength() > 1) {
      return 1;
    }
    return 2;
  }
  
  private static int r(id paramid1, id paramid2)
  {
    try
    {
      paramid2.p(paramid1);
      paramid2.R(1);
      for (int i = 0; paramid2.E(i) == 0; i++) {}
      if (i == 0) {
        return -1;
      }
      paramid2.G(i);
      return i;
    }
    catch (CryptoException localCryptoException) {}
    return -1;
  }
  
  public static boolean c(id paramid1, id paramid2, id paramid3, id paramid4, id paramid5, id paramid6)
  {
    Object localObject1 = null;
    Object localObject2 = null;
    try
    {
      if (!c(paramid1, paramid2, paramid3, paramid5, paramid6))
      {
        boolean bool1 = false;
        return bool1;
      }
      localObject1 = new id();
      localObject2 = new id();
      paramid3.p(paramid1);
      paramid3.Q(1);
      int i = paramid3.getBitLength();
      paramid5.p(paramid3);
      paramid5.G(1);
      paramid6.setValue(1);
      paramid4.setValue(1);
      for (int j = i - 2; j >= 0; j--)
      {
        int k = paramid3.E(j);
        if (!a(k, paramid1, paramid2, paramid5, paramid6, paramid4, (id)localObject1, (id)localObject2))
        {
          boolean bool3 = false;
          return bool3;
        }
      }
      if ((paramid6.getBitLength() == 1) && (paramid6.E(0) == 0))
      {
        j = 1;
        return j;
      }
    }
    catch (CryptoException localCryptoException)
    {
      boolean bool2 = false;
      return bool2;
    }
    finally
    {
      er.a((SensitiveData)localObject1);
      er.a((SensitiveData)localObject2);
    }
    return false;
  }
  
  public static boolean b(id paramid1, id paramid2, id paramid3, id paramid4)
  {
    id localid1 = new id();
    id localid2 = new id();
    try
    {
      boolean bool = c(paramid1, paramid2, paramid3, paramid4, localid1, localid2);
      return bool;
    }
    finally
    {
      er.a(localid1);
      er.a(localid2);
    }
  }
  
  private static boolean c(id paramid1, id paramid2, id paramid3, id paramid4, id paramid5)
  {
    try
    {
      int i = 1;
      paramid3.setValue(5);
      paramid2.setValue(5);
      while (c(paramid2, paramid1, paramid4, paramid5) != -1)
      {
        paramid3.Q(2);
        i *= -1;
        if (i == -1) {
          paramid1.g(paramid3, paramid2);
        } else {
          paramid2.p(paramid3);
        }
      }
      if (i == -1) {
        paramid1.g(paramid3, paramid2);
      } else {
        paramid2.p(paramid3);
      }
      return true;
    }
    catch (CryptoException localCryptoException) {}
    return false;
  }
  
  private static int c(id paramid1, id paramid2, id paramid3, id paramid4)
  {
    try
    {
      int i = 1;
      paramid3.p(paramid2);
      for (;;)
      {
        if ((paramid1.getBitLength() == 1) && (paramid1.E(0) == 0))
        {
          if (paramid3.getBitLength() <= 1) {
            break;
          }
          i = 0;
          break;
        }
        for (int j = 0; paramid1.E(j) == 0; j++) {}
        paramid1.G(j);
        if (((j & 0x1) == 1) && (paramid3.E(1) + paramid3.E(2) == 1)) {
          i *= -1;
        }
        if (paramid1.E(1) + paramid3.E(1) == 2) {
          i *= -1;
        }
        paramid3.j(paramid1, paramid4);
        paramid3.p(paramid1);
        paramid1.p(paramid4);
      }
      return i;
    }
    catch (CryptoException localCryptoException) {}
    return 1;
  }
  
  private static boolean a(int paramInt, id paramid1, id paramid2, id paramid3, id paramid4, id paramid5, id paramid6, id paramid7)
  {
    try
    {
      paramid4.i(paramid4, paramid6);
      paramid2.i(paramid6, paramid7);
      paramid5.i(paramid5, paramid6);
      paramid6.s(paramid7);
      paramid3.e(paramid6, paramid1, paramid7);
      paramid5.e(paramid4, paramid1, paramid6);
      paramid4.p(paramid6);
      paramid5.p(paramid7);
      if (paramInt == 0) {
        return true;
      }
      paramid2.i(paramid4, paramid6);
      paramid6.s(paramid5);
      paramid3.e(paramid6, paramid1, paramid7);
      paramid4.f(paramid5, paramid6);
      paramid3.e(paramid6, paramid1, paramid4);
      paramid5.p(paramid7);
      return true;
    }
    catch (CryptoException localCryptoException) {}
    return false;
  }
  
  private static void k(id paramid1, id paramid2, id paramid3)
    throws CryptoException
  {
    id localid1 = new id();
    id localid2 = new id();
    try
    {
      paramid1.j(paramid2, localid1);
      localid1.k(paramid2, localid2);
      localid2.i(paramid1, paramid3);
    }
    finally
    {
      er.a(localid1);
      er.a(localid2);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.if
 * JD-Core Version:    0.7.0.1
 */