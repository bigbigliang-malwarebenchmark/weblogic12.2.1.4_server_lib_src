package com.rsa.jcm.f;

public final class dv
  extends dw
{
  public dv()
  {
    super(1);
  }
  
  public String getName()
  {
    return "CTRDRBG";
  }
  
  protected boolean test(int paramInt)
    throws Exception
  {
    byte[] arrayOfByte = jb.hexStringToByteArray("cec29ad0e15dc0d8e8e277ba590f80f62f6ffc8f");
    return a("CTRDRBG/128", 128, 1, arrayOfByte);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dv
 * JD-Core Version:    0.7.0.1
 */