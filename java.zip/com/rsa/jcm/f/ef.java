package com.rsa.jcm.f;

public final class ef
  extends eo
{
  private static final byte[] iW = jb.hexStringToByteArray("bded7fa5c1699c010be23dd06ada3a48349f21e5f86263d512c0c5cc379f0e780ec55d9844b2f1db02a96453513568d0");
  private static final byte[] iX = jb.hexStringToByteArray("135e4d557fdf3aa6406d82975d5c606a9734c9334b42136e96990fbd5358cdb2");
  private static final byte[] iY = jb.hexStringToByteArray("e5acaf549cd25c22d964c0d930fa4b5261d2507fad84c33715b7b9a864020693");
  private static final byte[] iZ = jb.hexStringToByteArray("67267e650eb32444119d222a368c191af3082888dc35afe8368e638c828874be");
  private static final byte[] ja = jb.hexStringToByteArray("d58a7b1cd4fedaa232159df652ce188f9d997e061b9bf48e83b62990440931f6");
  private static final byte[] jb = jb.hexStringToByteArray("2f6962dfbc744c4b2138bb6b3d33054c5ecc14f24851d9896395a44ab3964efc2090c5bf51a0891209f46c1e1e998f62");
  private static final byte[] jc = jb.hexStringToByteArray("3088825988e77fce68d19f756e18e43eb7fe672433504feaf99b3c503d9091b164f166db301d70c9fc0870b4a94563907bee1a61fb786cb717576890bcc51cb9ead97e01d0a2fea99c953377b195205ff07b369589178796edc963fd80fdbe518a2fc1c35c18ae8d");
  
  public boolean test(int paramInt)
  {
    return (a(getName(), iW, jB, iY, iX, jb)) && (a(getName(), jb, jC, iZ, ja, jc));
  }
  
  public String getName()
  {
    return "KDFTLS10";
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ef
 * JD-Core Version:    0.7.0.1
 */