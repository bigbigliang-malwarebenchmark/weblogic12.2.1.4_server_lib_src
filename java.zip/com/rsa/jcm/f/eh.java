package com.rsa.jcm.f;

public abstract class eh
  extends ei
{
  eh(int paramInt)
  {
    super(paramInt);
  }
  
  protected abstract String aH();
  
  public boolean test(int paramInt)
    throws Exception
  {
    return n(paramInt);
  }
  
  abstract boolean n(int paramInt)
    throws Exception;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.eh
 * JD-Core Version:    0.7.0.1
 */