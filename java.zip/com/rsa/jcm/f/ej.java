package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.CryptoModule;
import com.rsa.crypto.KeyBuilder;
import com.rsa.crypto.Signature;

public final class ej
  extends em
{
  private static final String iH = "RSA KAT failed";
  public static final byte[] jf = jb.hexStringToByteArray("9dd7e0b4fa9ca8f9a5129b3b5f0f4a32ac2f4ae08272e55a23f62799317c06703831e097d1e0dd4fc4b4720a0ff038b3128d5f8560506ec47538eff8f6aa84c66937b651c49d41c01daeeb7f442681747b12aced188e2e90e338803063a2c6961fa558de087ee41f1fe4df2411f28e9586da01eb32fbcc93e0fdd6e6622c858d3a6b7cab62f244f67257f13321e61478988636895f220d3a587112db02d8d4a06b5a309b33fb8fbae8e45cbc4d0697eb5071e73c3af89c8914d0d944b0e4aaf7c4b980444eabd85da9d938d43fffd81eacffd4fed2746d1afadb9370f5b3085c1782f484a5afe6395988f205abfe0ad4a535cf427802807b1cd093af9e882e13");
  public static final byte[] jg = jb.hexStringToByteArray("29b34f");
  public static final byte[] jh = jb.hexStringToByteArray("0a09a3ab1c55dca3c78b2d7bf98095c24721caacfd1934bc16db5c40632951f85df6aa886ec78dbc4fc515d15366bac00cee8d859595cf45c11dfc4e21e7e5a3eca275c632c7b351f65f661b0d17bc1fc1dd3365f74f4a1136957eedb0b92b7fec80681bf5d3e4bb7e19b0d452858ce21705f57f985f01b7300ee4e4148b14c8d573b088eb1523109c2a7c1f2c26a11f8c702dd1cd3e061b7f759f4f2e8ada7f43b88b2ff05089f43fb442cc0f46597aade215f7219fee41ef530bdd02a2ac4e05f4c7f104cb26abe15fec9a41c1fc4b1563e8487d5eb7c9cf9ec57a476098066399d93202da4b6a105198beda9172f6c61c038ca56cb0fb47d0f9e0639f134f");
  public static final byte[] ji = jb.hexStringToByteArray("b51ed2c7d61ce4028a2063feb02bd6d27ce82286781485a697db885b7590794fb5c224f6c325de717b42c9e27eca790b12f8ee390c4916bba0b221cbe937faa37a7da4badc4dbb44b5e6b17ebbc3663562ab6f8fc8c7994831715c2f991152bf60c598534eb40cb61e2fcd7815c192130120222b3146f283c74830172a85cda1");
  public static final byte[] jj = jb.hexStringToByteArray("df197b17559224f35289b9b16580bbaed33ded0a60562464ba26af5fece27b1d02c4d73a3dbbac0a39425ee5b83a6cddb72f40e99dca2cc58591a6eeaff970031937d3a1deb10c54b6e697fffe49eb68ff4bb797bbf7b841a55983066d4dd77de6ac7c087784d65262286ded7279d8ab1a5c2d6648fe9715ac416cd78b6ed733");
  public static final byte[] jk = jb.hexStringToByteArray("0826ebfa9458af67067c30b3d58ec68a434776c8396c4c2ad221019a397665debb92d76ca9608e0837dd8e38a2355bb1a1af418b6e1d04829cb0d34d0a2cbe70fabf748a5a3d1e6e2648590611ffe6030f83926b9d5cd47c082fe9f5e58d8842231a2d237837ace0afe9fbffff7ed407d740daad0cd3f1e427cf8c5104ddf22f");
  public static final byte[] jl = jb.hexStringToByteArray("da00618c933de40479d38ce10ff5d33ebd30e24a5165c1f07a6ad52bd1852827d48ce34e5288abf03056f166ad2cb24a13fdaf84d2bffcdd56aefe10b3c81e11e4792406f554ae0a2272c836188bf2bd03bad51e13f004177b8e780aca469ca6c28e463f85dfb38945636cf41fc84a90c23acaeb3a0a27a0c7432952f883e493");
  public static final byte[] jm = jb.hexStringToByteArray("67b9ea5b97631e54d4bc01bb7ea75160a5a331e6c1c9af4fbcb40b0e7857b18a9a297dd2447a8fe9f528f582058696c6082e8cc3ddf8bf3ca4d04a0df69ac4da779822abe3e6c04a12755667c358456bd139c589ec565578dbe03e3586054aec9e8a2b909c5b1b057286bab1db027a1c69a49ddc7aa117bb8e8e0134f1296865");
  public static final byte[] jn = jb.hexStringToByteArray("31861d07ec3f72c8a56168128aafc755d5ccb8f1fea08fb02efde894f882f5d444c016218b9caa2d4af4266eb08664209a0d3d89c2ac59803390463001d2c81a369a70590f8a702a695aaeab76bf17e3b4923603202e05eba71a03f0dde886ddf15c5337e1d16cc6ead9295043248aa80aa3cce87fec3afa70e1465df48cd825");
  public static final byte[] jo = jb.hexStringToByteArray("30922914c8cd72bef7e0685fca19c4abd9ea9e6b75d6f95545561f427d062d69da77244e63c93e6d0cbb88d05c37efef841dc9343d60d0fe03d85e4aa00e69f66e2b1117dc2167442d4148663838686f70c831407db7a5a64dd4b6bed4d74165de5e2052d23e78d18b041ff0c821dae4f28ea42354d52674dab62fd21233e6a0d7c0891afa438ee24f664b8dafb6e974e62f189f6eab3ec547fc2e49cce880eec4f52cdeff843c153a2d53a6e3b49fd2abd4429bb9cc3373b333c11102ad034a83b80e915dd3ab848ec5c631f7ad58d274e6b66464ef8d72fa1b2a115a5d5b5c6d36d4b2e552b03be40d0d487ad0a11a7cb6d41a64d5bb55d8b7cd9404e5b51a");
  private static final String[] iP = { "SHA512/RSA" };
  
  public ej()
  {
    super(iP.length);
  }
  
  protected Signature l(int paramInt)
    throws Exception
  {
    return this.ip.newSignature(iP[paramInt]);
  }
  
  protected AlgInputParams o(int paramInt)
  {
    if (iP[paramInt].indexOf("PSS") != -1)
    {
      AlgInputParams localAlgInputParams = this.ip.newAlgInputParams();
      localAlgInputParams.set("salt", new byte[20]);
      return localAlgInputParams;
    }
    return null;
  }
  
  public String getName()
  {
    return "RSA";
  }
  
  public String aH()
  {
    return "RSA KAT failed";
  }
  
  protected void m(int paramInt)
  {
    this.ju = this.ip.getKeyBuilder().newRSAPrivateKey(jf, jg, jh, ji, jj, jk, jl, jm, (byte[][])null);
    this.jt = this.ip.getKeyBuilder().newRSAPublicKey(jf, jg);
  }
  
  protected byte[] aI()
  {
    return jn;
  }
  
  protected byte[] aJ()
  {
    return jo;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ej
 * JD-Core Version:    0.7.0.1
 */