package com.rsa.jcm.f;

import java.util.HashMap;
import java.util.Map;

public class gp
{
  private static final byte[][] mK = jf.g("NamedCurve.bin");
  private static final Map<String, ge> mL = new HashMap();
  
  public static ge e(String paramString)
  {
    return (ge)mL.get(paramString);
  }
  
  static
  {
    int i = 0;
    Object localObject = hu.o(new id(mK[(i++)]));
    gm localgm = ((gk)localObject).bf();
    mL.put("P192", new gq("P192", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), mK[(i++)], localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
    localObject = hu.o(new id(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("P224", new gq("P224", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), mK[(i++)], localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
    localObject = hu.o(new id(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("P256", new gq.a("P256", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), mK[(i++)], localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), "NistNamedCurve.P256.at.bin"));
    localObject = hu.o(new id(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("P384", new gq.a("P384", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), mK[(i++)], localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), "NistNamedCurve.P384.at.bin"));
    localObject = hu.o(new id(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("P521", new gq("P521", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), mK[(i++)], localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
    localObject = hc.a(jb.G(mK[(i++)]), jb.F(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("K163", new gq("K163", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), null, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
    localObject = hc.a(jb.G(mK[(i++)]), jb.F(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("B163", new gq("B163", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), mK[(i++)], localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
    localObject = hc.a(jb.G(mK[(i++)]), jb.F(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("K233", new gq("K233", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), null, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
    localObject = hc.a(jb.G(mK[(i++)]), jb.F(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("B233", new gq("B233", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), mK[(i++)], localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
    localObject = hc.a(jb.G(mK[(i++)]), jb.F(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("K283", new gq("K283", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), null, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
    localObject = hc.a(jb.G(mK[(i++)]), jb.F(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("B283", new gq("B283", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), mK[(i++)], localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
    localObject = hc.a(jb.G(mK[(i++)]), jb.F(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("K409", new gq("K409", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), null, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
    localObject = hc.a(jb.G(mK[(i++)]), jb.F(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("B409", new gq("B409", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), mK[(i++)], localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
    localObject = hc.a(jb.G(mK[(i++)]), jb.F(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("K571", new gq("K571", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), null, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
    localObject = hc.a(jb.G(mK[(i++)]), jb.F(mK[(i++)]));
    localgm = ((gk)localObject).bf();
    mL.put("B571", new gq("B571", (gk)localObject, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), mK[(i++)], localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)])), new id(mK[(i++)]), mK[(i++)][0] & 0xFF, localgm.j(new id(mK[(i++)])), localgm.j(new id(mK[(i++)]))));
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gp
 * JD-Core Version:    0.7.0.1
 */