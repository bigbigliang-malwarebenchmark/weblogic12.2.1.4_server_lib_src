package com.rsa.jcm.f;

import com.rsa.crypto.BigNum;
import com.rsa.crypto.ECParams;
import com.rsa.crypto.ECPoint;
import com.rsa.crypto.InvalidAlgorithmParameterException;

public final class fd
  extends cl
  implements ECParams
{
  private ge kg;
  private String kh;
  
  public fd(ke paramke, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5, byte[] paramArrayOfByte6, int paramInt1, byte[] paramArrayOfByte7, String paramString1, int paramInt2, byte[] paramArrayOfByte8, String paramString2)
    throws InvalidAlgorithmParameterException
  {
    super(paramke);
    hu localhu = hu.o(new id(paramArrayOfByte1));
    a(paramArrayOfByte2, paramArrayOfByte3, paramArrayOfByte4, paramArrayOfByte5, paramArrayOfByte6, paramInt1, paramArrayOfByte7, paramString1, localhu, paramInt2, paramArrayOfByte8, paramString2);
  }
  
  public fd(ke paramke, int paramInt1, int[] paramArrayOfInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5, int paramInt2, byte[] paramArrayOfByte6, String paramString1, int paramInt3, byte[] paramArrayOfByte7, String paramString2)
    throws InvalidAlgorithmParameterException
  {
    super(paramke);
    hc localhc = hc.a(paramInt1, paramArrayOfInt);
    a(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramArrayOfByte4, paramArrayOfByte5, paramInt2, paramArrayOfByte6, paramString1, localhc, paramInt3, paramArrayOfByte7, paramString2);
  }
  
  private void a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5, int paramInt1, byte[] paramArrayOfByte6, String paramString1, gk paramgk, int paramInt2, byte[] paramArrayOfByte7, String paramString2)
    throws InvalidAlgorithmParameterException
  {
    if ((paramArrayOfByte1 == null) || (paramArrayOfByte2 == null) || (paramArrayOfByte4 == null) || (paramArrayOfByte5 == null) || (paramArrayOfByte6 == null)) {
      throw new IllegalArgumentException("Parameters a,b,baseX, baseY and order must be non-null.");
    }
    gl localgl1 = paramgk.bf().s(paramArrayOfByte1, 0, paramArrayOfByte1.length);
    gl localgl2 = paramgk.bf().s(paramArrayOfByte2, 0, paramArrayOfByte2.length);
    gl localgl3 = paramgk.bf().s(paramArrayOfByte4, 0, paramArrayOfByte4.length);
    gl localgl4 = paramgk.bf().s(paramArrayOfByte5, 0, paramArrayOfByte5.length);
    if ((localgl1.bR().getBitLength() > paramgk.getFieldSize()) || (localgl2.bR().getBitLength() > paramgk.getFieldSize()) || (localgl3.bR().getBitLength() > paramgk.getFieldSize()) || (localgl4.bR().getBitLength() > paramgk.getFieldSize())) {
      throw new InvalidAlgorithmParameterException("Invalid EC curve parameters.");
    }
    id localid = new id(paramArrayOfByte6);
    this.kg = new ge(paramgk, localgl1, localgl2, paramArrayOfByte3, paramString1, localgl3, localgl4, localid, paramInt1, paramInt2, paramArrayOfByte7, paramString2);
    if (!this.kg.bd().bw()) {
      throw new InvalidAlgorithmParameterException("Invalid EC curve parameters.");
    }
  }
  
  public fd(ke paramke, String paramString)
  {
    super(paramke);
    this.kh = paramString;
    this.kg = gp.e(this.kh);
  }
  
  public fd(ke paramke, ge paramge)
  {
    super(paramke);
    this.kg = paramge;
  }
  
  public ge aS()
  {
    return this.kg;
  }
  
  public BigNum getOrder()
  {
    return aS().be();
  }
  
  public BigNum getA()
  {
    return aS().bb().bG().bQ();
  }
  
  public BigNum getB()
  {
    return aS().bb().bH().bQ();
  }
  
  public byte[] getSeed()
  {
    return aS().getSeed();
  }
  
  public int getCofactor()
  {
    return aS().getCofactor();
  }
  
  public BigNum getFieldPrime()
  {
    return aS().bb().getFieldPrime();
  }
  
  public int getFieldSize()
  {
    return aS().bb().ba().getFieldSize();
  }
  
  public int[] getFieldMidTerms()
  {
    return aS().bb().getFieldMidTerms();
  }
  
  public int getFieldType()
  {
    return aS().bb().ba().getType();
  }
  
  public ECPoint getBase()
  {
    return aS().bd();
  }
  
  public String getDigest()
  {
    return aS().getDigest();
  }
  
  public int getVersion()
  {
    return aS().getVersion();
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof fd)) {
      return false;
    }
    return aS().equals(((fd)paramObject).aS());
  }
  
  public int hashCode()
  {
    return aS().hashCode();
  }
  
  public String getCurveName()
  {
    String str = this.kh;
    if ((str == null) && ((this.kg instanceof go))) {
      str = ((go)this.kg).getCurveName();
    }
    return str;
  }
  
  public byte[] getBaseSeed()
  {
    return aS().getBaseSeed();
  }
  
  public String getBaseDigest()
  {
    return aS().getBaseDigest();
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fd
 * JD-Core Version:    0.7.0.1
 */