package com.rsa.jcm.f;

import com.rsa.crypto.AlgParamGenerator;
import com.rsa.crypto.Cipher;
import com.rsa.crypto.KDF;
import com.rsa.crypto.KeyAgreement;
import com.rsa.crypto.KeyConfirmation;
import com.rsa.crypto.KeyGenerator;
import com.rsa.crypto.KeyPairGenerator;
import com.rsa.crypto.MAC;
import com.rsa.crypto.MessageDigest;
import com.rsa.crypto.NoSuchAlgorithmException;
import com.rsa.crypto.SecureRandom;
import com.rsa.crypto.Signature;
import com.rsa.crypto.SymmCipher;
import java.util.Arrays;

public final class il
{
  public static MAC a(String[] paramArrayOfString, ke paramke)
  {
    if ("HMAC".equalsIgnoreCase(paramArrayOfString[0]))
    {
      if ("MD2".equalsIgnoreCase(paramArrayOfString[1])) {
        throw new NoSuchAlgorithmException(paramArrayOfString[1]);
      }
      return new bp(paramke, b(paramArrayOfString[1], paramke));
    }
    if ("PBHMAC".equalsIgnoreCase(paramArrayOfString[0]))
    {
      if ("MD2".equalsIgnoreCase(paramArrayOfString[1])) {
        throw new NoSuchAlgorithmException(paramArrayOfString[1]);
      }
      bq localbq1 = b(paramArrayOfString[1], paramke);
      bq localbq2 = (bq)localbq1.clone();
      return new bu(paramke, new bp(paramke, localbq2), localbq1, f(paramArrayOfString[2], paramke));
    }
    throw new NoSuchAlgorithmException(paramArrayOfString[0]);
  }
  
  public static KeyAgreement a(String paramString, ke paramke)
  {
    if ("ECDH".equalsIgnoreCase(paramString)) {
      return new fm(paramke);
    }
    if ("ECDHC".equalsIgnoreCase(paramString)) {
      return new fn(paramke);
    }
    if ("DH".equalsIgnoreCase(paramString)) {
      return new fl(paramke);
    }
    throw new NoSuchAlgorithmException(paramString);
  }
  
  public static SecureRandom b(String[] paramArrayOfString, ke paramke)
  {
    if ("FIPS186Random".equalsIgnoreCase(paramArrayOfString[0])) {
      return new cq(paramke);
    }
    if (("HMACDRBG".equalsIgnoreCase(paramArrayOfString[0])) || ("HASHDRBG".equalsIgnoreCase(paramArrayOfString[0])) || ("CTRDRBG".equalsIgnoreCase(paramArrayOfString[0])))
    {
      int i = paramArrayOfString.length > 1 ? Integer.parseInt(paramArrayOfString[1]) : 128;
      if (i > 256) {
        throw new NoSuchAlgorithmException("Invalid strength for " + paramArrayOfString[0]);
      }
      Object localObject;
      if (("HMACDRBG".equalsIgnoreCase(paramArrayOfString[0])) || ("HASHDRBG".equalsIgnoreCase(paramArrayOfString[0])))
      {
        localObject = paramArrayOfString.length > 2 ? a(i, paramArrayOfString[2], paramke) : a(i, paramke);
        ct localct = "HMACDRBG".equalsIgnoreCase(paramArrayOfString[0]) ? new cr(paramke, i, (bq)localObject) : new ct(paramke, i, (bq)localObject);
        localct.selfTest();
        return localct;
      }
      if ("CTRDRBG".equalsIgnoreCase(paramArrayOfString[0]))
      {
        localObject = new cf(paramke, i, f(new String[] { "AES", "ECB", "NoPad" }, paramke));
        ((cf)localObject).selfTest();
        return localObject;
      }
    }
    throw new NoSuchAlgorithmException(paramArrayOfString[0]);
  }
  
  public static KDF c(String[] paramArrayOfString, ke paramke)
  {
    Object localObject;
    if ("PBKDF2".equals(paramArrayOfString[0]))
    {
      localObject = new bp(paramke, b(paramArrayOfString[1], paramke));
      return new aq(paramke, new at((MAC)localObject));
    }
    if ("scrypt".equals(paramArrayOfString[0])) {
      return new aw(paramke);
    }
    if ("KDFTLS12".equals(paramArrayOfString[0]))
    {
      localObject = new String[2];
      localObject[0] = "HMAC";
      localObject[1] = paramArrayOfString[1];
      return new ey(paramke, a((String[])localObject, paramke));
    }
    if ("KDFTLS10".equals(paramArrayOfString[0]))
    {
      localObject = new String[2];
      localObject[0] = "HMAC";
      localObject[1] = "MD5";
      String[] arrayOfString = new String[2];
      arrayOfString[0] = "HMAC";
      arrayOfString[1] = "SHA1";
      return new ex(paramke, a((String[])localObject, paramke), a(arrayOfString, paramke));
    }
    if ("SSKDF".equals(paramArrayOfString[0]))
    {
      localObject = b(paramArrayOfString[1], paramke);
      return new ez(paramke, (MessageDigest)localObject);
    }
    throw new NoSuchAlgorithmException(paramArrayOfString[0]);
  }
  
  private static bq a(int paramInt, String paramString, ke paramke)
  {
    if ((!paramString.startsWith("SHA")) && (!"NoDigest".equalsIgnoreCase(paramString))) {
      throw new NoSuchAlgorithmException("Invalid digest");
    }
    if (paramInt > 192)
    {
      if (("SHA1".equalsIgnoreCase(paramString)) || ("SHA224".equalsIgnoreCase(paramString)) || ("SHA512-224".equalsIgnoreCase(paramString))) {
        throw new NoSuchAlgorithmException("Invalid digest");
      }
    }
    else if ((paramInt > 128) && ("SHA1".equalsIgnoreCase(paramString))) {
      throw new NoSuchAlgorithmException("Invalid digest");
    }
    return b(paramString, paramke);
  }
  
  public static bq b(String paramString, ke paramke)
  {
    if ("SHA1".equalsIgnoreCase(paramString)) {
      return new bw(paramke);
    }
    if ("MD5".equalsIgnoreCase(paramString)) {
      return new bs(paramke);
    }
    if ("SHA224".equalsIgnoreCase(paramString)) {
      return new bx(paramke);
    }
    if ("SHA256".equalsIgnoreCase(paramString)) {
      return new by(paramke);
    }
    if ("SHA384".equalsIgnoreCase(paramString)) {
      return new bz(paramke);
    }
    if ("SHA512".equalsIgnoreCase(paramString)) {
      return new ca(paramke);
    }
    if ("SHA512-224".equalsIgnoreCase(paramString)) {
      return new cb(paramke);
    }
    if ("SHA512-256".equalsIgnoreCase(paramString)) {
      return new cc(paramke);
    }
    if ("NoDigest".equalsIgnoreCase(paramString)) {
      return new bt(paramke);
    }
    if ("MD2".equalsIgnoreCase(paramString)) {
      return new br(paramke);
    }
    if ("RIPEMD160".equalsIgnoreCase(paramString)) {
      return new bv(paramke);
    }
    throw new NoSuchAlgorithmException(paramString);
  }
  
  public static KeyPairGenerator c(String paramString, ke paramke)
  {
    if ("EC".equalsIgnoreCase(paramString)) {
      return new fs(paramke);
    }
    if ("RSA".equalsIgnoreCase(paramString)) {
      return new fx(paramke);
    }
    if (("DSA".equalsIgnoreCase(paramString)) || ("DH".equalsIgnoreCase(paramString))) {
      return new fr(paramke, paramString);
    }
    throw new NoSuchAlgorithmException(paramString);
  }
  
  public static Signature d(String[] paramArrayOfString, ke paramke)
  {
    bq localbq1 = b(paramArrayOfString[0], paramke);
    Object localObject;
    if ("RSA".equalsIgnoreCase(paramArrayOfString[1]))
    {
      localObject = new it(paramke, localbq1);
    }
    else if ("ECDSA".equalsIgnoreCase(paramArrayOfString[1]))
    {
      localObject = new is();
    }
    else if ("DSA".equalsIgnoreCase(paramArrayOfString[1]))
    {
      localObject = new iq();
    }
    else if ("X931RSA".equalsIgnoreCase(paramArrayOfString[1]))
    {
      if (localbq1.getAlg().startsWith("NoDigest"))
      {
        if (paramArrayOfString.length == 3) {
          localObject = new ix(paramke, b(paramArrayOfString[2], paramke));
        } else {
          localObject = new ix(paramke);
        }
      }
      else
      {
        if (!ix.a(localbq1)) {
          throw new NoSuchAlgorithmException(localbq1.getAlg() + " not supported with X9.31RSA");
        }
        localObject = new ix(paramke, localbq1);
      }
    }
    else if ("RSAPSS".equalsIgnoreCase(paramArrayOfString[1]))
    {
      if (!paramArrayOfString[2].equalsIgnoreCase("MGF1")) {
        throw new NoSuchAlgorithmException(paramArrayOfString[2]);
      }
      bq localbq2 = b(paramArrayOfString[3], paramke);
      bq localbq3 = null;
      if (localbq1.getAlg().startsWith("NoDigest")) {
        localbq3 = localbq2;
      } else {
        localbq3 = localbq1;
      }
      localObject = new iu(paramke, localbq3, localbq2);
    }
    else if ("RawRSA".equalsIgnoreCase(paramArrayOfString[1]))
    {
      localObject = new g(paramke);
    }
    else
    {
      throw new NoSuchAlgorithmException(paramArrayOfString[1]);
    }
    return new iv(paramke, (iw)localObject, localbq1);
  }
  
  public static KeyGenerator d(String paramString, ke paramke)
  {
    if ("AES".equalsIgnoreCase(paramString)) {
      return new iz.a(paramke);
    }
    if ("DESede".equalsIgnoreCase(paramString)) {
      return new iz.d(paramke);
    }
    if ("HMAC".equalsIgnoreCase(paramString)) {
      return new iz.e(paramke);
    }
    if ("SSS".equalsIgnoreCase(paramString)) {
      return new in(paramke);
    }
    if ("RC4".equalsIgnoreCase(paramString)) {
      return new iz.g(paramke);
    }
    if ("RC2".equalsIgnoreCase(paramString)) {
      return new iz.f(paramke);
    }
    if ("DES".equalsIgnoreCase(paramString)) {
      return new iz.b(paramke);
    }
    if ("RC5".equalsIgnoreCase(paramString)) {
      return new iz.h(paramke);
    }
    if ("DESX".equalsIgnoreCase(paramString)) {
      return new iz.c(paramke);
    }
    throw new NoSuchAlgorithmException(paramString);
  }
  
  public static Cipher e(String[] paramArrayOfString, ke paramke)
  {
    if (paramArrayOfString.length == 0) {
      throw new NoSuchAlgorithmException("Invalid transformation string");
    }
    Object localObject;
    if ("RSA".equalsIgnoreCase(paramArrayOfString[0]))
    {
      if (paramArrayOfString.length == 1) {
        throw new NoSuchAlgorithmException("RSA requires a padding mode");
      }
      localObject = new g(paramke);
      if (("OAEP".equalsIgnoreCase(paramArrayOfString[1])) && (paramArrayOfString.length == 5)) {
        return a(paramArrayOfString, (bc)localObject, paramke);
      }
      if ((paramArrayOfString.length >= 2) && ("KEMKWS".equalsIgnoreCase(paramArrayOfString[1]))) {
        return c(paramArrayOfString, (bc)localObject, paramke);
      }
      if ((paramArrayOfString.length == 2) || (paramArrayOfString.length == 3)) {
        return b(paramArrayOfString, (bc)localObject, paramke);
      }
      throw new NoSuchAlgorithmException("Invalid RSA transformation string");
    }
    if ("ECIES".equalsIgnoreCase(paramArrayOfString[0]))
    {
      if ((paramArrayOfString[2].indexOf("SHA") != 0) || (paramArrayOfString[3].indexOf("SHA") != 0) || (paramArrayOfString[4].indexOf("ECDH") != 0)) {
        throw new NoSuchAlgorithmException("Invalid algorithm for EC cipher.");
      }
      localObject = b(paramArrayOfString[2], paramke);
      bq localbq = b(paramArrayOfString[3], paramke);
      KeyAgreement localKeyAgreement = a(paramArrayOfString[4], paramke);
      if ("XOR".equalsIgnoreCase(paramArrayOfString[1])) {
        return new f(paramke, (MessageDigest)localObject, new bp(paramke, localbq), localKeyAgreement);
      }
      SymmCipher localSymmCipher = f(new String[] { paramArrayOfString[1], "CBC", "PKCS5Pad" }, paramke);
      int i = Integer.parseInt(paramArrayOfString[5]);
      return new e(paramke, (MessageDigest)localObject, new bp(paramke, localbq), localSymmCipher, localKeyAgreement, i / 8);
    }
    throw new NoSuchAlgorithmException(paramArrayOfString[0]);
  }
  
  private static Cipher a(String[] paramArrayOfString, bc parambc, ke paramke)
  {
    bq localbq1 = b(paramArrayOfString[2], paramke);
    if (!"MGF1".equalsIgnoreCase(paramArrayOfString[3])) {
      throw new NoSuchAlgorithmException(paramArrayOfString[3]);
    }
    bq localbq2 = b(paramArrayOfString[4], paramke);
    am localam = new am(localbq1, new ia(localbq2));
    return a((g)parambc, localam, paramke);
  }
  
  private static Cipher b(String[] paramArrayOfString, bc parambc, ke paramke)
  {
    Object localObject;
    if ("NoPad".equalsIgnoreCase(paramArrayOfString[1])) {
      localObject = null;
    } else if ("PKCS1".equalsIgnoreCase(paramArrayOfString[1])) {
      localObject = new ak();
    } else if ("PKCS1BlockSSLPad".equalsIgnoreCase(paramArrayOfString[1])) {
      localObject = new al();
    } else {
      throw new NoSuchAlgorithmException("Padding mode, " + paramArrayOfString[1] + ", is not supported");
    }
    return a((g)parambc, (ao)localObject, paramke);
  }
  
  private static Cipher a(g paramg, ao paramao, ke paramke)
  {
    i locali = new i(paramke);
    locali.a(paramg);
    locali.a(paramao);
    return locali;
  }
  
  public static SymmCipher f(String[] paramArrayOfString, ke paramke)
  {
    if ("PBE".equalsIgnoreCase(paramArrayOfString[0])) {
      return g(paramArrayOfString, paramke);
    }
    if ("RC4".equalsIgnoreCase(paramArrayOfString[0])) {
      return new bi(paramke);
    }
    if (paramArrayOfString.length < 3) {
      throw new NoSuchAlgorithmException("Invalid transformation string");
    }
    bc localbc = f(paramArrayOfString[0]);
    ao localao = g(paramArrayOfString[2], paramke);
    n localn = a(paramArrayOfString[1], localbc, localao, paramke);
    localn.a(localbc);
    localn.a(localao);
    return localn;
  }
  
  public static Cipher e(String paramString, ke paramke)
  {
    Object localObject;
    if ("AESKeyWrapRFC3394".equalsIgnoreCase(paramString)) {
      localObject = new az();
    } else if ("AESKeyWrapRFC5649".equalsIgnoreCase(paramString)) {
      localObject = new ba();
    } else {
      throw new NoSuchAlgorithmException(paramString);
    }
    return new ac(paramke, (bg)localObject);
  }
  
  private static av f(String paramString, ke paramke)
  {
    if ("PKCS12".equalsIgnoreCase(paramString))
    {
      ar localar = new ar();
      localar.a(false);
      return localar;
    }
    if ("PKIX".equalsIgnoreCase(paramString)) {
      return new au();
    }
    throw new NoSuchAlgorithmException(paramString);
  }
  
  private static SymmCipher g(String[] paramArrayOfString, ke paramke)
  {
    bq localbq = b(paramArrayOfString[2], paramke);
    Object localObject1;
    if ("PKCS12".equalsIgnoreCase(paramArrayOfString[1]))
    {
      localObject1 = new ar();
    }
    else if ("PKCS5V2".equalsIgnoreCase(paramArrayOfString[1]))
    {
      bp localbp = new bp(paramke, localbq);
      localObject1 = new at(localbp);
    }
    else if ("PKCS5".equalsIgnoreCase(paramArrayOfString[1]))
    {
      localObject1 = new as();
    }
    else if ("SSLCPBE".equalsIgnoreCase(paramArrayOfString[1]))
    {
      localObject1 = new ax();
    }
    else
    {
      throw new NoSuchAlgorithmException(paramArrayOfString[1]);
    }
    int i;
    Object localObject2;
    if ("RC4".equalsIgnoreCase(paramArrayOfString[3]))
    {
      i = Integer.parseInt(paramArrayOfString[4]);
      localObject2 = new bi(paramke);
    }
    else
    {
      bc localbc = f(paramArrayOfString[3]);
      an localan = new an();
      localObject2 = a(paramArrayOfString[4], localbc, localan, paramke);
      ((ae)localObject2).a(localan);
      ((ae)localObject2).a(localbc);
      i = Integer.parseInt(paramArrayOfString[5]);
    }
    return new ap(paramke, (SymmCipher)localObject2, (av)localObject1, localbq, i);
  }
  
  private static ao g(String paramString, ke paramke)
  {
    if ("NoPad".equalsIgnoreCase(paramString)) {
      return null;
    }
    if ("PKCS5Pad".equalsIgnoreCase(paramString)) {
      return new an();
    }
    if ("ISO10126Pad".equalsIgnoreCase(paramString)) {
      return new aj();
    }
    throw new NoSuchAlgorithmException("Unsupported padding " + paramString);
  }
  
  private static n a(String paramString, bc parambc, ao paramao, ke paramke)
  {
    if ("ECB".equalsIgnoreCase(paramString)) {
      return new y(paramke);
    }
    if ("CBC".equalsIgnoreCase(paramString)) {
      return new q(paramke);
    }
    if ("GCM".equalsIgnoreCase(paramString)) {
      return new z(paramke);
    }
    if ("CBC_CS1".equalsIgnoreCase(paramString)) {
      return new r(paramke);
    }
    if ("CBC_CS2".equalsIgnoreCase(paramString)) {
      return new s(paramke);
    }
    if ("CBC_CS3".equalsIgnoreCase(paramString)) {
      return new t(paramke);
    }
    if ("CTR".equalsIgnoreCase(paramString)) {
      return new x(paramke);
    }
    if ("CCM".equalsIgnoreCase(paramString)) {
      return new u(paramke);
    }
    if ("XTS".equalsIgnoreCase(paramString))
    {
      if ((paramao != null) && (!paramao.getAlg().equals("NoPad"))) {
        throw new NoSuchAlgorithmException("Padding should be null.");
      }
      return new ah(paramke);
    }
    if ("BPS".equalsIgnoreCase(paramString)) {
      return new o(paramke);
    }
    String[] arrayOfString = im.a(paramString, "-");
    int i = arrayOfString.length == 2 ? Integer.parseInt(arrayOfString[1]) : 0;
    Object localObject;
    if ("CFB".equalsIgnoreCase(arrayOfString[0]))
    {
      if (i == 0) {
        i = parambc.getBlockSize() * 8;
      }
      localObject = new w(paramke, i);
      if (paramao != null) {
        return new ag(paramke, (af)localObject);
      }
      return localObject;
    }
    if ("OFB".equalsIgnoreCase(arrayOfString[0]))
    {
      localObject = new ad(paramke, i);
      if (paramao != null) {
        return new ag(paramke, (af)localObject);
      }
      return localObject;
    }
    throw new NoSuchAlgorithmException("Unsupported mode " + paramString);
  }
  
  private static bc f(String paramString)
  {
    if ("AES".equalsIgnoreCase(paramString)) {
      return new ay();
    }
    if ("DESede".equalsIgnoreCase(paramString)) {
      return new bf();
    }
    if ("DES".equalsIgnoreCase(paramString)) {
      return new bd();
    }
    if ("RC2".equalsIgnoreCase(paramString)) {
      return new bh();
    }
    if ("RC5".equalsIgnoreCase(paramString)) {
      return new bj();
    }
    if ("DESX".equalsIgnoreCase(paramString)) {
      return new be();
    }
    throw new NoSuchAlgorithmException("Unsupported cipher " + paramString);
  }
  
  private static bq a(int paramInt, ke paramke)
  {
    switch (paramInt)
    {
    case 128: 
      return new bw(paramke);
    case 192: 
      return new bx(paramke);
    case 256: 
      return new by(paramke);
    }
    return new by(paramke);
  }
  
  public static AlgParamGenerator h(String paramString, ke paramke)
  {
    if ("DSA".equalsIgnoreCase(paramString)) {
      return new ik(paramke);
    }
    throw new NoSuchAlgorithmException("Unsupported algorithm parameter generator " + paramString);
  }
  
  public static KeyConfirmation h(String[] paramArrayOfString, ke paramke)
  {
    if ((paramArrayOfString.length < 3) || (paramArrayOfString.length > 4)) {
      throw new NoSuchAlgorithmException("Unsupported Key Confirmation algorithm string " + Arrays.deepToString(paramArrayOfString));
    }
    fo localfo = fo.valueOf(paramArrayOfString[0]);
    fp localfp = fp.valueOf(paramArrayOfString[1]);
    if (localfo == null) {
      throw new NoSuchAlgorithmException("Unsupported Key Confirmation Party " + paramArrayOfString[0]);
    }
    if (localfp == null) {
      throw new NoSuchAlgorithmException("Unsupported Key Confirmation Direction " + paramArrayOfString[1]);
    }
    bq localbq = b(paramArrayOfString[2], paramke);
    bp localbp = new bp(paramke, localbq);
    if (paramArrayOfString.length == 3) {
      return new fq(localfo, localfp, localbp, paramke);
    }
    try
    {
      int i = Integer.valueOf(paramArrayOfString[3]).intValue();
      return new fq(localfo, localfp, localbp, i / 8, paramke);
    }
    catch (NumberFormatException localNumberFormatException)
    {
      throw new NoSuchAlgorithmException("Unsupported macTagBits" + paramArrayOfString[3]);
    }
  }
  
  private static Cipher c(String[] paramArrayOfString, bc parambc, ke paramke)
  {
    KDF localKDF = null;
    Object localObject = null;
    if (paramArrayOfString.length < 5) {
      throw new NoSuchAlgorithmException("Invalid RSA-KEM-KWS transformation string");
    }
    Cipher localCipher = b(new String[] { "RSA", "NoPad" }, parambc, paramke);
    int i;
    if ("SSKDF".equalsIgnoreCase(paramArrayOfString[2]))
    {
      i = 4;
      localKDF = c(new String[] { "SSKDF", paramArrayOfString[3] }, paramke);
    }
    else
    {
      throw new NoSuchAlgorithmException("Invalid RSA-KEM-KWS transformation string");
    }
    if (paramArrayOfString.length <= i) {
      throw new NoSuchAlgorithmException("Invalid RSA-KEM-KWS transformation string");
    }
    if (("AESKeyWrapRFC3394".equalsIgnoreCase(paramArrayOfString[i])) || ("AESKeyWrapRFC5649".equalsIgnoreCase(paramArrayOfString[i])))
    {
      localObject = e(paramArrayOfString[i], paramke);
    }
    else if ("AES".equalsIgnoreCase(paramArrayOfString[i]))
    {
      if (paramArrayOfString.length <= i + 2) {
        throw new NoSuchAlgorithmException("Invalid RSA-KEM-KWS transformation string");
      }
      if ("CCM".equalsIgnoreCase(paramArrayOfString[(i + 1)])) {
        localObject = f((String[])Arrays.copyOfRange(paramArrayOfString, i, i + 3), paramke);
      }
    }
    else
    {
      throw new NoSuchAlgorithmException("Invalid RSA-KEM-KWS transformation string");
    }
    return new j(paramke, localCipher, localKDF, (Cipher)localObject);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.il
 * JD-Core Version:    0.7.0.1
 */