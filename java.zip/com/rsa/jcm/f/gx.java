package com.rsa.jcm.f;

class gx
  extends gy
{
  gx(gk paramgk, ic paramic)
  {
    super(paramgk, paramic);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gx
 * JD-Core Version:    0.7.0.1
 */