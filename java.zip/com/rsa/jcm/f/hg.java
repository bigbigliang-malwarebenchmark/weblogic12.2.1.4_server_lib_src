package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import java.util.Arrays;

public final class hg
{
  static final int[] nF = { 2, 4, 10, 12, 18, 28, 36, 52, 58, 60, 66, 82, 100, 106, 130, 138, 148, 162, 172, 178, 180, 196, 210, 226, 268, 292, 316, 346, 348, 372, 378, 388, 418, 420, 442, 460, 466, 490, 508, 522, 540, 546, 556, 562, 586 };
  static final int[] nG = { 2, 3, 5, 6, 9, 11, 14, 18, 23, 26, 29, 30, 33, 35, 39, 41, 50, 51, 53, 65, 69, 74, 81, 83, 86, 89, 90, 95, 98, 99, 105, 113, 119, 131, 134, 135, 146, 155, 158, 173, 174, 179, 183, 186, 189, 191, 194, 209, 210, 221, 230, 231, 233, 239, 243, 245, 251, 254, 261, 270, 273, 278, 281, 293, 299, 303, 306, 309, 323, 326, 329, 330, 338, 350, 354, 359, 371, 375, 378, 386, 393, 398, 410, 411, 413, 413, 419, 426, 429, 431, 438, 441, 443, 453, 470, 473, 483, 491, 495, 509, 515, 519, 530, 531, 543, 545, 554, 558, 561, 575, 585, 593 };
  
  public static boolean x(int paramInt)
  {
    return (Arrays.binarySearch(nF, 0, nF.length, paramInt) > 0) || (Arrays.binarySearch(nG, 0, nG.length, paramInt) > 0);
  }
  
  static ic d(hc paramhc)
  {
    int i = paramhc.getFieldSize();
    int j = Arrays.binarySearch(nG, 0, nG.length, i);
    if (j >= 0) {
      return y(i);
    }
    j = Arrays.binarySearch(nF, 0, nF.length, i);
    if (j >= 0)
    {
      int k = i + 1;
      int m = gn.s(k);
      int[] arrayOfInt = new int[m];
      int n = gn.u(k);
      Arrays.fill(arrayOfInt, -1);
      int tmp79_78 = (arrayOfInt.length - 1);
      int[] tmp79_72 = arrayOfInt;
      tmp79_72[tmp79_78] = ((int)(tmp79_72[tmp79_78] & (-4294967296L >> 32 - n ^ 0xFFFFFFFF)));
      return ic.d(arrayOfInt);
    }
    throw new CryptoException("No ONB Representation where m = " + i + ".");
  }
  
  private static ic y(int paramInt)
  {
    ic localic = ic.cL();
    ic[] arrayOfic = new ic[3];
    arrayOfic[0] = ic.cL();
    arrayOfic[1] = ic.cL();
    arrayOfic[2] = ic.cL();
    localic.setValue(2);
    arrayOfic[0].setValue(1);
    arrayOfic[1].setValue(3);
    for (int i = 0; i < paramInt - 1; i++)
    {
      localic.a(arrayOfic[((i + 1) % 3)], arrayOfic[((i + 2) % 3)]);
      arrayOfic[((i + 2) % 3)].e(arrayOfic[(i % 3)]);
    }
    return arrayOfic[(paramInt % 3)];
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hg
 * JD-Core Version:    0.7.0.1
 */