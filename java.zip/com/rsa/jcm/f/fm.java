package com.rsa.jcm.f;

import com.rsa.crypto.ECParams;
import com.rsa.crypto.ECPrivateKey;
import com.rsa.crypto.ECPublicKey;
import com.rsa.crypto.InvalidKeyException;
import com.rsa.crypto.Key;
import com.rsa.crypto.KeyAgreement;

public class fm
  extends cl
  implements KeyAgreement
{
  protected static final String kK = "Key agreement has not been performed.";
  protected id kL;
  protected ECParams ki;
  protected gi kM;
  
  public fm(ke paramke)
  {
    super(paramke);
  }
  
  public Key doPhase(Key paramKey, boolean paramBoolean)
    throws InvalidKeyException
  {
    if (this.kL == null) {
      throw new IllegalStateException("Object has not been initialized.");
    }
    if (!(paramKey instanceof ECPublicKey)) {
      throw new InvalidKeyException("Expected public key of type EC.");
    }
    ECPublicKey localECPublicKey = (ECPublicKey)paramKey;
    if (!localECPublicKey.getParams().equals(this.ki)) {
      throw new InvalidKeyException("EC public key contained wrong point.");
    }
    a(localECPublicKey);
    this.kM = a((gi)localECPublicKey.getPublicPoint());
    if (!paramBoolean) {
      return new ff(this.an, (gi)this.kM.clone(), this.ki);
    }
    return null;
  }
  
  protected gi a(gi paramgi)
  {
    return paramgi.g(this.kL);
  }
  
  public byte[] getSecret()
  {
    if (this.kM == null) {
      throw new IllegalStateException("Key agreement has not been performed.");
    }
    int i = this.kM.br().ba().bO();
    byte[] arrayOfByte = this.kM.br().q(i);
    reset();
    return arrayOfByte;
  }
  
  public int getSecret(byte[] paramArrayOfByte, int paramInt)
  {
    if (this.kM == null) {
      throw new IllegalStateException("Key agreement has not been performed.");
    }
    int i = this.kM.br().w(paramArrayOfByte, paramInt);
    reset();
    return i;
  }
  
  public void init(Key paramKey)
    throws InvalidKeyException
  {
    if (!(paramKey instanceof ECPrivateKey)) {
      throw new InvalidKeyException("Expected private key of type EC.");
    }
    ECPrivateKey localECPrivateKey = (ECPrivateKey)paramKey;
    ECParams localECParams = localECPrivateKey.getParams();
    this.kL = ((id)localECPrivateKey.getD());
    this.ki = localECParams;
  }
  
  protected void a(ECPublicKey paramECPublicKey)
  {
    if (!((gi)paramECPublicKey.getPublicPoint()).bx()) {
      throw new InvalidKeyException("EC public key contained invalid point.");
    }
  }
  
  protected void reset()
  {
    er.a(this.kM);
    this.kM = null;
  }
  
  public void clearSensitiveData()
  {
    this.kL = null;
    this.ki = null;
    reset();
  }
  
  public String getAlg()
  {
    return "ECDH";
  }
  
  public Object clone()
  {
    fm localfm = (fm)super.clone();
    localfm.kL = ((id)es.a(this.kL));
    localfm.kM = ((gi)es.a(this.kM));
    localfm.ki = this.ki;
    return localfm;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fm
 * JD-Core Version:    0.7.0.1
 */