package com.rsa.jcm.f;

import com.rsa.crypto.CryptoModule;
import com.rsa.crypto.ECParams;
import com.rsa.crypto.KeyBuilder;
import com.rsa.crypto.SensitiveData;

public final class ea
  extends eh
{
  private static final String iH = "ECDH KAT failed";
  private static final byte[][] iO = { jb.hexStringToByteArray("03"), jb.hexStringToByteArray("5ecbe4d1a6330a44c8f7ef951d4bf165e6c6b721efada985fb41661bc6e7fd6c") };
  
  public ea()
  {
    super(1);
  }
  
  public String getName()
  {
    return "ECDH";
  }
  
  public String aH()
  {
    return "ECDH KAT failed";
  }
  
  boolean n(int paramInt)
    throws Exception
  {
    id localid = null;
    gi localgi1 = null;
    try
    {
      localid = new id(iO[0]);
      ECParams localECParams = this.ip.getKeyBuilder().newECParams("P256");
      gi localgi2 = (gi)localECParams.getBase();
      localgi1 = localgi2.g(localid);
      boolean bool = ja.c(iO[1], localgi1.getX());
      return bool;
    }
    finally
    {
      er.a(new SensitiveData[] { localid, localgi1 });
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ea
 * JD-Core Version:    0.7.0.1
 */