package com.rsa.jcm.f;

public class je
{
  public static <T> boolean a(T... paramVarArgs)
  {
    if (paramVarArgs == null) {
      return true;
    }
    for (T ? : paramVarArgs) {
      if (? == null) {
        return true;
      }
    }
    return false;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.je
 * JD-Core Version:    0.7.0.1
 */