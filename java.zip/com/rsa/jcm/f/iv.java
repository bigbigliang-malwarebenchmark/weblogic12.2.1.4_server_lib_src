package com.rsa.jcm.f;

import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.InvalidKeyException;
import com.rsa.crypto.MessageDigest;
import com.rsa.crypto.PrivateKey;
import com.rsa.crypto.PublicKey;
import com.rsa.crypto.SecureRandom;
import com.rsa.crypto.Signature;
import com.rsa.crypto.SignatureException;

public class iv
  extends cl
  implements Signature
{
  private static final String pQ = "Signature was not initialized for verification";
  static final String pR = "Signature verify failed.";
  private static final String pS = "Signature was not initialized for signing";
  private iw pT;
  private MessageDigest pG;
  
  public iv(ke paramke, iw paramiw, MessageDigest paramMessageDigest)
  {
    super(paramke);
    this.pT = paramiw;
    this.pG = paramMessageDigest;
  }
  
  public void initSign(PrivateKey paramPrivateKey)
    throws InvalidKeyException
  {
    this.pT.a(paramPrivateKey);
    this.pG.reset();
  }
  
  public void initSign(PrivateKey paramPrivateKey, AlgorithmParams paramAlgorithmParams)
    throws InvalidKeyException, InvalidAlgorithmParameterException
  {
    initSign(paramPrivateKey);
    this.pT.setAlgorithmParams(paramAlgorithmParams);
  }
  
  public void initSign(PrivateKey paramPrivateKey, SecureRandom paramSecureRandom)
    throws InvalidKeyException
  {
    initSign(paramPrivateKey);
    this.pT.a(paramSecureRandom);
  }
  
  public void initSign(PrivateKey paramPrivateKey, AlgorithmParams paramAlgorithmParams, SecureRandom paramSecureRandom)
    throws InvalidKeyException, InvalidAlgorithmParameterException
  {
    initSign(paramPrivateKey);
    this.pT.a(paramSecureRandom);
    this.pT.setAlgorithmParams(paramAlgorithmParams);
  }
  
  public void initVerify(PublicKey paramPublicKey)
    throws InvalidKeyException
  {
    this.pT.a(paramPublicKey);
    this.pG.reset();
  }
  
  public void initVerify(PublicKey paramPublicKey, AlgorithmParams paramAlgorithmParams)
    throws InvalidKeyException, InvalidAlgorithmParameterException
  {
    initVerify(paramPublicKey);
    this.pT.setAlgorithmParams(paramAlgorithmParams);
  }
  
  public void reInit(AlgorithmParams paramAlgorithmParams)
  {
    if (!this.pT.initialized()) {
      throw new IllegalStateException("Object has not been initialized.");
    }
    this.pG.reset();
    this.pT.setAlgorithmParams(paramAlgorithmParams);
  }
  
  public byte[] sign()
    throws SignatureException
  {
    if (!this.pT.e()) {
      throw new IllegalStateException("Signature was not initialized for signing");
    }
    int i = this.pT.getSignatureSize();
    byte[] arrayOfByte1 = new byte[i];
    int j = sign(arrayOfByte1, 0);
    if (j < arrayOfByte1.length)
    {
      byte[] arrayOfByte2 = new byte[j];
      System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, j);
      er.w(arrayOfByte1);
      return arrayOfByte2;
    }
    return arrayOfByte1;
  }
  
  public int sign(byte[] paramArrayOfByte, int paramInt)
    throws SignatureException
  {
    if (!this.pT.e()) {
      throw new IllegalStateException("Signature was not initialized for signing");
    }
    byte[] arrayOfByte = new byte[this.pG.getDigestSize()];
    int i = this.pG.digest(arrayOfByte, 0);
    try
    {
      int j = this.pT.d(arrayOfByte, 0, i, paramArrayOfByte, paramInt);
      return j;
    }
    finally
    {
      er.w(arrayOfByte);
    }
  }
  
  public void update(byte[] paramArrayOfByte)
    throws SignatureException
  {
    update(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void update(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws SignatureException
  {
    if (!this.pT.initialized()) {
      throw new IllegalStateException("Object has not been initialized.");
    }
    if (paramInt2 <= 0) {
      return;
    }
    this.pG.update(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public boolean verify(byte[] paramArrayOfByte)
    throws SignatureException
  {
    return verify(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public boolean verify(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws SignatureException
  {
    if (!this.pT.f()) {
      throw new IllegalStateException("Signature was not initialized for verification");
    }
    byte[] arrayOfByte = new byte[this.pG.getDigestSize()];
    this.pG.digest(arrayOfByte, 0);
    try
    {
      boolean bool1 = this.pT.a(arrayOfByte, 0, arrayOfByte.length, paramArrayOfByte, paramInt1, paramInt2);
      return bool1;
    }
    catch (SignatureException localSignatureException)
    {
      boolean bool2 = false;
      return bool2;
    }
    finally
    {
      er.w(arrayOfByte);
    }
  }
  
  public void clearSensitiveData()
  {
    er.a(this.pG);
    er.a(this.pT);
  }
  
  public String getAlg()
  {
    return this.pG.getAlg() + "/" + this.pT.getAlg();
  }
  
  public int getSignatureSize()
  {
    return this.pT.getSignatureSize();
  }
  
  public Object clone()
  {
    iv localiv = (iv)super.clone();
    localiv.pT = ((iw)es.a(this.pT));
    localiv.pG = ((MessageDigest)es.a(this.pG));
    return localiv;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.iv
 * JD-Core Version:    0.7.0.1
 */