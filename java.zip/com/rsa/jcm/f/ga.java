package com.rsa.jcm.f;

import java.io.Serializable;

public abstract interface ga
  extends Serializable
{
  public abstract void z(byte[] paramArrayOfByte);
  
  public abstract gi d(id paramid);
  
  public abstract gi aY();
  
  public abstract void aZ();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ga
 * JD-Core Version:    0.7.0.1
 */