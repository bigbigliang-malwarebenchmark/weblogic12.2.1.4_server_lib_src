package com.rsa.jcm.f;

import com.rsa.crypto.BigNum;
import com.rsa.crypto.PQGParams;

public class fg
  extends cl
  implements PQGParams
{
  private final BigNum kn;
  private final BigNum ko;
  private final BigNum kp;
  
  public fg(ke paramke, BigNum paramBigNum1, BigNum paramBigNum2, BigNum paramBigNum3)
  {
    super(paramke);
    this.ko = paramBigNum1;
    this.kp = paramBigNum3;
    this.kn = paramBigNum2;
  }
  
  public fg(ke paramke, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    super(paramke);
    this.ko = (paramArrayOfByte1 == null ? null : new id(paramArrayOfByte1));
    this.kn = (paramArrayOfByte2 == null ? null : new id(paramArrayOfByte2));
    this.kp = (paramArrayOfByte3 == null ? null : new id(paramArrayOfByte3));
  }
  
  public BigNum getQ()
  {
    return this.kn;
  }
  
  public BigNum getP()
  {
    return this.ko;
  }
  
  public BigNum getG()
  {
    return this.kp;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fg
 * JD-Core Version:    0.7.0.1
 */