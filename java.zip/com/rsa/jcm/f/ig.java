package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;

public class ig
{
  public static final int oG = 0;
  public static final int oH = 1;
  private static final int oI = 8192;
  private static final int[] oC = { 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251 };
  private static final int LAST_INDEX = 52;
  private static final int oJ = 65521;
  private static final int oK = 256;
  private byte[] oL;
  
  public static ig s(id paramid1, id paramid2)
    throws CryptoException
  {
    return d(paramid1, new id(), new id(), new id(), paramid2);
  }
  
  public static ig d(id paramid1, id paramid2, id paramid3, id paramid4, id paramid5)
    throws CryptoException
  {
    return new ig(paramid1, paramid2, paramid3, paramid4, paramid5);
  }
  
  void e(id paramid1, id paramid2, id paramid3, id paramid4, id paramid5)
    throws CryptoException
  {
    Z(256);
    int[] arrayOfInt = new int[2];
    int i;
    do
    {
      e(arrayOfInt);
      i = arrayOfInt[0];
      paramid2.setValue(i);
      paramid1.j(paramid2, paramid3);
      int j = paramid3.intValue();
      int k = 0;
      if (j != 0) {
        if (paramid5 != null) {
          k = a(paramid5, paramid2, paramid4, i, j, length() - 1);
        } else if ((j & 0x1) == 1) {
          k = (i - j) / 2;
        } else {
          k = i - j / 2;
        }
      }
      while (k < length())
      {
        set(k);
        k += i;
      }
    } while ((i < 65521) && (i > 0));
  }
  
  public void Z(int paramInt)
  {
    this.oL = new byte[paramInt];
  }
  
  public int length()
  {
    return this.oL.length;
  }
  
  public boolean isSet(int paramInt)
  {
    return this.oL[paramInt] != 0;
  }
  
  public void set(int paramInt)
  {
    this.oL[paramInt] = 1;
  }
  
  static void e(int[] paramArrayOfInt)
  {
    if (paramArrayOfInt[1] > 52)
    {
      if (paramArrayOfInt[0] < 65521)
      {
        int i = paramArrayOfInt[0] + 2;
        do
        {
          for (int j = 0; (j <= 52) && (i % oC[j] != 0); j++) {}
          if (j > 52)
          {
            paramArrayOfInt[0] = i;
            return;
          }
          i += 2;
        } while (i <= 65521);
      }
      paramArrayOfInt[0] = 0;
      paramArrayOfInt[1] = 0;
      return;
    }
    paramArrayOfInt[0] = oC[paramArrayOfInt[1]];
    paramArrayOfInt[1] += 1;
  }
  
  private static int a(id paramid1, id paramid2, id paramid3, int paramInt1, int paramInt2, int paramInt3)
  {
    try
    {
      paramid1.j(paramid2, paramid3);
      byte[] arrayOfByte = paramid3.toOctetString();
      int i = 0;
      for (int j = 0; j < arrayOfByte.length; j++) {
        i = (i << 8) + (arrayOfByte[j] & 0xFF);
      }
      j = 1;
      paramInt2 = (paramInt2 + i) % paramInt1;
      while ((paramInt2 != 0) && (j <= paramInt3))
      {
        paramInt2 = (paramInt2 + i) % paramInt1;
        j++;
      }
      return j;
    }
    catch (CryptoException localCryptoException) {}
    return paramInt3 + 1;
  }
  
  ig(id paramid1, id paramid2, id paramid3, id paramid4, id paramid5)
    throws CryptoException
  {
    e(paramid1, paramid2, paramid3, paramid4, paramid5);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ig
 * JD-Core Version:    0.7.0.1
 */