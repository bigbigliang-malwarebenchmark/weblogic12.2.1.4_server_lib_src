package com.rsa.jcm.f;

final class hd
{
  static int[][] a(hc paramhc)
  {
    int i = paramhc.getFieldSize();
    int j = paramhc.co();
    int k = paramhc.cc();
    int m = i / 4 * 4;
    int n = gn.u(i);
    int i1 = gn.t(i);
    int i2 = 1 << n;
    int[] arrayOfInt1 = paramhc.ck().cH();
    int[] arrayOfInt2 = new int[k];
    System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, k);
    int i3 = (j + 1) * 16;
    int[][] arrayOfInt = new int[i3][k];
    for (int i4 = 0; i4 <= j; i4++)
    {
      if (n != 0) {
        arrayOfInt2[i1] &= i2 - 1;
      }
      for (int i5 = i4 == 0 ? i - m : 0; i5 < 4; i5++)
      {
        int i6 = (i4 << 4) + (1 << i5);
        System.arraycopy(arrayOfInt2, 0, arrayOfInt[i6], 0, k);
        for (int i7 = 1; i7 < 1 << i5; i7++)
        {
          int i8 = (i4 << 4) + i7;
          for (int i9 = 0; i9 < arrayOfInt2.length; i9++) {
            arrayOfInt[(i6 + i7)][i9] = (arrayOfInt2[i9] ^ arrayOfInt[i8][i9]);
          }
        }
        i7 = ih.a(arrayOfInt2, k - 1, 1, arrayOfInt2);
        if (((n == 0) && (i7 != 0)) || ((n != 0) && ((arrayOfInt2[i1] & i2) != 0))) {
          for (i7 = 0; i7 < k; i7++) {
            arrayOfInt2[i7] ^= arrayOfInt1[i7];
          }
        }
      }
    }
    return arrayOfInt;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hd
 * JD-Core Version:    0.7.0.1
 */