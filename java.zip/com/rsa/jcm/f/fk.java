package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.SharedSecretKey;

public class fk
  extends di
  implements SharedSecretKey
{
  protected byte[] kA;
  protected byte[][] kB;
  protected byte[] kC;
  
  public fk(ke paramke, byte[] paramArrayOfByte1, byte[][] paramArrayOfByte, byte[] paramArrayOfByte2)
  {
    super(paramke, null, 0, 0, "SSS");
    this.kA = es.x(paramArrayOfByte1);
    this.kB = es.b(paramArrayOfByte);
    this.kC = es.x(paramArrayOfByte2);
  }
  
  public AlgorithmParams getSharedParams()
  {
    ii localii = new ii(this.an);
    localii.set("modulus", es.x(this.kA));
    localii.set("yData", es.b(this.kB));
    if (this.kC != null) {
      localii.set("digestData", es.x(this.kC));
    }
    return localii;
  }
  
  public void clearSensitiveData()
  {
    super.clearSensitiveData();
    er.w(this.kA);
    er.a(this.kB);
    er.w(this.kC);
  }
  
  public Object clone()
  {
    fk localfk = (fk)super.clone();
    localfk.kA = ((byte[])es.x(this.kA));
    localfk.kB = ((byte[][])es.b(this.kB));
    localfk.kC = ((byte[])es.x(this.kC));
    return localfk;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fk
 * JD-Core Version:    0.7.0.1
 */