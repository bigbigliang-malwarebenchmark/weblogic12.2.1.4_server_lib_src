package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.InvalidKeyException;
import com.rsa.crypto.KDF;
import com.rsa.crypto.Key;
import com.rsa.crypto.MessageDigest;
import com.rsa.crypto.SecretKey;

public class ez
  extends cl
  implements KDF
{
  private static final String KEY_ALG = "SSKDF";
  MessageDigest jX;
  
  public ez(ke paramke, MessageDigest paramMessageDigest)
  {
    super(paramke);
    this.jX = paramMessageDigest;
  }
  
  public SecretKey generate(Key paramKey, AlgorithmParams paramAlgorithmParams)
    throws InvalidAlgorithmParameterException, InvalidKeyException
  {
    if (paramKey == null) {
      paramKey = new di(this.an, new byte[0], 0, 0);
    }
    if (!(paramKey instanceof SecretKey)) {
      throw new InvalidKeyException("Key invalid for algorithm. Expected SecretKey");
    }
    if (!(paramAlgorithmParams instanceof AlgInputParams)) {
      throw new InvalidAlgorithmParameterException("Parameters object invalid for algorithm.");
    }
    SecretKey localSecretKey = (SecretKey)paramKey;
    AlgInputParams localAlgInputParams = (AlgInputParams)paramAlgorithmParams;
    byte[] arrayOfByte1 = ij.a(localAlgInputParams, "info", new byte[0]);
    int i = (ij.c(localAlgInputParams, "keyBits") + 7) / 8;
    if (i <= 0) {
      throw new InvalidAlgorithmParameterException("Invalid input for length of output keying material");
    }
    int j = this.jX.getDigestSize();
    int k = (i + j - 1) / j;
    byte[] arrayOfByte2 = localSecretKey.getKeyData();
    if (arrayOfByte2 == null) {
      throw new InvalidKeyException("Key invalid for algorithm.");
    }
    byte[] arrayOfByte3 = new byte[j * k];
    try
    {
      for (int m = 0; m < k; m++)
      {
        byte[] arrayOfByte4 = jb.ak(m + 1);
        this.jX.update(arrayOfByte4, 0, arrayOfByte4.length);
        this.jX.update(arrayOfByte2, 0, arrayOfByte2.length);
        this.jX.update(arrayOfByte1, 0, arrayOfByte1.length);
        this.jX.digest(arrayOfByte3, m * j);
      }
      di localdi = new di(this.an, arrayOfByte3, 0, i, "SSKDF");
      return localdi;
    }
    finally
    {
      er.w(arrayOfByte2);
      er.w(arrayOfByte3);
    }
  }
  
  public void clearSensitiveData()
  {
    this.jX.clearSensitiveData();
  }
  
  public Object clone()
  {
    ez localez = (ez)super.clone();
    localez.jX = ((bq)es.a(this.jX));
    return localez;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ez
 * JD-Core Version:    0.7.0.1
 */