package com.rsa.jcm.f;

import com.rsa.crypto.JCMCloneable;
import com.rsa.crypto.SensitiveData;
import java.io.Serializable;

public abstract interface gl
  extends JCMCloneable, SensitiveData, Serializable
{
  public abstract byte[] toOctetString();
  
  public abstract int w(byte[] paramArrayOfByte, int paramInt);
  
  public abstract int r(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  public abstract byte[] q(int paramInt);
  
  public abstract id bQ();
  
  public abstract ic bR();
  
  public abstract boolean isZero();
  
  public abstract boolean bS();
  
  public abstract boolean isValid();
  
  public abstract void bF();
  
  public abstract gk ba();
  
  public abstract gl a(gl paramgl);
  
  public abstract gl b(gl paramgl);
  
  public abstract gl c(gl paramgl);
  
  public abstract gl h(id paramid);
  
  public abstract gl d(gl paramgl);
  
  public abstract gl bT();
  
  public abstract gl bU();
  
  public abstract gl bV();
  
  public abstract gl i(id paramid);
  
  public abstract boolean equals(Object paramObject);
  
  public abstract int hashCode();
  
  public abstract Object clone();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gl
 * JD-Core Version:    0.7.0.1
 */