package com.rsa.jcm.f;

import com.rsa.crypto.CryptoModule;
import com.rsa.crypto.ECParams;
import com.rsa.crypto.KeyBuilder;
import com.rsa.crypto.Signature;

public final class eb
  extends em
{
  private static final String iH = "ECDSA KAT failed";
  private static final byte[][][] iQ = { { jb.hexStringToByteArray("c874a11fee76f9a48f2c1759dec93fb950ccd58cb8183c6297079b0cca46e580"), jb.hexStringToByteArray("061cc79ca680720d2fe7bd7db037315d24eebe2f2e338a3d9ae3d72fdaf2b659"), jb.hexStringToByteArray("84f332cc02a4c0050701624cb012a33ebb589cab40cb46a98a45ea136e88308e") }, { jb.hexStringToByteArray("b404e556588ced6c1acd4ebf053f6809f73a9355acad4d81ef20b346f8"), jb.hexStringToByteArray("025a631f15bc7771d3e6315bde0672e8b64b7c9543a92dd4a42558c97e"), jb.hexStringToByteArray("934abd21c312e9155c5224c6b86d334d930ba43f29ff2b8ac6eb7c4f0e") } };
  
  public eb()
  {
    super(iQ.length);
  }
  
  protected Signature l(int paramInt)
    throws Exception
  {
    return this.ip.newSignature("SHA256/ECDSA");
  }
  
  protected void m(int paramInt)
    throws Exception
  {
    ECParams[] arrayOfECParams = { this.ip.getKeyBuilder().newECParams("P256"), this.ip.getKeyBuilder().newECParams("B233") };
    this.ju = this.ip.getKeyBuilder().newECPrivateKey(iQ[paramInt][0], arrayOfECParams[paramInt]);
    this.jt = this.ip.getKeyBuilder().newECPublicKey(iQ[paramInt][1], iQ[paramInt][2], arrayOfECParams[paramInt]);
  }
  
  public String getName()
  {
    return "ECDSA";
  }
  
  public String aH()
  {
    return "ECDSA KAT failed";
  }
  
  protected byte[] aI()
  {
    return "This is the message to sign".getBytes();
  }
  
  protected byte[] aJ()
  {
    return null;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.eb
 * JD-Core Version:    0.7.0.1
 */