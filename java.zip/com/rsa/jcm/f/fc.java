package com.rsa.jcm.f;

import com.rsa.crypto.BigNum;
import com.rsa.crypto.DHPublicKey;
import com.rsa.crypto.DSAPublicKey;
import com.rsa.crypto.PQGParams;
import com.rsa.crypto.SecureRandom;

public class fc
  extends cl
  implements DHPublicKey, DSAPublicKey
{
  private BigNum kf;
  private PQGParams kd;
  private String ke;
  
  public fc(ke paramke, BigNum paramBigNum, PQGParams paramPQGParams, String paramString)
  {
    super(paramke);
    this.kf = paramBigNum;
    this.kd = paramPQGParams;
    this.ke = paramString;
  }
  
  public fc(ke paramke, byte[] paramArrayOfByte, PQGParams paramPQGParams, String paramString)
  {
    this(paramke, new id(paramArrayOfByte), paramPQGParams, paramString);
  }
  
  public BigNum getY()
  {
    return this.kf;
  }
  
  public PQGParams getParams()
  {
    return this.kd;
  }
  
  public void clearSensitiveData()
  {
    er.a((id)this.kf);
    this.kd = null;
  }
  
  public String getAlg()
  {
    return this.ke;
  }
  
  public boolean isValid(SecureRandom paramSecureRandom)
  {
    return ft.a(this, paramSecureRandom);
  }
  
  public Object clone()
  {
    fc localfc = (fc)super.clone();
    localfc.kf = ((id)es.a((id)this.kf));
    return localfc;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fc
 * JD-Core Version:    0.7.0.1
 */