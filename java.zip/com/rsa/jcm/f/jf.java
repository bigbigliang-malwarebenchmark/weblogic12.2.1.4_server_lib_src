package com.rsa.jcm.f;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.AccessController;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class jf
{
  private static final File qg = ;
  private static final String qh = jf.class.getPackage().getName().replace('.', '/').concat("/");
  
  public static byte[][] g(String paramString)
  {
    return (byte[][])a(paramString, 1);
  }
  
  public static int[][] h(String paramString)
  {
    return (int[][])a(paramString, 4);
  }
  
  private static Object a(String paramString, int paramInt)
  {
    InputStream localInputStream = null;
    JarFile localJarFile = d(qg);
    if (localJarFile == null)
    {
      localInputStream = jf.class.getResourceAsStream(paramString);
    }
    else
    {
      JarEntry localJarEntry = localJarFile.getJarEntry(qh + paramString);
      try
      {
        localInputStream = localJarFile.getInputStream(localJarEntry);
      }
      catch (IOException localIOException2) {}
    }
    if (localInputStream == null)
    {
      if (localJarFile != null) {
        try
        {
          localJarFile.close();
        }
        catch (IOException localIOException1) {}
      }
      return null;
    }
    DataInputStream localDataInputStream = new DataInputStream(localInputStream);
    try
    {
      int i = localDataInputStream.readUnsignedShort();
      Object localObject1;
      if (paramInt == 1) {
        localObject1 = new byte[i][];
      } else {
        localObject1 = new int[i][];
      }
      for (int k = 0; k < i; k++)
      {
        int j = localDataInputStream.readUnsignedShort();
        if (paramInt == 1)
        {
          localObject2 = (byte[][])localObject1;
          localObject2[k] = new byte[j];
          localDataInputStream.readFully((byte[])localObject2[k]);
        }
        else if (paramInt == 4)
        {
          j /= 4;
          localObject2 = new int[j];
          for (int m = 0; m < j; m++) {
            localObject2[m] = localDataInputStream.readInt();
          }
          int[][] arrayOfInt = (int[][])localObject1;
          arrayOfInt[k] = localObject2;
        }
      }
      Object localObject2 = localObject1;
      return localObject2;
    }
    catch (EOFException localEOFException) {}catch (IOException localIOException5) {}finally
    {
      try
      {
        localInputStream.close();
      }
      catch (IOException localIOException10) {}
      try
      {
        if (localJarFile != null) {
          localJarFile.close();
        }
      }
      catch (IOException localIOException11) {}
    }
    return null;
  }
  
  private static File cS()
  {
    return (File)AccessController.doPrivileged(new jf.1());
  }
  
  private static JarFile d(File paramFile)
  {
    if (paramFile == null) {
      return null;
    }
    try
    {
      return new JarFile(paramFile, false);
    }
    catch (IOException localIOException) {}
    return null;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.jf
 * JD-Core Version:    0.7.0.1
 */