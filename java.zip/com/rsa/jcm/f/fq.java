package com.rsa.jcm.f;

import com.rsa.crypto.BigNum;
import com.rsa.crypto.DHPublicKey;
import com.rsa.crypto.ECPublicKey;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.KeyConfirmation;
import com.rsa.crypto.MAC;
import com.rsa.crypto.PQGParams;
import com.rsa.crypto.PublicKey;
import com.rsa.crypto.SecretKey;
import java.util.Arrays;

public final class fq
  extends cl
  implements KeyConfirmation
{
  private fo kN;
  private fp kO;
  private final MAC cy;
  private String kP;
  private int kQ;
  
  public fq(fo paramfo, fp paramfp, MAC paramMAC, int paramInt, ke paramke)
  {
    super(paramke);
    this.kN = paramfo;
    this.kO = paramfp;
    this.cy = paramMAC;
    this.kQ = paramInt;
    this.kP = a(paramfo, paramfp);
  }
  
  public fq(fo paramfo, fp paramfp, MAC paramMAC, ke paramke)
  {
    this(paramfo, paramfp, paramMAC, paramMAC.getMacLength(), paramke);
  }
  
  public void clearSensitiveData()
  {
    this.cy.clearSensitiveData();
    this.kN = null;
    this.kO = null;
    this.kP = null;
    this.kQ = 0;
  }
  
  public byte[] computeMacTag(SecretKey paramSecretKey, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, PublicKey paramPublicKey1, byte[] paramArrayOfByte3, PublicKey paramPublicKey2, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5)
  {
    byte[] arrayOfByte = new byte[this.kQ];
    computeMacTag(paramSecretKey, paramArrayOfByte1, paramArrayOfByte2, paramPublicKey1, paramArrayOfByte3, paramPublicKey2, paramArrayOfByte4, paramArrayOfByte5, arrayOfByte, 0);
    return arrayOfByte;
  }
  
  public int computeMacTag(SecretKey paramSecretKey, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, PublicKey paramPublicKey1, byte[] paramArrayOfByte3, PublicKey paramPublicKey2, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5, byte[] paramArrayOfByte6, int paramInt)
  {
    a(paramSecretKey, paramArrayOfByte1, paramArrayOfByte2, paramPublicKey2, paramArrayOfByte4);
    byte[] arrayOfByte1 = b(paramPublicKey1);
    byte[] arrayOfByte2 = b(paramPublicKey2);
    byte[] arrayOfByte3 = new byte[this.cy.getMacLength()];
    try
    {
      this.cy.init(paramSecretKey);
      this.cy.update(this.kP.getBytes(), 0, this.kP.length());
      this.cy.update(paramArrayOfByte1, 0, paramArrayOfByte1.length);
      this.cy.update(paramArrayOfByte2, 0, paramArrayOfByte2.length);
      if (arrayOfByte1 != null) {
        this.cy.update(arrayOfByte1, 0, arrayOfByte1.length);
      } else if (paramArrayOfByte3 != null) {
        this.cy.update(paramArrayOfByte3, 0, paramArrayOfByte3.length);
      }
      if (arrayOfByte2 != null) {
        this.cy.update(arrayOfByte2, 0, arrayOfByte2.length);
      } else if (paramArrayOfByte4 != null) {
        this.cy.update(paramArrayOfByte4, 0, paramArrayOfByte4.length);
      }
      if (paramArrayOfByte5 != null) {
        this.cy.update(paramArrayOfByte5, 0, paramArrayOfByte5.length);
      }
      this.cy.mac(arrayOfByte3, 0);
      System.arraycopy(arrayOfByte3, 0, paramArrayOfByte6, paramInt, this.kQ);
      int i = this.kQ;
      return i;
    }
    finally
    {
      er.w(arrayOfByte3);
      er.w(arrayOfByte1);
      er.w(arrayOfByte2);
    }
  }
  
  public boolean verifyMacTag(SecretKey paramSecretKey, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, PublicKey paramPublicKey1, byte[] paramArrayOfByte3, PublicKey paramPublicKey2, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5, byte[] paramArrayOfByte6)
  {
    return verifyMacTag(paramSecretKey, paramArrayOfByte1, paramArrayOfByte2, paramPublicKey1, paramArrayOfByte3, paramPublicKey2, paramArrayOfByte4, paramArrayOfByte5, paramArrayOfByte6, 0);
  }
  
  public boolean verifyMacTag(SecretKey paramSecretKey, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, PublicKey paramPublicKey1, byte[] paramArrayOfByte3, PublicKey paramPublicKey2, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5, byte[] paramArrayOfByte6, int paramInt)
  {
    byte[] arrayOfByte = new byte[this.kQ];
    computeMacTag(paramSecretKey, paramArrayOfByte1, paramArrayOfByte2, paramPublicKey1, paramArrayOfByte3, paramPublicKey2, paramArrayOfByte4, paramArrayOfByte5, arrayOfByte, 0);
    return ja.c(arrayOfByte, Arrays.copyOfRange(paramArrayOfByte6, paramInt, paramInt + this.kQ));
  }
  
  public int getMacLength()
  {
    return this.kQ;
  }
  
  private String a(fo paramfo, fp paramfp)
  {
    if (paramfp == fp.Unilateral)
    {
      if ((paramfo == fo.Provider_PartyU) || (paramfo == fo.Recipient_PartyV)) {
        return "KC_1_U";
      }
      return "KC_1_V";
    }
    if ((paramfo == fo.Provider_PartyU) || (paramfo == fo.Recipient_PartyV)) {
      return "KC_2_U";
    }
    return "KC_2_V";
  }
  
  void a(SecretKey paramSecretKey, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, PublicKey paramPublicKey, byte[] paramArrayOfByte3)
  {
    int i = (paramSecretKey != null) && (paramArrayOfByte1 != null) && (paramArrayOfByte1.length > 0) && (paramArrayOfByte2 != null) && (paramArrayOfByte2.length > 0) && ((paramPublicKey != null) || (paramArrayOfByte3 != null)) ? 1 : 0;
    if (i == 0) {
      throw new InvalidAlgorithmParameterException("Parameters do not match the Key Confirmation Scheme requirement.");
    }
  }
  
  byte[] b(PublicKey paramPublicKey)
  {
    if (paramPublicKey == null) {
      return null;
    }
    Object localObject1;
    Object localObject2;
    byte[] arrayOfByte1;
    if ((paramPublicKey instanceof DHPublicKey))
    {
      localObject1 = (DHPublicKey)paramPublicKey;
      if (((DHPublicKey)localObject1).getY() != null)
      {
        localObject2 = (id)((DHPublicKey)localObject1).getY();
        arrayOfByte1 = ((id)localObject2).A((((DHPublicKey)localObject1).getParams().getP().getBitLength() + 7) / 8);
      }
      else
      {
        throw new InvalidAlgorithmParameterException("Ephemeral Public Key does not have key data.");
      }
    }
    else if ((paramPublicKey instanceof ECPublicKey))
    {
      localObject1 = (ECPublicKey)paramPublicKey;
      if (((ECPublicKey)localObject1).getPublicPoint() != null)
      {
        localObject2 = ((gi)((ECPublicKey)localObject1).getPublicPoint()).br();
        gl localgl = ((gi)((ECPublicKey)localObject1).getPublicPoint()).bs();
        int i = ((gl)localObject2).ba().bO();
        byte[] arrayOfByte2 = new byte[i];
        byte[] arrayOfByte3 = new byte[i];
        ((gl)localObject2).r(arrayOfByte2, 0, arrayOfByte2.length);
        localgl.r(arrayOfByte3, 0, arrayOfByte3.length);
        arrayOfByte1 = ja.c(new byte[][] { arrayOfByte2, arrayOfByte3 });
      }
      else
      {
        throw new InvalidAlgorithmParameterException("Ephemeral Public Key does not have key data.");
      }
    }
    else
    {
      throw new InvalidAlgorithmParameterException("Ephemeral Public Key does not match the Key Confirmation Scheme requirement.");
    }
    return arrayOfByte1;
  }
  
  fp aW()
  {
    return this.kO;
  }
  
  fo aX()
  {
    return this.kN;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fq
 * JD-Core Version:    0.7.0.1
 */