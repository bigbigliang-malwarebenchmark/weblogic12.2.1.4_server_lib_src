package com.rsa.jcm.f;

import com.rsa.crypto.BigNum;
import com.rsa.crypto.RSAPrivateKey;

public class fi
  extends cl
  implements RSAPrivateKey
{
  private BigNum kr;
  private BigNum ks;
  private BigNum kt;
  private BigNum ko;
  private BigNum kn;
  private BigNum ku;
  private BigNum kv;
  private BigNum kw;
  private BigNum[] kx;
  
  public fi(ke paramke, BigNum paramBigNum1, BigNum paramBigNum2)
  {
    super(paramke);
    this.kr = paramBigNum1;
    this.ks = paramBigNum2;
  }
  
  public fi(ke paramke, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this(paramke, new id(paramArrayOfByte1), new id(paramArrayOfByte2));
  }
  
  public fi(ke paramke, BigNum paramBigNum1, BigNum paramBigNum2, BigNum paramBigNum3, BigNum paramBigNum4, BigNum paramBigNum5, BigNum paramBigNum6, BigNum paramBigNum7, BigNum paramBigNum8)
  {
    this(paramke, paramBigNum1, paramBigNum3);
    this.kt = paramBigNum2;
    this.ko = paramBigNum4;
    this.kn = paramBigNum5;
    this.ku = paramBigNum6;
    this.kv = paramBigNum7;
    this.kw = paramBigNum8;
  }
  
  public fi(ke paramke, BigNum paramBigNum1, BigNum paramBigNum2, BigNum paramBigNum3, BigNum paramBigNum4, BigNum paramBigNum5, BigNum paramBigNum6, BigNum paramBigNum7, BigNum paramBigNum8, BigNum[] paramArrayOfBigNum)
  {
    this(paramke, paramBigNum1, paramBigNum3);
    this.kt = paramBigNum2;
    this.ko = paramBigNum4;
    this.kn = paramBigNum5;
    this.ku = paramBigNum6;
    this.kv = paramBigNum7;
    this.kw = paramBigNum8;
    this.kx = paramArrayOfBigNum;
  }
  
  public fi(ke paramke, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5, byte[] paramArrayOfByte6, byte[] paramArrayOfByte7, byte[] paramArrayOfByte8)
  {
    this(paramke, paramArrayOfByte1, paramArrayOfByte3);
    this.kt = (paramArrayOfByte2 == null ? null : new id(paramArrayOfByte2));
    this.ko = (paramArrayOfByte4 == null ? null : new id(paramArrayOfByte4));
    this.kn = (paramArrayOfByte5 == null ? null : new id(paramArrayOfByte5));
    this.ku = (paramArrayOfByte6 == null ? null : new id(paramArrayOfByte6));
    this.kv = (paramArrayOfByte7 == null ? null : new id(paramArrayOfByte7));
    this.kw = (paramArrayOfByte8 == null ? null : new id(paramArrayOfByte8));
  }
  
  public fi(ke paramke, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5, byte[] paramArrayOfByte6, byte[] paramArrayOfByte7, byte[] paramArrayOfByte8, byte[][] paramArrayOfByte)
  {
    this(paramke, paramArrayOfByte1, paramArrayOfByte3);
    this.kt = (paramArrayOfByte2 == null ? null : new id(paramArrayOfByte2));
    this.ko = (paramArrayOfByte4 == null ? null : new id(paramArrayOfByte4));
    this.kn = (paramArrayOfByte5 == null ? null : new id(paramArrayOfByte5));
    this.ku = (paramArrayOfByte6 == null ? null : new id(paramArrayOfByte6));
    this.kv = (paramArrayOfByte7 == null ? null : new id(paramArrayOfByte7));
    this.kw = (paramArrayOfByte8 == null ? null : new id(paramArrayOfByte8));
    if (paramArrayOfByte != null)
    {
      this.kx = new BigNum[3];
      for (int i = 0; i < paramArrayOfByte.length; i++) {
        this.kx[i] = new id(paramArrayOfByte[i]);
      }
    }
  }
  
  public BigNum getN()
  {
    return this.kr;
  }
  
  public BigNum getD()
  {
    return this.ks;
  }
  
  public BigNum getP()
  {
    return this.ko;
  }
  
  public BigNum getQ()
  {
    return this.kn;
  }
  
  public BigNum getExpP()
  {
    return this.ku;
  }
  
  public BigNum getExpQ()
  {
    return this.kv;
  }
  
  public BigNum getCoeff()
  {
    return this.kw;
  }
  
  public BigNum[] getOtherMultiPrimeInfo()
  {
    return this.kx;
  }
  
  public BigNum getE()
  {
    return this.kt;
  }
  
  public boolean hasCRTInfo()
  {
    return this.ko != null;
  }
  
  public boolean isMultiprime()
  {
    return this.kx != null;
  }
  
  public boolean isValid()
  {
    return ft.b(this);
  }
  
  public void clearSensitiveData()
  {
    er.a((id)this.kr);
    er.a((id)this.ks);
    er.a((id)this.kt);
    er.a((id)this.ko);
    er.a((id)this.kn);
    er.a((id)this.ku);
    er.a((id)this.kv);
    er.a((id)this.kw);
    if (this.kx != null) {
      for (int i = 0; i < this.kx.length; i++) {
        er.a((id)this.kx[i]);
      }
    }
  }
  
  public String getAlg()
  {
    return "RSA";
  }
  
  public Object clone()
  {
    if (this.kx == null) {
      return new fi(this.an, (id)es.a((id)this.kr), (id)es.a((id)this.kt), (id)es.a((id)this.ks), (id)es.a((id)this.ko), (id)es.a((id)this.kn), (id)es.a((id)this.ku), (id)es.a((id)this.kv), (id)es.a((id)this.kw));
    }
    BigNum[] arrayOfBigNum = new BigNum[this.kx.length];
    for (int i = 0; i < this.kx.length; i++) {
      arrayOfBigNum[i] = ((id)es.a((id)this.kx[i]));
    }
    return new fi(this.an, (id)es.a((id)this.kr), (id)es.a((id)this.kt), (id)es.a((id)this.ks), (id)es.a((id)this.ko), (id)es.a((id)this.kn), (id)es.a((id)this.ku), (id)es.a((id)this.kv), (id)es.a((id)this.kw), arrayOfBigNum);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fi
 * JD-Core Version:    0.7.0.1
 */