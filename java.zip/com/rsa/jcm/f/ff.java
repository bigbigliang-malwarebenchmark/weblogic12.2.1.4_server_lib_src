package com.rsa.jcm.f;

import com.rsa.crypto.ECParams;
import com.rsa.crypto.ECPoint;
import com.rsa.crypto.ECPublicKey;
import com.rsa.crypto.SecureRandom;

public class ff
  extends cl
  implements ECPublicKey
{
  private ECPoint kk;
  private final ECParams ki;
  
  public ff(ke paramke, gi paramgi, ECParams paramECParams)
  {
    super(paramke);
    this.kk = paramgi;
    this.ki = paramECParams;
  }
  
  public ff(ke paramke, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, ECParams paramECParams)
  {
    super(paramke);
    this.ki = paramECParams;
    this.kk = new gi(((fd)this.ki).aS(), new id(paramArrayOfByte1), new id(paramArrayOfByte2));
  }
  
  public ECPoint getPublicPoint()
  {
    return this.kk;
  }
  
  public ECParams getParams()
  {
    return this.ki;
  }
  
  public void clearSensitiveData()
  {
    er.a(this.kk);
  }
  
  public String getAlg()
  {
    return "EC";
  }
  
  public boolean isValid(SecureRandom paramSecureRandom)
  {
    return ft.a(this, paramSecureRandom);
  }
  
  public Object clone()
  {
    ff localff = (ff)super.clone();
    localff.kk = ((gi)es.a((gi)this.kk));
    return localff;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ff
 * JD-Core Version:    0.7.0.1
 */