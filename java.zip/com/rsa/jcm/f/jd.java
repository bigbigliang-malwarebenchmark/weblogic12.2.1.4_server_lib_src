package com.rsa.jcm.f;

public final class jd
{
  private static final byte[] qc = new byte[1024];
  private static final int[] qd = new int[256];
  private static final long[] qe = new long[''];
  private static final char[] qf = new char[1024];
  
  public static void K(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null) {
      return;
    }
    I(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public static void I(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (paramArrayOfByte == null) {
      return;
    }
    int i = 0;
    int j;
    while ((j = paramInt2 - i) > 0)
    {
      if (j > qc.length) {
        j = qc.length;
      }
      System.arraycopy(qc, 0, paramArrayOfByte, paramInt1 + i, j);
      i += j;
    }
  }
  
  public static void d(byte[][] paramArrayOfByte)
  {
    if (paramArrayOfByte == null) {
      return;
    }
    for (int i = 0; i < paramArrayOfByte.length; i++) {
      K(paramArrayOfByte[i]);
    }
  }
  
  public static void f(int[] paramArrayOfInt)
  {
    if (paramArrayOfInt == null) {
      return;
    }
    int i = 0;
    int j;
    while ((j = paramArrayOfInt.length - i) > 0)
    {
      if (j > qd.length) {
        j = qd.length;
      }
      System.arraycopy(qd, 0, paramArrayOfInt, i, j);
      i += j;
    }
  }
  
  public static void c(long[] paramArrayOfLong)
  {
    if (paramArrayOfLong == null) {
      return;
    }
    int i = 0;
    int j;
    while ((j = paramArrayOfLong.length - i) > 0)
    {
      if (j > qe.length) {
        j = qe.length;
      }
      System.arraycopy(qe, 0, paramArrayOfLong, i, j);
      i += j;
    }
  }
  
  public static void c(char[] paramArrayOfChar)
  {
    if (paramArrayOfChar == null) {
      return;
    }
    int i = 0;
    int j;
    while ((j = paramArrayOfChar.length - i) > 0)
    {
      if (j > qf.length) {
        j = qf.length;
      }
      System.arraycopy(qf, 0, paramArrayOfChar, i, j);
      i += j;
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.jd
 * JD-Core Version:    0.7.0.1
 */