package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;

public final class gg
{
  private static final byte lQ = 0;
  private static final byte lR = 2;
  private static final byte lS = 3;
  private static final byte lT = 4;
  private static final byte lU = 6;
  private static final byte lV = 7;
  
  public static byte[] e(gi paramgi)
  {
    if (paramgi.isInfinite()) {
      return new byte[] { 0 };
    }
    int i = paramgi.aS().bb().ba().bO();
    byte[] arrayOfByte = new byte[1 + i * 2];
    arrayOfByte[0] = 4;
    paramgi.br().w(arrayOfByte, 1);
    paramgi.bs().w(arrayOfByte, 1 + i);
    return arrayOfByte;
  }
  
  public static gg.a a(gm paramgm, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    switch (paramArrayOfByte[paramInt1])
    {
    case 0: 
      return new gg.a();
    case 4: 
      if (paramInt2 % 2 != 1) {
        throw new CryptoException("Invalid encoded data provided. Must contain equal length ordinates plus single header byte.");
      }
      int i = (paramInt2 - 1) / 2;
      gl localgl1 = paramgm.s(paramArrayOfByte, paramInt1 + 1, i);
      gl localgl2 = paramgm.s(paramArrayOfByte, paramInt1 + 1 + i, i);
      if ((localgl1.isZero()) && (localgl2.isZero())) {
        throw new CryptoException("Invalid uncompressed point encoding. Point (0,0) is not on a curve.");
      }
      return new gg.a(localgl1, localgl2);
    }
    throw new CryptoException("Unsupported point encoding. Only supports uncompressed ordinates.");
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gg
 * JD-Core Version:    0.7.0.1
 */