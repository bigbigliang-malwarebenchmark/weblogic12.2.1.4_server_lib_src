package com.rsa.jcm.f;

import java.util.StringTokenizer;

public class im
{
  public static String[] split(String paramString)
  {
    return a(paramString, "/");
  }
  
  public static String[] a(String paramString1, String paramString2)
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString1, paramString2);
    String[] arrayOfString = new String[localStringTokenizer.countTokens()];
    int i = 0;
    while (localStringTokenizer.hasMoreElements()) {
      arrayOfString[(i++)] = localStringTokenizer.nextToken();
    }
    return arrayOfString;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.im
 * JD-Core Version:    0.7.0.1
 */