package com.rsa.jcm.f;

import com.rsa.crypto.MessageDigest;
import java.io.Serializable;

public abstract interface ib
  extends Serializable
{
  public abstract void d(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4);
  
  public abstract String getAlg();
  
  public abstract MessageDigest cG();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ib
 * JD-Core Version:    0.7.0.1
 */