package com.rsa.jcm.f;

import com.rsa.crypto.BigNum;
import java.io.Serializable;

public class gj
  implements Serializable
{
  public static final int mk = 0;
  public static final int ml = 1;
  public static final int mm = 2;
  public static final int mn = 3;
  public static final int mo = -1;
  public static final int mp = -2;
  gk mq;
  gl mr;
  gl ms;
  gl mt;
  int mu = -1;
  byte[] jY;
  String mv;
  boolean mw;
  private byte[][] mx;
  
  public gj(gk paramgk, gl paramgl1, gl paramgl2, byte[] paramArrayOfByte, String paramString)
  {
    this.mq = paramgk;
    this.mr = paramgl1;
    this.ms = paramgl2;
    this.jY = es.x(paramArrayOfByte);
    this.mv = ((this.jY != null) && (paramString == null) ? "SHA1" : paramString);
    this.mw = (this.jY != null);
    bM();
    bN();
    this.mt.bF();
    this.mr.bF();
    this.ms.bF();
  }
  
  public gj(gk paramgk, gl paramgl1, gl paramgl2, byte[] paramArrayOfByte, String paramString, boolean paramBoolean, byte[][] paramArrayOfByte1)
  {
    this(paramgk, paramgl1, paramgl2, paramArrayOfByte, paramString);
    this.mx = paramArrayOfByte1;
  }
  
  public gk ba()
  {
    return this.mq;
  }
  
  public gl bG()
  {
    return this.mr;
  }
  
  public gl bH()
  {
    return this.ms;
  }
  
  public byte[] getSeed()
  {
    return es.x(this.jY);
  }
  
  public gm bf()
  {
    return ba().bf();
  }
  
  public int bI()
  {
    return this.mu;
  }
  
  public gl bJ()
  {
    return this.mt;
  }
  
  public boolean bK()
  {
    return this.mw;
  }
  
  public String getDigest()
  {
    return this.mv;
  }
  
  public byte[][] bL()
  {
    return this.mx;
  }
  
  public int[] getFieldMidTerms()
  {
    if (this.mq.getType() == 0) {
      return null;
    }
    return ((hc)this.mq).cd();
  }
  
  public BigNum getFieldPrime()
  {
    if (this.mq.getType() == 0) {
      return ((hu)this.mq).cA();
    }
    return null;
  }
  
  public int hashCode()
  {
    return this.mq.hashCode() ^ this.mr.hashCode() ^ this.ms.hashCode();
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == null) {
      return false;
    }
    if (!(paramObject instanceof gj)) {
      return false;
    }
    gj localgj = (gj)paramObject;
    return (this.mq.equals(localgj.mq)) && (this.mr.equals(localgj.mr)) && (this.ms.equals(localgj.ms));
  }
  
  private void bM()
  {
    if (this.mq.getType() == 1) {
      this.mu = -2;
    } else if (bG().isZero()) {
      this.mu = 0;
    } else if (bG().bS()) {
      this.mu = 1;
    } else if (bG().equals(((hu)ba()).cB())) {
      this.mu = 2;
    } else {
      this.mu = 3;
    }
  }
  
  private void bN()
  {
    this.mt = this.ms;
    for (int i = 0; i < this.mq.getFieldSize() - 2; i++) {
      this.mt = this.mt.bT();
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gj
 * JD-Core Version:    0.7.0.1
 */