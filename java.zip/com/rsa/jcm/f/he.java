package com.rsa.jcm.f;

final class he
{
  private final ic[] nv;
  private final gk mq;
  
  private he(gk paramgk)
  {
    this.mq = paramgk;
    this.nv = new ic[paramgk.getFieldSize()];
  }
  
  static int[] b(hc paramhc)
  {
    int i = paramhc.getFieldSize();
    int[] arrayOfInt = hf.w(i);
    if (arrayOfInt != null) {
      return arrayOfInt;
    }
    return c(paramhc);
  }
  
  private static int[] c(hc paramhc)
  {
    int i = paramhc.getFieldSize();
    int[] arrayOfInt = new int[2 * i - 1];
    int j = 2;
    he localhe1 = new he(paramhc);
    he localhe3 = new he(paramhc);
    ic localic = ic.b(new int[] { j }, 1);
    gl localgl1 = paramhc.cj().a(localic);
    gl localgl2 = paramhc.cj().a(localic);
    for (int k = 0; k < i; k++)
    {
      localhe1.nv[k] = localgl2.bR();
      localhe3.nv[k] = localgl1.c(localgl2).bR();
      localgl2 = localgl2.bT();
    }
    he localhe2 = localhe1.cq();
    localhe1 = localhe3.a(localhe2);
    k = 0;
    for (int m = 0; m < i; m++)
    {
      int n = 0;
      int i1 = 0;
      while ((n < i) && (i1 < 2))
      {
        int i2 = (i - m) % i;
        int i3 = n - m;
        if (i3 < 0) {
          i3 += i;
        }
        if (localhe1.nv[i3].testBit(i2))
        {
          arrayOfInt[(k++)] = n;
          i1++;
        }
        n++;
      }
    }
    return arrayOfInt;
  }
  
  private static he a(gk paramgk)
  {
    he localhe = new he(paramgk);
    for (int i = 0; i < paramgk.getFieldSize(); i++)
    {
      ic localic = ic.cL();
      int j = i / 32;
      int k = i % 32;
      localic.j(j, 1 << k);
      localhe.nv[i] = localic;
    }
    return localhe;
  }
  
  private he cq()
  {
    he localhe = a(this.mq);
    for (int i = 0; i < this.mq.getFieldSize(); i++)
    {
      int j = i / 32;
      int k = i % 32;
      int m = j * 32 + k;
      for (int n = i; n < this.mq.getFieldSize(); n++) {
        if ((this.nv[n].F(j) >>> k & 0x1) != 0)
        {
          if (i != n)
          {
            ic localic = this.nv[i];
            this.nv[i] = this.nv[n];
            this.nv[n] = localic;
            localic = localhe.nv[i];
            localhe.nv[i] = localhe.nv[n];
            localhe.nv[n] = localic;
          }
          for (int i1 = 0; i1 < this.mq.getFieldSize(); i1++) {
            if ((i1 != i) && (this.nv[i1].testBit(m)))
            {
              this.nv[i1].e(this.nv[i]);
              localhe.nv[i1].e(localhe.nv[i]);
            }
          }
          break;
        }
      }
    }
    return localhe;
  }
  
  private he a(he paramhe)
  {
    he localhe = new he(this.mq);
    int i = this.mq.getFieldSize();
    for (int j = 0; j < i; j++) {
      localhe.nv[j] = paramhe.c(this.nv[j]);
    }
    return localhe;
  }
  
  private ic c(ic paramic)
  {
    ic localic = ic.cL();
    int i = this.mq.getFieldSize();
    for (int j = 0; j < i; j++) {
      if (paramic.testBit(j)) {
        localic.e(this.nv[j]);
      }
    }
    return localic;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.he
 * JD-Core Version:    0.7.0.1
 */