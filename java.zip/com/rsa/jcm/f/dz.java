package com.rsa.jcm.f;

import com.rsa.crypto.CryptoModule;
import com.rsa.crypto.MessageDigest;

abstract class dz
  extends ei
{
  dz()
  {
    super(1);
  }
  
  protected boolean a(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    MessageDigest localMessageDigest = this.ip.newMessageDigest(paramString);
    byte[] arrayOfByte = new byte[localMessageDigest.getDigestSize()];
    localMessageDigest.update(paramArrayOfByte1, 0, paramArrayOfByte1.length);
    localMessageDigest.digest(arrayOfByte, 0);
    return ja.f(paramArrayOfByte2, 0, paramArrayOfByte2.length, arrayOfByte, 0, arrayOfByte.length);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dz
 * JD-Core Version:    0.7.0.1
 */