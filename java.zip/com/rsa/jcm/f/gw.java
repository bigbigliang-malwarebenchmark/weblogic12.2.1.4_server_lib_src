package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;

public class gw
  extends gu
{
  gw(gk paramgk, ic paramic)
  {
    super(paramgk, paramic);
  }
  
  public boolean bS()
  {
    int[] arrayOfInt = this.mS.cH();
    int i = this.mS.cJ();
    for (int j = 0; j < i - 2; j++) {
      if (arrayOfInt[j] != -1) {
        return false;
      }
    }
    j = gn.u(this.mR.getFieldSize());
    int k = (int)(-4294967296L >> 32 - j ^ 0xFFFFFFFF);
    return arrayOfInt[(i - 1)] == k;
  }
  
  public gl c(gl paramgl)
  {
    int i = this.mR.getFieldSize();
    int j = i + 32 - 1 >>> 5;
    int k = i % 32;
    if (k == 0) {
      k = 32;
    }
    int m = 2;
    int[] arrayOfInt1 = new int[j];
    int[] arrayOfInt2 = this.mR.cm();
    int[] arrayOfInt3 = f(this);
    int[] arrayOfInt4 = f(paramgl);
    int n = arrayOfInt3[0] & arrayOfInt4[arrayOfInt2[0]];
    int i1;
    for (int i2 = 1; i2 < i; i2++)
    {
      i1 = arrayOfInt4[arrayOfInt2[(i2 * m - (m - 1))]];
      for (i3 = m - 2; i3 >= 0; i3--) {
        if (arrayOfInt2[(i2 * m - i3)] > 0) {
          i1 ^= arrayOfInt4[arrayOfInt2[(i2 * m - i3)]];
        }
      }
      n ^= arrayOfInt3[i2] & i1;
    }
    if (k != 32) {
      n >>>= 32 - k;
    }
    arrayOfInt1[(j - 1)] = n;
    i2 = k;
    int i3 = k;
    for (int i4 = j - 2; i4 >= 0; i4--)
    {
      n = arrayOfInt3[i2] & arrayOfInt4[(i3 + arrayOfInt2[0])];
      for (int i5 = i - 1; i5 > 0; i5--)
      {
        i1 = arrayOfInt4[(i3 + arrayOfInt2[(i5 * m - (m - 1))])];
        for (int i6 = m - 2; i6 >= 0; i6--) {
          if (arrayOfInt2[(i5 * m - i6)] > 0) {
            i1 ^= arrayOfInt4[(i3 + arrayOfInt2[(i5 * m - i6)])];
          }
        }
        n ^= arrayOfInt3[(i2 + i5)] & i1;
      }
      arrayOfInt1[i4] = n;
      i2 += 32;
      i3 += 32;
    }
    ic localic = ic.b(arrayOfInt1, arrayOfInt1.length);
    return this.mT.a(localic);
  }
  
  static int[] f(gl paramgl)
  {
    int i = paramgl.ba().getFieldSize();
    int j = gn.s(i);
    int[] arrayOfInt1 = ((gu)paramgl).mS.B(j);
    int[] arrayOfInt2 = new int[i * 2];
    int k = i % 32;
    if (k == 0) {
      k = 32;
    }
    if (i < 32)
    {
      a(i, arrayOfInt1, arrayOfInt2);
      return arrayOfInt2;
    }
    int m = 0;
    for (int n = k; n > 0; n--) {
      arrayOfInt2[(m++)] = (arrayOfInt1[(j - 1)] << 32 - n | arrayOfInt1[(j - 2)] >>> n);
    }
    for (n = j - 2; n > 0; n--)
    {
      arrayOfInt2[(m++)] = arrayOfInt1[n];
      for (int i1 = 31; i1 > 0; i1--) {
        arrayOfInt2[(m++)] = (arrayOfInt1[n] << 32 - i1 | arrayOfInt1[(n - 1)] >>> i1);
      }
    }
    arrayOfInt2[(m++)] = arrayOfInt1[0];
    for (n = 31; n > 0; n--) {
      arrayOfInt2[(m++)] = (arrayOfInt1[0] << 32 - n | arrayOfInt2[0] >>> n);
    }
    System.arraycopy(arrayOfInt2, 0, arrayOfInt2, i, i);
    return arrayOfInt2;
  }
  
  private static void a(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int i = 0;
    paramArrayOfInt2[(i++)] = (paramArrayOfInt1[0] << 32 - paramInt);
    for (int j = paramInt - 1; j > 0; j--) {
      paramArrayOfInt2[(i++)] = (paramArrayOfInt1[0] << 32 - j | paramArrayOfInt2[0] >>> j);
    }
    System.arraycopy(paramArrayOfInt2, 0, paramArrayOfInt2, paramInt, paramInt);
  }
  
  public gl bT()
  {
    ic localic = (ic)this.mS.clone();
    localic.K(this.mR.getFieldSize() - 1);
    return this.mT.a(localic);
  }
  
  gl v(int paramInt)
  {
    ic localic = (ic)this.mS.clone();
    localic.k(paramInt, this.mR.getFieldSize() - 1);
    return this.mT.a(localic);
  }
  
  public gl bU()
  {
    if (isZero()) {
      throw new CryptoException("Inversion of zero is not valid.");
    }
    int i = this.mR.getFieldSize() - 1;
    for (int j = 31; (i | 1 << j) != i; j--) {}
    Object localObject1 = this;
    Object localObject2 = this;
    int k = 1;
    for (int m = j - 1; m >= 0; m--)
    {
      localObject2 = a((gl)localObject2, k);
      localObject2 = ((gl)localObject2).c((gl)localObject1);
      k <<= 1;
      if ((i & 1 << m) != 0)
      {
        localObject2 = ((gl)localObject2).bT();
        localObject2 = ((gl)localObject2).c(this);
        k++;
      }
      localObject1 = localObject2;
    }
    return ((gl)localObject1).bT();
  }
  
  private gl a(gl paramgl, int paramInt)
  {
    return ((gw)paramgl).v(paramInt);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gw
 * JD-Core Version:    0.7.0.1
 */