package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;

public abstract class gu
  implements gl
{
  final hc mR;
  ic mS;
  gm mT;
  
  gu(gk paramgk, ic paramic)
  {
    this.mR = ((hc)paramgk);
    this.mT = new hb(this.mR);
    this.mS = paramic;
  }
  
  public gk ba()
  {
    return this.mR;
  }
  
  public byte[] toOctetString()
  {
    return this.mS.toOctetString();
  }
  
  public int w(byte[] paramArrayOfByte, int paramInt)
  {
    int i = gn.r(this.mR.getFieldSize());
    this.mS.v(paramArrayOfByte, paramInt, i);
    return i;
  }
  
  public int r(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.mS.v(paramArrayOfByte, paramInt1, paramInt2);
    return paramInt2;
  }
  
  public byte[] q(int paramInt)
  {
    return this.mS.A(paramInt);
  }
  
  public id bQ()
  {
    return new id(this.mS);
  }
  
  public ic bR()
  {
    return (ic)this.mS.clone();
  }
  
  public boolean isZero()
  {
    return this.mS.isZero();
  }
  
  public abstract boolean bS();
  
  public gl a(gl paramgl)
  {
    ic localic = (ic)this.mS.clone();
    localic.e(e(paramgl));
    return this.mT.a(localic);
  }
  
  public abstract gl c(gl paramgl);
  
  public gl h(id paramid)
  {
    gl localgl1 = this.mR.bf().j(paramid);
    try
    {
      gl localgl2 = c(localgl1);
      return localgl2;
    }
    finally
    {
      er.a(localgl1);
    }
  }
  
  public abstract gl bT();
  
  public abstract gl bU();
  
  public gl bV()
  {
    return (gl)clone();
  }
  
  public gl i(id paramid)
  {
    throw new CryptoException("This operation is currently not supported for binary field elements.");
  }
  
  public gl b(gl paramgl)
  {
    return a(paramgl);
  }
  
  public gl d(gl paramgl)
  {
    gl localgl1 = paramgl.bU();
    try
    {
      gl localgl2 = c(localgl1);
      return localgl2;
    }
    finally
    {
      er.a(localgl1);
    }
  }
  
  public void bF() {}
  
  public boolean isValid()
  {
    return this.mS.getBitLength() <= this.mR.getFieldSize();
  }
  
  ic e(gl paramgl)
  {
    return ((gu)paramgl).mS;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof gu)) {
      return false;
    }
    gu localgu = (gu)paramObject;
    return (this.mS.equals(localgu.mS)) && (this.mR.equals(localgu.mR));
  }
  
  public int hashCode()
  {
    return this.mS.hashCode() ^ this.mR.hashCode();
  }
  
  public Object clone()
  {
    gu localgu;
    try
    {
      localgu = (gu)super.clone();
      localgu.mS = ((ic)es.a(this.mS));
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new CryptoException("Object.clone() unexpectedly threw CloneNotSupportedException.");
    }
    return localgu;
  }
  
  public void clearSensitiveData()
  {
    er.a(this.mS);
    this.mS = null;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gu
 * JD-Core Version:    0.7.0.1
 */