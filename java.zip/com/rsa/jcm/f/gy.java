package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.SensitiveData;

public abstract class gy
  extends gu
{
  private static final ic mU = ic.d(new int[] { 2 });
  
  gy(gk paramgk, ic paramic)
  {
    super(paramgk, paramic);
  }
  
  public boolean bS()
  {
    return this.mS.C(1);
  }
  
  public gl c(gl paramgl)
  {
    int i = this.mR.cc();
    int[] arrayOfInt1 = this.mS.B(i);
    int[][] arrayOfInt = new int[32][];
    arrayOfInt[0] = ((gu)paramgl).mS.B(i + 1);
    for (int j = 1; j < 32; j++)
    {
      arrayOfInt[j] = new int[i + 1];
      ih.a(arrayOfInt[(j - 1)], i + 1, arrayOfInt[j]);
    }
    int[] arrayOfInt2 = new int[2 * i];
    for (int k = i - 1; k >= 0; k--) {
      for (int m = 31; m >= 0; m--)
      {
        int n = 1 << m;
        if ((n & arrayOfInt1[k]) != 0)
        {
          int i1 = i;
          if ((i1 & 0x1) == 0)
          {
            arrayOfInt2[(i1 + k)] ^= arrayOfInt[m][i1];
            i1--;
          }
          if ((i1 & 0x2) == 0)
          {
            arrayOfInt2[(i1 + k)] ^= arrayOfInt[m][i1];
            i1--;
            arrayOfInt2[(i1 + k)] ^= arrayOfInt[m][i1];
            i1--;
          }
          while (i1 >= 0)
          {
            arrayOfInt2[(i1 + k)] ^= arrayOfInt[m][i1];
            i1--;
            arrayOfInt2[(i1 + k)] ^= arrayOfInt[m][i1];
            i1--;
            arrayOfInt2[(i1 + k)] ^= arrayOfInt[m][i1];
            i1--;
            arrayOfInt2[(i1 + k)] ^= arrayOfInt[m][i1];
            i1--;
          }
        }
      }
    }
    ic localic = ic.b(arrayOfInt2, arrayOfInt2.length);
    b(localic);
    return this.mT.a(localic);
  }
  
  public gl bT()
  {
    int i = this.mR.cc();
    int[] arrayOfInt1 = this.mS.B(i);
    int[] arrayOfInt2 = new int[i * 2];
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      int m = hh.nH[(arrayOfInt1[k] & 0xFF)];
      arrayOfInt2[j] = m;
      m = hh.nH[(arrayOfInt1[k] >>> 8 & 0xFF)];
      arrayOfInt2[j] |= m << 16;
      j++;
      m = hh.nH[(arrayOfInt1[k] >>> 16 & 0xFF)];
      arrayOfInt2[j] = m;
      m = hh.nH[(arrayOfInt1[k] >>> 24)];
      arrayOfInt2[j] |= m << 16;
      j++;
    }
    ic localic = ic.b(arrayOfInt2, arrayOfInt2.length);
    b(localic);
    return this.mT.a(localic);
  }
  
  public gl bU()
  {
    if (isZero()) {
      throw new CryptoException("Inversion of zero is not valid.");
    }
    Object localObject1 = (ic)this.mS.clone();
    Object localObject2 = this.mR.ck();
    Object localObject3 = ic.d(new int[] { 1 });
    Object localObject4 = ic.d(new int[] { 0 });
    while (!((ic)localObject1).C(1))
    {
      int i = ((ic)localObject1).getBitLength() - ((ic)localObject2).getBitLength();
      if (i < 0)
      {
        localObject5 = localObject1;
        localObject1 = localObject2;
        localObject2 = localObject5;
        localObject6 = localObject3;
        localObject3 = localObject4;
        localObject4 = localObject6;
        i = -i;
      }
      Object localObject5 = (ic)((ic)localObject2).clone();
      ((ic)localObject5).H(i);
      ((ic)localObject1).e((ic)localObject5);
      Object localObject6 = (ic)((ic)localObject4).clone();
      ((ic)localObject6).H(i);
      ((ic)localObject3).e((ic)localObject6);
      er.a((SensitiveData)localObject5);
      er.a((SensitiveData)localObject6);
    }
    er.a((SensitiveData)localObject1);
    er.a((SensitiveData)localObject2);
    er.a((SensitiveData)localObject4);
    return this.mT.a((ic)localObject3);
  }
  
  public boolean ca()
  {
    Object localObject1 = (ic)this.mS.clone();
    ((ic)localObject1).e(mU);
    Object localObject2 = this.mR.ck();
    while (!((ic)localObject1).isZero())
    {
      int i = ((ic)localObject1).getBitLength() - ((ic)localObject2).getBitLength();
      if (i < 0)
      {
        localObject3 = localObject1;
        localObject1 = localObject2;
        localObject2 = localObject3;
        i = -i;
      }
      Object localObject3 = (ic)((ic)localObject2).clone();
      ((ic)localObject3).H(i);
      ((ic)localObject1).e((ic)localObject3);
    }
    return ((ic)localObject2).C(1);
  }
  
  void b(ic paramic)
  {
    int i = this.mR.getFieldSize();
    int j = this.mR.co();
    int k = i / 4;
    int m = k * 4;
    int n = gn.s(i);
    int[] arrayOfInt1 = paramic.cH();
    int[][] arrayOfInt = this.mR.cn();
    int i1 = m;
    int i2;
    int i3;
    int i4;
    int i5;
    int[] arrayOfInt2;
    int i6;
    switch (n & 0x3)
    {
    case 0: 
      for (i2 = 0; i2 <= j; i2++)
      {
        i3 = i1 / 32;
        i4 = i1 & 0x1F;
        i5 = arrayOfInt1[i3] >>> i4 & 0xF;
        arrayOfInt2 = arrayOfInt[(i2 << 4 | i5)];
        for (i6 = n - 1; i6 > 0; i6--)
        {
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
        }
        i1 += 4;
      }
      break;
    case 1: 
      for (i2 = 0; i2 <= j; i2++)
      {
        i3 = i1 / 32;
        i4 = i1 & 0x1F;
        i5 = arrayOfInt1[i3] >>> i4 & 0xF;
        arrayOfInt2 = arrayOfInt[(i2 << 4 | i5)];
        i6 = n - 1;
        arrayOfInt1[i6] ^= arrayOfInt2[i6];
        i6--;
        while (i6 > 0)
        {
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
        }
        i1 += 4;
      }
      break;
    case 2: 
      for (i2 = 0; i2 <= j; i2++)
      {
        i3 = i1 / 32;
        i4 = i1 & 0x1F;
        i5 = arrayOfInt1[i3] >>> i4 & 0xF;
        arrayOfInt2 = arrayOfInt[(i2 << 4 | i5)];
        i6 = n - 1;
        arrayOfInt1[i6] ^= arrayOfInt2[i6];
        i6--;
        arrayOfInt1[i6] ^= arrayOfInt2[i6];
        i6--;
        while (i6 > 0)
        {
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
        }
        i1 += 4;
      }
      break;
    case 3: 
      for (i2 = 0; i2 <= j; i2++)
      {
        i3 = i1 / 32;
        i4 = i1 & 0x1F;
        i5 = arrayOfInt1[i3] >>> i4 & 0xF;
        arrayOfInt2 = arrayOfInt[(i2 << 4 | i5)];
        i6 = n - 1;
        arrayOfInt1[i6] ^= arrayOfInt2[i6];
        i6--;
        arrayOfInt1[i6] ^= arrayOfInt2[i6];
        i6--;
        arrayOfInt1[i6] ^= arrayOfInt2[i6];
        i6--;
        while (i6 > 0)
        {
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
          arrayOfInt1[i6] ^= arrayOfInt2[i6];
          i6--;
        }
        i1 += 4;
      }
    }
    gn.a(arrayOfInt1, n, i % 32);
    paramic.a(arrayOfInt1, arrayOfInt1.length);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gy
 * JD-Core Version:    0.7.0.1
 */