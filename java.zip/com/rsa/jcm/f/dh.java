package com.rsa.jcm.f;

import com.rsa.crypto.CryptoModule;
import com.rsa.crypto.KeyPair;
import com.rsa.crypto.SecureRandom;
import com.rsa.crypto.Signature;

public final class dh
{
  private static final CryptoModule jdField_if = new ke();
  private static final byte[] ig = "Message to sign".getBytes();
  
  public static void a(KeyPair paramKeyPair, SecureRandom paramSecureRandom)
  {
    String str = paramKeyPair.getAlgorithm();
    if ("DH".equals(str)) {
      str = "DSA";
    }
    if ("EC".equals(str)) {
      str = "ECDSA";
    }
    if (a("SHA256/" + str, paramKeyPair, paramSecureRandom)) {
      return;
    }
    throw new SecurityException("An internal FIPS 140-2 required pairwise consistency check failed");
  }
  
  private static boolean a(String paramString, KeyPair paramKeyPair, SecureRandom paramSecureRandom)
  {
    Signature localSignature1 = null;
    Signature localSignature2 = null;
    try
    {
      localSignature1 = jdField_if.newSignature(paramString);
      localSignature1.initSign(paramKeyPair.getPrivate(), paramSecureRandom);
      localSignature1.update(ig);
      byte[] arrayOfByte = localSignature1.sign();
      localSignature2 = jdField_if.newSignature(paramString);
      localSignature2.initVerify(paramKeyPair.getPublic());
      localSignature2.update(ig);
      bool = localSignature2.verify(arrayOfByte);
      return bool;
    }
    catch (Exception localException)
    {
      boolean bool = false;
      return bool;
    }
    finally
    {
      er.a(localSignature1);
      er.a(localSignature2);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dh
 * JD-Core Version:    0.7.0.1
 */