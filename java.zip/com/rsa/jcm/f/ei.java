package com.rsa.jcm.f;

import com.rsa.crypto.CryptoModule;
import com.rsa.crypto.SecureRandom;

public abstract class ei
  implements dr
{
  private final int jd;
  private ee je = ee.iV;
  protected CryptoModule ip;
  
  private void b(ee paramee)
  {
    this.je = this.je.a(paramee);
  }
  
  protected ei(int paramInt)
  {
    this.jd = paramInt;
  }
  
  public final int aK()
  {
    return this.jd;
  }
  
  public ee aL()
  {
    return this.je;
  }
  
  protected abstract boolean test(int paramInt)
    throws Exception;
  
  protected SecureRandom aM()
  {
    SecureRandom localSecureRandom = this.ip.newSecureRandom("CTRDRBG");
    cp.a((cg)localSecureRandom);
    return localSecureRandom;
  }
  
  public dr aB()
    throws Exception
  {
    aN();
    return this;
  }
  
  public boolean aC()
  {
    return this.je == ee.iS;
  }
  
  public final synchronized void aN()
  {
    if (this.je == ee.iU) {
      return;
    }
    if (this.je == ee.iT) {
      return;
    }
    if (this.je == ee.iV) {
      b(ee.iU);
    }
    boolean bool1 = true;
    for (int i = 0; i < aK(); i++)
    {
      String str = getName();
      ds localds = new ds(i, str);
      dt.a(localds);
      boolean bool2;
      try
      {
        bool2 = test(i);
        if (bool2) {
          dt.c(localds);
        } else {
          dt.d(localds);
        }
      }
      catch (Throwable localThrowable)
      {
        bool2 = false;
        dt.d(localds);
      }
      bool1 &= bool2;
      dt.b(localds);
    }
    if (!bool1) {
      b(ee.iT);
    } else if (this.je != ee.iS) {
      b(ee.iS);
    }
  }
  
  public ei a(CryptoModule paramCryptoModule)
  {
    this.ip = paramCryptoModule;
    return this;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ei
 * JD-Core Version:    0.7.0.1
 */