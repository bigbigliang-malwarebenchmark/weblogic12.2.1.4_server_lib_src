package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.KeyGenerator;
import com.rsa.crypto.MessageDigest;
import com.rsa.crypto.SecretKey;
import com.rsa.crypto.SecureRandom;

public final class in
  extends cl
  implements KeyGenerator
{
  private int threshold;
  private byte[] oY;
  private byte[][] oZ;
  private String jZ;
  private boolean initialized = false;
  
  public in(ke paramke)
  {
    super(paramke);
  }
  
  public void initialize(AlgorithmParams paramAlgorithmParams)
    throws InvalidAlgorithmParameterException
  {
    clearSensitiveData();
    if (paramAlgorithmParams == null) {
      throw new InvalidAlgorithmParameterException("Algorithm parameters required.");
    }
    if (!(paramAlgorithmParams instanceof AlgInputParams)) {
      throw new InvalidAlgorithmParameterException(paramAlgorithmParams.getClass().getName());
    }
    AlgInputParams localAlgInputParams = (AlgInputParams)paramAlgorithmParams;
    this.threshold = ij.c(localAlgInputParams, "keyThreshold");
    if (this.threshold < 2) {
      throw new InvalidAlgorithmParameterException("Key threshold must be at least 2.");
    }
    this.oY = ij.a(localAlgInputParams, "secret");
    this.oZ = ((byte[][])localAlgInputParams.get("xData"));
    if (this.oZ == null) {
      throw new InvalidAlgorithmParameterException("Expected xData parameter not present.");
    }
    if (this.oZ.length < this.threshold) {
      throw new InvalidAlgorithmParameterException("xData is too short.");
    }
    this.jZ = ij.a(localAlgInputParams, "digest", null);
    this.initialized = true;
  }
  
  public SecretKey generate(int paramInt, SecureRandom paramSecureRandom)
  {
    if (!this.initialized) {
      throw new IllegalStateException("Object has not been initialized.");
    }
    if (!io.ad(paramInt)) {
      throw new InvalidAlgorithmParameterException("Invalid key size.");
    }
    int i = paramInt >> 3;
    if (this.oY.length > i) {
      throw new InvalidAlgorithmParameterException("The secret must not be larger than the key size.");
    }
    for (int j = 0; j < this.oZ.length; j++) {
      if (this.oZ[j].length > i) {
        throw new InvalidAlgorithmParameterException("The x values must not be larger than key size.");
      }
    }
    byte[][] arrayOfByte = (byte[][])null;
    try
    {
      byte[] arrayOfByte1 = io.ae(paramInt);
      byte[] arrayOfByte2 = io.a(i, this.oY, paramSecureRandom);
      arrayOfByte = io.a(this.threshold, arrayOfByte1, arrayOfByte2, this.oZ, paramSecureRandom);
      byte[] arrayOfByte3 = null;
      if (this.jZ != null)
      {
        localObject1 = il.b(this.jZ, this.an);
        ((MessageDigest)localObject1).update(arrayOfByte2, 0, arrayOfByte2.length);
        arrayOfByte3 = new byte[((MessageDigest)localObject1).getDigestSize()];
        ((MessageDigest)localObject1).digest(arrayOfByte3, 0);
      }
      Object localObject1 = new fk(this.an, arrayOfByte1, arrayOfByte, arrayOfByte3);
      return localObject1;
    }
    finally
    {
      er.a(arrayOfByte);
    }
  }
  
  public void clearSensitiveData()
  {
    this.initialized = false;
    this.threshold = 0;
    this.oY = null;
    this.oZ = ((byte[][])null);
    this.jZ = null;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.in
 * JD-Core Version:    0.7.0.1
 */