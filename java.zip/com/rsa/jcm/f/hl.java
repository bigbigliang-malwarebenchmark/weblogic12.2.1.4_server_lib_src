package com.rsa.jcm.f;

import com.rsa.crypto.SensitiveData;

class hl
  extends hj
{
  hl(hu paramhu)
  {
    super(paramhu);
  }
  
  public gi a(gi paramgi1, gi paramgi2)
  {
    if (paramgi1.isInfinite()) {
      return (gi)paramgi2.clone();
    }
    if (paramgi2.isInfinite()) {
      return (gi)paramgi1.clone();
    }
    gl localgl1 = paramgi1.bt();
    gl localgl2 = paramgi1.bu();
    gl localgl3 = paramgi1.bv();
    gl localgl4 = paramgi2.bt();
    gl localgl5 = paramgi2.bu();
    gl localgl6 = paramgi2.bv();
    gl localgl7 = null;
    gl localgl8 = null;
    gl localgl9 = null;
    gl localgl10 = null;
    gl localgl13 = null;
    gl localgl14 = null;
    gl localgl15 = null;
    gl localgl16 = null;
    gl localgl17 = null;
    gl localgl18 = null;
    Object localObject1 = null;
    Object localObject2 = null;
    Object localObject3 = null;
    Object localObject4 = null;
    Object localObject5 = null;
    Object localObject6 = null;
    Object localObject7 = null;
    Object localObject8 = null;
    Object localObject9 = null;
    Object localObject10 = null;
    Object localObject11 = null;
    Object localObject12 = null;
    try
    {
      localgl7 = localgl6.bT();
      localgl8 = localgl1.c(localgl7);
      localgl9 = localgl7.c(localgl6);
      localgl10 = localgl2.c(localgl9);
      gl localgl11;
      gl localgl12;
      if (!localgl3.bS())
      {
        localgl13 = localgl3.bT();
        localgl11 = localgl4.c(localgl13);
        localgl14 = localgl13.c(localgl3);
        localgl12 = localgl5.c(localgl14);
        localObject11 = localgl11;
        localObject12 = localgl12;
      }
      else
      {
        localgl11 = localgl4;
        localgl12 = localgl5;
      }
      localgl15 = localgl8.b(localgl11);
      localgl16 = localgl10.b(localgl12);
      localgl17 = localgl8.a(localgl11);
      localgl18 = localgl10.a(localgl12);
      Object localObject13;
      if (localgl15.isZero())
      {
        if (localgl16.isZero())
        {
          localObject13 = c(paramgi1);
          return localObject13;
        }
        localObject13 = paramgi1.aS().bg().bk();
        return localObject13;
      }
      localObject1 = localgl6.c(localgl15);
      if (localgl3.bS())
      {
        localObject13 = localObject1;
        localObject1 = null;
      }
      else
      {
        localObject13 = localgl3.c((gl)localObject1);
      }
      localObject2 = localgl15.bT();
      localObject3 = ((gl)localObject2).c(localgl15);
      localObject4 = localgl17.c((gl)localObject2);
      localObject5 = localgl16.bT();
      gl localgl19 = ((gl)localObject5).b((gl)localObject4);
      localObject6 = localgl19.a(localgl19);
      localObject7 = ((gl)localObject4).b((gl)localObject6);
      localObject8 = localgl18.c((gl)localObject3);
      localObject9 = ((gl)localObject7).c(localgl16);
      localObject10 = ((gl)localObject9).b((gl)localObject8);
      gl localgl20 = ((hn)localObject10).cs();
      gi localgi = paramgi1.aS().bg().a(localgl19, localgl20, (gl)localObject13);
      return localgi;
    }
    finally
    {
      er.a(localgl7);
      er.a(localgl8);
      er.a(localgl9);
      er.a(localgl10);
      er.a(localgl13);
      er.a(localgl14);
      er.a(localgl15);
      er.a(localgl16);
      er.a(localgl17);
      er.a(localgl18);
      er.a((SensitiveData)localObject1);
      er.a((SensitiveData)localObject2);
      er.a((SensitiveData)localObject3);
      er.a((SensitiveData)localObject4);
      er.a((SensitiveData)localObject5);
      er.a((SensitiveData)localObject6);
      er.a((SensitiveData)localObject7);
      er.a((SensitiveData)localObject8);
      er.a((SensitiveData)localObject9);
      er.a((SensitiveData)localObject10);
      er.a(localObject11);
      er.a(localObject12);
    }
  }
  
  public gi c(gi paramgi)
  {
    if (paramgi.isInfinite()) {
      return (gi)paramgi.clone();
    }
    ge localge = paramgi.aS();
    gl localgl1 = paramgi.bt();
    gl localgl2 = paramgi.bu();
    gl localgl3 = paramgi.bv();
    gl localgl4 = null;
    gl localgl5 = null;
    Object localObject1 = null;
    Object localObject2 = null;
    Object localObject3 = null;
    Object localObject4 = null;
    Object localObject5 = null;
    Object localObject6 = null;
    Object localObject7 = null;
    Object localObject8 = null;
    Object localObject9 = null;
    Object localObject10 = null;
    Object localObject11 = null;
    Object localObject12 = null;
    Object localObject13 = null;
    Object localObject14 = null;
    try
    {
      localgl4 = hi.a(localge, localgl1, localgl2, localgl3);
      localgl5 = localgl2.c(localgl3);
      gl localgl6 = localgl5.a(localgl5);
      if (localgl6.isZero())
      {
        localObject15 = paramgi.aS().bg().bk();
        return localObject15;
      }
      localObject1 = localgl2.bT();
      localObject2 = localgl1.c((gl)localObject1);
      localObject3 = ((gl)localObject2).a((gl)localObject2);
      localObject4 = ((gl)localObject3).a((gl)localObject3);
      localObject5 = localObject4;
      localObject6 = localgl4.bT();
      localObject7 = ((gl)localObject6).b((gl)localObject5);
      Object localObject15 = ((gl)localObject7).b((gl)localObject5);
      localObject8 = ((gl)localObject1).bT();
      localObject9 = ((gl)localObject8).a((gl)localObject8);
      localObject10 = ((gl)localObject9).a((gl)localObject9);
      localObject11 = ((gl)localObject10).a((gl)localObject10);
      localObject12 = localObject11;
      localObject13 = ((gl)localObject5).b((gl)localObject15);
      localObject14 = localgl4.c((gl)localObject13);
      gl localgl7 = ((gl)localObject14).b((gl)localObject12);
      gi localgi = paramgi.aS().bg().a((gl)localObject15, localgl7, localgl6);
      return localgi;
    }
    finally
    {
      er.a(localgl4);
      er.a(localgl5);
      er.a((SensitiveData)localObject1);
      er.a((SensitiveData)localObject2);
      er.a((SensitiveData)localObject3);
      er.a((SensitiveData)localObject4);
      er.a((SensitiveData)localObject5);
      er.a((SensitiveData)localObject6);
      er.a((SensitiveData)localObject7);
      er.a((SensitiveData)localObject8);
      er.a((SensitiveData)localObject9);
      er.a((SensitiveData)localObject10);
      er.a((SensitiveData)localObject11);
      er.a((SensitiveData)localObject12);
      er.a((SensitiveData)localObject13);
      er.a((SensitiveData)localObject14);
    }
  }
  
  public gi d(gi paramgi)
  {
    return paramgi.aS().bg().a(paramgi.bo(), paramgi.bu().bV(), paramgi.bq());
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hl
 * JD-Core Version:    0.7.0.1
 */