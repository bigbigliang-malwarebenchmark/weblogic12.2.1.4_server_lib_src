package com.rsa.jcm.f;

import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.KeyPair;
import com.rsa.crypto.SecureRandom;

public abstract class fv
{
  public static fv d(String paramString)
  {
    if ("RSA".equalsIgnoreCase(paramString)) {
      return new fv.b(new fy());
    }
    return new fv.a();
  }
  
  public abstract void a(AlgorithmParams paramAlgorithmParams, KeyPair paramKeyPair, SecureRandom paramSecureRandom);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fv
 * JD-Core Version:    0.7.0.1
 */