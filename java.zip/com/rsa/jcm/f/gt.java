package com.rsa.jcm.f;

import com.rsa.crypto.SensitiveData;

class gt
  extends gs
{
  gt(hc paramhc)
  {
    super(paramhc);
  }
  
  public gi a(gi paramgi1, gi paramgi2)
  {
    if (paramgi1.isInfinite()) {
      return (gi)paramgi2.clone();
    }
    if (paramgi2.isInfinite()) {
      return (gi)paramgi1.clone();
    }
    ge localge = paramgi1.aS();
    gl localgl1 = paramgi1.bt();
    gl localgl2 = paramgi1.bu();
    gl localgl3 = paramgi1.bv();
    gl localgl4 = paramgi2.bt();
    gl localgl5 = paramgi2.bu();
    gl localgl6 = paramgi2.bv();
    Object localObject1 = null;
    Object localObject2 = null;
    Object localObject3 = null;
    gl localgl10 = null;
    gl localgl11 = null;
    gl localgl12 = null;
    gl localgl13 = null;
    gl localgl14 = null;
    gl localgl15 = null;
    Object localObject4 = null;
    Object localObject5 = null;
    Object localObject6 = null;
    Object localObject7 = null;
    Object localObject8 = null;
    Object localObject9 = null;
    Object localObject10 = null;
    Object localObject11 = null;
    Object localObject12 = null;
    Object localObject13 = null;
    Object localObject14 = null;
    Object localObject15 = null;
    Object localObject16 = null;
    Object localObject17 = null;
    Object localObject18 = null;
    Object localObject19 = null;
    SensitiveData localSensitiveData = null;
    Object localObject20 = null;
    boolean bool = localgl6.bS();
    try
    {
      if (!bool)
      {
        gl localgl9 = localgl6;
        localgl10 = localgl9.bT();
        localgl7 = localgl1.c(localgl10);
        localgl13 = localgl10;
        localgl10 = localgl6.c(localgl10);
        localgl8 = localgl2.c(localgl10);
        localObject19 = localgl7;
        localObject19 = localgl8;
      }
      else
      {
        localgl7 = localgl1;
        localgl8 = localgl2;
      }
      localgl14 = localgl10;
      localgl10 = localgl3.bT();
      localgl11 = localgl4.c(localgl10);
      localgl15 = localgl10;
      localgl10 = localgl3.c(localgl10);
      localgl12 = localgl5.c(localgl10);
      if (localgl7.equals(localgl11))
      {
        if (localgl8.equals(localgl12))
        {
          localObject21 = c(paramgi1);
          return localObject21;
        }
        localObject21 = this.mR.b(paramgi1.aS()).bk();
        return localObject21;
      }
      if (!bool)
      {
        localObject4 = localgl8;
        localObject5 = localgl7;
      }
      gl localgl8 = localgl8.a(localgl12);
      gl localgl7 = localgl7.a(localgl11);
      localObject2 = localgl8.c(localgl4);
      localObject1 = localgl7.c(localgl3);
      localObject3 = ((gl)localObject1).c(localgl5);
      localObject6 = localObject2;
      localObject2 = ((gl)localObject2).a((gl)localObject3);
      localObject7 = localObject3;
      localObject3 = ((gl)localObject1).bT();
      localObject8 = localgl10;
      localgl10 = ((gl)localObject2).c((gl)localObject3);
      if (!bool)
      {
        localObject9 = localObject1;
        localObject1 = ((gl)localObject1).c(localgl6);
      }
      Object localObject21 = localObject1;
      localObject1 = null;
      if (!localge.bb().bG().isZero())
      {
        localObject10 = localgl11;
        localgl11 = ((gl)localObject21).bT();
        localObject11 = localgl12;
        localgl12 = localgl11.c(localge.bb().bG());
      }
      localObject12 = localObject2;
      localObject2 = localgl8.a((gl)localObject21);
      localObject13 = localgl8;
      localgl8 = localgl8.c((gl)localObject2);
      localObject14 = localObject3;
      localObject3 = localgl7.bT();
      localObject15 = localgl7;
      localgl7 = localgl7.c((gl)localObject3);
      localObject16 = localgl7;
      localgl7 = localgl7.a(localgl8);
      localObject20 = localgl8;
      if (!localge.bb().bG().isZero())
      {
        localObject17 = localgl7;
        localgl7 = localgl7.a(localgl12);
      }
      gl localgl16 = localgl7;
      localgl7 = null;
      localObject18 = localObject2;
      localObject2 = localgl16.c((gl)localObject2);
      gl localgl17 = ((gl)localObject2).a(localgl10);
      gi localgi = this.mR.b(paramgi1.aS()).a(localgl16, localgl17, (gl)localObject21);
      return localgi;
    }
    finally
    {
      er.a((SensitiveData)localObject1);
      er.a((SensitiveData)localObject2);
      er.a((SensitiveData)localObject3);
      er.a(localgl10);
      er.a(localgl11);
      er.a(localgl12);
      er.a(localgl13);
      er.a(localgl14);
      er.a(localgl15);
      er.a((SensitiveData)localObject4);
      er.a((SensitiveData)localObject5);
      er.a((SensitiveData)localObject6);
      er.a((SensitiveData)localObject7);
      er.a((SensitiveData)localObject8);
      er.a((SensitiveData)localObject9);
      er.a((SensitiveData)localObject10);
      er.a((SensitiveData)localObject11);
      er.a((SensitiveData)localObject12);
      er.a((SensitiveData)localObject13);
      er.a((SensitiveData)localObject14);
      er.a((SensitiveData)localObject15);
      er.a((SensitiveData)localObject16);
      er.a((SensitiveData)localObject17);
      er.a((SensitiveData)localObject18);
      er.a(localObject19);
      er.a(localSensitiveData);
      er.a((SensitiveData)localObject20);
    }
  }
  
  public gi c(gi paramgi)
  {
    ge localge = paramgi.aS();
    if (paramgi.isInfinite()) {
      return this.mR.b(paramgi.aS()).bk();
    }
    gl localgl1 = paramgi.bt();
    gl localgl2 = paramgi.bu();
    gl localgl3 = paramgi.bv();
    gl localgl4 = localge.bb().bJ();
    if ((localgl1.isZero()) || (localgl3.isZero())) {
      return this.mR.b(paramgi.aS()).bk();
    }
    gl localgl5 = null;
    gl localgl6 = null;
    gl localgl7 = null;
    gl localgl8 = null;
    gl localgl9 = null;
    gl localgl10 = null;
    gl localgl11 = null;
    gl localgl12 = null;
    gl localgl13 = null;
    gl localgl14 = null;
    gl localgl15 = null;
    gl localgl16 = null;
    gl localgl17 = null;
    gl localgl18 = null;
    try
    {
      localgl5 = localgl2.c(localgl3);
      localgl6 = localgl3.bT();
      localgl7 = localgl6.c(localgl4);
      localgl8 = localgl1.c(localgl6);
      localgl9 = localgl5.a(localgl8);
      localgl10 = localgl1.a(localgl7);
      localgl11 = localgl10.bT();
      localgl12 = localgl1.bT();
      localgl13 = localgl11.bT();
      localgl14 = localgl12.a(localgl9);
      localgl15 = localgl14.c(localgl13);
      localgl16 = localgl12.bT();
      localgl17 = localgl16.c(localgl8);
      localgl18 = localgl17.a(localgl15);
      gl localgl19 = localgl13;
      gl localgl20 = localgl18;
      gl localgl21 = localgl8;
      localgl13 = null;
      localgl18 = null;
      localgl8 = null;
      gi localgi = paramgi.aS().bg().a(localgl19, localgl20, localgl21);
      return localgi;
    }
    finally
    {
      er.a(localgl5);
      er.a(localgl6);
      er.a(localgl7);
      er.a(localgl8);
      er.a(localgl9);
      er.a(localgl10);
      er.a(localgl11);
      er.a(localgl12);
      er.a(localgl13);
      er.a(localgl14);
      er.a(localgl15);
      er.a(localgl16);
      er.a(localgl17);
      er.a(localgl18);
    }
  }
  
  public gi d(gi paramgi)
  {
    gl localgl = paramgi.bt().c(paramgi.bv());
    try
    {
      gi localgi = this.mR.b(paramgi.aS()).a(paramgi.bo(), localgl.a(paramgi.bu()), paramgi.bq());
      return localgi;
    }
    finally
    {
      er.a(localgl);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gt
 * JD-Core Version:    0.7.0.1
 */