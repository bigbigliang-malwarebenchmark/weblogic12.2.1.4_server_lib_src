package com.rsa.jcm.f;

final class ee
{
  private final ee[] iR;
  public static final ee iS = new ee(new ee[] { iT });
  public static final ee iT = new ee(new ee[] { iT });
  public static final ee iU = new ee(new ee[] { iS, iT });
  public static final ee iV = new ee(new ee[] { iU, iT });
  
  private ee(ee[] paramArrayOfee)
  {
    this.iR = paramArrayOfee;
  }
  
  public ee a(ee paramee)
  {
    for (int i = 0; i < this.iR.length; i++) {
      if (this.iR[i] == paramee) {
        return paramee;
      }
    }
    throw new SecurityException("Invalid KATState transition");
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ee
 * JD-Core Version:    0.7.0.1
 */