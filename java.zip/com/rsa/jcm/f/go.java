package com.rsa.jcm.f;

public abstract class go
  extends ge
{
  private String mJ;
  
  go(String paramString, gk paramgk, gl paramgl1, gl paramgl2, byte[] paramArrayOfByte, gl paramgl3, gl paramgl4, id paramid, int paramInt)
  {
    super(paramgk, paramgl1, paramgl2, paramArrayOfByte, null, paramgl3, paramgl4, paramid, paramInt);
    this.mJ = paramString;
  }
  
  public String getCurveName()
  {
    return this.mJ;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.go
 * JD-Core Version:    0.7.0.1
 */