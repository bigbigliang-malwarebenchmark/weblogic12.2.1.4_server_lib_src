package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.AlgParamGenerator;
import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.BigNum;
import com.rsa.crypto.CryptoException;
import com.rsa.crypto.DHDSAParams;
import com.rsa.crypto.DSAParams;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.MessageDigest;
import com.rsa.crypto.SecureRandom;

public class ik
  extends cl
  implements AlgParamGenerator
{
  private static final int oN = 160;
  static final int fs = 20;
  static final String oO = "Could not generate prime.";
  private static final int oP = 0;
  private static final int oQ = 1;
  private static final int oR = 2;
  static final int oS = 50;
  SecureRandom j;
  int oT;
  int oU;
  private String jZ;
  private DHDSAParams oV;
  private int oW;
  private DHDSAParams oX;
  
  public ik(ke paramke)
  {
    super(paramke);
  }
  
  public void initGen(AlgorithmParams paramAlgorithmParams, SecureRandom paramSecureRandom)
  {
    reset();
    if (!(paramAlgorithmParams instanceof AlgInputParams)) {
      throw new InvalidAlgorithmParameterException("Parameters object invalid for algorithm.");
    }
    AlgInputParams localAlgInputParams = (AlgInputParams)paramAlgorithmParams;
    Object localObject = localAlgInputParams.get("paramsForBaseGen");
    if (localObject == null)
    {
      this.oT = ij.c(localAlgInputParams, "primeLen");
      this.oU = ij.a(localAlgInputParams, "subprimeLen", ab(this.oT));
      m(this.oT, this.oU);
      this.jZ = ij.a(localAlgInputParams, "digest", ac(this.oU));
    }
    else
    {
      if (!(localObject instanceof DSAParams)) {
        throw new InvalidAlgorithmParameterException("Expected baseOnly parameter of type DSAParams");
      }
      this.oX = ((DSAParams)localObject);
    }
    this.j = paramSecureRandom;
  }
  
  private void m(int paramInt1, int paramInt2)
  {
    if ((paramInt2 < 160) || (paramInt2 >= paramInt1)) {
      throw new InvalidAlgorithmParameterException("Sub-prime Q len must be > 160and < prime P len");
    }
  }
  
  public AlgorithmParams generate()
  {
    if (this.oV != null) {
      throw new IllegalStateException("Not initialized for generation.");
    }
    if (this.oX != null)
    {
      localid1 = new id();
      localid2 = new id();
      e((id)this.oX.getP(), (id)this.oX.getQ(), localid1, localid2);
      return new fa(this.an, this.oX.getP(), this.oX.getQ(), localid1, this.oX.getSeed(), this.oX.getCounter(), localid2, this.oX.getDigestAlg());
    }
    id localid1 = new id();
    id localid2 = new id();
    id localid3 = new id();
    byte[] arrayOfByte = new byte[this.oU / 8];
    int[] arrayOfInt = new int[1];
    id localid4 = new id();
    a(localid2, localid1, localid3, arrayOfByte, arrayOfInt, localid4, this.jZ);
    return new fa(this.an, localid2, localid1, localid3, arrayOfByte, arrayOfInt[0], localid4, this.jZ);
  }
  
  private int aa(int paramInt)
    throws InvalidAlgorithmParameterException
  {
    if (paramInt <= 160) {
      return 19;
    }
    if (paramInt <= 224) {
      return 24;
    }
    if (paramInt <= 256) {
      return 27;
    }
    if (paramInt <= 2048) {
      return 3;
    }
    return 2;
  }
  
  private void a(id paramid1, id paramid2, id paramid3, byte[] paramArrayOfByte, int[] paramArrayOfInt, id paramid4, String paramString)
  {
    a(paramid1, paramid2, paramArrayOfByte, paramArrayOfInt, paramString);
    e(paramid1, paramid2, paramid3, paramid4);
  }
  
  protected boolean a(byte[] paramArrayOfByte, String paramString, SecureRandom paramSecureRandom, id paramid1, id paramid2, int[] paramArrayOfInt, boolean paramBoolean)
  {
    boolean bool;
    if (paramBoolean) {
      bool = a(paramArrayOfByte, paramArrayOfByte.length * 8, paramSecureRandom, paramid2);
    } else {
      bool = a(paramArrayOfByte, paramSecureRandom, paramid2, paramString, this.oU);
    }
    if (!bool) {
      return false;
    }
    int i = 1;
    if (paramBoolean) {
      i = 2;
    }
    return a(paramArrayOfByte, paramid2, paramSecureRandom, paramid1, paramArrayOfInt, paramString, i);
  }
  
  private boolean a(byte[] paramArrayOfByte, SecureRandom paramSecureRandom, id paramid, String paramString, int paramInt)
  {
    id localid1 = new id();
    id localid2 = new id();
    id localid3 = new id();
    byte[] arrayOfByte = null;
    bq localbq = null;
    try
    {
      localbq = il.b(paramString, this.an);
      int i = localbq.getDigestSize();
      localbq.update(paramArrayOfByte, 0, paramArrayOfByte.length);
      arrayOfByte = new byte[i];
      localbq.digest(arrayOfByte, 0);
      localid2.t(arrayOfByte, 0, arrayOfByte.length);
      for (int k = paramInt; k <= i * 8; k++) {
        localid2.i(k, 0);
      }
      paramid.p(localid2);
      paramid.i(paramInt - 1, 1);
      paramid.Q(1);
      if (localid2.cI()) {
        paramid.R(1);
      }
      k = (if.a(paramid, localid1, localid2, localid3, paramSecureRandom, aa(paramInt))) && (if.b(paramid, localid1, localid3, localid2)) ? 1 : 0;
      return k;
    }
    finally
    {
      er.a(localid1);
      er.a(localid2);
      er.a(localid3);
      er.a(localbq);
      er.w(arrayOfByte);
    }
  }
  
  private boolean a(byte[] paramArrayOfByte, int paramInt, SecureRandom paramSecureRandom, id paramid)
  {
    boolean bool1 = false;
    byte[] arrayOfByte1 = new byte[20];
    byte[] arrayOfByte2 = new byte[20];
    id localid1 = new id();
    id localid2 = new id();
    id localid3 = new id();
    bw localbw = new bw(this.an);
    try
    {
      a(paramArrayOfByte, paramInt, 0, 0, localid1, localbw, false, arrayOfByte1);
      a(paramArrayOfByte, paramInt, 1, 0, localid1, localbw, true, arrayOfByte2);
      for (boolean bool2 = false; bool2 < true; bool2++)
      {
        boolean tmp99_97 = bool2;
        byte[] tmp99_95 = arrayOfByte1;
        tmp99_95[tmp99_97] = ((byte)(tmp99_95[tmp99_97] ^ arrayOfByte2[bool2]));
      }
      int tmp118_117 = 0;
      byte[] tmp118_115 = arrayOfByte1;
      tmp118_115[tmp118_117] = ((byte)(tmp118_115[tmp118_117] | 0x80));
      byte[] tmp130_126 = arrayOfByte1;
      tmp130_126[19] = ((byte)(tmp130_126[19] | 0x1));
      paramid.t(arrayOfByte1, 0, 20);
      if (if.i(paramid, localid1, localid2)) {
        bool1 = if.a(paramid, localid1, localid2, localid3, paramSecureRandom, 50);
      }
      bool2 = bool1;
      return bool2;
    }
    finally
    {
      localid1.clearSensitiveData();
      localid2.clearSensitiveData();
      localid3.clearSensitiveData();
    }
  }
  
  private boolean a(byte[] paramArrayOfByte, id paramid1, id paramid2, String paramString, int paramInt, boolean paramBoolean)
  {
    int i = paramid1.getBitLength();
    int k = paramid2.getBitLength();
    if (paramInt > 4 * i - 1) {
      return false;
    }
    int m = paramArrayOfByte.length * 8;
    if (m < k) {
      return false;
    }
    id localid1 = new id();
    id localid2 = new id();
    try
    {
      int[] arrayOfInt = { -1 };
      boolean bool1;
      if ((!if.i(paramid2, localid1, localid2)) || (!if.i(paramid1, localid1, localid2)))
      {
        bool1 = false;
        return bool1;
      }
      if (paramBoolean) {
        bool1 = a(paramArrayOfByte, paramArrayOfByte.length * 8, this.j, localid2);
      } else {
        bool1 = a(paramArrayOfByte, this.j, localid2, paramString, k);
      }
      if ((!bool1) || (!paramid2.equals(localid2)))
      {
        bool2 = false;
        return bool2;
      }
      boolean bool2 = true;
      int n;
      if (paramBoolean) {
        n = 2;
      }
      if (!a(paramArrayOfByte, localid2, this.j, localid1, arrayOfInt, paramString, n))
      {
        bool3 = false;
        return bool3;
      }
      boolean bool3 = (arrayOfInt[0] == paramInt) && (paramid1.equals(localid1));
      return bool3;
    }
    finally
    {
      er.a(localid1);
      er.a(localid2);
    }
  }
  
  private boolean a(byte[] paramArrayOfByte, id paramid1, SecureRandom paramSecureRandom, id paramid2, int[] paramArrayOfInt, String paramString, int paramInt)
  {
    id localid1 = null;
    id localid2 = new id();
    id localid3 = new id();
    id localid4 = new id();
    id localid5 = new id();
    bq localbq = null;
    byte[] arrayOfByte = null;
    try
    {
      localbq = il.b(paramString, this.an);
      int i = localbq.getDigestSize() * 8;
      int k = (this.oT - 1) / i;
      int m = (this.oT - 1) % i;
      arrayOfByte = new byte[(i + 7) / 8];
      int n = paramArrayOfByte.length * 8;
      localid1 = (id)paramid1.clone();
      localid1.H(1);
      int i1 = aa(this.oT);
      int i2 = 0;
      while (i2 < 4 * this.oT - 1)
      {
        a(paramArrayOfByte, n, k, m, paramInt, localid2, localid3, localbq, localid5, arrayOfByte, i);
        localid5.i(this.oT - 1, 1);
        localid5.j(localid1, localid4);
        localid5.t(localid4);
        localid5.Q(1);
        if ((localid5.getBitLength() >= this.oT) && (if.a(localid5, localid2, localid3, localid4, paramSecureRandom, i1)) && (if.b(localid5, localid2, localid3, localid4)))
        {
          paramid2.p(localid5);
          paramArrayOfInt[0] = i2;
          boolean bool = true;
          return bool;
        }
        i2++;
        paramInt += k + 1;
      }
    }
    finally
    {
      er.a(localid5);
      er.a(localid1);
      er.a(localid4);
      er.a(localid2);
      er.a(localid3);
      er.a(localbq);
      er.w(arrayOfByte);
    }
    return false;
  }
  
  private void a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, id paramid1, id paramid2, MessageDigest paramMessageDigest, id paramid3, byte[] paramArrayOfByte2, int paramInt5)
  {
    paramid3.setValue(0);
    for (int i = 0; i <= paramInt2; i++)
    {
      a(paramArrayOfByte1, paramInt1, i, paramInt4, paramid1, paramMessageDigest, true, paramArrayOfByte2);
      paramid2.t(paramArrayOfByte2, 0, paramArrayOfByte2.length);
      if (i == paramInt2) {
        for (int k = paramInt3; k < paramInt5; k++) {
          paramid2.i(k, 0);
        }
      }
      paramid2.H(i * paramInt5);
      paramid3.s(paramid2);
    }
  }
  
  private static int ab(int paramInt)
  {
    if ((paramInt < 512) || (paramInt > 4096)) {
      throw new InvalidAlgorithmParameterException("primeP size MUST be between 512 and 4096.");
    }
    if (paramInt <= 1024) {
      return 160;
    }
    if (paramInt <= 2048) {
      return 224;
    }
    return 256;
  }
  
  private static String ac(int paramInt)
  {
    if (paramInt == 160) {
      return "SHA1";
    }
    if (paramInt <= 224) {
      return "SHA224";
    }
    if (paramInt <= 256) {
      return "SHA256";
    }
    return "SHA512";
  }
  
  public void initVerify(AlgorithmParams paramAlgorithmParams, SecureRandom paramSecureRandom)
  {
    reset();
    if ((paramAlgorithmParams instanceof AlgInputParams))
    {
      Object localObject = ((AlgInputParams)paramAlgorithmParams).get("domainParams");
      if (!(localObject instanceof DHDSAParams)) {
        throw new InvalidAlgorithmParameterException("Expected paramsToVerify to be DSAParams");
      }
      this.oV = ((DHDSAParams)localObject);
      this.oW = ij.a((AlgInputParams)paramAlgorithmParams, "verifyType", 0);
    }
    else if ((paramAlgorithmParams instanceof DHDSAParams))
    {
      this.oV = ((DHDSAParams)paramAlgorithmParams);
      this.oW = 0;
    }
    else
    {
      throw new InvalidAlgorithmParameterException("Expected either DSAParams or AlgInputParams");
    }
    this.j = paramSecureRandom;
    if ((this.oV.getP() == null) || (this.oV.getQ() == null)) {
      throw new InvalidAlgorithmParameterException("DSA P & Q must be specified.");
    }
    this.oT = this.oV.getP().getBitLength();
    this.oU = this.oV.getQ().getBitLength();
  }
  
  public boolean verify()
  {
    if (this.oV == null) {
      throw new IllegalStateException("Not initialized for verification.");
    }
    id localid1 = (id)this.oV.getP();
    id localid2 = (id)this.oV.getQ();
    id localid3 = (id)this.oV.getG();
    byte[] arrayOfByte = this.oV.getSeed();
    int i = this.oV.getCounter();
    String str = this.oV.getDigestAlg();
    if ((this.oW != 1) && (!d(localid1, localid2, localid3, new id()))) {
      return false;
    }
    if (this.oW != 2)
    {
      boolean bool = a(arrayOfByte, localid1, localid2, str, i, true);
      if (!bool) {
        bool = a(arrayOfByte, localid1, localid2, str, i, false);
      }
      if (!bool) {
        return false;
      }
    }
    return true;
  }
  
  void reset()
  {
    this.oT = 0;
    this.oU = 0;
    this.j = null;
    this.oX = null;
    this.oW = 0;
    this.oV = null;
    this.jZ = null;
  }
  
  protected boolean d(id paramid1, id paramid2, id paramid3, id paramid4)
  {
    try
    {
      paramid4.p(paramid1);
      paramid4.R(1);
      if ((paramid3.getBitLength() < 2) || (paramid3.q(paramid4) > 0))
      {
        bool = false;
        return bool;
      }
      paramid3.g(paramid2, paramid1, paramid4);
      boolean bool = paramid4.C(1);
      return bool;
    }
    finally
    {
      paramid4.clearSensitiveData();
    }
  }
  
  protected void a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, int paramInt3, id paramid, MessageDigest paramMessageDigest, boolean paramBoolean, byte[] paramArrayOfByte2)
  {
    try
    {
      int i = paramArrayOfByte1.length;
      paramid.t(paramArrayOfByte1, 0, i);
      paramid.Q(paramInt3 + paramInt2);
      if (paramBoolean) {
        paramid.i(paramInt1, 0);
      }
      byte[] arrayOfByte = paramid.A(i);
      paramMessageDigest.update(arrayOfByte, 0, i);
      paramMessageDigest.digest(paramArrayOfByte2, 0);
    }
    catch (CryptoException localCryptoException)
    {
      throw new CryptoException("Could not generate prime.");
    }
  }
  
  protected void e(id paramid1, id paramid2, id paramid3, id paramid4)
  {
    id localid1 = new id();
    id localid2 = new id(2);
    try
    {
      paramid1.f(paramid2, paramid4, localid1);
      localid2.g(paramid4, paramid1, paramid3);
      while (paramid3.C(1))
      {
        localid2.Q(1);
        localid2.g(paramid4, paramid1, paramid3);
      }
    }
    finally
    {
      localid1.clearSensitiveData();
      localid2.clearSensitiveData();
    }
  }
  
  void a(id paramid1, id paramid2, byte[] paramArrayOfByte, int[] paramArrayOfInt, String paramString)
  {
    boolean bool;
    do
    {
      this.j.nextBytes(paramArrayOfByte);
      bool = a(paramArrayOfByte, paramString, this.j, paramid1, paramid2, paramArrayOfInt, false);
    } while (!bool);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ik
 * JD-Core Version:    0.7.0.1
 */