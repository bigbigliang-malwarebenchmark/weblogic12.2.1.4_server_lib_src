package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;

public abstract class hn
  implements gl
{
  hu nI;
  id nL;
  id nM;
  
  hn(gk paramgk)
  {
    this(paramgk, (id)id.on.clone());
  }
  
  hn(gk paramgk, id paramid)
  {
    this.nI = ((hu)paramgk);
    this.nM = this.nI.cA();
    this.nL = paramid;
  }
  
  public gk ba()
  {
    return this.nI;
  }
  
  public byte[] toOctetString()
  {
    return cr().toOctetString();
  }
  
  public int w(byte[] paramArrayOfByte, int paramInt)
  {
    int i = this.nI.bO();
    cr().v(paramArrayOfByte, paramInt, i);
    return i;
  }
  
  public int r(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    cr().v(paramArrayOfByte, paramInt1, paramInt2);
    return paramInt2;
  }
  
  public id bQ()
  {
    return (id)cr().clone();
  }
  
  public ic bR()
  {
    return cr().bR();
  }
  
  public byte[] q(int paramInt)
  {
    return cr().A(paramInt);
  }
  
  id cr()
  {
    return this.nL;
  }
  
  public boolean isZero()
  {
    return cr().isZero();
  }
  
  public boolean bS()
  {
    return cr().C(1);
  }
  
  public gl a(gl paramgl)
  {
    return m(d(cr(), g(paramgl)));
  }
  
  id d(id paramid1, id paramid2)
  {
    id localid = new id();
    paramid1.f(paramid2, localid);
    l(localid);
    return localid;
  }
  
  public gl b(gl paramgl)
  {
    return m(e(cr(), g(paramgl)));
  }
  
  id e(id paramid1, id paramid2)
  {
    id localid = new id();
    if (paramid1.q(paramid2) >= 0)
    {
      paramid1.g(paramid2, localid);
      return localid;
    }
    paramid1.f(this.nM, localid);
    l(paramid2);
    localid.t(paramid2);
    if (localid.q(this.nM) >= 0) {
      localid.t(this.nM);
    }
    return localid;
  }
  
  public gl c(gl paramgl)
  {
    return h(g(paramgl));
  }
  
  public gl h(id paramid)
  {
    id localid = new id();
    cr().i(paramid, localid);
    l(localid);
    return m(localid);
  }
  
  public gl d(gl paramgl)
  {
    gl localgl1 = null;
    try
    {
      localgl1 = paramgl.bU();
      gl localgl2 = c(localgl1);
      return localgl2;
    }
    finally
    {
      er.a(localgl1);
    }
  }
  
  public gl cs()
  {
    id localid = (id)cr().clone();
    if (localid.testBit(0)) {
      localid.s(this.nM);
    }
    localid.G(1);
    l(localid);
    return m(localid);
  }
  
  public gl bT()
  {
    return c(this);
  }
  
  public gl bU()
  {
    id localid = new id();
    cr().k(this.nM, localid);
    return m(localid);
  }
  
  public gl bV()
  {
    id localid = new id();
    this.nM.g(cr(), localid);
    return m(localid);
  }
  
  public gl i(id paramid)
  {
    id localid = new id();
    cr().g(paramid, this.nM, localid);
    return m(localid);
  }
  
  void l(id paramid)
  {
    id localid = (id)es.a(paramid);
    localid.j(this.nM, paramid);
    er.a(localid);
  }
  
  public boolean ct()
  {
    id localid1 = (id)this.nM.clone();
    localid1.G(1);
    id localid2 = new id();
    try
    {
      cr().g(localid1, this.nM, localid2);
      boolean bool1 = localid2.C(1);
      return bool1;
    }
    catch (CryptoException localCryptoException)
    {
      boolean bool2 = false;
      return bool2;
    }
    finally
    {
      er.a(localid1);
      er.a(localid2);
    }
  }
  
  gl a(hn paramhn)
  {
    id localid = new id();
    cr().g(paramhn.cr(), this.nM, localid);
    return m(localid);
  }
  
  public boolean isValid()
  {
    return cr().q(this.nM) < 0;
  }
  
  id g(gl paramgl)
  {
    return ((hn)paramgl).cr();
  }
  
  private gl m(id paramid)
  {
    return this.nI.bf().j(paramid);
  }
  
  public void bF() {}
  
  public void clearSensitiveData()
  {
    er.a(this.nL);
    this.nL = null;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof hn)) {
      return false;
    }
    hn localhn = (hn)paramObject;
    return (this.nM.equals(localhn.nM)) && (cr().equals(localhn.cr()));
  }
  
  public int hashCode()
  {
    return this.nM.hashCode() ^ cr().hashCode();
  }
  
  public Object clone()
  {
    hn localhn;
    try
    {
      localhn = (hn)super.clone();
      localhn.nL = ((id)es.a(this.nL));
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new CryptoException("Object.clone() unexpectedly threw CloneNotSupportedException.");
    }
    return localhn;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hn
 * JD-Core Version:    0.7.0.1
 */