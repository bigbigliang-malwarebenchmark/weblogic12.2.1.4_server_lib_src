package com.rsa.jcm.f;

public class hm
  implements gm
{
  private hu nI;
  private int nK;
  
  hm(hu paramhu)
  {
    this.nI = paramhu;
    this.nK = this.nI.cy();
  }
  
  public gl bW()
  {
    switch (this.nK)
    {
    case 192: 
      return new ho(this.nI);
    case 224: 
      return new hp(this.nI);
    case 256: 
      return new hq(this.nI);
    case 384: 
      return new hr(this.nI);
    case 521: 
      return new hs(this.nI);
    }
    return new ht(this.nI);
  }
  
  public gl j(id paramid)
  {
    switch (this.nK)
    {
    case 192: 
      return new ho(this.nI, paramid);
    case 224: 
      return new hp(this.nI, paramid);
    case 256: 
      return new hq(this.nI, paramid);
    case 384: 
      return new hr(this.nI, paramid);
    case 521: 
      return new hs(this.nI, paramid);
    }
    return new ht(this.nI, paramid);
  }
  
  public gl s(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return j(new id(paramArrayOfByte, paramInt1, paramInt2));
  }
  
  public gl bX()
  {
    return j((id)id.oo.clone());
  }
  
  public gl k(id paramid)
  {
    return new ht(this.nI, paramid, true);
  }
  
  public gl a(ic paramic)
  {
    return j(new id(paramic));
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hm
 * JD-Core Version:    0.7.0.1
 */