package com.rsa.jcm.f;

public final class eg
  extends eo
{
  private static final byte[] iW = jb.hexStringToByteArray("f8938ecc9edebc5030c0c6a441e213cd24e6f770a50dda07876f8d55da062bcadb386b411fd4fe4313a604fce6c17fbc");
  private static final byte[] iX = jb.hexStringToByteArray("f6c9575ed7ddd73e1f7d16eca115415812a43c2b747daaaae043abfb50053fce");
  private static final byte[] iY = jb.hexStringToByteArray("36c129d01a3200894b9179faac589d9835d58775f9b5ea3587cb8fd0364cae8c");
  private static final byte[] iZ = jb.hexStringToByteArray("ae6c806f8ad4d80784549dff28a4b58fd837681a51d928c3e30ee5ff14f39868");
  private static final byte[] ja = jb.hexStringToByteArray("62e1fd91f23f558a605f28478c58cf72637b89784d959df7e946d3f07bd1b616");
  private static final byte[] jb = jb.hexStringToByteArray("202c88c00f84a17a20027079604787461176455539e705be730890602c289a5001e34eeb3a043e5d52a65e66125188bf");
  private static final byte[] jc = jb.hexStringToByteArray("d06139889fffac1e3a71865f504aa5d0d2a2e89506c6f2279b670c3e1b74f531016a2530c51a3a0f7e1d6590d0f0566b2f387f8d11fd4f731cdd572d2eae927f6f2f81410b25e6960be68985add6c38445ad9f8c64bf8068bf9a6679485d966f1ad6f68b43495b10a683755ea2b858d70ccac7ec8b053c6bd41ca299d4e51928");
  
  public boolean test(int paramInt)
  {
    return (a("KDFTLS12/SHA256", iW, jB, iY, iX, jb)) && (a("KDFTLS12/SHA256", jb, jC, iZ, ja, jc));
  }
  
  public String getName()
  {
    return "KDFTLS12";
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.eg
 * JD-Core Version:    0.7.0.1
 */