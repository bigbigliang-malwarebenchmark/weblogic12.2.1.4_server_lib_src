package com.rsa.jcm.f;

import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.BigNum;
import com.rsa.crypto.CryptoException;
import com.rsa.crypto.DHParams;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.KeyPair;
import com.rsa.crypto.KeyPairGenerator;
import com.rsa.crypto.PQGParams;
import com.rsa.crypto.SecureRandom;

public final class fr
  extends cl
  implements KeyPairGenerator
{
  public static final int kR = 160;
  private id G;
  private id kS;
  private id kT;
  private SecureRandom M;
  private boolean initialized;
  private PQGParams kU;
  private String ke;
  
  public fr(ke paramke, String paramString)
  {
    super(paramke);
    this.ke = paramString;
  }
  
  public void initialize(AlgorithmParams paramAlgorithmParams, SecureRandom paramSecureRandom)
    throws InvalidAlgorithmParameterException
  {
    if (!(paramAlgorithmParams instanceof PQGParams)) {
      throw new InvalidAlgorithmParameterException("Parameters object invalid for algorithm.");
    }
    this.kU = ((PQGParams)paramAlgorithmParams);
    this.G = ((id)this.kU.getP());
    if (this.kU.getQ() == null)
    {
      int i = 160;
      if (((paramAlgorithmParams instanceof DHParams)) && (((DHParams)paramAlgorithmParams).getMaxExponentLen() != 0)) {
        i = ((DHParams)paramAlgorithmParams).getMaxExponentLen();
      }
      this.kS = new id();
      this.kS.O(i);
      this.kS.R(1);
    }
    else
    {
      if (this.kU.getQ().getBitLength() < 160) {
        throw new InvalidAlgorithmParameterException("Key size subprime length too small");
      }
      this.kS = ((id)this.kU.getQ());
    }
    this.kT = ((id)this.kU.getG());
    this.M = paramSecureRandom;
    this.initialized = true;
  }
  
  public KeyPair generate()
  {
    return generate(cz.ai());
  }
  
  public KeyPair generate(boolean paramBoolean)
  {
    if (!this.initialized) {
      throw new IllegalStateException("Object not initialized.");
    }
    id localid1 = null;
    byte[] arrayOfByte = null;
    fu localfu1 = null;
    try
    {
      localid1 = (id)this.kS.clone();
      localid1.R(1);
      arrayOfByte = new byte[(this.kS.getBitLength() + 7) / 8 + 8];
      this.M.nextBytes(arrayOfByte);
      id localid2 = new id();
      id localid3 = new id();
      localid3.t(arrayOfByte, 0, arrayOfByte.length);
      localid3.j(localid1, localid2);
      localid2.Q(1);
      this.kT.g(localid2, this.G, localid3);
      fc localfc = new fc(this.an, localid3, this.kU, this.ke);
      fb localfb = new fb(this.an, localid2, this.kU, this.ke);
      localfu1 = new fu(this.ke, localfb, localfc);
      if (paramBoolean) {
        dm.b(localfu1, this.M);
      }
      fu localfu2 = localfu1;
      return localfu2;
    }
    catch (SecurityException localSecurityException)
    {
      er.a(localfu1);
      throw localSecurityException;
    }
    catch (CryptoException localCryptoException)
    {
      er.a(localfu1);
      throw localCryptoException;
    }
    finally
    {
      er.w(arrayOfByte);
      er.a(localid1);
    }
  }
  
  public void clearSensitiveData()
  {
    this.initialized = false;
    if ((this.kU != null) && (!this.kS.equals(this.kU.getQ()))) {
      er.a(this.kS);
    }
    this.G = null;
    this.kT = null;
    this.kS = null;
    this.kU = null;
    this.M = null;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fr
 * JD-Core Version:    0.7.0.1
 */