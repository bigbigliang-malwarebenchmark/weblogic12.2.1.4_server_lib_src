package com.rsa.jcm.f;

public class ht
  extends hn
{
  private id nX;
  
  ht(gk paramgk)
  {
    super(paramgk);
  }
  
  ht(gk paramgk, id paramid)
  {
    super(paramgk, paramid);
  }
  
  ht(gk paramgk, id paramid, boolean paramBoolean)
  {
    super(paramgk, paramBoolean ? null : paramid);
    if (paramBoolean) {
      this.nX = paramid;
    }
  }
  
  id cr()
  {
    if (this.nL == null) {
      cv();
    }
    return this.nL;
  }
  
  id cu()
  {
    if (this.nX == null) {
      cw();
    }
    return this.nX;
  }
  
  id h(gl paramgl)
  {
    return ((ht)paramgl).cu();
  }
  
  private void cv()
  {
    this.nL = new id();
    this.nX.a(this.nM, this.nI.cC(), this.nL);
  }
  
  private void cw()
  {
    this.nX = new id();
    id localid = new id();
    l(this.nL);
    try
    {
      this.nL.h(this.nM, localid, this.nX);
      er.a(localid);
    }
    finally
    {
      er.a(localid);
    }
  }
  
  public gl a(gl paramgl)
  {
    if ((a(this)) || (i(paramgl))) {
      return n(d(cu(), h(paramgl)));
    }
    return super.a(paramgl);
  }
  
  public gl b(gl paramgl)
  {
    if ((a(this)) || (i(paramgl))) {
      return n(e(cu(), h(paramgl)));
    }
    return super.b(paramgl);
  }
  
  public gl c(gl paramgl)
  {
    id localid = new id();
    cu().a(h(paramgl), this.nM, this.nI.cC(), localid);
    return n(localid);
  }
  
  public gl bT()
  {
    id localid = new id();
    cu().b(this.nM, this.nI.cC(), localid);
    return n(localid);
  }
  
  private gl n(id paramid)
  {
    return ((hm)this.nI.bf()).k(paramid);
  }
  
  boolean i(gl paramgl)
  {
    return ((ht)paramgl).nX != null;
  }
  
  boolean a(ht paramht)
  {
    return paramht.nX != null;
  }
  
  public void clearSensitiveData()
  {
    super.clearSensitiveData();
    er.a(this.nX);
  }
  
  public void bF()
  {
    if (this.nX == null) {
      cw();
    }
    if (this.nL == null) {
      cv();
    }
  }
  
  public Object clone()
  {
    ht localht = (ht)super.clone();
    localht.nX = ((id)es.a(this.nX));
    return localht;
  }
  
  public String toString()
  {
    return jb.I(cr().toOctetString());
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ht
 * JD-Core Version:    0.7.0.1
 */