package com.rsa.jcm.f;

public final class ek
  extends dz
{
  public boolean test(int paramInt)
    throws Exception
  {
    return a(getName(), jb.hexStringToByteArray("8d4e3c0e3889191491816e9d98bff0a0"), jb.hexStringToByteArray("cb0b67a4b8712cd73c9aabc0b199e9269b20844afb75acbdd1c153c9828924c3ddedaafe669c5fdd0bc66f630f6773988213eb1b16f517ad0de4b2f0c95c90f8"));
  }
  
  public String getName()
  {
    return "SHA512";
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ek
 * JD-Core Version:    0.7.0.1
 */