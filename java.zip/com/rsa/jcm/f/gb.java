package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.SensitiveData;

public class gb
  extends fz
{
  private static final byte[] lA = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 7, 6, 5, 4, 3, 2, 1 };
  private static final int lB = 8;
  private static final int lC = 4;
  private static final int lD = 16;
  
  gb(gi paramgi)
  {
    super(paramgi);
  }
  
  public void z(byte[] paramArrayOfByte)
  {
    throw new Error("On the fly acceleration tables should only be generated on the fly.");
  }
  
  public gi d(id paramid)
  {
    if (this.lw == null) {
      throw new CryptoException("Acceleration Table has not been set");
    }
    id localid;
    if (paramid.q(this.lx.be()) > -1)
    {
      localid = new id();
      paramid.j(this.lv.aS().be(), localid);
    }
    else
    {
      localid = (id)paramid.clone();
    }
    byte[] arrayOfByte = e(localid);
    gi[] arrayOfgi = new gi[8];
    try
    {
      for (int i = 0; i < arrayOfgi.length; i++) {
        arrayOfgi[i] = this.lv.aS().bg().bk();
      }
      a(arrayOfByte, this.lw, arrayOfgi);
      gi localgi = a(arrayOfgi);
      return localgi;
    }
    finally
    {
      er.a(localid);
      er.a(arrayOfgi);
    }
  }
  
  private byte[] e(id paramid)
  {
    int i = paramid.getBitLength() / 4 + 1;
    byte[] arrayOfByte = new byte[i];
    for (int j = 0; j < i; j++)
    {
      int tmp25_23 = j;
      byte[] tmp25_22 = arrayOfByte;
      tmp25_22[tmp25_23] = ((byte)(tmp25_22[tmp25_23] + a(paramid, j * 4)));
      if (arrayOfByte[j] > 15)
      {
        int tmp53_52 = (j + 1);
        byte[] tmp53_48 = arrayOfByte;
        tmp53_48[tmp53_52] = ((byte)(tmp53_48[tmp53_52] + 1));
        arrayOfByte[j] = 0;
      }
      else if (arrayOfByte[j] > 8)
      {
        int tmp81_80 = (j + 1);
        byte[] tmp81_76 = arrayOfByte;
        tmp81_76[tmp81_80] = ((byte)(tmp81_76[tmp81_80] + 1));
        arrayOfByte[j] = ((byte)-(16 - arrayOfByte[j]));
      }
    }
    return arrayOfByte;
  }
  
  private byte a(id paramid, int paramInt)
  {
    int i = 1;
    int j = (byte)paramid.E(paramInt);
    while (i < 4)
    {
      j = (byte)(j + (paramid.E(paramInt + i) << i));
      i++;
    }
    return j;
  }
  
  private gi a(gi[] paramArrayOfgi)
  {
    gi localgi1 = null;
    gi localgi2 = null;
    gi localgi3 = null;
    gi localgi4 = null;
    gi localgi5 = null;
    gi localgi6 = null;
    gi localgi7 = null;
    gi localgi8 = null;
    gi localgi9 = null;
    gi localgi10 = null;
    gi localgi11 = null;
    gi localgi12 = null;
    gi localgi13 = null;
    try
    {
      localgi1 = paramArrayOfgi[5].f(paramArrayOfgi[6]);
      localgi6 = paramArrayOfgi[7].bz();
      localgi7 = localgi6.f(localgi1);
      localgi9 = localgi7.f(paramArrayOfgi[4]);
      localgi8 = localgi9.f(paramArrayOfgi[3]);
      localgi10 = localgi1.f(paramArrayOfgi[1]);
      localgi2 = localgi10.f(paramArrayOfgi[2]);
      localgi3 = paramArrayOfgi[0].f(paramArrayOfgi[2]);
      localgi4 = localgi3.f(paramArrayOfgi[4]);
      localgi5 = localgi4.f(paramArrayOfgi[6]);
      localgi11 = localgi8.bz();
      localgi12 = localgi11.f(localgi2);
      localgi13 = localgi12.bz();
      gi localgi14 = localgi13.f(localgi5);
      return localgi14;
    }
    finally
    {
      er.a(new SensitiveData[] { localgi1, localgi2, localgi3, localgi4, localgi5, localgi6, localgi7, localgi8, localgi9, localgi10, localgi11, localgi12, localgi13 });
    }
  }
  
  public void aZ()
  {
    setParams();
    this.lw = new gi[this.lz * this.ly + 1];
    gi localgi = (gi)this.lv.clone();
    this.lw[0] = ((gi)this.lv.clone());
    this.lw[0].bF();
    for (int i = 1; i < this.ly + 1; i++)
    {
      for (int j = 0; j < 4; j++) {
        localgi = localgi.bz();
      }
      this.lw[i] = ((gi)localgi.clone());
      this.lw[i].bF();
    }
  }
  
  private void setParams()
  {
    this.ly = ((this.lv.aS().be().getBitLength() + 4 - 1) / 4);
    this.lz = 1;
  }
  
  public gi a(id paramid1, gb paramgb, id paramid2)
  {
    if ((this.lw == null) || (paramgb.lw == null)) {
      throw new CryptoException("Acceleration Table has not been set");
    }
    id localid1;
    if (paramid1.q(this.lx.be()) > -1)
    {
      localid1 = new id();
      paramid1.j(this.lv.aS().be(), localid1);
    }
    else
    {
      localid1 = (id)paramid1.clone();
    }
    id localid2;
    if (paramid2.q(this.lx.be()) > -1)
    {
      localid2 = new id();
      paramid2.j(this.lv.aS().be(), localid2);
    }
    else
    {
      localid2 = (id)paramid2.clone();
    }
    byte[] arrayOfByte1 = e(localid1);
    byte[] arrayOfByte2 = e(localid2);
    gi[] arrayOfgi = new gi[8];
    for (int i = 0; i < arrayOfgi.length; i++) {
      arrayOfgi[i] = this.lv.aS().bg().bk();
    }
    a(arrayOfByte1, this.lw, arrayOfgi);
    a(arrayOfByte2, paramgb.lw, arrayOfgi);
    try
    {
      gi localgi = a(arrayOfgi);
      return localgi;
    }
    finally
    {
      er.a(arrayOfgi);
      er.a(localid1);
      er.a(localid2);
    }
  }
  
  private void a(byte[] paramArrayOfByte, gi[] paramArrayOfgi1, gi[] paramArrayOfgi2)
  {
    for (int i = 0; i < paramArrayOfByte.length; i++)
    {
      int j = 0;
      gi localgi1 = null;
      gi localgi2 = null;
      try
      {
        if (paramArrayOfByte[i] > 0)
        {
          j = paramArrayOfByte[i];
          localgi1 = (gi)paramArrayOfgi1[i].clone();
        }
        else if (paramArrayOfByte[i] < 0)
        {
          j = -paramArrayOfByte[i];
          localgi1 = paramArrayOfgi1[i].bA();
        }
        int k = lA[j];
        if (k > 0)
        {
          localgi2 = paramArrayOfgi2[(k - 1)];
          paramArrayOfgi2[(k - 1)] = paramArrayOfgi2[(k - 1)].f(localgi1);
        }
      }
      finally
      {
        er.a(localgi1);
        er.a(localgi2);
      }
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gb
 * JD-Core Version:    0.7.0.1
 */