package com.rsa.jcm.f;

public enum fo
{
  Provider_PartyU,  Provider_PartyV,  Recipient_PartyU,  Recipient_PartyV;
  
  private fo() {}
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fo
 * JD-Core Version:    0.7.0.1
 */