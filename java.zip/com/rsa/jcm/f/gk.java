package com.rsa.jcm.f;

import java.io.Serializable;

public abstract interface gk
  extends Serializable
{
  public static final int my = 0;
  public static final int mz = 1;
  
  public abstract int getType();
  
  public abstract int getFieldSize();
  
  public abstract int bO();
  
  public abstract gf bP();
  
  public abstract gm bf();
  
  public abstract gh b(ge paramge);
  
  public abstract boolean equals(Object paramObject);
  
  public abstract int hashCode();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gk
 * JD-Core Version:    0.7.0.1
 */