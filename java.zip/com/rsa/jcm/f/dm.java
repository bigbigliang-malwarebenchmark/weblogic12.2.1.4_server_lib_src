package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.KeyPair;
import com.rsa.crypto.SecureRandom;
import com.rsa.crypto.SelfTestEventListener;
import java.io.File;
import java.util.concurrent.ExecutorService;

public class dm
{
  private static final dl il = new dl();
  private static final dj im = new dj(il);
  
  public static synchronized void b(File paramFile, SelfTestEventListener paramSelfTestEventListener, ExecutorService paramExecutorService, dc paramdc)
  {
    if (!cz.ai()) {
      return;
    }
    im.a(paramFile, paramSelfTestEventListener, paramExecutorService, paramdc);
  }
  
  public static synchronized void ax()
  {
    if (!cz.ai()) {
      return;
    }
    im.ax();
  }
  
  public static void h(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, int paramInt3)
  {
    if (!cz.ai()) {
      return;
    }
    cy.g(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2, paramInt3);
  }
  
  public static void b(KeyPair paramKeyPair, SecureRandom paramSecureRandom)
  {
    if (!cz.ai()) {
      return;
    }
    dh.a(paramKeyPair, paramSecureRandom);
  }
  
  public static boolean az()
  {
    if (!cz.ai()) {
      return false;
    }
    return (!da.aj()) && (!il.c(dk.UNDER_SELF_TEST));
  }
  
  public static void aA()
  {
    if ((cz.ai()) && ((il.c(dk.FAILED)) || (il.c(dk.NOT_INITIALIZED)))) {
      throw new CryptoException("FIPS 140 Module Health Invalid");
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dm
 * JD-Core Version:    0.7.0.1
 */