package com.rsa.jcm.f;

import com.rsa.crypto.CryptoModule;
import com.rsa.crypto.Signature;

public final class dx
  extends em
{
  private static final String iH = "DSA KAT failed";
  private static final int iI = 0;
  private static final int iJ = 1;
  private static final int iK = 2;
  private static final int iL = 3;
  private static final int iM = 4;
  private static final int iN = 5;
  private static final byte[][] iO = { jb.hexStringToByteArray("d83029481643fe07dae3e1524f7385fcb722b7cced4fd0ca8c07f8fcb17cc72bc415fc4bce8334bcf6331cde1d387f31f7b6e68a94f069cf19988679f37de1673f8233e47d60b1f367ec0183f78b9c3d75c18fcf87014b6d685add246bb4514681ac451befe0ba21674aa4fb26e52c927c7a9cf704d58b363db3c6193bfbff6feaee484ccc09e05e616f6f1ad24422bbeee5d3039450d02be7fee01c9bce524c12c824451fa59ef2cc2f5f1e58bae7c34e919322b93db432c80fb1c4b704bc59cf406f38748e135d7cfd9849a41b48bde098b632cda41d43da0a9546f745f05939a5e4a0caa1d9acd6f603f8b78b08f0ae0d38ff796dca35adfc5445f45d9dd1"), jb.hexStringToByteArray("b9681274f90e801acf94a61226761ca069f832cc9c1e110197c46763"), jb.hexStringToByteArray("890ff6c8eb58a777a749240c9472d0c16f27b23b4db1745643662e4659fb31bc8c657e07c03e8fd5754baecd3fbe420df59b83967323b3c19e3c5db08c558d27ed8aa93249d3b2cf161be7330257654cb2f6fc53eab5cbbedb3e35ede44cab317ab1798099fa4b9d65ea954f3d88ae194689e9c27ce1bf45679d81fec16718157287cc8e908cb04faa19f901deb2da6f690d5d7a98ede2daef72afcf9d82912b531b254cddaa75093014ecb403528966a8cc4900b161a543dd271c9c41315624fbbc75fc397f723a579818f4f99d360f4a7783caab4b48b5f7d31c0eeb061beaeefe3740d3994469faedf409e77d48972a0f953e03f8a8279debf4a075805305"), jb.hexStringToByteArray("661336deb6e75f90b3fb541fbb7e119a648a6ef4d89915bf9afb220b"), jb.hexStringToByteArray("49a93e2b7d7fc801de2751994564925872be4f053ff51208d94cb23c21daae3c4d1ed3f677d20ed72dafefca6ff530f40ea48d89b5e9110ce15ac677d413c57d0c7a0045cfd199093eacd229b279cda17c1d47d6b888910cc7f53c9b8ba22d26fabc7d446b804f39f164856753c5ee79948aa3daa243e88f48e89a03f0c19afe36bf637e7b9ae6d0c276fc5d9082d4d6a88c32f50134733e5954500f9325d2563e8b160eb15f26f024bde5cdb7ea736e92487da65934a9baf9273fb2c0ebf541cb424ef852ce70758a4f7c658cb23b67090d6e8f25b4632e82837df89a7aa7805ee4438b982f2c0419fcebaf3ca4161e052fdc8b10861858384b4a04c858bf4f"), jb.hexStringToByteArray("095fdc37fa3ab2ed99d95efb5e7a6e756eda971e94bc98efdb14adb7b5d375b406606209150793009bf0b9956c0b61ebdb234e1c2bd479df06b6648b6776afdb0c95fbcb4767cf5bb0f3360d1d35f713599d598a63c6f6cbcbe3f63ea6feb1a6102006e24702a0cabd55439b557eadcfbe04cf55dd54845a4e769e4e9331ed83") };
  private static final String[] iP = { "SHA256/DSA" };
  
  public dx()
  {
    super(1);
  }
  
  protected Signature l(int paramInt)
    throws Exception
  {
    return this.ip.newSignature(iP[paramInt]);
  }
  
  protected void m(int paramInt)
    throws Exception
  {
    id localid1 = new id(iO[0]);
    id localid2 = new id(iO[1]);
    id localid3 = new id(iO[2]);
    id localid4 = new id(iO[3]);
    id localid5 = new id(iO[4]);
    this.jt = new fc(null, localid5, new fg(null, localid1, localid2, localid3), "DSA");
    this.ju = new fb(null, localid4, new fg(null, localid1, localid2, localid3), "DSA");
  }
  
  public String getName()
  {
    return "DSA";
  }
  
  public String aH()
  {
    return "DSA KAT failed";
  }
  
  protected byte[] aI()
  {
    return iO[5];
  }
  
  protected byte[] aJ()
  {
    return null;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dx
 * JD-Core Version:    0.7.0.1
 */