package com.rsa.jcm.f;

import com.rsa.crypto.DHPrivateKey;
import com.rsa.crypto.DHPublicKey;
import com.rsa.crypto.InvalidKeyException;
import com.rsa.crypto.Key;
import com.rsa.crypto.KeyAgreement;
import com.rsa.crypto.PQGParams;

public final class fl
  extends cl
  implements KeyAgreement
{
  private static final String kD = "Secret has not been computed.";
  private id kE;
  private id kF;
  private id kG;
  private int kH;
  private id kI = new id();
  private id kJ;
  
  public fl(ke paramke)
  {
    super(paramke);
  }
  
  private void aU()
    throws InvalidKeyException
  {
    int i = this.kE.getBitLength();
    if (this.kG.q(this.kE) >= 0) {
      throw new InvalidKeyException("Base is larger than prime.");
    }
    int j = this.kH;
    if ((j != 0) && ((j > i) || (j < 160))) {
      throw new InvalidKeyException("Invalid exponent length.");
    }
  }
  
  public void init(Key paramKey)
    throws InvalidKeyException
  {
    if (!(paramKey instanceof DHPrivateKey)) {
      throw new InvalidKeyException(paramKey.getClass().getName());
    }
    DHPrivateKey localDHPrivateKey = (DHPrivateKey)paramKey;
    this.kE = ((id)localDHPrivateKey.getParams().getP());
    this.kF = ((id)localDHPrivateKey.getParams().getQ());
    this.kG = ((id)localDHPrivateKey.getParams().getG());
    this.kJ = ((id)localDHPrivateKey.getX());
    aU();
  }
  
  public void clearSensitiveData()
  {
    er.a(this.kI);
    this.kJ = null;
    this.kE = null;
    this.kF = null;
    this.kG = null;
    aV();
    this.kH = 0;
  }
  
  public Key doPhase(Key paramKey, boolean paramBoolean)
    throws InvalidKeyException
  {
    if (this.kJ == null) {
      throw new IllegalStateException("Object not initialized.");
    }
    if (!(paramKey instanceof DHPublicKey)) {
      throw new InvalidKeyException(paramKey.getClass().getName());
    }
    DHPublicKey localDHPublicKey = (DHPublicKey)paramKey;
    if (!b((id)localDHPublicKey.getParams().getP(), (id)localDHPublicKey.getParams().getG())) {
      throw new InvalidKeyException("Parameters in key do not match initialized parameters.");
    }
    id localid = new id();
    ((id)localDHPublicKey.getY()).g(this.kJ, this.kE, localid);
    if (!paramBoolean) {
      return new fc(this.an, localid, new fg(this.an, this.kE, this.kF, this.kG), "DH");
    }
    er.a(this.kI);
    this.kI = localid;
    return null;
  }
  
  private boolean b(id paramid1, id paramid2)
  {
    return (paramid1.equals(this.kE)) && (paramid2.equals(this.kG));
  }
  
  public byte[] getSecret()
  {
    if (this.kI == null) {
      throw new IllegalStateException("Secret has not been computed.");
    }
    byte[] arrayOfByte = this.kI.A((this.kE.getBitLength() + 7) / 8);
    aV();
    return arrayOfByte;
  }
  
  public int getSecret(byte[] paramArrayOfByte, int paramInt)
  {
    if (this.kI == null) {
      throw new IllegalStateException("Secret has not been computed.");
    }
    int i = (this.kE.getBitLength() + 7) / 8;
    this.kI.v(paramArrayOfByte, paramInt, i);
    aV();
    return i;
  }
  
  private void aV()
  {
    er.a(this.kI);
    this.kI = null;
  }
  
  public String getAlg()
  {
    return "DH";
  }
  
  public Object clone()
  {
    fl localfl = (fl)super.clone();
    localfl.kE = ((id)es.a(this.kE));
    localfl.kF = ((id)es.a(this.kF));
    localfl.kG = ((id)es.a(this.kG));
    localfl.kI = ((id)es.a(this.kI));
    localfl.kJ = ((id)es.a(this.kJ));
    return localfl;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fl
 * JD-Core Version:    0.7.0.1
 */