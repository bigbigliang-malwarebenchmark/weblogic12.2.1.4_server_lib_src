package com.rsa.jcm.f;

final class hi
{
  static gl a(ge paramge, gl paramgl1, gl paramgl2, gl paramgl3)
  {
    switch (paramge.bb().bI())
    {
    case 0: 
      return b(paramgl1, paramgl3);
    case 1: 
      return c(paramgl1, paramgl3);
    case 2: 
      return d(paramgl1, paramgl3);
    }
    return b(paramge, paramgl1, paramgl2, paramgl3);
  }
  
  static gl b(ge paramge, gl paramgl1, gl paramgl2, gl paramgl3)
  {
    gl localgl1 = null;
    gl localgl2 = null;
    gl localgl3 = null;
    gl localgl4 = null;
    gl localgl5 = null;
    gl localgl6 = null;
    try
    {
      localgl1 = paramgl3.bT();
      localgl2 = localgl1.bT();
      localgl3 = paramge.bb().bG().c(localgl2);
      localgl4 = paramgl1.bT();
      localgl5 = localgl4.a(localgl4);
      localgl6 = localgl5.a(localgl4);
      gl localgl7 = localgl3.a(localgl6);
      return localgl7;
    }
    finally
    {
      er.a(localgl1);
      er.a(localgl2);
      er.a(localgl3);
      er.a(localgl4);
      er.a(localgl5);
      er.a(localgl6);
    }
  }
  
  static gl b(gl paramgl1, gl paramgl2)
  {
    gl localgl1 = null;
    gl localgl2 = null;
    try
    {
      localgl1 = paramgl1.bT();
      localgl2 = localgl1.a(localgl1);
      gl localgl3 = localgl2.a(localgl1);
      return localgl3;
    }
    finally
    {
      er.a(localgl1);
      er.a(localgl2);
    }
  }
  
  static gl c(gl paramgl1, gl paramgl2)
  {
    gl localgl1 = null;
    gl localgl2 = null;
    gl localgl3 = null;
    gl localgl4 = null;
    gl localgl5 = null;
    try
    {
      localgl1 = paramgl2.bT();
      localgl2 = localgl1.bT();
      localgl3 = paramgl1.bT();
      localgl4 = localgl3.a(localgl3);
      localgl5 = localgl4.a(localgl3);
      gl localgl6 = localgl2.a(localgl5);
      return localgl6;
    }
    finally
    {
      er.a(localgl1);
      er.a(localgl2);
      er.a(localgl3);
      er.a(localgl4);
      er.a(localgl5);
    }
  }
  
  static gl d(gl paramgl1, gl paramgl2)
  {
    gl localgl1 = null;
    gl localgl2 = null;
    gl localgl3 = null;
    gl localgl4 = null;
    gl localgl5 = null;
    try
    {
      localgl1 = paramgl2.bT();
      localgl2 = paramgl1.a(localgl1);
      localgl3 = paramgl1.b(localgl1);
      localgl4 = localgl2.c(localgl3);
      localgl5 = localgl4.a(localgl4);
      gl localgl6 = localgl5.a(localgl4);
      return localgl6;
    }
    finally
    {
      er.a(localgl1);
      er.a(localgl2);
      er.a(localgl3);
      er.a(localgl4);
      er.a(localgl5);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hi
 * JD-Core Version:    0.7.0.1
 */