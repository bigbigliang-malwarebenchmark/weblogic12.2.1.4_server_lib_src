package com.rsa.jcm.f;

public class ho
  extends hn
{
  private static final int nN = 12;
  private static final int nO = 6;
  private static final long nP = 4294967295L;
  
  ho(gk paramgk)
  {
    super(paramgk);
  }
  
  ho(gk paramgk, id paramid)
  {
    super(paramgk, paramid);
  }
  
  public void l(id paramid)
  {
    int[] arrayOfInt1 = paramid.cM();
    int i = paramid.cJ();
    if (i <= 6)
    {
      if (i == 6)
      {
        int j = paramid.q(this.nM);
        switch (j)
        {
        case 0: 
          paramid.p(paramid);
          return;
        case -1: 
          return;
        }
        paramid.t(this.nM);
        return;
      }
      return;
    }
    int[] arrayOfInt2 = new int[12];
    System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, i);
    int i1 = 6;
    int m = arrayOfInt2[i1] + arrayOfInt2[(i1 + 4)];
    int n = (arrayOfInt2[i1] & (arrayOfInt2[i1] ^ m) | (m & 0x7FFFFFFF) - (arrayOfInt2[i1] & 0x7FFFFFFF) & (arrayOfInt2[i1] ^ m ^ 0xFFFFFFFF)) >>> 31;
    arrayOfInt2[0] += m;
    n += ((m & (m ^ arrayOfInt2[0]) | (arrayOfInt2[0] & 0x7FFFFFFF) - (m & 0x7FFFFFFF) & (m ^ arrayOfInt2[0] ^ 0xFFFFFFFF)) >>> 31);
    m = arrayOfInt2[(i1 + 1)] + n;
    n = (n & (n ^ m) | (m & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ m ^ 0xFFFFFFFF)) >>> 31;
    m += arrayOfInt2[(i1 + 5)];
    n += ((arrayOfInt2[(i1 + 5)] & (arrayOfInt2[(i1 + 5)] ^ m) | (m & 0x7FFFFFFF) - (arrayOfInt2[(i1 + 5)] & 0x7FFFFFFF) & (arrayOfInt2[(i1 + 5)] ^ m ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[1] += m;
    n += ((m & (m ^ arrayOfInt2[1]) | (arrayOfInt2[1] & 0x7FFFFFFF) - (m & 0x7FFFFFFF) & (m ^ arrayOfInt2[1] ^ 0xFFFFFFFF)) >>> 31);
    m = arrayOfInt2[i1] + n;
    n = (n & (n ^ m) | (m & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ m ^ 0xFFFFFFFF)) >>> 31;
    m += arrayOfInt2[(i1 + 2)];
    n += ((arrayOfInt2[(i1 + 2)] & (arrayOfInt2[(i1 + 2)] ^ m) | (m & 0x7FFFFFFF) - (arrayOfInt2[(i1 + 2)] & 0x7FFFFFFF) & (arrayOfInt2[(i1 + 2)] ^ m ^ 0xFFFFFFFF)) >>> 31);
    m += arrayOfInt2[(i1 + 4)];
    n += ((arrayOfInt2[(i1 + 4)] & (arrayOfInt2[(i1 + 4)] ^ m) | (m & 0x7FFFFFFF) - (arrayOfInt2[(i1 + 4)] & 0x7FFFFFFF) & (arrayOfInt2[(i1 + 4)] ^ m ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[2] += m;
    n += ((m & (m ^ arrayOfInt2[2]) | (arrayOfInt2[2] & 0x7FFFFFFF) - (m & 0x7FFFFFFF) & (m ^ arrayOfInt2[2] ^ 0xFFFFFFFF)) >>> 31);
    m = arrayOfInt2[(i1 + 1)] + n;
    n = (n & (n ^ m) | (m & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ m ^ 0xFFFFFFFF)) >>> 31;
    m += arrayOfInt2[(i1 + 3)];
    n += ((arrayOfInt2[(i1 + 3)] & (arrayOfInt2[(i1 + 3)] ^ m) | (m & 0x7FFFFFFF) - (arrayOfInt2[(i1 + 3)] & 0x7FFFFFFF) & (arrayOfInt2[(i1 + 3)] ^ m ^ 0xFFFFFFFF)) >>> 31);
    m += arrayOfInt2[(i1 + 5)];
    n += ((arrayOfInt2[(i1 + 5)] & (arrayOfInt2[(i1 + 5)] ^ m) | (m & 0x7FFFFFFF) - (arrayOfInt2[(i1 + 5)] & 0x7FFFFFFF) & (arrayOfInt2[(i1 + 5)] ^ m ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[3] += m;
    n += ((m & (m ^ arrayOfInt2[3]) | (arrayOfInt2[3] & 0x7FFFFFFF) - (m & 0x7FFFFFFF) & (m ^ arrayOfInt2[3] ^ 0xFFFFFFFF)) >>> 31);
    m = arrayOfInt2[(i1 + 2)] + n;
    n = (n & (n ^ m) | (m & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ m ^ 0xFFFFFFFF)) >>> 31;
    m += arrayOfInt2[(i1 + 4)];
    n += ((arrayOfInt2[(i1 + 4)] & (arrayOfInt2[(i1 + 4)] ^ m) | (m & 0x7FFFFFFF) - (arrayOfInt2[(i1 + 4)] & 0x7FFFFFFF) & (arrayOfInt2[(i1 + 4)] ^ m ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[4] += m;
    n += ((m & (m ^ arrayOfInt2[4]) | (arrayOfInt2[4] & 0x7FFFFFFF) - (m & 0x7FFFFFFF) & (m ^ arrayOfInt2[4] ^ 0xFFFFFFFF)) >>> 31);
    m = arrayOfInt2[(i1 + 3)] + n;
    n = (n & (n ^ m) | (m & 0x7FFFFFFF) - (n & 0x7FFFFFFF) & (n ^ m ^ 0xFFFFFFFF)) >>> 31;
    m += arrayOfInt2[(i1 + 5)];
    n += ((arrayOfInt2[(i1 + 5)] & (arrayOfInt2[(i1 + 5)] ^ m) | (m & 0x7FFFFFFF) - (arrayOfInt2[(i1 + 5)] & 0x7FFFFFFF) & (arrayOfInt2[(i1 + 5)] ^ m ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[5] += m;
    n += ((m & (m ^ arrayOfInt2[5]) | (arrayOfInt2[5] & 0x7FFFFFFF) - (m & 0x7FFFFFFF) & (m ^ arrayOfInt2[5] ^ 0xFFFFFFFF)) >>> 31);
    arrayOfInt2[6] = 0;
    if (n != 0)
    {
      arrayOfInt2[0] += n;
      int k;
      if ((0xFFFFFFFF & arrayOfInt2[0]) < (0xFFFFFFFF & n))
      {
        k = 1;
        arrayOfInt2[k] += 1;
        while (arrayOfInt2[k] == 0) {
          arrayOfInt2[(++k)] += 1;
        }
      }
      arrayOfInt2[2] += n;
      if ((0xFFFFFFFF & arrayOfInt2[2]) < (0xFFFFFFFF & n))
      {
        k = 3;
        arrayOfInt2[k] += 1;
        while (arrayOfInt2[k] == 0) {
          arrayOfInt2[(++k)] += 1;
        }
      }
    }
    paramid.a(arrayOfInt2, 6);
    if (paramid.q(this.nM) >= 0) {
      paramid.t(this.nM);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ho
 * JD-Core Version:    0.7.0.1
 */