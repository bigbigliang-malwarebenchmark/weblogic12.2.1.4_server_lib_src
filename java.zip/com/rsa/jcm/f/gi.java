package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.ECPoint;
import com.rsa.crypto.JCMCloneable;

public class gi
  implements ECPoint, JCMCloneable
{
  ge lY;
  boolean lZ;
  gl ma;
  private gl mb;
  private gl mc;
  private gl md;
  private gl me;
  ga mf;
  gm mg;
  private hw mh;
  hy mi;
  private gf mj;
  
  gi(ge paramge)
  {
    a(paramge);
    this.ma = null;
    this.mb = null;
    this.lZ = true;
  }
  
  public gi(ge paramge, id paramid1, id paramid2)
  {
    a(paramge);
    this.ma = this.mg.j(paramid1);
    this.mb = this.mg.j(paramid2);
  }
  
  gi(ge paramge, gl paramgl1, gl paramgl2)
  {
    a(paramge);
    this.ma = paramgl1;
    this.mb = paramgl2;
  }
  
  gi(ge paramge, gl paramgl1, gl paramgl2, gl paramgl3)
  {
    a(paramge);
    this.mc = paramgl1;
    this.md = paramgl2;
    this.me = paramgl3;
  }
  
  public gi(ge paramge, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    a(paramge);
    q(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public ge aS()
  {
    return this.lY;
  }
  
  protected void a(ge paramge)
  {
    this.lY = paramge;
    this.mj = this.lY.ba().bP();
    this.mg = this.lY.bf();
    this.mh = hx.c(this.lY);
    this.mi = hx.cD();
  }
  
  protected void q(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    gg.a locala = gg.a(this.mg, paramArrayOfByte, paramInt1, paramInt2);
    if (locala.isInfinite())
    {
      this.lZ = true;
      this.ma = null;
      this.mb = null;
    }
    else
    {
      this.lZ = false;
      this.ma = locala.bi();
      this.mb = locala.bj();
    }
  }
  
  public byte[] getEncoded()
  {
    return gg.e(this);
  }
  
  public boolean isInfinite()
  {
    return (this.lZ) || ((this.ma != null) && (this.mb != null) && (this.ma.isZero()) && (this.mb.isZero()));
  }
  
  public boolean bl()
  {
    return this.mf != null;
  }
  
  public gl bm()
  {
    return (gl)es.a(br());
  }
  
  public gl bn()
  {
    return (gl)es.a(bs());
  }
  
  public gl bo()
  {
    return (gl)es.a(bt());
  }
  
  public gl bp()
  {
    return (gl)es.a(bu());
  }
  
  public gl bq()
  {
    return (gl)es.a(bv());
  }
  
  public gl br()
  {
    if ((!this.lZ) && (this.ma == null)) {
      bD();
    }
    return this.ma;
  }
  
  public gl bs()
  {
    if ((!this.lZ) && (this.mb == null)) {
      bD();
    }
    return this.mb;
  }
  
  public gl bt()
  {
    if ((!this.lZ) && (this.mc == null)) {
      bE();
    }
    return this.mc;
  }
  
  public gl bu()
  {
    if ((!this.lZ) && (this.md == null)) {
      bE();
    }
    return this.md;
  }
  
  public gl bv()
  {
    if ((!this.lZ) && (this.me == null)) {
      bE();
    }
    return this.me;
  }
  
  public void A(byte[] paramArrayOfByte)
  {
    this.mf = new gc(this);
    this.mf.z(paramArrayOfByte);
  }
  
  public boolean bw()
  {
    return this.mj.b(this);
  }
  
  public boolean bx()
  {
    return this.mj.a(this, true);
  }
  
  public boolean by()
  {
    return this.mj.a(this, false);
  }
  
  public gi f(gi paramgi)
  {
    return this.mj.a(this, paramgi);
  }
  
  public gi bz()
  {
    return this.mj.c(this);
  }
  
  public gi bA()
  {
    return this.mj.d(this);
  }
  
  public gi bB()
  {
    if (bl()) {
      return this.mf.aY();
    }
    id localid = (id)aS().be().clone();
    localid.R(1);
    gi localgi1 = this.mh.a(this, localid);
    try
    {
      gi localgi2 = localgi1.f(this);
      return localgi2;
    }
    finally
    {
      er.a(localid);
      er.a(localgi1);
    }
  }
  
  public gi g(id paramid)
  {
    if (bl()) {
      return this.mf.d(paramid);
    }
    return this.mh.a(this, paramid);
  }
  
  public gi a(id paramid1, gi paramgi, id paramid2)
  {
    if ((!bl()) && (!paramgi.bl())) {
      return this.mi.a(this, paramid1, paramgi, paramid2);
    }
    gi localgi1 = null;
    gi localgi2 = null;
    try
    {
      localgi1 = g(paramid1);
      localgi2 = paramgi.g(paramid2);
      gi localgi3 = localgi1.f(localgi2);
      return localgi3;
    }
    finally
    {
      er.a(localgi1);
      er.a(localgi2);
    }
  }
  
  public void bC()
  {
    this.mf = new gb(this);
    if (this.mc != null) {
      bD();
    }
    if (this.ma != null) {
      bE();
    }
    this.mf.aZ();
  }
  
  private void bD()
  {
    gl localgl1 = this.mc;
    gl localgl2 = this.md;
    gl localgl3 = this.me;
    gl localgl4 = null;
    gl localgl5 = null;
    gl localgl6 = null;
    try
    {
      localgl4 = localgl3.bU();
      localgl5 = localgl4.bT();
      localgl6 = localgl5.c(localgl4);
      this.ma = localgl1.c(localgl5);
      this.mb = localgl2.c(localgl6);
    }
    finally
    {
      er.a(localgl4);
      er.a(localgl5);
      er.a(localgl6);
    }
  }
  
  private void bE()
  {
    this.mc = this.ma;
    this.md = this.mb;
    this.me = this.mg.bX();
  }
  
  public void bF()
  {
    if ((this.mc == null) && (this.ma != null)) {
      bE();
    }
    if ((this.mc != null) && (this.ma == null)) {
      bD();
    }
    if (this.mc != null) {
      this.mc.bF();
    }
    if (this.md != null) {
      this.md.bF();
    }
    if (this.me != null) {
      this.me.bF();
    }
    if (this.ma != null) {
      this.ma.bF();
    }
    if (this.mb != null) {
      this.mb.bF();
    }
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == null) {
      return false;
    }
    if (!(paramObject instanceof gi)) {
      return false;
    }
    gi localgi = (gi)paramObject;
    if (isInfinite()) {
      return localgi.isInfinite();
    }
    return (br().equals(localgi.br())) && (bs().equals(localgi.bs()));
  }
  
  public int hashCode()
  {
    if (isInfinite()) {
      return 0;
    }
    return br().hashCode() ^ bs().hashCode();
  }
  
  public Object clone()
  {
    gi localgi;
    try
    {
      localgi = (gi)super.clone();
      localgi.ma = ((gl)es.a(this.ma));
      localgi.mb = ((gl)es.a(this.mb));
      localgi.mc = ((gl)es.a(this.mc));
      localgi.md = ((gl)es.a(this.md));
      localgi.me = ((gl)es.a(this.me));
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new CryptoException("Object.clone() unexpectedly threw CloneNotSupportedException.");
    }
    return localgi;
  }
  
  public void clearSensitiveData()
  {
    this.lZ = true;
    er.a(this.ma);
    er.a(this.mb);
    er.a(this.mc);
    er.a(this.md);
    er.a(this.me);
    this.mf = null;
  }
  
  public byte[] getX()
  {
    return br().toOctetString();
  }
  
  public byte[] getY()
  {
    return bs().toOctetString();
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gi
 * JD-Core Version:    0.7.0.1
 */