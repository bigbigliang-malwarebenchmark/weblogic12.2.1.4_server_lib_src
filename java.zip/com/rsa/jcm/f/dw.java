package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import com.rsa.crypto.CryptoModule;
import com.rsa.crypto.SecureRandom;
import java.util.Arrays;

abstract class dw
  extends ei
{
  dw(int paramInt)
  {
    super(paramInt);
  }
  
  boolean a(String paramString, int paramInt1, int paramInt2, byte[] paramArrayOfByte)
    throws Exception
  {
    SecureRandom localSecureRandom = this.ip.newSecureRandom(paramString);
    cp.a((cg)localSecureRandom);
    AlgInputParams localAlgInputParams = this.ip.newAlgInputParams();
    localAlgInputParams.set("predictionResistance", Integer.valueOf(paramInt2));
    localAlgInputParams.set("securityStrength", Integer.valueOf(paramInt1));
    localSecureRandom.setOperationalParameters(localAlgInputParams);
    byte[] arrayOfByte = new byte[paramArrayOfByte.length];
    localSecureRandom.nextBytes(arrayOfByte);
    return Arrays.equals(paramArrayOfByte, arrayOfByte);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dw
 * JD-Core Version:    0.7.0.1
 */