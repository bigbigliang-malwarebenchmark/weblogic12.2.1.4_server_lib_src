package com.rsa.jcm.f;

public class hz
  implements hy
{
  private static final int WINDOW = 2;
  private static final int oj = 4;
  
  public static gi b(gi paramgi1, id paramid1, gi paramgi2, id paramid2)
  {
    return new hz().a(paramgi1, paramid1, paramgi2, paramid2);
  }
  
  public gi a(gi paramgi1, id paramid1, gi paramgi2, id paramid2)
  {
    if (paramid1.getBitLength() < paramid2.getBitLength())
    {
      localObject1 = paramid1;
      localObject2 = paramgi1;
      paramgi1 = paramgi2;
      paramid1 = paramid2;
      paramgi2 = (gi)localObject2;
      paramid2 = (id)localObject1;
    }
    Object localObject1 = b(paramgi1, paramgi2);
    Object localObject2 = (id)paramid1.clone();
    ((id)localObject2).j(paramgi1.aS().be(), paramid1);
    localObject2 = (id)paramid2.clone();
    ((id)localObject2).j(paramgi2.aS().be(), paramid2);
    gi localgi = paramgi1.aS().bg().bk();
    int i = paramid1.getBitLength();
    int j = (i + 1) / 2;
    for (int k = j - 1; k >= 0; k--)
    {
      int m = paramid1.E(2 * k + 1);
      m <<= 1;
      m |= paramid1.E(2 * k);
      int n = paramid2.E(2 * k + 1);
      n <<= 1;
      n |= paramid2.E(2 * k);
      localgi = localgi.bz();
      localgi = localgi.bz();
      localgi = localgi.f(localObject1[m][n]);
    }
    return localgi;
  }
  
  private static gi[][] b(gi paramgi1, gi paramgi2)
  {
    gi[][] arrayOfgi = new gi[4][4];
    id localid1 = new id(0);
    id localid2 = new id(1);
    id localid3 = new id(2);
    id localid4 = new id(3);
    gi[] arrayOfgi1 = new gi[4];
    arrayOfgi1[0] = paramgi1.g(localid1);
    arrayOfgi1[1] = paramgi1.g(localid2);
    arrayOfgi1[2] = paramgi1.g(localid3);
    arrayOfgi1[3] = paramgi1.g(localid4);
    gi[] arrayOfgi2 = new gi[4];
    arrayOfgi2[0] = paramgi2.g(localid1);
    arrayOfgi2[1] = paramgi2.g(localid2);
    arrayOfgi2[2] = paramgi2.g(localid3);
    arrayOfgi2[3] = paramgi2.g(localid4);
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        arrayOfgi[i][j] = arrayOfgi1[i].f(arrayOfgi2[j]);
      }
    }
    return arrayOfgi;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hz
 * JD-Core Version:    0.7.0.1
 */