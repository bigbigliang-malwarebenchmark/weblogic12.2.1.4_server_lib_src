package com.rsa.jcm.f;

import java.io.Serializable;

public abstract interface hy
  extends Serializable
{
  public abstract gi a(gi paramgi1, id paramid1, gi paramgi2, id paramid2);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hy
 * JD-Core Version:    0.7.0.1
 */