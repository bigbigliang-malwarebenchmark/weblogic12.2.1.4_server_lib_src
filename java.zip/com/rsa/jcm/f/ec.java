package com.rsa.jcm.f;

public final class ec
  extends dw
{
  public ec()
  {
    super(1);
  }
  
  public String getName()
  {
    return "HASHDRBG";
  }
  
  protected boolean test(int paramInt)
    throws Exception
  {
    byte[] arrayOfByte = jb.hexStringToByteArray("f80bea2581378bafd213f8c55697130ba163844f");
    return a("HashDRBG/128/SHA1", 128, 1, arrayOfByte);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ec
 * JD-Core Version:    0.7.0.1
 */