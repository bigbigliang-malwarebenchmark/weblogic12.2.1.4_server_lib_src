package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.SecureRandom;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public final class io
{
  private static Map<Integer, byte[]> pa;
  
  public static boolean ad(int paramInt)
  {
    return (paramInt == 128) || (paramInt == 256) || (paramInt == 384) || (paramInt == 512) || (paramInt == 768) || (paramInt == 1024) || (paramInt == 1536) || (paramInt == 2048) || (paramInt == 3072) || (paramInt == 4096);
  }
  
  public static synchronized byte[] ae(int paramInt)
  {
    if (pa == null)
    {
      localObject = jf.g("SSS.bin");
      pa = new HashMap();
      pa.put(Integer.valueOf(128), localObject[0]);
      pa.put(Integer.valueOf(256), localObject[1]);
      pa.put(Integer.valueOf(384), localObject[2]);
      pa.put(Integer.valueOf(512), localObject[3]);
      pa.put(Integer.valueOf(768), localObject[4]);
      pa.put(Integer.valueOf(1024), localObject[5]);
      pa.put(Integer.valueOf(1536), localObject[6]);
      pa.put(Integer.valueOf(2048), localObject[7]);
      pa.put(Integer.valueOf(3072), localObject[8]);
      pa.put(Integer.valueOf(4096), localObject[9]);
    }
    Object localObject = (byte[])pa.get(Integer.valueOf(paramInt));
    if (localObject == null) {
      throw new CryptoException("Invalid prime size.");
    }
    return es.x((byte[])localObject);
  }
  
  private static id[] a(id paramid, int paramInt, SecureRandom paramSecureRandom)
  {
    int i = paramInt - 1;
    id[] arrayOfid = new id[i];
    int j = paramid.getBitLength();
    int k = (j + 7) / 8;
    byte[] arrayOfByte1 = new byte[k];
    byte[] arrayOfByte2 = new byte[k];
    int m = 0;
    int n = 0;
    int i1 = (j - 1) % 8;
    for (int i2 = 0; i2 < i1; i2++)
    {
      if (i2 == 0) {
        m = 1;
      } else {
        m = (byte)(m << 1);
      }
      n = (byte)(n | m);
    }
    Arrays.fill(arrayOfByte2, 0, k, (byte)-1);
    arrayOfByte2[0] = n;
    id localid1 = new id(arrayOfByte2);
    id localid2 = new id();
    paramid.g(localid1, localid2);
    localid2.R(1);
    for (int i3 = 0; i3 < i; i3++)
    {
      paramSecureRandom.nextBytes(arrayOfByte1);
      int tmp164_163 = 0;
      byte[] tmp164_161 = arrayOfByte1;
      tmp164_161[tmp164_163] = ((byte)(tmp164_161[tmp164_163] & n));
      int tmp174_173 = 0;
      byte[] tmp174_171 = arrayOfByte1;
      tmp174_171[tmp174_173] = ((byte)(tmp174_171[tmp174_173] | m));
      arrayOfid[i3] = new id();
      arrayOfid[i3].t(arrayOfByte1, 0, k);
      arrayOfid[i3].s(localid2);
    }
    er.w(arrayOfByte1);
    return arrayOfid;
  }
  
  private static id[] a(int paramInt, id paramid1, id paramid2, id[] paramArrayOfid1, id[] paramArrayOfid2)
  {
    int i = paramArrayOfid1.length;
    int j = paramInt - 1;
    id[] arrayOfid = new id[i];
    id localid1 = new id();
    id localid2 = new id();
    id localid3 = new id();
    id localid4 = new id();
    for (int k = 0; k < i; k++)
    {
      id localid5 = new id(0);
      localid4.setValue(1);
      for (int m = 0; m < j; m++)
      {
        paramArrayOfid1[k].g(localid4, paramid1, localid1);
        localid1.i(paramArrayOfid2[m], localid2);
        localid4.Q(1);
        localid5.f(localid2, localid3);
        localid3.j(paramid1, localid5);
      }
      localid5.f(paramid2, localid3);
      localid3.j(paramid1, localid5);
      arrayOfid[k] = localid5;
    }
    return arrayOfid;
  }
  
  public static byte[][] a(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[][] paramArrayOfByte, SecureRandom paramSecureRandom)
  {
    id localid1 = null;
    id[] arrayOfid1 = null;
    id[] arrayOfid2 = null;
    id[] arrayOfid3 = null;
    try
    {
      id localid2 = new id(paramArrayOfByte1);
      localid1 = new id(paramArrayOfByte2);
      int i = paramArrayOfByte.length;
      arrayOfid1 = new id[i];
      for (int j = 0; j < i; j++) {
        arrayOfid1[j] = new id(paramArrayOfByte[j]);
      }
      arrayOfid3 = a(localid2, paramInt, paramSecureRandom);
      arrayOfid2 = a(paramInt, localid2, localid1, arrayOfid1, arrayOfid3);
      byte[][] arrayOfByte1 = new byte[i][];
      for (int k = 0; k < i; k++) {
        arrayOfByte1[k] = arrayOfid2[k].A(paramArrayOfByte1.length);
      }
      byte[][] arrayOfByte2 = arrayOfByte1;
      return arrayOfByte2;
    }
    finally
    {
      er.a(localid1);
      er.a(arrayOfid1);
      er.a(arrayOfid2);
      er.a(arrayOfid3);
    }
  }
  
  private static id a(id paramid1, id[] paramArrayOfid1, id[] paramArrayOfid2, id paramid2)
  {
    int i = paramArrayOfid1.length;
    id[] arrayOfid = new id[i];
    id localid1 = new id();
    id localid2 = new id();
    id localid3 = new id();
    id localid4 = new id();
    for (int j = 0; j < i; j++)
    {
      localid1.p(id.oo);
      localid2.p(id.oo);
      for (int k = 0; k < i; k++) {
        if (k != j)
        {
          paramid2.d(paramArrayOfid1[k], paramid1, localid3);
          localid1.i(localid3, localid4);
          localid4.j(paramid1, localid1);
          paramArrayOfid1[j].d(paramArrayOfid1[k], paramid1, localid3);
          localid2.i(localid3, localid4);
          localid4.j(paramid1, localid2);
        }
      }
      if (!localid2.k(paramid1, localid3)) {
        throw new CryptoException("Failed to recover secret");
      }
      localid3.i(localid1, localid4);
      id localid6 = new id();
      localid4.j(paramid1, localid6);
      arrayOfid[j] = localid6;
    }
    id localid5 = new id(0);
    for (int m = 0; m < i; m++)
    {
      paramArrayOfid2[m].i(arrayOfid[m], localid4);
      localid4.f(localid5, localid3);
      localid3.j(paramid1, localid5);
    }
    return localid5;
  }
  
  public static byte[] a(byte[] paramArrayOfByte1, byte[][] paramArrayOfByte2, byte[][] paramArrayOfByte3, byte[] paramArrayOfByte4)
  {
    id[] arrayOfid1 = null;
    id[] arrayOfid2 = null;
    id localid1 = null;
    id localid2 = null;
    try
    {
      id localid3 = new id(paramArrayOfByte1);
      int i = paramArrayOfByte2.length;
      arrayOfid1 = new id[i];
      arrayOfid2 = new id[i];
      for (int j = 0; j < i; j++)
      {
        arrayOfid1[j] = new id(paramArrayOfByte2[j]);
        arrayOfid2[j] = new id(paramArrayOfByte3[j]);
      }
      if (paramArrayOfByte4 == null) {
        paramArrayOfByte4 = new byte[] { 0 };
      }
      localid1 = new id(paramArrayOfByte4);
      localid2 = a(localid3, arrayOfid1, arrayOfid2, localid1);
      byte[] arrayOfByte = localid2.A(paramArrayOfByte1.length);
      return arrayOfByte;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new CryptoException("Failed to recover secret");
    }
    finally
    {
      er.a(arrayOfid1);
      er.a(arrayOfid2);
      er.a(localid1);
      er.a(localid2);
    }
  }
  
  public static byte[] a(int paramInt, byte[] paramArrayOfByte, SecureRandom paramSecureRandom)
  {
    int i = paramInt - paramArrayOfByte.length;
    byte[] arrayOfByte = new byte[paramInt + 1];
    if (paramArrayOfByte.length == paramInt)
    {
      arrayOfByte[0] = 1;
    }
    else
    {
      arrayOfByte[0] = 0;
      paramSecureRandom.nextBytes(arrayOfByte, 1, i - 1);
      for (int j = 1; j < i; j++) {
        if (arrayOfByte[j] == 1) {
          arrayOfByte[j] = 0;
        }
      }
      arrayOfByte[i] = 1;
    }
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte, i + 1, paramArrayOfByte.length);
    return arrayOfByte;
  }
  
  public static byte[] unpad(byte[] paramArrayOfByte)
  {
    int i = -1;
    for (int j = 0; j < paramArrayOfByte.length; j++) {
      if (paramArrayOfByte[j] == 1)
      {
        i = j;
        break;
      }
    }
    if (i == -1) {
      return null;
    }
    j = paramArrayOfByte.length - i - 1;
    byte[] arrayOfByte = new byte[j];
    System.arraycopy(paramArrayOfByte, i + 1, arrayOfByte, 0, j);
    return arrayOfByte;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.io
 * JD-Core Version:    0.7.0.1
 */