package com.rsa.jcm.f;

import java.io.Serializable;

public abstract interface hw
  extends Serializable
{
  public abstract gi a(gi paramgi, id paramid);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hw
 * JD-Core Version:    0.7.0.1
 */