package com.rsa.jcm.f;

public class hx
{
  public static hw c(ge paramge)
  {
    return new hv(true);
  }
  
  public static hw d(ge paramge)
  {
    return new hv(false);
  }
  
  public static hy cD()
  {
    return new hz();
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hx
 * JD-Core Version:    0.7.0.1
 */