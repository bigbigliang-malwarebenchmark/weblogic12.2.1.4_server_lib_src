package com.rsa.jcm.f;

public class ih
{
  public static int a(int[] paramArrayOfInt1, int paramInt1, int[] paramArrayOfInt2, int paramInt2, int[] paramArrayOfInt3)
  {
    int i = 0;
    long l1 = 0L;
    long l2;
    while (i < paramInt2)
    {
      l2 = (paramArrayOfInt1[i] & 0xFFFFFFFF) - (paramArrayOfInt2[i] & 0xFFFFFFFF) + l1;
      paramArrayOfInt3[i] = ((int)l2);
      l1 = l2 >> 32;
      i++;
    }
    if (paramInt1 == paramInt2) {
      return (int)l1;
    }
    if (paramArrayOfInt3 != paramArrayOfInt1) {
      while (i < paramInt1)
      {
        paramArrayOfInt3[i] = paramArrayOfInt1[i];
        i++;
      }
    }
    for (i = paramInt2; (l1 != 0L) && (i < paramInt1); i++)
    {
      l2 = (paramArrayOfInt3[i] & 0xFFFFFFFF) + l1;
      paramArrayOfInt3[i] = ((int)l2);
      l1 = l2 >> 32;
    }
    return (int)l1;
  }
  
  public static int b(int[] paramArrayOfInt1, int paramInt1, int[] paramArrayOfInt2, int paramInt2, int[] paramArrayOfInt3)
  {
    int i = 0;
    long l1 = 0L;
    long l2;
    if (paramInt1 >= paramInt2)
    {
      while (i < paramInt2)
      {
        l2 = (paramArrayOfInt1[i] & 0xFFFFFFFF) + (paramArrayOfInt2[i] & 0xFFFFFFFF) + l1;
        paramArrayOfInt3[i] = ((int)l2);
        l1 = l2 >>> 32;
        i++;
      }
      if (paramInt1 == paramInt2) {
        return (int)l1;
      }
      if (paramArrayOfInt3 != paramArrayOfInt1) {
        while (i < paramInt1)
        {
          paramArrayOfInt3[i] = paramArrayOfInt1[i];
          i++;
        }
      }
      for (i = paramInt2; (l1 != 0L) && (i < paramInt1); i++)
      {
        l2 = (paramArrayOfInt3[i] & 0xFFFFFFFF) + l1;
        paramArrayOfInt3[i] = ((int)l2);
        l1 = l2 >>> 32;
      }
      return (int)l1;
    }
    while (i < paramInt1)
    {
      l2 = (paramArrayOfInt1[i] & 0xFFFFFFFF) + (paramArrayOfInt2[i] & 0xFFFFFFFF) + l1;
      paramArrayOfInt3[i] = ((int)l2);
      l1 = l2 >>> 32;
      i++;
    }
    while (i < paramInt2)
    {
      paramArrayOfInt3[i] = paramArrayOfInt2[i];
      i++;
    }
    for (i = paramInt1; (l1 != 0L) && (i < paramInt2); i++)
    {
      l2 = (paramArrayOfInt3[i] & 0xFFFFFFFF) + l1;
      paramArrayOfInt3[i] = ((int)l2);
      l1 = l2 >>> 32;
    }
    return (int)l1;
  }
  
  public static int a(int[] paramArrayOfInt1, int paramInt1, int paramInt2, int[] paramArrayOfInt2)
  {
    int j = 0;
    if (paramInt2 == 0)
    {
      System.arraycopy(paramArrayOfInt1, 0, paramArrayOfInt2, 0, paramInt1);
    }
    else
    {
      int k = 32 - paramInt2;
      for (int m = 0; m <= paramInt1; m++)
      {
        int i = paramArrayOfInt1[m];
        paramArrayOfInt2[m] = (i << paramInt2 | j);
        j = i >>> k;
      }
    }
    return j;
  }
  
  public static int b(int[] paramArrayOfInt1, int paramInt1, int paramInt2, int[] paramArrayOfInt2)
  {
    int j = 0;
    if (paramInt2 == 0)
    {
      System.arraycopy(paramArrayOfInt1, 0, paramArrayOfInt2, 0, paramInt1);
    }
    else
    {
      int k = 32 - paramInt2;
      for (int m = 0; m <= paramInt1; m++)
      {
        int i = paramArrayOfInt1[m];
        paramArrayOfInt2[m] = (i << paramInt2 | j);
        j = i >>> k;
      }
    }
    return j;
  }
  
  public static int c(int[] paramArrayOfInt1, int paramInt1, int paramInt2, int[] paramArrayOfInt2)
  {
    int j = 0;
    if (paramInt2 == 0)
    {
      System.arraycopy(paramArrayOfInt1, 0, paramArrayOfInt2, 0, paramInt1 + 1);
    }
    else
    {
      int k = 32 - paramInt2;
      for (int m = paramInt1; m >= 0; m--)
      {
        int i = paramArrayOfInt1[m];
        paramArrayOfInt2[m] = (i >>> paramInt2 | j);
        j = i << k;
      }
    }
    return j;
  }
  
  public static int d(int[] paramArrayOfInt1, int paramInt1, int paramInt2, int[] paramArrayOfInt2)
  {
    int j = 0;
    if (paramInt2 == 0)
    {
      System.arraycopy(paramArrayOfInt1, 0, paramArrayOfInt2, 0, paramInt1 + 1);
    }
    else
    {
      int k = 32 - paramInt2;
      for (int m = paramInt1; m >= 0; m--)
      {
        int i = paramArrayOfInt1[m];
        paramArrayOfInt2[m] = (i >>> paramInt2 | j);
        j = i << k;
      }
    }
    return j;
  }
  
  public static int a(int[] paramArrayOfInt1, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt2)
  {
    int j = 0;
    int k = 32 - paramInt3;
    for (int m = paramInt2; m >= 0; m--)
    {
      int i = paramArrayOfInt1[(paramInt1 + m)];
      paramArrayOfInt2[m] = (i >>> paramInt3 | j);
      j = i << k;
    }
    return j;
  }
  
  public static int a(int[] paramArrayOfInt1, int paramInt1, int paramInt2, int[] paramArrayOfInt2, int paramInt3)
  {
    int j = 0;
    if (paramInt2 == 0)
    {
      System.arraycopy(paramArrayOfInt1, 0, paramArrayOfInt2, paramInt3, paramInt1 + 1);
    }
    else
    {
      int k = 32 - paramInt2;
      for (int m = 0; m <= paramInt1; m++)
      {
        int i = paramArrayOfInt1[m];
        paramArrayOfInt2[(paramInt3 + m)] = (i << paramInt2 | j);
        j = i >>> k;
      }
    }
    return j;
  }
  
  public static int b(int[] paramArrayOfInt1, int paramInt1, int paramInt2, int[] paramArrayOfInt2, int paramInt3)
  {
    int j = 0;
    int k = 32 - paramInt2;
    for (int m = paramInt1; m >= 0; m--)
    {
      int i = paramArrayOfInt1[m];
      paramArrayOfInt2[(paramInt3 + m)] = (i >>> paramInt2 | j);
      j = i << k;
    }
    return j;
  }
  
  public static int a(int[] paramArrayOfInt1, int paramInt, int[] paramArrayOfInt2)
  {
    int j = 0;
    for (int k = 0; k < paramInt; k++)
    {
      int i = paramArrayOfInt1[k];
      paramArrayOfInt2[k] = (i << 1 | j);
      j = i >>> 31;
    }
    return j;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ih
 * JD-Core Version:    0.7.0.1
 */