package com.rsa.jcm.f;

import com.rsa.crypto.PasswordKey;
import java.util.Arrays;

public class fh
  extends di
  implements PasswordKey
{
  private char[] kq;
  
  public fh(ke paramke, char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    super(paramke, new byte[0], 0, 0);
    this.kq = (paramArrayOfChar == null ? null : Arrays.copyOfRange(paramArrayOfChar, paramInt1, paramInt1 + paramInt2));
  }
  
  public char[] getPassword()
  {
    return es.b(this.kq);
  }
  
  public void clearSensitiveData()
  {
    er.w(this.gd);
  }
  
  public Object clone()
  {
    fh localfh = (fh)super.clone();
    localfh.kq = es.b(this.kq);
    return localfh;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fh
 * JD-Core Version:    0.7.0.1
 */