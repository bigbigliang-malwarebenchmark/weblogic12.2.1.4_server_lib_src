package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.FIPS140Context;
import java.io.File;

public final class db
  implements FIPS140Context
{
  private int hG;
  private int mode;
  
  public db(int paramInt1, int paramInt2)
  {
    k(paramInt2);
    setMode(paramInt1);
  }
  
  public int getRole()
  {
    return this.hG;
  }
  
  public void a(byte[] paramArrayOfByte, File paramFile)
  {
    u(paramArrayOfByte);
    da.a(paramArrayOfByte, this.hG, paramFile);
  }
  
  private void u(byte[] paramArrayOfByte)
  {
    if ((paramArrayOfByte == null) || (paramArrayOfByte.length != 64)) {
      throw new CryptoException("Invalid PIN");
    }
  }
  
  private void k(int paramInt)
  {
    if ((paramInt != 10) && (paramInt != 11)) {
      throw new CryptoException("Invalid role");
    }
    this.hG = paramInt;
  }
  
  public int getMode()
  {
    return this.mode;
  }
  
  private void setMode(int paramInt)
  {
    if ((paramInt != 0) && (paramInt != 1)) {
      throw new CryptoException("Invalid mode");
    }
    this.mode = paramInt;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.db
 * JD-Core Version:    0.7.0.1
 */