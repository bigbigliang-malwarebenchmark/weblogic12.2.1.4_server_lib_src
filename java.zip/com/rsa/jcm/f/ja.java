package com.rsa.jcm.f;

import java.util.Arrays;

public class ja
{
  public static boolean c(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    if ((paramArrayOfByte1 == null) || (paramArrayOfByte2 == null)) {
      return (paramArrayOfByte1 == null) && (paramArrayOfByte2 == null);
    }
    if (paramArrayOfByte1.length != paramArrayOfByte2.length) {
      return false;
    }
    int i = 0;
    for (int j = 0; j < paramArrayOfByte1.length; j++) {
      i |= paramArrayOfByte1[j] ^ paramArrayOfByte2[j];
    }
    return i == 0;
  }
  
  public static boolean e(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4)
  {
    if ((paramArrayOfByte1 == null) || (paramArrayOfByte2 == null)) {
      return (paramArrayOfByte1 == null) && (paramArrayOfByte2 == null);
    }
    if (paramInt2 != paramInt4) {
      return false;
    }
    int i = 0;
    for (int j = 0; j < paramInt2; j++) {
      i |= paramArrayOfByte1[(paramInt1 + j)] ^ paramArrayOfByte2[(paramInt3 + j)];
    }
    return i == 0;
  }
  
  public static boolean f(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4)
  {
    if ((paramArrayOfByte1 == null) || (paramArrayOfByte2 == null)) {
      return (paramArrayOfByte1 == null) && (paramArrayOfByte2 == null);
    }
    if (paramInt2 != paramInt4) {
      return false;
    }
    for (int i = 0; i < paramInt2; i++) {
      if (paramArrayOfByte1[(paramInt1 + i)] != paramArrayOfByte2[(paramInt3 + i)]) {
        return false;
      }
    }
    return true;
  }
  
  public static byte[] a(byte[][] paramArrayOfByte, int[] paramArrayOfInt)
  {
    if ((paramArrayOfByte == null) || (paramArrayOfInt == null)) {
      return null;
    }
    int i = 0;
    for (int j = 0; j < paramArrayOfInt.length; j++) {
      i += paramArrayOfInt[j];
    }
    byte[] arrayOfByte = new byte[i];
    i = 0;
    for (int k = 0; k < paramArrayOfByte.length; k++) {
      if (paramArrayOfInt[k] != 0)
      {
        System.arraycopy(paramArrayOfByte[k], 0, arrayOfByte, i, paramArrayOfInt[k]);
        i += paramArrayOfInt[k];
      }
    }
    return arrayOfByte;
  }
  
  public static byte[] c(byte[]... paramVarArgs)
  {
    if (paramVarArgs == null) {
      return null;
    }
    int[] arrayOfInt = new int[paramVarArgs.length];
    for (int i = 0; i < paramVarArgs.length; i++) {
      if (paramVarArgs[i] != null) {
        arrayOfInt[i] = paramVarArgs[i].length;
      }
    }
    return a(paramVarArgs, arrayOfInt);
  }
  
  public static byte[] a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (paramArrayOfByte2 == null) {
      return paramArrayOfByte1;
    }
    byte[] arrayOfByte;
    if (paramArrayOfByte1 == null)
    {
      arrayOfByte = Arrays.copyOfRange(paramArrayOfByte2, paramInt1, paramInt1 + paramInt2);
    }
    else
    {
      arrayOfByte = Arrays.copyOf(paramArrayOfByte1, paramArrayOfByte1.length + paramInt2);
      System.arraycopy(paramArrayOfByte2, paramInt1, arrayOfByte, paramArrayOfByte1.length, paramInt2);
      if (paramBoolean) {
        er.w(paramArrayOfByte1);
      }
    }
    return arrayOfByte;
  }
  
  public static byte[] D(byte[] paramArrayOfByte)
  {
    if ((paramArrayOfByte == null) || (paramArrayOfByte.length == 0)) {
      return new byte[] { 1 };
    }
    byte[] arrayOfByte = Arrays.copyOf(paramArrayOfByte, paramArrayOfByte.length);
    for (int i = arrayOfByte.length - 1; i >= 0; i--)
    {
      int tmp35_34 = i;
      arrayOfByte;
      if ((tmp35_33[tmp35_34] = (byte)(tmp35_33[tmp35_34] + 1)) != 0) {
        break;
      }
    }
    return arrayOfByte;
  }
  
  public static byte[] k(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    byte[] arrayOfByte = new byte[paramInt1];
    int i = 0;
    int j = paramInt1 - 1;
    int k = paramInt2 - 1;
    while ((k >= 0) && (j >= 0))
    {
      i += (paramArrayOfByte1[j] & 0xFF) + (paramArrayOfByte2[k] & 0xFF);
      arrayOfByte[j] = ((byte)i);
      i >>>= 8;
      k--;
      j--;
    }
    while ((i > 0) && (j >= 0))
    {
      i += (paramArrayOfByte1[j] & 0xFF);
      arrayOfByte[j] = ((byte)i);
      i >>>= 8;
      j--;
    }
    System.arraycopy(paramArrayOfByte1, 0, arrayOfByte, 0, j + 1);
    return arrayOfByte;
  }
  
  public static byte[] b(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    int i = paramArrayOfByte1.length;
    int j = paramArrayOfByte2.length;
    byte[] arrayOfByte = new byte[i];
    System.arraycopy(paramArrayOfByte1, 0, arrayOfByte, 0, i);
    int k = Math.min(j, Math.min(i, paramInt));
    for (int m = 0; m < k; m++) {
      arrayOfByte[m] = ((byte)(paramArrayOfByte1[m] ^ paramArrayOfByte2[m]));
    }
    return arrayOfByte;
  }
  
  public static byte[] aj(int paramInt)
  {
    byte[] arrayOfByte = new byte[paramInt];
    for (int i = 0; i < paramInt; i++) {
      arrayOfByte[i] = ((byte)i);
    }
    return arrayOfByte;
  }
  
  public static byte[] B(byte[] paramArrayOfByte, int paramInt)
  {
    byte[] arrayOfByte = new byte[paramInt];
    return c(new byte[][] { paramArrayOfByte, arrayOfByte });
  }
  
  public static byte[] C(byte[] paramArrayOfByte, int paramInt)
  {
    return Arrays.copyOfRange(paramArrayOfByte, 0, paramInt);
  }
  
  public static byte[] D(byte[] paramArrayOfByte, int paramInt)
  {
    int i = (paramInt + 7) / 8;
    return C(paramArrayOfByte, i);
  }
  
  public static byte[] E(byte[] paramArrayOfByte, int paramInt)
  {
    int i = paramArrayOfByte.length - paramInt;
    int j = paramArrayOfByte.length;
    return Arrays.copyOfRange(paramArrayOfByte, i, j);
  }
  
  public static boolean E(byte[] paramArrayOfByte)
  {
    int i = 0;
    for (int j = 0; j < paramArrayOfByte.length; j++) {
      i = (byte)(i | paramArrayOfByte[j]);
    }
    return i == 0;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ja
 * JD-Core Version:    0.7.0.1
 */