package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.JCMCloneable;
import com.rsa.crypto.SensitiveData;
import java.io.Serializable;

public final class ic
  implements JCMCloneable, SensitiveData, Serializable
{
  private static final long nP = 4294967295L;
  private static final int mB = 32;
  private static final int DEFAULT_SIZE = 10;
  private int[] value;
  private int om;
  
  private ic()
  {
    this.value = new int[10];
    this.om = 1;
  }
  
  ic(int paramInt)
  {
    this.value = new int[paramInt];
    this.om = 1;
  }
  
  private ic(int[] paramArrayOfInt)
  {
    c(paramArrayOfInt);
  }
  
  private ic(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    t(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  ic(int[] paramArrayOfInt, int paramInt)
  {
    this.value = paramArrayOfInt;
    this.om = paramInt;
    normalize();
  }
  
  public void t(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0)
    {
      setValue(0);
      return;
    }
    int i = (paramInt2 * 8 + 31) / 32;
    M(i);
    this.om = i;
    int m = paramInt1 + paramInt2 - 4;
    int k = 0;
    while (k < this.om - 1)
    {
      j = paramArrayOfByte[m] << 24 | (paramArrayOfByte[(m + 1)] & 0xFF) << 16 | (paramArrayOfByte[(m + 2)] & 0xFF) << 8 | paramArrayOfByte[(m + 3)] & 0xFF;
      this.value[k] = j;
      k++;
      m -= 4;
    }
    int j = 0;
    switch (paramInt2 & 0x3)
    {
    case 0: 
      j = paramArrayOfByte[paramInt1] << 8;
      paramInt1++;
    case 3: 
      j |= paramArrayOfByte[paramInt1] & 0xFF;
      paramInt1++;
      j <<= 8;
    case 2: 
      j |= paramArrayOfByte[paramInt1] & 0xFF;
      paramInt1++;
      j <<= 8;
    case 1: 
      j |= paramArrayOfByte[paramInt1] & 0xFF;
    }
    this.value[k] = j;
    normalize();
  }
  
  public void c(int[] paramArrayOfInt)
  {
    b(paramArrayOfInt, 0, paramArrayOfInt.length);
  }
  
  public void a(int[] paramArrayOfInt, int paramInt)
  {
    this.value = paramArrayOfInt;
    this.om = paramInt;
    normalize();
  }
  
  public void b(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0)
    {
      setValue(0);
      return;
    }
    M(paramInt2);
    System.arraycopy(paramArrayOfInt, paramInt1, this.value, 0, paramInt2);
    this.om = paramInt2;
    normalize();
  }
  
  public void setValue(int paramInt)
  {
    M(10);
    this.value[0] = paramInt;
    this.om = 1;
  }
  
  public byte[] toOctetString()
  {
    int i = getBitLength();
    int j = (i + 7) / 8;
    byte[] arrayOfByte = new byte[j];
    int k = j - 1;
    int m = 0;
    while (m < this.om)
    {
      int n = this.value[m];
      int i1 = 4;
      if (j < 4) {
        i1 = j;
      }
      int i2 = 0;
      while (i2 < i1)
      {
        arrayOfByte[k] = ((byte)n);
        n >>>= 8;
        i2++;
        k--;
      }
      m++;
      j -= 4;
    }
    return arrayOfByte;
  }
  
  public int w(byte[] paramArrayOfByte, int paramInt)
    throws CryptoException
  {
    int i = getBitLength();
    int j = (i + 7) / 8;
    if (paramInt + j > paramArrayOfByte.length) {
      throw new CryptoException("Value too large for octet string. Requires " + j + " bytes.");
    }
    w(paramArrayOfByte, paramInt, j);
    return j;
  }
  
  public int u(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws CryptoException
  {
    if (paramInt1 + paramInt2 > paramArrayOfByte.length) {
      throw new CryptoException("Length too large for octet string. Requires " + (paramInt1 + paramInt2) + " bytes. Is " + paramArrayOfByte.length + " bytes.");
    }
    int i = getBitLength();
    int j = (i + 7) / 8;
    if (j > paramInt2) {
      throw new CryptoException("Value too large for octet string. Requires " + (paramInt1 + j) + " bytes.");
    }
    paramInt1 += paramInt2 - j;
    w(paramArrayOfByte, paramInt1, j);
    return j;
  }
  
  public void v(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws CryptoException
  {
    if (paramInt1 + paramInt2 > paramArrayOfByte.length) {
      throw new CryptoException("Length too large for octet string. Requires " + (paramInt1 + paramInt2) + " bytes. Is " + paramArrayOfByte.length + " bytes.");
    }
    int i = getBitLength();
    int j = (i + 7) / 8;
    if (j > paramInt2) {
      throw new CryptoException("Value too large for octet string. Requires " + (paramInt1 + j) + " bytes.");
    }
    if (paramInt2 > j)
    {
      int k = paramInt2 - j;
      jd.I(paramArrayOfByte, paramInt1, k);
      paramInt1 += k;
    }
    w(paramArrayOfByte, paramInt1, j);
  }
  
  private void w(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    int i = paramInt2 - 1;
    for (int j = 0; j < this.om; j++)
    {
      int k = this.value[j];
      if (paramInt2 < 4)
      {
        for (int m = paramInt2 - 1; m >= 0; m--)
        {
          paramArrayOfByte[(paramInt1 + m)] = ((byte)k);
          k >>>= 8;
        }
      }
      else
      {
        paramArrayOfByte[(paramInt1 + i--)] = ((byte)k);
        paramArrayOfByte[(paramInt1 + i--)] = ((byte)(k >>> 8));
        paramArrayOfByte[(paramInt1 + i--)] = ((byte)(k >>> 16));
        paramArrayOfByte[(paramInt1 + i--)] = ((byte)(k >>> 24));
      }
      paramInt2 -= 4;
    }
  }
  
  public byte[] A(int paramInt)
    throws CryptoException
  {
    byte[] arrayOfByte = new byte[paramInt];
    u(arrayOfByte, 0, paramInt);
    return arrayOfByte;
  }
  
  public int[] B(int paramInt)
  {
    if (paramInt < this.om) {
      throw new CryptoException("Length too small to store value");
    }
    int[] arrayOfInt = new int[paramInt];
    System.arraycopy(this.value, 0, arrayOfInt, 0, this.om);
    return arrayOfInt;
  }
  
  public int[] toIntArray()
  {
    int[] arrayOfInt = new int[this.om];
    System.arraycopy(this.value, 0, arrayOfInt, 0, this.om);
    return arrayOfInt;
  }
  
  public int[] cH()
  {
    return this.value;
  }
  
  public boolean cI()
  {
    return (this.value[0] & 0x1) == 1;
  }
  
  public boolean isZero()
  {
    normalize();
    return ((this.om == 1) && (this.value[0] == 0)) || (this.om == 0);
  }
  
  public boolean C(int paramInt)
  {
    return (this.om == 1) && (this.value[0] == paramInt);
  }
  
  public int getBitLength()
  {
    normalize();
    int i = this.value[(this.om - 1)];
    if ((this.om == 1) && (i == 0)) {
      return 1;
    }
    int j = this.om * 32;
    if ((i & 0xFFFF0000) == 0)
    {
      j -= 16;
      i <<= 16;
    }
    if ((i & 0xFF000000) == 0)
    {
      j -= 8;
      i <<= 8;
    }
    if ((i & 0xF0000000) == 0)
    {
      j -= 4;
      i <<= 4;
    }
    do
    {
      if ((i & 0x80000000) != 0) {
        break;
      }
      j--;
      i <<= 1;
    } while (j > 0);
    return j;
  }
  
  public int cJ()
  {
    return this.om;
  }
  
  public void D(int paramInt)
  {
    this.om = paramInt;
  }
  
  public int E(int paramInt)
  {
    int i = getBitLength();
    if (i <= paramInt) {
      return 0;
    }
    int j = paramInt / 32;
    paramInt %= 32;
    int k = this.value[j];
    k = k >>> paramInt & 0x1;
    return k;
  }
  
  public void i(int paramInt1, int paramInt2)
  {
    int i = paramInt1 / 32;
    paramInt1 %= 32;
    if (i >= this.om)
    {
      if (paramInt2 == 0) {
        return;
      }
      j = i - this.om + 1;
      int[] arrayOfInt = new int[j];
      arrayOfInt[(j - 1)] = (1 << paramInt1);
      c(arrayOfInt, 0, j);
      return;
    }
    int j = this.value[i];
    int k = 1 << paramInt1;
    if (paramInt2 != 0) {
      j |= k;
    } else {
      j &= (k ^ 0xFFFFFFFF);
    }
    this.value[i] = j;
    normalize();
  }
  
  public boolean testBit(int paramInt)
  {
    return E(paramInt) == 1;
  }
  
  public int F(int paramInt)
  {
    return this.value[paramInt];
  }
  
  public void j(int paramInt1, int paramInt2)
  {
    if (paramInt1 < this.om)
    {
      this.value[paramInt1] = paramInt2;
      if (paramInt2 == 0) {
        normalize();
      }
      return;
    }
    if (paramInt2 == 0) {
      return;
    }
    if (paramInt1 < this.value.length)
    {
      this.om = (paramInt1 + 1);
      this.value[paramInt1] = paramInt2;
      return;
    }
    int[] arrayOfInt = new int[this.om];
    System.arraycopy(this.value, 0, arrayOfInt, 0, arrayOfInt.length);
    M(paramInt1 + 10);
    System.arraycopy(arrayOfInt, 0, this.value, 0, arrayOfInt.length);
    this.value[paramInt1] = paramInt2;
    this.om = (paramInt1 + 1);
    normalize();
  }
  
  public void G(int paramInt)
  {
    if (paramInt <= 0) {
      return;
    }
    int i = paramInt >>> 5;
    int j = paramInt & 0x1F;
    if (i != 0) {
      I(i);
    }
    if (j == 0) {
      return;
    }
    int i1 = 32 - j;
    int m = 0;
    for (int n = this.om - 1; n >= 0; n--)
    {
      int k = this.value[n] << i1;
      this.value[n] >>>= j;
      this.value[n] |= m;
      m = k;
    }
    normalize();
  }
  
  public void H(int paramInt)
  {
    if (paramInt <= 0) {
      return;
    }
    if (isZero()) {
      return;
    }
    int i = paramInt >>> 5;
    int j = paramInt & 0x1F;
    if (i != 0) {
      J(i);
    }
    if (j == 0) {
      return;
    }
    int i1 = this.om - 2;
    int i2 = 32 - j;
    int k = this.value[(this.om - 1)] >>> i2;
    this.value[(this.om - 1)] <<= j;
    if (k != 0)
    {
      int[] arrayOfInt = { k };
      c(arrayOfInt, 0, 1);
    }
    int m = 0;
    for (int n = 0; n <= i1; n++)
    {
      k = this.value[n] << j | m;
      m = this.value[n] >>> i2;
      this.value[n] = k;
    }
    this.value[n] |= m;
    normalize();
  }
  
  public void I(int paramInt)
  {
    if (paramInt <= 0) {
      return;
    }
    if (paramInt >= this.om)
    {
      this.value[0] = 0;
      this.om = 1;
      return;
    }
    this.om -= paramInt;
    System.arraycopy(this.value, paramInt, this.value, 0, this.om);
    normalize();
  }
  
  public void J(int paramInt)
  {
    if (paramInt <= 0) {
      return;
    }
    if (this.value.length < this.om + paramInt)
    {
      int[] arrayOfInt = new int[this.value.length + paramInt];
      System.arraycopy(this.value, 0, arrayOfInt, paramInt, this.om);
      this.value = arrayOfInt;
      this.om += paramInt;
      normalize();
      return;
    }
    for (int i = this.om - 1; i >= 0; i--) {
      this.value[(i + paramInt)] = this.value[i];
    }
    for (i = 0; i < paramInt; i++) {
      this.value[i] = 0;
    }
    this.om += paramInt;
    normalize();
  }
  
  public void K(int paramInt)
  {
    int i = E(0);
    i(paramInt + 1, i);
    G(1);
  }
  
  public void k(int paramInt1, int paramInt2)
  {
    if (paramInt1 == 0) {
      return;
    }
    L((paramInt2 + 1 + 32 - 1) / 32);
    this.om = ((paramInt2 + 1 + 32 - 1) / 32);
    L(this.om);
    if (paramInt1 == 1)
    {
      K(paramInt2);
      return;
    }
    if (paramInt1 >= 32)
    {
      l(paramInt1, paramInt2);
      return;
    }
    int k = 32 - paramInt1;
    int m = (paramInt2 + 1) % 32;
    int j = this.value[0] << k >>> 32 - m;
    int tmp108_107 = (this.om - 1);
    int[] tmp108_99 = this.value;
    tmp108_99[tmp108_107] = ((int)(tmp108_99[tmp108_107] | this.value[0] << m & (-4294967296L >> 32 - paramInt1 ^ 0xFFFFFFFF)));
    for (int n = this.om - 1; n >= 0; n--)
    {
      int i = this.value[n] << k;
      this.value[n] >>>= paramInt1;
      this.value[n] |= j;
      j = i;
    }
    normalize();
  }
  
  private void l(int paramInt1, int paramInt2)
  {
    if (paramInt1 == 0) {
      return;
    }
    for (int i = 0; i < paramInt1; i++)
    {
      int j = E(i);
      i(paramInt2 + 1 + i, j);
    }
    G(paramInt1);
  }
  
  public void d(ic paramic)
  {
    int i;
    if (this.om >= paramic.om)
    {
      i = paramic.om;
    }
    else
    {
      i = this.om;
      L(paramic.om);
      this.om = paramic.om;
    }
    for (int j = 0; j < i; j++) {
      this.value[j] &= paramic.value[j];
    }
    for (j = i; j < this.om; j++) {
      this.value[j] = 0;
    }
    normalize();
  }
  
  public void e(ic paramic)
  {
    int i;
    if (this.om >= paramic.om)
    {
      i = paramic.om;
    }
    else
    {
      i = this.om;
      L(paramic.om);
      this.om = paramic.om;
    }
    for (int j = 0; j < i; j++) {
      this.value[j] ^= paramic.value[j];
    }
    System.arraycopy(paramic.value, i, this.value, i, paramic.om - i);
    normalize();
  }
  
  public void a(ic paramic1, ic paramic2)
  {
    int i = cJ() + paramic1.cJ();
    paramic2.M(i);
    int[] arrayOfInt1 = this.value;
    int[] arrayOfInt2 = paramic1.cH();
    int[] arrayOfInt3 = paramic2.cH();
    long l1 = arrayOfInt1[0] & 0xFFFFFFFF;
    int j = paramic1.cJ();
    long l2 = 0L;
    int k = 0;
    int m = 0;
    long l3;
    while (m < j)
    {
      l3 = (arrayOfInt2[m] & 0xFFFFFFFF) * l1 + l2;
      arrayOfInt3[k] = ((int)l3);
      l2 = l3 >>> 32;
      m++;
      k++;
    }
    arrayOfInt3[k] = ((int)l2);
    for (m = 1; m < this.om; m++)
    {
      l1 = arrayOfInt1[m] & 0xFFFFFFFF;
      k = m;
      l2 = 0L;
      int n = 0;
      while (n < j)
      {
        l3 = (arrayOfInt2[n] & 0xFFFFFFFF) * l1 + (arrayOfInt3[k] & 0xFFFFFFFF) + l2;
        arrayOfInt3[k] = ((int)l3);
        l2 = l3 >>> 32;
        n++;
        k++;
      }
      arrayOfInt3[k] = ((int)l2);
    }
    paramic2.D(k + 1);
    paramic2.normalize();
  }
  
  private void L(int paramInt)
  {
    if (this.value.length < paramInt)
    {
      int[] arrayOfInt = new int[paramInt];
      System.arraycopy(this.value, 0, arrayOfInt, 0, this.om);
      er.a(this.value);
      this.value = arrayOfInt;
    }
  }
  
  public boolean M(int paramInt)
  {
    if (this.value == null)
    {
      this.value = new int[paramInt];
      return true;
    }
    if (this.value.length < paramInt)
    {
      cK();
      this.value = new int[paramInt];
      return true;
    }
    cK();
    return false;
  }
  
  public void normalize()
  {
    for (int i = this.om - 1; (i > 0) && (this.value[i] == 0); i--) {
      this.om -= 1;
    }
    if (this.om == 0)
    {
      this.om = 1;
      if (this.value.length < 1) {
        this.value = new int[1];
      }
    }
  }
  
  public void c(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    if (this.value.length < this.om + paramInt2)
    {
      int[] arrayOfInt = new int[this.om + paramInt2 + 10];
      int i = this.om;
      System.arraycopy(this.value, 0, arrayOfInt, 0, this.om);
      clearSensitiveData();
      this.value = arrayOfInt;
      this.om = i;
    }
    System.arraycopy(paramArrayOfInt, paramInt1, this.value, this.om, paramInt2);
    this.om += paramInt2;
    normalize();
  }
  
  void cK()
  {
    er.a(this.value);
    this.om = 1;
  }
  
  public void clearSensitiveData()
  {
    cK();
  }
  
  public Object clone()
  {
    try
    {
      ic localic = (ic)super.clone();
      localic.value = es.b(this.value);
      return localic;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new CryptoException("Object.clone() unexpectedly threw CloneNotSupportedException.");
    }
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == null) {
      return false;
    }
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof ic)) {
      return false;
    }
    ic localic = (ic)paramObject;
    if ((isZero()) || (localic.isZero())) {
      return (isZero()) && (localic.isZero());
    }
    if (this.om != localic.om) {
      return false;
    }
    for (int i = 0; i < this.om; i++) {
      if (this.value[i] != localic.value[i]) {
        return false;
      }
    }
    return true;
  }
  
  public int hashCode()
  {
    if ((this.value == null) || (this.value.length == 0) || (isZero())) {
      return 0;
    }
    int i = 0;
    for (int j = 0; j < this.value.length; j++) {
      i += this.value[j] * 3;
    }
    return i;
  }
  
  public static ic cL()
  {
    return new ic();
  }
  
  public static ic b(int[] paramArrayOfInt, int paramInt)
  {
    return new ic(paramArrayOfInt, paramInt);
  }
  
  public static ic d(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    ic localic = new ic();
    localic.b(paramArrayOfInt, paramInt1, paramInt2);
    return localic;
  }
  
  public static ic d(int[] paramArrayOfInt)
  {
    return new ic(paramArrayOfInt);
  }
  
  public static ic x(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return new ic(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public static ic N(int paramInt)
  {
    return new ic(paramInt);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ic
 * JD-Core Version:    0.7.0.1
 */