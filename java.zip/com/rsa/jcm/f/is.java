package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.ECParams;
import com.rsa.crypto.ECPrivateKey;
import com.rsa.crypto.ECPublicKey;
import com.rsa.crypto.InvalidKeyException;
import com.rsa.crypto.KeyPairGenerator;
import com.rsa.crypto.PrivateKey;
import com.rsa.crypto.PublicKey;

public class is
  extends ip
{
  private ECPrivateKey pD;
  private ECPublicKey pE;
  private int pF;
  
  public int getSignatureSize()
  {
    return this.pF;
  }
  
  protected id c(PublicKey paramPublicKey)
  {
    ECPublicKey localECPublicKey = (ECPublicKey)paramPublicKey;
    gi localgi = (gi)localECPublicKey.getPublicPoint();
    try
    {
      gl localgl = localgi.br();
      id localid = localgl.bQ();
      return localid;
    }
    finally
    {
      er.a(localgi);
    }
  }
  
  protected id c(PrivateKey paramPrivateKey)
  {
    return (id)((ECPrivateKey)paramPrivateKey).getD();
  }
  
  KeyPairGenerator cO()
  {
    fs localfs = new fs(null);
    localfs.initialize(this.pD.getParams(), this.M);
    return localfs;
  }
  
  id t(id paramid1, id paramid2)
    throws CryptoException
  {
    gi localgi = null;
    gl localgl = null;
    try
    {
      localgi = ((gi)this.pE.getParams().getBase()).a(paramid1, (gi)this.pE.getPublicPoint(), paramid2);
      if (localgi.isInfinite()) {
        throw new CryptoException("Point at infinity");
      }
      localgl = localgi.bm();
      id localid = localgl.bQ();
      return localid;
    }
    finally
    {
      er.a(localgi);
      er.a(localgl);
    }
  }
  
  public void a(PrivateKey paramPrivateKey)
    throws InvalidKeyException
  {
    if (!(paramPrivateKey instanceof ECPrivateKey)) {
      throw new InvalidKeyException("Expected private key of type EC.");
    }
    this.pd = ((id)((ECPrivateKey)paramPrivateKey).getD());
    this.pD = ((ECPrivateKey)paramPrivateKey);
    this.initialized = true;
    this.pb = true;
    ECParams localECParams = this.pD.getParams();
    this.pc = ((id)localECParams.getOrder());
    this.pF = (2 * gn.r(localECParams.getFieldSize()) + 8);
  }
  
  public void a(PublicKey paramPublicKey)
    throws InvalidKeyException
  {
    if (!(paramPublicKey instanceof ECPublicKey)) {
      throw new InvalidKeyException("Expected public key of type EC.");
    }
    this.pE = ((ECPublicKey)paramPublicKey);
    this.initialized = true;
    this.pb = false;
    ECParams localECParams = this.pE.getParams();
    this.pc = ((id)localECParams.getOrder());
    this.pF = (2 * gn.r(localECParams.getFieldSize()) + 8);
  }
  
  public String getAlg()
  {
    return "ECDSA";
  }
  
  public Object clone()
  {
    is localis = (is)super.clone();
    localis.pD = ((ECPrivateKey)es.a(this.pD));
    localis.pE = ((ECPublicKey)es.a(this.pE));
    return localis;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.is
 * JD-Core Version:    0.7.0.1
 */