package com.rsa.jcm.f;

public class gq
  extends go
{
  final gi mM = bg().a(paramgl5, paramgl6);
  volatile boolean mN;
  
  gq(String paramString, gk paramgk, gl paramgl1, gl paramgl2, byte[] paramArrayOfByte, gl paramgl3, gl paramgl4, id paramid, int paramInt, gl paramgl5, gl paramgl6)
  {
    super(paramString, paramgk, paramgl1, paramgl2, paramArrayOfByte, paramgl3, paramgl4, paramid, paramInt);
  }
  
  public gi bY()
  {
    return this.mM;
  }
  
  public gi bd()
  {
    if (!this.mN) {
      bZ();
    }
    return this.lJ;
  }
  
  synchronized void bZ()
  {
    if (this.mN) {
      return;
    }
    this.lJ.bC();
    this.mN = true;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gq
 * JD-Core Version:    0.7.0.1
 */