package com.rsa.jcm.f;

import com.rsa.crypto.MessageDigest;
import com.rsa.crypto.SignatureException;

public class ix
  extends g
{
  private static final String pU = "Digest not supported with X9.31 Signature: ";
  private MessageDigest pG;
  
  public static boolean a(bq parambq)
  {
    return parambq instanceof cd;
  }
  
  public ix(ke paramke)
  {
    super(paramke);
    this.pG = new bw(null);
  }
  
  public ix(ke paramke, MessageDigest paramMessageDigest)
  {
    super(paramke);
    this.pG = paramMessageDigest;
  }
  
  protected int c(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    int i = super.c(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
    id localid1 = new id();
    id localid2 = new id(paramArrayOfByte2, paramInt3, i);
    try
    {
      int j = paramArrayOfByte2[(this.K + paramInt3 - 1)] & 0xF;
      if (j == 12)
      {
        int k = this.K;
        return k;
      }
      this.G.g(localid2, localid1);
      localid1.v(paramArrayOfByte2, paramInt3, this.K);
    }
    finally
    {
      er.a(localid2);
      er.a(localid1);
    }
    return this.K;
  }
  
  protected id b(id paramid)
  {
    id localid1 = new id();
    try
    {
      this.G.g(paramid, localid1);
      if (paramid.q(localid1) > 0) {
        paramid.p(localid1);
      }
      id localid2 = paramid;
      return localid2;
    }
    finally
    {
      localid1.clearSensitiveData();
    }
  }
  
  public void a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2)
    throws SignatureException
  {
    if ((this.K < 128) || (this.K % 32 != 0)) {
      throw new SignatureException("Invalid block size for X9.31: must be >= 128 bytes and multiple of 32");
    }
    paramArrayOfByte2[(this.K - 1)] = -52;
    if (!(this.pG instanceof cd)) {
      throw new SignatureException("Digest not supported with X9.31 Signature: " + this.pG.getAlg());
    }
    paramArrayOfByte2[(this.K - 2)] = ((cd)this.pG).Q();
    int i = this.K - 3;
    int j = paramInt2 - 1;
    while (j >= 0)
    {
      paramArrayOfByte2[i] = paramArrayOfByte1[(j + paramInt1)];
      j--;
      i--;
    }
    paramArrayOfByte2[i] = -70;
    i--;
    while (i > paramInt1)
    {
      paramArrayOfByte2[i] = -69;
      i--;
    }
    paramArrayOfByte2[paramInt1] = 107;
  }
  
  public int c(byte[] paramArrayOfByte, int paramInt)
    throws SignatureException
  {
    if (paramArrayOfByte[paramInt] != 107) {
      throw new SignatureException("Signature verify failed.");
    }
    if (paramArrayOfByte[(paramInt + this.K - 1)] != -52) {
      throw new SignatureException("Signature verify failed.");
    }
    int i;
    if ((this.pG instanceof cd)) {
      i = ((cd)this.pG).Q();
    } else {
      throw new SignatureException("Signature verify failed.");
    }
    if (paramArrayOfByte[(paramInt + this.K - 2)] != i)
    {
      if (!this.pG.getAlg().equalsIgnoreCase("SHA512-256")) {
        throw new SignatureException("Signature verify failed.");
      }
      i = ((cd)this.pG).R();
      if (paramArrayOfByte[(paramInt + this.K - 2)] != i) {
        throw new SignatureException("Signature verify failed.");
      }
    }
    for (int j = paramInt + 1; (j < paramInt + this.K) && (paramArrayOfByte[j] == -69); j++) {}
    if (paramArrayOfByte[j] != -70) {
      throw new SignatureException("Signature verify failed.");
    }
    j++;
    int k = this.K + paramInt - j - 2;
    while (j < this.K - 2)
    {
      paramArrayOfByte[paramInt] = paramArrayOfByte[j];
      j++;
      paramInt++;
    }
    while (paramInt < this.K)
    {
      paramArrayOfByte[paramInt] = 0;
      paramInt++;
    }
    return k;
  }
  
  public void clearSensitiveData()
  {
    super.clearSensitiveData();
  }
  
  public String getAlg()
  {
    return "X931RSA";
  }
  
  public int getSignatureSize()
  {
    return getBlockSize();
  }
  
  public Object clone()
  {
    return super.clone();
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ix
 * JD-Core Version:    0.7.0.1
 */