package com.rsa.jcm.f;

public enum fp
{
  Unilateral,  Bilateral;
  
  private fp() {}
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fp
 * JD-Core Version:    0.7.0.1
 */