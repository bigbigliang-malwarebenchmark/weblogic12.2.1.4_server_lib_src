package com.rsa.jcm.f;

import com.rsa.crypto.DHPrivateKey;
import com.rsa.crypto.DHPublicKey;
import com.rsa.crypto.DSAPrivateKey;
import com.rsa.crypto.DSAPublicKey;
import com.rsa.crypto.ECParams;
import com.rsa.crypto.ECPrivateKey;
import com.rsa.crypto.ECPublicKey;
import com.rsa.crypto.PQGParams;
import com.rsa.crypto.PrivateKey;
import com.rsa.crypto.PublicKey;
import com.rsa.crypto.RSAPrivateKey;
import com.rsa.crypto.RSAPublicKey;
import com.rsa.crypto.SecureRandom;

public final class ft
{
  private static final byte[] kX = jb.hexStringToByteArray("08138e8a0fcf3a4e84a771d40fd305d7f4aa59306d7251de54d98af8fe95729a1f73d893fa424cd2edc8636a6c3285e022b0e3866a565ae8108eed8591cd4fe8d2ce86165a978d719ebf647f362d33fca29cd179fb42401cbaf3df0c614056f9c8f3cfd51e474afb6bc6974f78db8aba8e9e517fded658591ab7502bd41849462f");
  private static final id kY = new id(kX, 0, kX.length);
  
  private static boolean a(RSAPublicKey paramRSAPublicKey, SecureRandom paramSecureRandom)
  {
    id localid1 = (id)paramRSAPublicKey.getE();
    id localid2 = (id)paramRSAPublicKey.getN();
    id localid3 = new id();
    id localid4 = new id();
    id localid5 = new id();
    try
    {
      int i = localid2.getBitLength();
      if ((i != 1024) && (i != 2048) && (i != 3072))
      {
        boolean bool1 = false;
        return bool1;
      }
      int j = localid1.getBitLength();
      boolean bool2;
      if ((j <= 16) || (j > 256))
      {
        bool2 = false;
        return bool2;
      }
      if ((!localid2.cI()) || (!localid1.cI()))
      {
        bool2 = false;
        return bool2;
      }
      int k = if.X(i);
      if (if.b(localid2, localid3, localid4, localid5, paramSecureRandom, k) != 2)
      {
        bool3 = false;
        return bool3;
      }
      kY.q(localid2, localid3);
      boolean bool3 = localid3.C(1);
      return bool3;
    }
    finally
    {
      er.a(localid3);
      er.a(localid4);
      er.a(localid5);
    }
  }
  
  public static boolean a(PublicKey paramPublicKey, SecureRandom paramSecureRandom)
  {
    if ((paramPublicKey instanceof DSAPublicKey)) {
      return a((DSAPublicKey)paramPublicKey);
    }
    if ((paramPublicKey instanceof RSAPublicKey)) {
      return a((RSAPublicKey)paramPublicKey, paramSecureRandom);
    }
    if ((paramPublicKey instanceof ECPublicKey)) {
      return b((ECPublicKey)paramPublicKey);
    }
    if ((paramPublicKey instanceof DHPublicKey)) {
      return a((DHPublicKey)paramPublicKey);
    }
    return true;
  }
  
  private static boolean b(ECPublicKey paramECPublicKey)
  {
    return ((gi)paramECPublicKey.getPublicPoint()).bx();
  }
  
  public static boolean b(PrivateKey paramPrivateKey)
  {
    if ((paramPrivateKey instanceof DSAPrivateKey)) {
      return a((DSAPrivateKey)paramPrivateKey);
    }
    if ((paramPrivateKey instanceof RSAPrivateKey)) {
      return a((RSAPrivateKey)paramPrivateKey);
    }
    if ((paramPrivateKey instanceof ECPrivateKey)) {
      return a((ECPrivateKey)paramPrivateKey);
    }
    if ((paramPrivateKey instanceof DHPrivateKey)) {
      return a((DHPrivateKey)paramPrivateKey);
    }
    return true;
  }
  
  private static boolean c(id paramid1, id paramid2)
  {
    return (!paramid1.equals(id.on)) && (paramid1.q(paramid2) < 0);
  }
  
  private static boolean a(ECPrivateKey paramECPrivateKey)
  {
    return c((id)paramECPrivateKey.getD(), (id)paramECPrivateKey.getParams().getOrder());
  }
  
  private static boolean a(RSAPrivateKey paramRSAPrivateKey)
  {
    return c((id)paramRSAPrivateKey.getD(), (id)paramRSAPrivateKey.getN());
  }
  
  private static boolean a(DSAPrivateKey paramDSAPrivateKey)
  {
    return c((id)paramDSAPrivateKey.getX(), (id)paramDSAPrivateKey.getParams().getQ());
  }
  
  private static boolean a(DHPrivateKey paramDHPrivateKey)
  {
    return c((id)paramDHPrivateKey.getX(), (id)paramDHPrivateKey.getParams().getQ());
  }
  
  private static boolean a(DSAPublicKey paramDSAPublicKey)
  {
    PQGParams localPQGParams = paramDSAPublicKey.getParams();
    if (localPQGParams == null) {
      return true;
    }
    return a((id)localPQGParams.getP(), (id)localPQGParams.getQ(), (id)paramDSAPublicKey.getY());
  }
  
  private static boolean a(DHPublicKey paramDHPublicKey)
  {
    PQGParams localPQGParams = paramDHPublicKey.getParams();
    if (localPQGParams == null) {
      return true;
    }
    return a((id)localPQGParams.getP(), (id)localPQGParams.getQ(), (id)paramDHPublicKey.getY());
  }
  
  public static boolean a(id paramid1, id paramid2, id paramid3)
  {
    id localid1 = new id();
    id localid2 = new id();
    try
    {
      localid1.p(paramid1);
      localid1.R(2);
      if ((paramid3.getBitLength() < 2) || (paramid3.q(localid1) > 0))
      {
        bool = false;
        return bool;
      }
      paramid3.g(paramid2, paramid1, localid2);
      boolean bool = localid2.C(1);
      return bool;
    }
    finally
    {
      er.a(localid1);
      er.a(localid2);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ft
 * JD-Core Version:    0.7.0.1
 */