package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.JCMCloneable;

public class es
{
  public static final String jE = "Object.clone() unexpectedly threw CloneNotSupportedException.";
  
  public static Object a(JCMCloneable paramJCMCloneable)
  {
    if (paramJCMCloneable != null) {
      return paramJCMCloneable.clone();
    }
    return null;
  }
  
  public static void a(JCMCloneable[] paramArrayOfJCMCloneable1, JCMCloneable[] paramArrayOfJCMCloneable2)
  {
    a(paramArrayOfJCMCloneable1, paramArrayOfJCMCloneable2, paramArrayOfJCMCloneable1.length);
  }
  
  public static void a(JCMCloneable[] paramArrayOfJCMCloneable1, JCMCloneable[] paramArrayOfJCMCloneable2, int paramInt)
  {
    if (paramArrayOfJCMCloneable1 == null) {
      return;
    }
    if (paramInt > paramArrayOfJCMCloneable2.length) {
      throw new CryptoException("Result array must be larger than the input.");
    }
    for (int i = 0; i < paramInt; i++) {
      paramArrayOfJCMCloneable2[i] = ((JCMCloneable)a(paramArrayOfJCMCloneable1[i]));
    }
  }
  
  public static byte[] x(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte != null) {
      return (byte[])paramArrayOfByte.clone();
    }
    return null;
  }
  
  public static int[] b(int[] paramArrayOfInt)
  {
    if (paramArrayOfInt != null) {
      return (int[])paramArrayOfInt.clone();
    }
    return null;
  }
  
  public static char[] b(char[] paramArrayOfChar)
  {
    if (paramArrayOfChar != null) {
      return (char[])paramArrayOfChar.clone();
    }
    return null;
  }
  
  public static long[] b(long[] paramArrayOfLong)
  {
    if (paramArrayOfLong != null) {
      return (long[])paramArrayOfLong.clone();
    }
    return null;
  }
  
  public static byte[][] b(byte[][] paramArrayOfByte)
  {
    if (paramArrayOfByte == null) {
      return (byte[][])null;
    }
    byte[][] arrayOfByte = new byte[paramArrayOfByte.length][];
    for (int i = 0; i < paramArrayOfByte.length; i++) {
      arrayOfByte[i] = x(paramArrayOfByte[i]);
    }
    return arrayOfByte;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.es
 * JD-Core Version:    0.7.0.1
 */