package com.rsa.jcm.f;

import com.rsa.crypto.SelfTestEvent;

public class ds
  implements SelfTestEvent
{
  private final int ix;
  private final String iy;
  
  public ds(int paramInt, String paramString)
  {
    this.ix = paramInt;
    this.iy = paramString;
  }
  
  public int getTestId()
  {
    return this.ix;
  }
  
  public String getTestName()
  {
    return this.iy;
  }
  
  public String toString()
  {
    if (this.ix == -1) {
      return this.iy;
    }
    return this.iy + " " + this.ix;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ds
 * JD-Core Version:    0.7.0.1
 */