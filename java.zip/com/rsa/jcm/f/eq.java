package com.rsa.jcm.f;

public abstract interface eq
{
  public static final int O = 0;
  public static final int jD = 1;
  public static final int P = 2;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.eq
 * JD-Core Version:    0.7.0.1
 */