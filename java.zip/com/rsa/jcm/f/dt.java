package com.rsa.jcm.f;

import com.rsa.crypto.SelfTestEventListener;

public final class dt
{
  private static SelfTestEventListener iz;
  
  public static void a(SelfTestEventListener paramSelfTestEventListener)
  {
    iz = paramSelfTestEventListener;
  }
  
  public static void a(ds paramds)
  {
    if (iz != null) {
      iz.started(paramds);
    }
  }
  
  public static void b(ds paramds)
  {
    if (iz != null) {
      iz.finished(paramds);
    }
  }
  
  public static void c(ds paramds)
  {
    if (iz != null) {
      iz.passed(paramds);
    }
  }
  
  public static void d(ds paramds)
  {
    if (iz != null) {
      iz.failed(paramds);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dt
 * JD-Core Version:    0.7.0.1
 */