package com.rsa.jcm.f;

class ha
  extends gz
{
  ha(gk paramgk, ic paramic)
  {
    super(paramgk, paramic);
  }
  
  void b(ic paramic)
  {
    int i = this.mR.getFieldSize();
    int j = i >>> 1;
    int k = this.mR.cc();
    int[] arrayOfInt1 = paramic.B(gn.s(i) * 2);
    int m = this.mR.cf();
    int[] arrayOfInt2 = new int[k + 1];
    int[] arrayOfInt3 = new int[k + 1];
    int n = i - 1 + j >>> 5;
    int i1 = 2 * i - 2 >>> 5;
    int i2 = i1 - n + 1;
    int i3 = (i - 1 + j) % 32;
    arrayOfInt2[i2] = 0;
    System.arraycopy(arrayOfInt1, n, arrayOfInt2, 0, i2);
    arrayOfInt2[0] = (arrayOfInt2[0] >>> i3 << i3);
    n = j - 1 + m >>> 5;
    i1 = i - 2 + m >>> 5;
    int i4 = (j - 1 + m) % 32;
    arrayOfInt3[i2] = 0;
    if (i3 >= i4)
    {
      ih.d(arrayOfInt2, i2 - 1, i3 - i4, arrayOfInt3);
    }
    else
    {
      i5 = ih.a(arrayOfInt2, i2 - 1, i4 - i3, arrayOfInt3);
      if (i5 != 0) {
        arrayOfInt3[i2] = i5;
      }
    }
    for (int i5 = i1 - n; i5 >= 0; i5--) {
      arrayOfInt1[(n + i5)] ^= arrayOfInt3[i5];
    }
    n = j - 1 >>> 5;
    i1 = i - 2 >>> 5;
    i4 = (j - 1) % 32;
    arrayOfInt3[i1] = 0;
    if (i3 > i4)
    {
      ih.b(arrayOfInt2, i2 - 1, i3 - i4, arrayOfInt3, n);
    }
    else
    {
      i5 = ih.a(arrayOfInt2, i2 - 1, i4 - i3, arrayOfInt3, n);
      if (i5 != 0) {
        arrayOfInt3[i1] = i5;
      }
    }
    for (i5 = n; i5 <= i1; i5++) {
      arrayOfInt1[i5] ^= arrayOfInt3[i5];
    }
    gn.a(arrayOfInt1, (i - 1 + j >>> 5) + 1, (i - 1 + j) % 32);
    n = i >>> 5;
    i1 = i - 2 + j >>> 5;
    i3 = i % 32;
    ih.a(arrayOfInt1, n, i1 - n, i3, arrayOfInt2);
    i2 = gn.s(j - 1);
    n = m >>> 5;
    i1 = j - 2 + m >>> 5;
    i4 = m % 32;
    arrayOfInt3[i1] = 0;
    i5 = ih.a(arrayOfInt2, i2 - 1, i4, arrayOfInt3, n);
    if (i5 != 0) {
      arrayOfInt3[i1] = i5;
    }
    for (int i6 = n; i6 <= i1; i6++) {
      arrayOfInt1[i6] ^= arrayOfInt3[i6];
    }
    i1 = j - 2 >>> 5;
    for (i6 = i1; i6 >= 0; i6--) {
      arrayOfInt1[i6] ^= arrayOfInt2[i6];
    }
    gn.a(arrayOfInt1, k, i % 32);
    paramic.a(arrayOfInt1, k);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ha
 * JD-Core Version:    0.7.0.1
 */