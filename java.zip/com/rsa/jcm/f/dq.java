package com.rsa.jcm.f;

import com.rsa.crypto.SecretKey;

class dq
{
  private static final byte[] hT = { 101, 32, 67, 111, 110, 115, 117, 108, 116, 105, 110, 103, 32, 40, 80, 116, 121, 41, 32, 76, 116, 100, 46, 49, 31, 48, 29, 6, 3, 85 };
  
  static SecretKey aG()
  {
    return new di(null, hT, 0, hT.length);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dq
 * JD-Core Version:    0.7.0.1
 */