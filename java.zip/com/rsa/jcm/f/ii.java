package com.rsa.jcm.f;

import com.rsa.crypto.AlgInputParams;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class ii
  extends cl
  implements AlgInputParams
{
  private final Map oM = new HashMap();
  
  public ii(ke paramke)
  {
    super(paramke);
  }
  
  public void set(String paramString, Object paramObject)
  {
    this.oM.put(paramString.toLowerCase(), paramObject);
  }
  
  public Object get(String paramString)
  {
    return this.oM.get(paramString.toLowerCase());
  }
  
  public String toString()
  {
    return this.oM.toString();
  }
  
  public Object clone()
  {
    ii localii = new ii(this.an);
    Iterator localIterator = this.oM.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Object localObject = this.oM.get(str);
      if ((localObject instanceof byte[])) {
        localii.oM.put(str, es.x((byte[])localObject));
      } else if (localObject != null) {
        localii.oM.put(str, localObject);
      }
    }
    return localii;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ii
 * JD-Core Version:    0.7.0.1
 */