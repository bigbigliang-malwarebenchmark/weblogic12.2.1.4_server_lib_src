package com.rsa.jcm.f;

public class gr
  extends go
{
  gr(String paramString, gk paramgk, gl paramgl1, gl paramgl2, byte[] paramArrayOfByte, gl paramgl3, gl paramgl4, id paramid, int paramInt)
  {
    super(paramString, paramgk, paramgl1, paramgl2, paramArrayOfByte, paramgl3, paramgl4, paramid, paramInt);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gr
 * JD-Core Version:    0.7.0.1
 */