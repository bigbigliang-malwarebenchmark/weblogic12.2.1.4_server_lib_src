package com.rsa.jcm.f;

public abstract class dg
{
  abstract String av();
  
  String aw()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(System.getProperty("os.name", ""));
    localStringBuffer.append(System.getProperty("os.arch", ""));
    localStringBuffer.append(System.getProperty("java.vm.specification.vendor", ""));
    localStringBuffer.append(System.getProperty("java.specification.version", ""));
    localStringBuffer.append(System.getProperty("java.vm.name", ""));
    localStringBuffer.append(System.getProperty("java.runtime.name", ""));
    return localStringBuffer.toString();
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dg
 * JD-Core Version:    0.7.0.1
 */