package com.rsa.jcm.f;

public class jb
{
  public static final int qb = 8;
  
  public static int[] F(byte[] paramArrayOfByte)
  {
    int[] arrayOfInt = new int[paramArrayOfByte.length];
    for (int i = 0; i < arrayOfInt.length; i++) {
      paramArrayOfByte[i] &= 0xFF;
    }
    return arrayOfInt;
  }
  
  public static int G(byte[] paramArrayOfByte)
  {
    return D(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public static int D(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    int i = 0;
    for (int j = 0; j < paramInt2; j++) {
      i = (i << 8) + (paramArrayOfByte[(j + paramInt1)] & 0xFF);
    }
    return i;
  }
  
  public static long H(byte[] paramArrayOfByte)
  {
    return E(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public static long E(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    long l = 0L;
    for (int i = 0; i < paramInt2; i++) {
      l = (l << 8) + (paramArrayOfByte[(i + paramInt1)] & 0xFF);
    }
    return l;
  }
  
  public static long F(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    long l = 0L;
    for (int i = paramInt2 + paramInt1 - 1; i >= paramInt1; i--) {
      l = (l << 8) + (paramArrayOfByte[i] & 0xFF);
    }
    return l;
  }
  
  public static long F(byte[] paramArrayOfByte, int paramInt)
  {
    int i = paramInt + 8 - 1;
    long l = paramArrayOfByte[(i--)];
    l = (l << 8) + (paramArrayOfByte[(i--)] & 0xFF);
    l = (l << 8) + (paramArrayOfByte[(i--)] & 0xFF);
    l = (l << 8) + (paramArrayOfByte[(i--)] & 0xFF);
    l = (l << 8) + (paramArrayOfByte[(i--)] & 0xFF);
    l = (l << 8) + (paramArrayOfByte[(i--)] & 0xFF);
    l = (l << 8) + (paramArrayOfByte[(i--)] & 0xFF);
    return (l << 8) + (paramArrayOfByte[i] & 0xFF);
  }
  
  public static byte[] ak(int paramInt)
  {
    return new byte[] { (byte)(paramInt >>> 24), (byte)(paramInt >> 16 & 0xFF), (byte)(paramInt >> 8 & 0xFF), (byte)(paramInt & 0xFF) };
  }
  
  public static void a(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    paramArrayOfByte[(paramInt2 + 3)] = ((byte)paramInt1);
    paramArrayOfByte[(paramInt2 + 2)] = ((byte)(paramInt1 >> 8));
    paramArrayOfByte[(paramInt2 + 1)] = ((byte)(paramInt1 >> 16));
    paramArrayOfByte[paramInt2] = ((byte)(paramInt1 >> 24));
  }
  
  public static void b(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    int i = 0;
    for (int j = 0; j < paramInt3; j++)
    {
      paramArrayOfByte[(paramInt2 + paramInt3 - 1 - j)] = ((byte)(paramInt1 >> i));
      i += 8;
    }
  }
  
  public static byte[] c(long paramLong)
  {
    return new byte[] { (byte)(int)(paramLong >>> 56), (byte)(int)(paramLong >> 48 & 0xFF), (byte)(int)(paramLong >> 40 & 0xFF), (byte)(int)(paramLong >> 32 & 0xFF), (byte)(int)(paramLong >> 24 & 0xFF), (byte)(int)(paramLong >> 16 & 0xFF), (byte)(int)(paramLong >> 8 & 0xFF), (byte)(int)(paramLong & 0xFF) };
  }
  
  public static void a(long paramLong, byte[] paramArrayOfByte, int paramInt)
  {
    paramArrayOfByte[(paramInt + 7)] = ((byte)(int)paramLong);
    paramArrayOfByte[(paramInt + 6)] = ((byte)(int)(paramLong >> 8));
    paramArrayOfByte[(paramInt + 5)] = ((byte)(int)(paramLong >> 16));
    paramArrayOfByte[(paramInt + 4)] = ((byte)(int)(paramLong >> 24));
    paramArrayOfByte[(paramInt + 3)] = ((byte)(int)(paramLong >> 32));
    paramArrayOfByte[(paramInt + 2)] = ((byte)(int)(paramLong >> 40));
    paramArrayOfByte[(paramInt + 1)] = ((byte)(int)(paramLong >> 48));
    paramArrayOfByte[paramInt] = ((byte)(int)(paramLong >> 56));
  }
  
  public static void b(long paramLong, byte[] paramArrayOfByte, int paramInt)
  {
    paramArrayOfByte[paramInt] = ((byte)(int)paramLong);
    paramArrayOfByte[(paramInt + 1)] = ((byte)(int)(paramLong >> 8));
    paramArrayOfByte[(paramInt + 2)] = ((byte)(int)(paramLong >> 16));
    paramArrayOfByte[(paramInt + 3)] = ((byte)(int)(paramLong >> 24));
    paramArrayOfByte[(paramInt + 4)] = ((byte)(int)(paramLong >> 32));
    paramArrayOfByte[(paramInt + 5)] = ((byte)(int)(paramLong >> 40));
    paramArrayOfByte[(paramInt + 6)] = ((byte)(int)(paramLong >> 48));
    paramArrayOfByte[(paramInt + 7)] = ((byte)(int)(paramLong >> 56));
  }
  
  public static void b(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    for (int i = 0; i < paramInt2; i++) {
      paramArrayOfByte[(paramInt1 + i)] = ((byte)(int)(paramLong >> i * 8));
    }
  }
  
  public static byte[] hexStringToByteArray(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0)) {
      return null;
    }
    byte[] arrayOfByte = null;
    if (paramString.length() % 2 == 0)
    {
      int i = paramString.length() / 2;
      arrayOfByte = new byte[i];
      for (int j = 0; j < i; j++) {
        arrayOfByte[j] = ((byte)Integer.parseInt(paramString.substring(j * 2, j * 2 + 2), 16));
      }
    }
    return arrayOfByte;
  }
  
  public static String I(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null) {
      return "null";
    }
    StringBuffer localStringBuffer = new StringBuffer();
    int i = paramArrayOfByte.length;
    for (int j = 0; i > 0; j++)
    {
      int k = paramArrayOfByte[j] & 0xFF;
      String str = Integer.toHexString(k);
      if (str.length() == 1) {
        localStringBuffer = localStringBuffer.append("0");
      }
      localStringBuffer = localStringBuffer.append(str);
      i--;
    }
    return localStringBuffer.toString();
  }
  
  public static short G(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    int i = 0;
    for (int j = 0; j < paramInt2; j++) {
      i = (i << 8) + (paramArrayOfByte[(j + paramInt1)] & 0xFF);
    }
    return (short)i;
  }
  
  public static void b(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    paramArrayOfByte[paramInt2] = ((byte)(paramInt1 >>> 8 & 0xFF));
    paramArrayOfByte[(paramInt2 + 1)] = ((byte)(paramInt1 & 0xFF));
  }
  
  public static byte[] J(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = new byte[paramArrayOfByte.length];
    i(paramArrayOfByte, 0, paramArrayOfByte.length, arrayOfByte, 0);
    return arrayOfByte;
  }
  
  public static void i(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    for (int i = paramInt2; i > 0; i--) {
      paramArrayOfByte2[(paramInt2 + paramInt3 - i)] = paramArrayOfByte1[(i - 1 + paramInt1)];
    }
  }
  
  public static void H(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    int i = paramInt1;
    int j = paramInt2 - 1;
    while (j > i)
    {
      int k = paramArrayOfByte[j];
      paramArrayOfByte[j] = paramArrayOfByte[i];
      paramArrayOfByte[i] = k;
      j--;
      i++;
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.jb
 * JD-Core Version:    0.7.0.1
 */