package com.rsa.jcm.f;

import com.rsa.crypto.SelfTestEventListener;
import java.io.File;
import java.util.concurrent.ExecutorService;

final class dj
{
  private dl ih;
  private el ii;
  static final String ij = "BSAFE Crypto Module has entered an inoperable state, an internal FIPS 140 self-verification test has failed";
  
  dj(dl paramdl)
  {
    this.ih = paramdl;
  }
  
  public void a(File paramFile, SelfTestEventListener paramSelfTestEventListener, ExecutorService paramExecutorService, dc paramdc)
  {
    dt.a(paramSelfTestEventListener);
    if (this.ih.c(dk.UNDER_SELF_TEST)) {
      return;
    }
    if (this.ih.c(dk.NOT_INITIALIZED))
    {
      this.ih.b(dk.UNDER_SELF_TEST);
      dn localdn = new dn(paramFile);
      do localdo = new do();
      this.ii = new el(localdn, localdo, paramdc);
      boolean bool;
      try
      {
        bool = this.ii.a(paramExecutorService);
      }
      catch (Throwable localThrowable)
      {
        this.ih.b(dk.FAILED);
        throw new SecurityException(localThrowable);
      }
      if (!bool)
      {
        this.ih.b(dk.FAILED);
        throw new SecurityException("BSAFE Crypto Module has entered an inoperable state, an internal FIPS 140 self-verification test has failed(" + this.ii.aO() + ")");
      }
      this.ih.b(dk.OPERATIONAL);
    }
    if (this.ih.c(dk.FAILED)) {
      throw new SecurityException("BSAFE Crypto Module has entered an inoperable state, an internal FIPS 140 self-verification test has failed");
    }
  }
  
  public void ax()
  {
    if ((this.ih.c(dk.NOT_INITIALIZED)) || (this.ih.c(dk.UNDER_SELF_TEST))) {
      throw new SecurityException("Unexpected state: cannot re-run self-tests before power-up");
    }
    if (this.ih.c(dk.FAILED)) {
      throw new SecurityException("BSAFE Crypto Module has entered an inoperable state, an internal FIPS 140 self-verification test has failed");
    }
    if (this.ih.c(dk.OPERATIONAL))
    {
      boolean bool;
      try
      {
        bool = this.ii.aP();
      }
      catch (Throwable localThrowable)
      {
        this.ih.b(dk.FAILED);
        throw new SecurityException(localThrowable);
      }
      if (!bool)
      {
        this.ih.b(dk.FAILED);
        throw new SecurityException("BSAFE Crypto Module has entered an inoperable state, an internal FIPS 140 self-verification test has failed(" + this.ii.aO() + ")");
      }
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dj
 * JD-Core Version:    0.7.0.1
 */