package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.MAC;
import com.rsa.crypto.SecretKey;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class dd
{
  private static final int hL = 8;
  private static final int hM = -1483652555;
  private static final int hN = 4;
  private static final int hO = 0;
  private static final int hP = 4;
  private static final int hQ = 2;
  private static final int hR = 6;
  private static final int hS = 64;
  private static final byte[] hT = { -2, 91, 109, 102, 85, -104, 81, -11, -106, -27, 0, -37, 56, 44, -27, 96 };
  private static final SecretKey hU = new di(null, hT, 0, hT.length);
  
  public static df a(File paramFile)
    throws CryptoException
  {
    if (paramFile == null) {
      throw new CryptoException("Invalid configuration file");
    }
    RandomAccessFile localRandomAccessFile = null;
    bp localbp = new bp(null, new ca(null));
    try
    {
      localRandomAccessFile = new RandomAccessFile(paramFile, "r");
      if (localRandomAccessFile.length() == 0L)
      {
        localObject1 = new df(new ArrayList());
        return localObject1;
      }
      Object localObject1 = new byte[(int)localRandomAccessFile.length()];
      localRandomAccessFile.readFully((byte[])localObject1);
      if ((localObject1.length < 4) || (jb.D((byte[])localObject1, 0, 4) != -1483652555)) {
        throw new CryptoException("Not a Crypto-J module configuration file: " + paramFile.getName());
      }
      if (localObject1.length < 8) {
        throw new CryptoException("Illegal module configuration file.");
      }
      int i = jb.G((byte[])localObject1, 4, 2);
      if (i != 1) {
        throw new CryptoException("Version of config file " + paramFile.getName() + ": " + i + " is not supported.");
      }
      int j = jb.G((byte[])localObject1, 6, 2);
      if (localObject1.length != j) {
        throw new CryptoException("Config file " + paramFile.getName() + " is of illegal size.");
      }
      ArrayList localArrayList = new ArrayList();
      for (int k = 8; k + 64 < j; k += 137) {
        localArrayList.add(de.u((byte[])localObject1, k));
      }
      if ((localArrayList.size() != 2) || (((de)localArrayList.get(0)).getValue() != 10) || (((de)localArrayList.get(1)).getValue() != 11)) {
        throw new CryptoException("Config file " + paramFile.getName() + " does not contain two roles.");
      }
      localbp.init(hU, null);
      localbp.update((byte[])localObject1, 0, localObject1.length - 64);
      if (!localbp.verify((byte[])localObject1, localObject1.length - 64, 64)) {
        throw new CryptoException("Config file " + paramFile.getName() + " verification failed.");
      }
      df localdf = new df(localArrayList);
      return localdf;
    }
    catch (IOException localIOException1)
    {
      throw new CryptoException("Error reading disk cache file", localIOException1);
    }
    finally
    {
      er.a(localbp);
      if (localRandomAccessFile != null) {
        try
        {
          localRandomAccessFile.close();
        }
        catch (IOException localIOException4) {}
      }
    }
  }
  
  public static void a(df paramdf, File paramFile)
    throws CryptoException
  {
    RandomAccessFile localRandomAccessFile = null;
    bp localbp = new bp(null, new ca(null));
    try
    {
      List localList = paramdf.as();
      int i = 8 + 137 * localList.size() + 64;
      byte[] arrayOfByte = new byte[i];
      jb.a(-1483652555, arrayOfByte, 0);
      jb.b(paramdf.ar(), arrayOfByte, 4);
      jb.b(i, arrayOfByte, 6);
      int j = 8;
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        de localde = (de)localIterator.next();
        j += localde.v(arrayOfByte, j);
      }
      localbp.init(hU, null);
      localbp.update(arrayOfByte, 0, i - 64);
      localbp.mac(arrayOfByte, arrayOfByte.length - 64);
      localRandomAccessFile = new RandomAccessFile(paramFile, "rwd");
      localRandomAccessFile.setLength(0L);
      localRandomAccessFile.write(arrayOfByte);
      return;
    }
    catch (IOException localIOException2)
    {
      throw new CryptoException("Error reading disk cache file", localIOException2);
    }
    finally
    {
      er.a(localbp);
      if (localRandomAccessFile != null) {
        try
        {
          localRandomAccessFile.close();
        }
        catch (IOException localIOException3) {}
      }
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dd
 * JD-Core Version:    0.7.0.1
 */