package com.rsa.jcm.f;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class dc
{
  private static final String hH = "fips140.kat.status";
  private static final String hI = "KATSUCCESS";
  private File hJ;
  private dg hK;
  
  public dc(dg paramdg, File paramFile)
  {
    this.hK = paramdg;
    this.hJ = paramFile;
  }
  
  public void am()
  {
    if (this.hJ == null) {
      return;
    }
    FileOutputStream localFileOutputStream = null;
    try
    {
      String str = ao();
      if (!this.hJ.exists()) {
        this.hJ.createNewFile();
      }
      localFileOutputStream = new FileOutputStream(this.hJ);
      Properties localProperties = new Properties();
      localProperties.setProperty("fips140.kat.status", str);
      localProperties.store(localFileOutputStream, null);
      return;
    }
    catch (Exception localException) {}finally
    {
      if (localFileOutputStream != null) {
        try
        {
          localFileOutputStream.close();
        }
        catch (IOException localIOException3) {}
      }
    }
  }
  
  public boolean an()
  {
    if (this.hJ == null) {
      return true;
    }
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(this.hJ);
      Properties localProperties = new Properties();
      localProperties.load(localFileInputStream);
      String str = localProperties.getProperty("fips140.kat.status");
      boolean bool2 = !b(str);
      return bool2;
    }
    catch (Exception localException)
    {
      boolean bool1 = true;
      return bool1;
    }
    finally
    {
      if (localFileInputStream != null) {
        try
        {
          localFileInputStream.close();
        }
        catch (IOException localIOException3) {}
      }
    }
  }
  
  private String ao()
  {
    bp localbp = new bp(null, new by(null));
    localbp.init(dq.aG());
    a(localbp, "KATSUCCESS");
    a(localbp, ev.getVersionString());
    a(localbp, this.hK.av());
    byte[] arrayOfByte = new byte[localbp.getMacLength()];
    localbp.mac(arrayOfByte, 0);
    return jb.I(arrayOfByte);
  }
  
  private void a(bp parambp, String paramString)
  {
    a(parambp, paramString.getBytes());
  }
  
  private void a(bp parambp, byte[] paramArrayOfByte)
  {
    parambp.update(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  private boolean b(String paramString)
  {
    if ((paramString == null) || (paramString.isEmpty())) {
      return false;
    }
    String str = ao();
    return str.equals(paramString);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.dc
 * JD-Core Version:    0.7.0.1
 */