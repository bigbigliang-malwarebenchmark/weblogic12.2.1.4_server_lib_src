package com.rsa.jcm.f;

import com.rsa.crypto.BigNum;
import com.rsa.crypto.DHParams;
import com.rsa.crypto.DSAParams;

public class fa
  extends fg
  implements DHParams, DSAParams
{
  private byte[] jY;
  private int counter;
  private String jZ;
  private BigNum ka;
  private int kb;
  
  public fa(ke paramke, BigNum paramBigNum1, BigNum paramBigNum2, BigNum paramBigNum3, byte[] paramArrayOfByte, int paramInt, BigNum paramBigNum4, String paramString)
  {
    this(paramke, paramBigNum1, paramBigNum2, paramBigNum3, paramArrayOfByte, paramInt, paramBigNum4, 0, paramString);
  }
  
  public fa(ke paramke, BigNum paramBigNum1, BigNum paramBigNum2, BigNum paramBigNum3, byte[] paramArrayOfByte, int paramInt1, BigNum paramBigNum4, int paramInt2, String paramString)
  {
    super(paramke, paramBigNum1, paramBigNum2, paramBigNum3);
    this.jY = es.x(paramArrayOfByte);
    this.counter = paramInt1;
    this.jZ = paramString;
    this.ka = paramBigNum4;
    this.kb = paramInt2;
  }
  
  public fa(ke paramke, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, int paramInt1, byte[] paramArrayOfByte5, int paramInt2, String paramString)
  {
    this(paramke, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    this.jY = es.x(paramArrayOfByte4);
    this.counter = paramInt1;
    this.jZ = paramString;
    this.ka = (paramArrayOfByte5 == null ? null : new id(paramArrayOfByte5));
    this.kb = paramInt2;
    this.jZ = paramString;
  }
  
  public fa(ke paramke, BigNum paramBigNum1, BigNum paramBigNum2, BigNum paramBigNum3)
  {
    super(paramke, paramBigNum1, paramBigNum2, paramBigNum3);
  }
  
  public fa(ke paramke, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    super(paramke, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
  }
  
  public byte[] getSeed()
  {
    return es.x(this.jY);
  }
  
  public int getCounter()
  {
    return this.counter;
  }
  
  public String getDigestAlg()
  {
    return this.jZ;
  }
  
  public BigNum getJ()
  {
    return this.ka;
  }
  
  public int getMaxExponentLen()
  {
    return this.kb;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fa
 * JD-Core Version:    0.7.0.1
 */