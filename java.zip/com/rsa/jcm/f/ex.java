package com.rsa.jcm.f;

import com.rsa.crypto.MAC;
import com.rsa.crypto.SecretKey;

public class ex
  extends ew
{
  private MAC jV;
  private MAC jW;
  
  public ex(ke paramke, MAC paramMAC1, MAC paramMAC2)
  {
    super(paramke);
    this.jV = paramMAC1;
    this.jW = paramMAC2;
  }
  
  void a(SecretKey paramSecretKey, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    byte[] arrayOfByte1 = paramSecretKey.getKeyData();
    int i = arrayOfByte1.length + 1 >> 1;
    di localdi1 = new di(this.an, arrayOfByte1, 0, i);
    di localdi2 = new di(this.an, arrayOfByte1, arrayOfByte1.length - i, i);
    byte[] arrayOfByte2 = new byte[paramArrayOfByte3.length];
    byte[] arrayOfByte3 = new byte[paramArrayOfByte3.length];
    this.jV.init(localdi1);
    a(this.jV, paramArrayOfByte1, paramArrayOfByte2, arrayOfByte2, 0, arrayOfByte2.length);
    this.jW.init(localdi2);
    a(this.jW, paramArrayOfByte1, paramArrayOfByte2, arrayOfByte3, 0, arrayOfByte3.length);
    for (int j = 0; j < paramArrayOfByte3.length; j++) {
      paramArrayOfByte3[j] = ((byte)(arrayOfByte2[j] ^ arrayOfByte3[j]));
    }
    er.w(arrayOfByte1);
    er.a(localdi1);
    er.a(localdi2);
  }
  
  public void clearSensitiveData()
  {
    this.jV.clearSensitiveData();
    this.jW.clearSensitiveData();
  }
  
  public Object clone()
  {
    ex localex = (ex)super.clone();
    localex.jV = ((MAC)es.a(this.jV));
    localex.jW = ((MAC)es.a(this.jW));
    return localex;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ex
 * JD-Core Version:    0.7.0.1
 */