package com.rsa.jcm.f;

public abstract class fz
  implements ga
{
  gi lv;
  gi[] lw;
  ge lx;
  int ly;
  int lz;
  
  public fz(gi paramgi)
  {
    this.lv = ((gi)paramgi.clone());
    this.lv.bF();
    this.lx = this.lv.aS();
  }
  
  public abstract void z(byte[] paramArrayOfByte);
  
  public gi aY()
  {
    id localid = (id)this.lx.be().clone();
    localid.R(1);
    gi localgi1 = d(localid);
    try
    {
      gi localgi2 = localgi1.f(this.lv);
      return localgi2;
    }
    finally
    {
      er.a(localid);
      er.a(localgi1);
    }
  }
  
  public abstract gi d(id paramid);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fz
 * JD-Core Version:    0.7.0.1
 */