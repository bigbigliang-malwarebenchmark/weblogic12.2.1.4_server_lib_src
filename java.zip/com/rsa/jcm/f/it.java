package com.rsa.jcm.f;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.MessageDigest;
import com.rsa.crypto.SignatureException;
import java.util.Arrays;

public final class it
  extends g
{
  private MessageDigest pG;
  
  public it(ke paramke, MessageDigest paramMessageDigest)
  {
    super(paramke);
    this.pG = paramMessageDigest;
  }
  
  public void a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2)
    throws SignatureException
  {
    int i = this.K - paramInt2;
    int j = paramInt1 + i - 1;
    if ((this.K < 12) || (i < 11)) {
      throw new SignatureException("Input size must have length less than " + (this.K - 11));
    }
    int k = ir.a(this.pG, paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, 0);
    if (k != 0)
    {
      i = this.K - k;
      j = i - 1;
    }
    System.arraycopy(paramArrayOfByte2, 0, paramArrayOfByte2, j + 1, k);
    paramArrayOfByte2[j] = 0;
    paramArrayOfByte2[0] = 0;
    paramArrayOfByte2[1] = 1;
    Arrays.fill(paramArrayOfByte2, 2, j, (byte)-1);
  }
  
  public int c(byte[] paramArrayOfByte, int paramInt)
    throws SignatureException
  {
    if ((paramArrayOfByte[paramInt] != 0) || (paramArrayOfByte[(paramInt + 1)] != 1)) {
      throw new SignatureException("Signature verify failed.");
    }
    int j = this.K + paramInt;
    for (int i = paramInt + 2; (i < j) && (paramArrayOfByte[i] == -1); i++) {}
    if (i < paramInt + 2 + 8) {
      throw new SignatureException("Signature verify failed.");
    }
    if (i == j) {
      throw new SignatureException("Signature verify failed.");
    }
    if (paramArrayOfByte[i] != 0) {
      throw new SignatureException("Signature verify failed.");
    }
    i++;
    int k = j - i;
    int m = ir.a(paramArrayOfByte, i, k, this.pG);
    int n = j - m;
    System.arraycopy(paramArrayOfByte, m, paramArrayOfByte, paramInt, n);
    Arrays.fill(paramArrayOfByte, paramInt + n, j, (byte)0);
    return n;
  }
  
  public int d(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws SignatureException
  {
    byte[] arrayOfByte = new byte[this.K];
    a(paramArrayOfByte1, paramInt1, paramInt2, arrayOfByte);
    try
    {
      return a(arrayOfByte, 0, paramArrayOfByte2, paramInt3);
    }
    catch (CryptoException localCryptoException)
    {
      throw new SignatureException("Signature generation failed: " + localCryptoException.getMessage());
    }
  }
  
  public void clearSensitiveData()
  {
    super.clearSensitiveData();
    er.a(this.pG);
  }
  
  public String getAlg()
  {
    return "RSA/PKCS1";
  }
  
  public Object clone()
  {
    it localit = (it)super.clone();
    localit.pG = ((MessageDigest)es.a(this.pG));
    return localit;
  }
  
  public int getSignatureSize()
  {
    return getBlockSize();
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.it
 * JD-Core Version:    0.7.0.1
 */