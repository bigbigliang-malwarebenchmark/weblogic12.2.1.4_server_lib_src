package com.rsa.jcm.f;

import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.CryptoException;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.KeyPair;
import com.rsa.crypto.KeyPairGenerator;
import com.rsa.crypto.PrivateKey;
import com.rsa.crypto.PublicKey;
import com.rsa.crypto.SecureRandom;
import com.rsa.crypto.SignatureException;
import java.util.Arrays;

abstract class ip
  implements iw
{
  protected boolean initialized;
  protected boolean pb;
  protected SecureRandom M;
  protected id pc;
  protected id pd;
  
  public boolean e()
  {
    return (this.initialized) && (this.pb);
  }
  
  public boolean f()
  {
    return (this.initialized) && (!this.pb);
  }
  
  public boolean initialized()
  {
    return this.initialized;
  }
  
  protected abstract id c(PublicKey paramPublicKey);
  
  protected abstract id c(PrivateKey paramPrivateKey);
  
  abstract id t(id paramid1, id paramid2)
    throws CryptoException;
  
  id[] y(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws CryptoException
  {
    try
    {
      int i = paramInt1;
      if (paramArrayOfByte[(i++)] != 48) {
        throw new CryptoException();
      }
      int j = x(paramArrayOfByte, i);
      int k = z(paramArrayOfByte, i, j);
      i += j;
      if (k + j + 1 != paramInt2) {
        throw new CryptoException();
      }
      if (paramArrayOfByte[(i++)] != 2) {
        throw new CryptoException();
      }
      int m = x(paramArrayOfByte, i);
      int n = z(paramArrayOfByte, i, m);
      i += m;
      id localid1 = new id(paramArrayOfByte, i, n);
      i += n;
      if (paramArrayOfByte[(i++)] != 2) {
        throw new CryptoException();
      }
      int i1 = x(paramArrayOfByte, i);
      int i2 = z(paramArrayOfByte, i, i1);
      i += i1;
      id localid2 = new id(paramArrayOfByte, i, i2);
      i += i2;
      if (i != paramInt1 + paramInt2) {
        throw new CryptoException();
      }
      if ((localid1.isZero()) || (localid1.q(this.pc) >= 0) || (localid2.isZero()) || (localid2.q(this.pc) >= 0)) {
        throw new CryptoException();
      }
      return new id[] { localid1, localid2 };
    }
    catch (Exception localException)
    {
      throw new CryptoException();
    }
  }
  
  private int z(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    switch (paramInt2)
    {
    case 1: 
      return paramArrayOfByte[paramInt1] & 0xFF;
    case 2: 
      return paramArrayOfByte[(paramInt1 + 1)] & 0xFF;
    case 3: 
      int i = (paramArrayOfByte[(paramInt1 + 1)] & 0xFF) << 8;
      i |= paramArrayOfByte[(paramInt1 + 2)] & 0xFF;
      return i;
    }
    throw new CryptoException();
  }
  
  private int x(byte[] paramArrayOfByte, int paramInt)
  {
    if ((paramArrayOfByte[paramInt] & 0xFFFFFF80) == 0) {
      return 1;
    }
    return 1 + paramArrayOfByte[paramInt] & 0x7F;
  }
  
  public boolean a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4)
    throws SignatureException
  {
    id localid1 = null;
    id localid2 = null;
    id localid3 = null;
    id localid4 = null;
    id localid5 = null;
    id localid6 = null;
    id[] arrayOfid = null;
    try
    {
      arrayOfid = y(paramArrayOfByte2, paramInt3, paramInt4);
      localid1 = A(paramArrayOfByte1, paramInt1, paramInt2);
      id localid7 = arrayOfid[1];
      localid5 = new id();
      localid7.k(this.pc, localid5);
      localid2 = new id();
      localid3 = new id();
      localid1.e(localid5, this.pc, localid2);
      id localid8 = arrayOfid[0];
      localid8.e(localid5, this.pc, localid3);
      localid6 = t(localid2, localid3);
      localid4 = new id();
      localid6.j(this.pc, localid4);
      boolean bool2 = localid8.equals(localid4);
      return bool2;
    }
    catch (CryptoException localCryptoException)
    {
      boolean bool1 = false;
      return bool1;
    }
    finally
    {
      er.a(localid6);
      er.a(localid1);
      er.a(localid2);
      er.a(localid3);
      er.a(localid4);
      er.a(localid5);
      er.a(arrayOfid);
    }
  }
  
  abstract KeyPairGenerator cO();
  
  public int d(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws SignatureException
  {
    KeyPairGenerator localKeyPairGenerator = cO();
    try
    {
      int i = a(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3, localKeyPairGenerator);
      return i;
    }
    finally
    {
      er.a(localKeyPairGenerator);
    }
  }
  
  protected int a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, KeyPairGenerator paramKeyPairGenerator)
    throws SignatureException
  {
    id localid1 = new id();
    id localid2 = new id();
    id localid3 = null;
    id localid4 = null;
    id localid5 = null;
    id localid6 = null;
    try
    {
      localid5 = new id();
      localid3 = A(paramArrayOfByte1, paramInt1, paramInt2);
      do
      {
        KeyPair localKeyPair = paramKeyPairGenerator.generate(false);
        try
        {
          localid6 = c(localKeyPair.getPublic());
          localid6.j(this.pc, localid1);
          localid4 = c(localKeyPair.getPrivate());
          if (!localid4.k(this.pc, localid5))
          {
            er.a(localKeyPair);
          }
          else
          {
            this.pd.e(localid1, this.pc, localid4);
            localid3.f(localid4, localid2);
            localid2.j(this.pc, localid4);
            localid4.e(localid5, this.pc, localid2);
          }
        }
        finally
        {
          er.a(localKeyPair);
        }
      } while (localid2.isZero());
      int i = a(localid1, localid2, paramArrayOfByte2, paramInt3);
      return i;
    }
    catch (CryptoException localCryptoException)
    {
      throw new SignatureException("Signature generation failed: " + localCryptoException.getMessage());
    }
    finally
    {
      er.a(localid3);
      er.a(localid5);
      er.a(localid4);
      er.a(localid6);
      er.a(localid2);
      er.a(localid1);
    }
  }
  
  private id A(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws SignatureException
  {
    id localid = new id();
    int j = this.pc.getBitLength();
    int i;
    if (paramInt2 * 8 < j) {
      i = paramInt2;
    } else {
      i = (j + 7) / 8;
    }
    localid.t(paramArrayOfByte, paramInt1, i);
    if (i * 8 > j) {
      localid.G(8 - j % 8);
    }
    return localid;
  }
  
  int a(id paramid1, id paramid2, byte[] paramArrayOfByte, int paramInt)
    throws CryptoException
  {
    byte[] arrayOfByte1 = paramid1.toOctetString();
    byte[] arrayOfByte2 = paramid2.toOctetString();
    int i = arrayOfByte1.length;
    int j = arrayOfByte2.length;
    if ((arrayOfByte1[0] & 0xFFFFFF80) != 0) {
      i++;
    }
    int k = af(i);
    if ((arrayOfByte2[0] & 0xFFFFFF80) != 0) {
      j++;
    }
    int m = af(j);
    int n = i + k + j + m + 2;
    int i1 = af(n);
    int i2 = n + i1 + 1;
    if (i2 > paramArrayOfByte.length - paramInt) {
      throw new SignatureException("Signature Buffer Too Small");
    }
    Arrays.fill(paramArrayOfByte, paramInt, i2, (byte)0);
    int i3 = paramInt;
    paramArrayOfByte[(i3++)] = 48;
    i3 += b(paramArrayOfByte, i3, n, i1);
    paramArrayOfByte[(i3++)] = 2;
    i3 += b(paramArrayOfByte, i3, i, k);
    System.arraycopy(arrayOfByte1, 0, paramArrayOfByte, i3 + i - arrayOfByte1.length, arrayOfByte1.length);
    i3 += i;
    paramArrayOfByte[(i3++)] = 2;
    i3 += b(paramArrayOfByte, i3, j, m);
    System.arraycopy(arrayOfByte2, 0, paramArrayOfByte, i3 + j - arrayOfByte2.length, arrayOfByte2.length);
    return i2;
  }
  
  private int b(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    int i = paramInt3;
    if (paramInt3 > 1)
    {
      paramArrayOfByte[paramInt1] = ((byte)(0x80 | paramInt3 - 1));
      paramInt1++;
      paramInt3--;
    }
    for (int j = paramInt1 + paramInt3 - 1; j >= paramInt1; j--)
    {
      paramArrayOfByte[j] = ((byte)paramInt2);
      paramInt2 >>>= 8;
    }
    return i;
  }
  
  private int af(int paramInt)
  {
    int i = 1;
    if (paramInt > 127)
    {
      i++;
      if (paramInt > 255) {
        i++;
      }
    }
    return i;
  }
  
  public void setAlgorithmParams(AlgorithmParams paramAlgorithmParams)
    throws InvalidAlgorithmParameterException
  {}
  
  public void a(SecureRandom paramSecureRandom)
  {
    this.M = paramSecureRandom;
  }
  
  public void clearSensitiveData()
  {
    this.initialized = false;
    this.pc = null;
    this.pd = null;
    this.M = null;
  }
  
  public Object clone()
  {
    ip localip;
    try
    {
      localip = (ip)super.clone();
      localip.pc = ((id)es.a(this.pc));
      localip.pd = ((id)es.a(this.pd));
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new CryptoException("Object.clone() unexpectedly threw CloneNotSupportedException.");
    }
    return localip;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.ip
 * JD-Core Version:    0.7.0.1
 */