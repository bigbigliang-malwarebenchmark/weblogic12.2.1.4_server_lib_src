package com.rsa.jcm.f;

class hj
  implements gf
{
  hu nI;
  
  hj(hu paramhu)
  {
    this.nI = paramhu;
  }
  
  public boolean b(gi paramgi)
  {
    if (paramgi.isInfinite()) {
      return false;
    }
    gl localgl1 = paramgi.aS().bb().bG();
    gl localgl2 = paramgi.aS().bb().bH();
    gl localgl3 = paramgi.br();
    gl localgl4 = paramgi.bs();
    if ((!localgl3.isValid()) || (!localgl4.isValid())) {
      return false;
    }
    gl localgl5 = null;
    gl localgl6 = null;
    gl localgl7 = null;
    gl localgl8 = null;
    gl localgl9 = null;
    gl localgl10 = null;
    try
    {
      localgl5 = localgl4.bT();
      localgl7 = localgl3.bT();
      localgl8 = localgl7.c(localgl3);
      localgl9 = localgl1.c(localgl3);
      localgl10 = localgl8.a(localgl9);
      localgl6 = localgl10.a(localgl2);
      if (!localgl5.equals(localgl6))
      {
        bool = false;
        return bool;
      }
      boolean bool = true;
      return bool;
    }
    finally
    {
      er.a(localgl5);
      er.a(localgl7);
      er.a(localgl8);
      er.a(localgl9);
      er.a(localgl10);
      er.a(localgl6);
    }
  }
  
  public boolean a(gi paramgi, boolean paramBoolean)
  {
    if (paramgi.isInfinite()) {
      return true;
    }
    if (!paramgi.bw()) {
      return false;
    }
    if ((paramBoolean) && (paramgi.aS().getCofactor() == 1)) {
      return true;
    }
    return paramgi.bB().isInfinite();
  }
  
  public gi a(gi paramgi1, gi paramgi2)
  {
    if (paramgi1.isInfinite()) {
      return (gi)paramgi2.clone();
    }
    if (paramgi2.isInfinite()) {
      return (gi)paramgi1.clone();
    }
    gl localgl1 = paramgi1.br();
    gl localgl2 = paramgi1.bs();
    gl localgl3 = paramgi2.br();
    gl localgl4 = paramgi2.bs();
    if (localgl1.equals(localgl3))
    {
      if (localgl2.equals(localgl4)) {
        return c(paramgi1);
      }
      return paramgi1.aS().bg().bk();
    }
    gl localgl5 = null;
    gl localgl6 = null;
    gl localgl7 = null;
    try
    {
      localgl5 = localgl4.b(localgl2);
      localgl6 = localgl3.b(localgl1);
      localgl7 = localgl5.d(localgl6);
      gi localgi = a(paramgi1, paramgi2, localgl7);
      return localgi;
    }
    finally
    {
      er.a(localgl5);
      er.a(localgl6);
      er.a(localgl7);
    }
  }
  
  public gi c(gi paramgi)
  {
    if (paramgi.isInfinite()) {
      return (gi)paramgi.clone();
    }
    if (paramgi.bs().isZero()) {
      return paramgi.aS().bg().bk();
    }
    gl localgl1 = paramgi.br();
    gl localgl2 = paramgi.bs();
    gl localgl3 = paramgi.aS().bb().bG();
    gl localgl4 = null;
    gl localgl5 = null;
    gl localgl6 = null;
    gl localgl7 = null;
    gl localgl8 = null;
    gl localgl9 = null;
    try
    {
      localgl4 = localgl1.bT();
      localgl5 = localgl4.a(localgl4);
      localgl6 = localgl5.a(localgl4);
      localgl7 = localgl6.a(localgl3);
      localgl8 = localgl2.a(localgl2);
      localgl9 = localgl7.d(localgl8);
      gi localgi = a(paramgi, paramgi, localgl9);
      return localgi;
    }
    finally
    {
      er.a(localgl4);
      er.a(localgl5);
      er.a(localgl6);
      er.a(localgl7);
      er.a(localgl8);
      er.a(localgl9);
    }
  }
  
  public gi d(gi paramgi)
  {
    return paramgi.aS().bg().a(paramgi.bm(), paramgi.bs().bV());
  }
  
  private gi a(gi paramgi1, gi paramgi2, gl paramgl)
  {
    gl localgl1 = paramgi1.br();
    gl localgl2 = paramgi1.bs();
    gl localgl3 = paramgi2.br();
    gl localgl4 = null;
    gl localgl5 = null;
    gl localgl6 = null;
    gl localgl7 = null;
    try
    {
      localgl4 = paramgl.c(paramgl);
      localgl5 = localgl4.b(localgl1);
      gl localgl8 = localgl5.b(localgl3);
      localgl6 = localgl1.b(localgl8);
      localgl7 = paramgl.c(localgl6);
      gl localgl9 = localgl7.b(localgl2);
      gi localgi = paramgi1.aS().bg().a(localgl8, localgl9);
      return localgi;
    }
    finally
    {
      er.a(localgl4);
      er.a(localgl5);
      er.a(localgl6);
      er.a(localgl7);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hj
 * JD-Core Version:    0.7.0.1
 */