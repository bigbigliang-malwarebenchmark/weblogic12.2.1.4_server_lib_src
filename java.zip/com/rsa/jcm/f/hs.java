package com.rsa.jcm.f;

public class hs
  extends hn
{
  private static final int nO = 17;
  private static final int nN = 34;
  private static final int nV = 511;
  private static final int nW = -1;
  private static final long nP = 4294967295L;
  
  hs(gk paramgk)
  {
    super(paramgk);
  }
  
  hs(gk paramgk, id paramid)
  {
    super(paramgk, paramid);
  }
  
  public void l(id paramid)
  {
    int[] arrayOfInt1 = paramid.cM();
    int i = paramid.cJ();
    if (i <= 17)
    {
      if (i < 17) {
        return;
      }
      if ((arrayOfInt1[16] & 0xFFFFFFFF) < 511L) {
        return;
      }
      if (arrayOfInt1[16] == 511)
      {
        for (int j = 15; j > 0; j--) {
          if (arrayOfInt1[j] != -1) {
            return;
          }
        }
        paramid.setValue(0);
        return;
      }
    }
    int[] arrayOfInt2 = new int[34];
    System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, i);
    int[] arrayOfInt3 = new int[17];
    arrayOfInt3[0] = (arrayOfInt2[16] >>> 9 | arrayOfInt2[17] << 23);
    arrayOfInt3[1] = (arrayOfInt2[17] >>> 9 | arrayOfInt2[18] << 23);
    arrayOfInt3[2] = (arrayOfInt2[18] >>> 9 | arrayOfInt2[19] << 23);
    arrayOfInt3[3] = (arrayOfInt2[19] >>> 9 | arrayOfInt2[20] << 23);
    arrayOfInt3[4] = (arrayOfInt2[20] >>> 9 | arrayOfInt2[21] << 23);
    arrayOfInt3[5] = (arrayOfInt2[21] >>> 9 | arrayOfInt2[22] << 23);
    arrayOfInt3[6] = (arrayOfInt2[22] >>> 9 | arrayOfInt2[23] << 23);
    arrayOfInt3[7] = (arrayOfInt2[23] >>> 9 | arrayOfInt2[24] << 23);
    arrayOfInt3[8] = (arrayOfInt2[24] >>> 9 | arrayOfInt2[25] << 23);
    arrayOfInt3[9] = (arrayOfInt2[25] >>> 9 | arrayOfInt2[26] << 23);
    arrayOfInt3[10] = (arrayOfInt2[26] >>> 9 | arrayOfInt2[27] << 23);
    arrayOfInt3[11] = (arrayOfInt2[27] >>> 9 | arrayOfInt2[28] << 23);
    arrayOfInt3[12] = (arrayOfInt2[28] >>> 9 | arrayOfInt2[29] << 23);
    arrayOfInt3[13] = (arrayOfInt2[29] >>> 9 | arrayOfInt2[30] << 23);
    arrayOfInt3[14] = (arrayOfInt2[30] >>> 9 | arrayOfInt2[31] << 23);
    arrayOfInt3[15] = (arrayOfInt2[31] >>> 9 | arrayOfInt2[32] << 23);
    arrayOfInt3[16] = (arrayOfInt2[32] >>> 9);
    arrayOfInt2[16] &= 0x1FF;
    i = 17;
    ih.b(arrayOfInt2, i, arrayOfInt3, i, arrayOfInt2);
    int k;
    if ((arrayOfInt2[16] & 0xFFFFFFFF) > 511L)
    {
      arrayOfInt2[16] &= 0x1FF;
      for (k = 0;; k++) {
        if (arrayOfInt2[k] += 1 != 0) {
          break;
        }
      }
    }
    if (arrayOfInt2[16] == 511)
    {
      for (k = 15; k >= 0; k--) {
        if (arrayOfInt2[k] != -1)
        {
          paramid.a(arrayOfInt2, i);
          return;
        }
      }
      paramid.setValue(0);
      return;
    }
    paramid.a(arrayOfInt2, i);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.hs
 * JD-Core Version:    0.7.0.1
 */