package com.rsa.jcm.f;

import com.rsa.crypto.BigNum;
import com.rsa.crypto.DHPrivateKey;
import com.rsa.crypto.DSAPrivateKey;
import com.rsa.crypto.PQGParams;

public class fb
  extends cl
  implements DHPrivateKey, DSAPrivateKey
{
  private final BigNum kc;
  private PQGParams kd;
  private String ke;
  
  public fb(ke paramke, BigNum paramBigNum, PQGParams paramPQGParams, String paramString)
  {
    super(paramke);
    this.kc = paramBigNum;
    this.kd = paramPQGParams;
    this.ke = paramString;
  }
  
  public fb(ke paramke, byte[] paramArrayOfByte, PQGParams paramPQGParams, String paramString)
  {
    this(paramke, new id(paramArrayOfByte), paramPQGParams, paramString);
  }
  
  public BigNum getX()
  {
    return this.kc;
  }
  
  public PQGParams getParams()
  {
    return this.kd;
  }
  
  public boolean isValid()
  {
    return ft.b(this);
  }
  
  public void clearSensitiveData()
  {
    er.a((id)this.kc);
    this.kd = null;
  }
  
  public String getAlg()
  {
    return this.ke;
  }
  
  public Object clone()
  {
    return new fb(this.an, (id)es.a((id)this.kc), this.kd, this.ke);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.fb
 * JD-Core Version:    0.7.0.1
 */