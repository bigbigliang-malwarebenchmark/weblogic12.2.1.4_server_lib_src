package com.rsa.jcm.f;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public final class df
{
  public static final int ib = 0;
  public static final int ic = 1;
  public static final short id = 1;
  private final List ie;
  
  public df(List paramList)
  {
    this.ie = new ArrayList(paramList);
  }
  
  public short ar()
  {
    return 1;
  }
  
  public List as()
  {
    return this.ie;
  }
  
  public de at()
  {
    return (de)this.ie.get(0);
  }
  
  public de au()
  {
    return (de)this.ie.get(1);
  }
  
  public void b(File paramFile)
  {
    dd.a(this, paramFile);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.df
 * JD-Core Version:    0.7.0.1
 */