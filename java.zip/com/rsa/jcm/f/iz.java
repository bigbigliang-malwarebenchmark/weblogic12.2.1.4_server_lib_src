package com.rsa.jcm.f;

import com.rsa.crypto.AlgorithmParams;
import com.rsa.crypto.InvalidAlgorithmParameterException;
import com.rsa.crypto.KeyGenerator;
import com.rsa.crypto.SecretKey;
import com.rsa.crypto.SecureRandom;

public abstract class iz
  extends cl
  implements KeyGenerator
{
  private static final int pW = 64;
  private static final int pX = 192;
  private static final int pY = 128;
  private static final int pZ = 192;
  private static final int qa = 8;
  SecureRandom j;
  String fB;
  
  public iz(ke paramke, String paramString)
  {
    super(paramke);
    this.fB = paramString;
  }
  
  public void clearSensitiveData()
  {
    this.fB = null;
    this.j = null;
  }
  
  public SecretKey generate(int paramInt, SecureRandom paramSecureRandom)
  {
    this.j = paramSecureRandom;
    if (!ai(paramInt)) {
      throw new InvalidAlgorithmParameterException("Invalid keySize " + paramInt + " bits for " + this.fB);
    }
    return ah(paramInt);
  }
  
  protected SecretKey ah(int paramInt)
  {
    int i = (paramInt + 7) / 8;
    byte[] arrayOfByte = new byte[i];
    this.j.nextBytes(arrayOfByte);
    return new di(this.an, arrayOfByte, 0, arrayOfByte.length, this.fB);
  }
  
  protected abstract boolean ai(int paramInt);
  
  void C(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    for (int i = 0; i < paramInt2; i++)
    {
      int k = paramArrayOfByte[(i + paramInt1)];
      int m = 1;
      for (int n = 0; n < 7; n++)
      {
        k = (byte)(k >>> 1);
        m = (byte)(m ^ k);
      }
      m = (byte)(m & 0x1);
      int tmp63_62 = (i + paramInt1);
      byte[] tmp63_58 = paramArrayOfByte;
      tmp63_58[tmp63_62] = ((byte)(tmp63_58[tmp63_62] & 0xFFFFFFFE));
      int tmp75_74 = (i + paramInt1);
      byte[] tmp75_70 = paramArrayOfByte;
      tmp75_70[tmp75_74] = ((byte)(tmp75_70[tmp75_74] | m));
    }
  }
  
  public void initialize(AlgorithmParams paramAlgorithmParams)
    throws InvalidAlgorithmParameterException
  {
    throw new UnsupportedOperationException();
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.iz
 * JD-Core Version:    0.7.0.1
 */