package com.rsa.jcm.f;

class gs
  implements gf
{
  final hc mR;
  
  gs(hc paramhc)
  {
    this.mR = paramhc;
  }
  
  public boolean b(gi paramgi)
  {
    if (paramgi.isInfinite()) {
      return false;
    }
    gl localgl1 = paramgi.aS().bb().bG();
    gl localgl2 = paramgi.aS().bb().bH();
    gl localgl3 = paramgi.br();
    gl localgl4 = paramgi.bs();
    if ((!localgl3.isValid()) || (!localgl4.isValid())) {
      return false;
    }
    gl localgl5 = null;
    gl localgl6 = null;
    gl localgl7 = null;
    gl localgl8 = null;
    gl localgl9 = null;
    gl localgl10 = null;
    gl localgl11 = null;
    gl localgl12 = null;
    try
    {
      localgl5 = localgl4.bT();
      localgl6 = localgl3.c(localgl4);
      localgl7 = localgl5.a(localgl6);
      localgl8 = localgl3.bT();
      localgl9 = localgl8.c(localgl3);
      localgl10 = localgl1.c(localgl8);
      localgl11 = localgl9.a(localgl10);
      localgl12 = localgl11.a(localgl2);
      boolean bool = localgl7.equals(localgl12);
      return bool;
    }
    finally
    {
      er.a(localgl5);
      er.a(localgl6);
      er.a(localgl7);
      er.a(localgl8);
      er.a(localgl9);
      er.a(localgl10);
      er.a(localgl11);
      er.a(localgl12);
    }
  }
  
  public boolean a(gi paramgi, boolean paramBoolean)
  {
    if (paramgi.isInfinite()) {
      return true;
    }
    if (!paramgi.bw()) {
      return false;
    }
    if ((paramBoolean) && (paramgi.aS().getCofactor() == 1)) {
      return true;
    }
    gi localgi = paramgi.bB();
    boolean bool = localgi.isInfinite();
    er.a(localgi);
    return bool;
  }
  
  public gi a(gi paramgi1, gi paramgi2)
  {
    if (paramgi1.isInfinite()) {
      return (gi)paramgi2.clone();
    }
    if (paramgi2.isInfinite()) {
      return (gi)paramgi1.clone();
    }
    gl localgl1 = paramgi1.br();
    gl localgl2 = paramgi1.bs();
    gl localgl3 = paramgi2.br();
    gl localgl4 = paramgi2.bs();
    gl localgl5 = paramgi1.aS().bb().bG();
    if (localgl1.equals(localgl3))
    {
      if (localgl2.equals(localgl4)) {
        return c(paramgi1);
      }
      return this.mR.b(paramgi1.aS()).bk();
    }
    gl localgl6 = null;
    gl localgl7 = null;
    gl localgl8 = null;
    gl localgl9 = null;
    gl localgl10 = null;
    gl localgl11 = null;
    gl localgl12 = null;
    gl localgl13 = null;
    gl localgl14 = null;
    try
    {
      localgl6 = localgl1.a(localgl3);
      localgl7 = localgl2.a(localgl4);
      localgl8 = localgl7.d(localgl6);
      localgl12 = localgl8.bT();
      localgl9 = localgl12.a(localgl8);
      localgl10 = localgl9.a(localgl1);
      localgl11 = localgl10.a(localgl3);
      gl localgl15 = localgl11.a(localgl5);
      localgl13 = localgl1.a(localgl15);
      localgl14 = localgl8.c(localgl13);
      gl localgl16 = localgl14.a(localgl15).a(localgl2);
      gi localgi = this.mR.b(paramgi1.aS()).a(localgl15, localgl16);
      return localgi;
    }
    finally
    {
      er.a(localgl6);
      er.a(localgl7);
      er.a(localgl8);
      er.a(localgl9);
      er.a(localgl10);
      er.a(localgl11);
      er.a(localgl12);
      er.a(localgl13);
      er.a(localgl14);
    }
  }
  
  public gi c(gi paramgi)
  {
    if (paramgi.isInfinite()) {
      return (gi)paramgi.clone();
    }
    if (paramgi.bm().isZero()) {
      return this.mR.b(paramgi.aS()).bk();
    }
    gl localgl1 = paramgi.br();
    gl localgl2 = paramgi.bs();
    gl localgl3 = paramgi.aS().bb().bG();
    gl localgl4 = null;
    gl localgl5 = null;
    gl localgl6 = null;
    gl localgl7 = null;
    gl localgl8 = null;
    gl localgl9 = null;
    gl localgl10 = null;
    try
    {
      localgl4 = localgl2.d(localgl1);
      localgl5 = localgl4.a(localgl1);
      localgl6 = localgl5.bT();
      localgl7 = localgl6.a(localgl5);
      gl localgl11 = localgl7.a(localgl3);
      localgl8 = localgl1.bT();
      localgl9 = localgl5.c(localgl11);
      localgl9 = localgl5.c(localgl11);
      localgl10 = localgl8.a(localgl9);
      gl localgl12 = localgl10.a(localgl11);
      gi localgi = this.mR.b(paramgi.aS()).a(localgl11, localgl12);
      return localgi;
    }
    finally
    {
      er.a(localgl4);
      er.a(localgl5);
      er.a(localgl6);
      er.a(localgl7);
      er.a(localgl8);
      er.a(localgl9);
      er.a(localgl10);
    }
  }
  
  public gi d(gi paramgi)
  {
    return this.mR.b(paramgi.aS()).a(paramgi.bm(), paramgi.br().a(paramgi.bs()));
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.gs
 * JD-Core Version:    0.7.0.1
 */