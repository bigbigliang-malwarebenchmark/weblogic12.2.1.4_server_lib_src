package com.rsa.jcm.f;

public abstract interface et
{
  public static final String jF = "Algorithm does not accept parameters.";
  public static final String jG = "Algorithm parameters required.";
  public static final String g = "Object has not been initialized.";
  public static final String jH = "Parameters object invalid for algorithm.";
  public static final String jI = "Key invalid for algorithm.";
  public static final String jJ = "Expected public key of type ";
  public static final String jK = "Expected private key of type ";
  public static final String jL = "Expected public key of type EC.";
  public static final String jM = "Expected private key of type EC.";
  public static final String jN = "Expected public key of type RSA.";
  public static final String jO = "Expected private key of type RSA.";
  public static final String jP = "Invalid key length.";
  public static final String jQ = "Invalid algorithm specified.";
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.et
 * JD-Core Version:    0.7.0.1
 */