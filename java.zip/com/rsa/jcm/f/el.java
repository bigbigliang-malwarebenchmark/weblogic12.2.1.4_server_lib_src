package com.rsa.jcm.f;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class el
{
  private do jp;
  private dn jq;
  private dc jr;
  private String js;
  
  public el(dn paramdn, do paramdo, dc paramdc)
  {
    this.jp = paramdo;
    this.jq = paramdn;
    this.jr = paramdc;
  }
  
  public String aO()
  {
    return this.js;
  }
  
  public boolean aP()
  {
    List localList = this.jp.a(this.jq, true);
    ds localds = new ds(0, "On-Demand Self-Test");
    ExecutorService localExecutorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() + 1);
    try
    {
      boolean bool = a(localList, localds, localExecutorService);
      return bool;
    }
    finally
    {
      localExecutorService.shutdown();
      dt.b(localds);
    }
  }
  
  public boolean a(ExecutorService paramExecutorService)
  {
    ds localds = new ds(0, "Power-Up");
    boolean bool1 = (this.jr == null) || (this.jr.an());
    List localList = this.jp.a(this.jq, bool1);
    ExecutorService localExecutorService = paramExecutorService;
    if (localExecutorService == null) {
      localExecutorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() + 1);
    }
    try
    {
      boolean bool2 = a(localList, localds, localExecutorService);
      if ((bool2) && (this.jr != null) && (bool1)) {
        this.jr.am();
      }
      boolean bool3 = bool2;
      return bool3;
    }
    finally
    {
      if (paramExecutorService == null) {
        localExecutorService.shutdown();
      }
      dt.b(localds);
    }
  }
  
  private boolean a(List<dr> paramList, ds paramds, ExecutorService paramExecutorService)
  {
    dt.a(paramds);
    try
    {
      List localList = paramExecutorService.invokeAll(Collections.unmodifiableList(paramList));
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        Future localFuture = (Future)localIterator.next();
        dr localdr = (dr)localFuture.get();
        if (!localdr.aC())
        {
          this.js = localdr.getName();
          dt.d(paramds);
          return false;
        }
        paramList.remove(localdr);
      }
      if (!paramList.isEmpty())
      {
        this.js = (paramList.size() + " self-tests did not run.");
        dt.d(paramds);
        return false;
      }
      dt.c(paramds);
      return true;
    }
    catch (Exception localException)
    {
      dt.d(paramds);
      this.js = localException.getMessage();
    }
    return false;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.jcm.f.el
 * JD-Core Version:    0.7.0.1
 */