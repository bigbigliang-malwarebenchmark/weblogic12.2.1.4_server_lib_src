package com.rsa.ssl;

/**
 * @deprecated
 */
public final class FIPS140Role
{
  /**
   * @deprecated
   */
  public static final FIPS140Role CRYPTO_OFFICER_ROLE = new FIPS140Role("CRYPTO_OFFICER", 10);
  /**
   * @deprecated
   */
  public static final FIPS140Role USER_ROLE = new FIPS140Role("USER", 11);
  private int role;
  private String name;
  
  private FIPS140Role(String paramString, int paramInt)
  {
    this.name = paramString;
    this.role = paramInt;
  }
  
  /**
   * @deprecated
   */
  public String getName()
  {
    return this.name;
  }
  
  /**
   * @deprecated
   */
  public int getValue()
  {
    return this.role;
  }
  
  /**
   * @deprecated
   */
  public String toString()
  {
    return this.name;
  }
  
  /**
   * @deprecated
   */
  public static FIPS140Role lookup(int paramInt)
  {
    return paramInt == CRYPTO_OFFICER_ROLE.role ? CRYPTO_OFFICER_ROLE : USER_ROLE;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.FIPS140Role
 * JD-Core Version:    0.7.0.1
 */