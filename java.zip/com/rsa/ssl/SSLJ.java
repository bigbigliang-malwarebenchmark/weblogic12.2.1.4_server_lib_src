package com.rsa.ssl;

import com.rsa.jsafe.crypto.JSAFE_InvalidUseException;

/**
 * @deprecated
 */
public final class SSLJ
{
  /**
   * @deprecated
   */
  public static int getMode()
  {
    return com.rsa.jsafe.crypto.CryptoJ.getMode();
  }
  
  /**
   * @deprecated
   */
  public static int getRole()
  {
    return com.rsa.jsafe.crypto.CryptoJ.getRole();
  }
  
  /**
   * @deprecated
   */
  public static int getState()
  {
    return com.rsa.jsafe.crypto.CryptoJ.getState();
  }
  
  /**
   * @deprecated
   */
  public static boolean runSelfTests()
    throws SSLException
  {
    try
    {
      return com.rsa.jsafe.crypto.CryptoJ.runSelfTests();
    }
    catch (JSAFE_InvalidUseException localJSAFE_InvalidUseException)
    {
      throw new SSLException(localJSAFE_InvalidUseException.getMessage());
    }
  }
  
  /**
   * @deprecated
   */
  public static boolean selfTestPassed()
  {
    return com.rsa.jsafe.crypto.CryptoJ.selfTestPassed();
  }
  
  /**
   * @deprecated
   */
  public static void setMode(int paramInt)
    throws SSLException
  {
    try
    {
      com.rsa.jsafe.CryptoJ.setMode(paramInt);
      com.rsa.jsafe.crypto.CryptoJ.setMode(paramInt);
    }
    catch (Exception localException)
    {
      throw new SSLException(localException.getMessage());
    }
  }
  
  /**
   * @deprecated
   */
  public static void setRole(int paramInt)
    throws SSLException
  {
    try
    {
      com.rsa.jsafe.crypto.CryptoJ.setRole(paramInt);
      com.rsa.jsafe.CryptoJ.setRole(paramInt);
    }
    catch (Exception localException)
    {
      throw new SSLException(localException.getMessage());
    }
  }
  
  /**
   * @deprecated
   */
  public static boolean isFIPS140Compliant()
  {
    return SSLJVersion.isFIPS140Compliant();
  }
  
  /**
   * @deprecated
   */
  public static void verifyToolkits()
    throws SSLException
  {
    try
    {
      SSLJVersion.isFIPS140Compliant();
    }
    catch (Throwable localThrowable)
    {
      throw new SSLException(localThrowable);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.SSLJ
 * JD-Core Version:    0.7.0.1
 */