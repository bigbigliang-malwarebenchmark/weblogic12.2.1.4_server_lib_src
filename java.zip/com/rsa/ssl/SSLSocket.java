package com.rsa.ssl;

import com.rsa.sslj.x.aR;
import com.rsa.sslj.x.aT;
import com.rsa.sslj.x.cC;
import com.rsa.sslj.x.cE;
import com.rsa.sslj.x.cF;
import com.rsa.sslj.x.cJ;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.channels.SocketChannel;
import java.security.cert.CertificateException;
import javax.net.ssl.SSLPeerUnverifiedException;

/**
 * @deprecated
 */
public final class SSLSocket
  extends Socket
{
  /**
   * @deprecated
   */
  public static final int HTTPS = 443;
  /**
   * @deprecated
   */
  public static final int SSMTP = 465;
  /**
   * @deprecated
   */
  public static final int SNNTP = 563;
  private SSLParams params;
  private aT delegate;
  private boolean handshakeDone;
  
  /**
   * @deprecated
   */
  public SSLSocket(String paramString, int paramInt, SSLParams paramSSLParams)
    throws IOException, UnknownHostException
  {
    this.params = paramSSLParams;
    this.delegate = cE.a(paramString, paramInt, paramSSLParams.sslParamsDelegate);
  }
  
  /**
   * @deprecated
   */
  public SSLSocket(InetAddress paramInetAddress, int paramInt, SSLParams paramSSLParams)
    throws IOException
  {
    this.params = paramSSLParams;
    this.delegate = cE.a(paramInetAddress, paramInt, paramSSLParams.sslParamsDelegate);
  }
  
  /**
   * @deprecated
   */
  public SSLSocket(Socket paramSocket, SSLParams paramSSLParams)
    throws SSLException
  {
    this.params = paramSSLParams;
    try
    {
      this.delegate = cE.a(paramSocket, paramSSLParams.sslParamsDelegate);
    }
    catch (IOException localIOException)
    {
      throw new SSLException(localIOException);
    }
  }
  
  /**
   * @deprecated
   */
  SSLSocket(aT paramaT, SSLParams paramSSLParams)
  {
    this.params = paramSSLParams;
    this.delegate = paramaT;
    paramaT.a(paramSSLParams.sslParamsDelegate.l);
  }
  
  /**
   * @deprecated
   */
  public SSLSocket(Socket paramSocket, SSLParams paramSSLParams, boolean paramBoolean)
    throws SSLException
  {
    this.params = paramSSLParams;
    try
    {
      this.delegate = cE.a(paramSocket, paramSSLParams.sslParamsDelegate, paramBoolean);
    }
    catch (IOException localIOException)
    {
      throw new SSLException(localIOException);
    }
  }
  
  /**
   * @deprecated
   */
  public InputStream getInputStream()
    throws IOException
  {
    if (!this.handshakeDone)
    {
      this.handshakeDone = true;
      this.delegate.startHandshake();
    }
    return this.delegate.getInputStream();
  }
  
  /**
   * @deprecated
   */
  public OutputStream getOutputStream()
    throws IOException
  {
    if (!this.handshakeDone)
    {
      this.handshakeDone = true;
      this.delegate.startHandshake();
    }
    if (this.params.getBuffered()) {
      return new BufferedOutputStream(this.delegate.getOutputStream());
    }
    return this.delegate.getOutputStream();
  }
  
  /**
   * @deprecated
   */
  public CipherSuite getCipherSuite()
  {
    if (this.delegate == null) {
      return null;
    }
    this.handshakeDone = true;
    String str = this.delegate.a().getCipherSuite();
    if (str.equals("SSL_NULL_WITH_NULL_NULL")) {
      return null;
    }
    return CipherSuiteLists.getCipherSuite(str);
  }
  
  /**
   * @deprecated
   */
  public SSLSession getSession()
  {
    this.handshakeDone = true;
    return cF.a((aR)this.delegate.a(), this.delegate.getUseClientMode(), this.params);
  }
  
  /**
   * @deprecated
   */
  public CompressionMethod getCompression()
  {
    return null;
  }
  
  /**
   * @deprecated
   */
  public com.rsa.certj.cert.X509Certificate[] getPeerCertificateChain()
  {
    try
    {
      return cJ.a((java.security.cert.X509Certificate[])this.delegate.a().getPeerCertificates());
    }
    catch (SSLPeerUnverifiedException localSSLPeerUnverifiedException)
    {
      return null;
    }
    catch (CertificateException localCertificateException)
    {
      throw new RuntimeException(localCertificateException);
    }
  }
  
  /**
   * @deprecated
   */
  public void renegotiate(SSLParams paramSSLParams)
    throws SSLException, AlertedException
  {
    this.params = paramSSLParams;
    try
    {
      cE.a(this.delegate, this.params.sslParamsDelegate);
      this.delegate.startHandshake();
      this.handshakeDone = true;
    }
    catch (IOException localIOException)
    {
      throw new SSLException(localIOException.getMessage());
    }
  }
  
  /**
   * @deprecated
   */
  public void close()
    throws IOException
  {
    this.delegate.close();
    this.handshakeDone = false;
  }
  
  /**
   * @deprecated
   */
  public void shutdownInput()
    throws IOException
  {}
  
  /**
   * @deprecated
   */
  public void shutdownOutput()
    throws IOException
  {}
  
  /**
   * @deprecated
   */
  public void bind(SocketAddress paramSocketAddress)
    throws IOException
  {
    this.delegate.bind(paramSocketAddress);
  }
  
  /**
   * @deprecated
   */
  public void connect(SocketAddress paramSocketAddress, int paramInt)
    throws IOException
  {
    this.delegate.connect(paramSocketAddress, paramInt);
  }
  
  /**
   * @deprecated
   */
  public void connect(SocketAddress paramSocketAddress)
    throws IOException
  {
    this.delegate.connect(paramSocketAddress);
  }
  
  /**
   * @deprecated
   */
  public SocketChannel getChannel()
  {
    return this.delegate.getChannel();
  }
  
  /**
   * @deprecated
   */
  public InetAddress getInetAddress()
  {
    return this.delegate.getInetAddress();
  }
  
  /**
   * @deprecated
   */
  public boolean getKeepAlive()
    throws SocketException
  {
    return this.delegate.getKeepAlive();
  }
  
  /**
   * @deprecated
   */
  public InetAddress getLocalAddress()
  {
    return this.delegate.getLocalAddress();
  }
  
  /**
   * @deprecated
   */
  public int getLocalPort()
  {
    return this.delegate.getLocalPort();
  }
  
  /**
   * @deprecated
   */
  public SocketAddress getLocalSocketAddress()
  {
    return this.delegate.getLocalSocketAddress();
  }
  
  /**
   * @deprecated
   */
  public boolean getOOBInline()
    throws SocketException
  {
    return this.delegate.getOOBInline();
  }
  
  /**
   * @deprecated
   */
  public int getPort()
  {
    return this.delegate.getPort();
  }
  
  /**
   * @deprecated
   */
  public synchronized int getReceiveBufferSize()
    throws SocketException
  {
    return this.delegate.getReceiveBufferSize();
  }
  
  /**
   * @deprecated
   */
  public SocketAddress getRemoteSocketAddress()
  {
    return this.delegate.getRemoteSocketAddress();
  }
  
  /**
   * @deprecated
   */
  public boolean getReuseAddress()
    throws SocketException
  {
    return this.delegate.getReuseAddress();
  }
  
  /**
   * @deprecated
   */
  public synchronized int getSendBufferSize()
    throws SocketException
  {
    return this.delegate.getSendBufferSize();
  }
  
  /**
   * @deprecated
   */
  public int getSoLinger()
    throws SocketException
  {
    return this.delegate.getSoLinger();
  }
  
  /**
   * @deprecated
   */
  public synchronized int getSoTimeout()
    throws SocketException
  {
    return this.delegate.getSoTimeout();
  }
  
  /**
   * @deprecated
   */
  public boolean getTcpNoDelay()
    throws SocketException
  {
    return this.delegate.getTcpNoDelay();
  }
  
  /**
   * @deprecated
   */
  public int getTrafficClass()
    throws SocketException
  {
    return this.delegate.getTrafficClass();
  }
  
  /**
   * @deprecated
   */
  public boolean isBound()
  {
    return this.delegate.isBound();
  }
  
  /**
   * @deprecated
   */
  public boolean isClosed()
  {
    return this.delegate.isClosed();
  }
  
  /**
   * @deprecated
   */
  public boolean isConnected()
  {
    return this.delegate.isConnected();
  }
  
  /**
   * @deprecated
   */
  public boolean isInputShutdown()
  {
    return this.delegate.isInputShutdown();
  }
  
  /**
   * @deprecated
   */
  public boolean isOutputShutdown()
  {
    return this.delegate.isOutputShutdown();
  }
  
  /**
   * @deprecated
   */
  public void sendUrgentData(int paramInt)
    throws IOException
  {
    this.delegate.sendUrgentData(paramInt);
  }
  
  /**
   * @deprecated
   */
  public void setKeepAlive(boolean paramBoolean)
    throws SocketException
  {
    this.delegate.setKeepAlive(paramBoolean);
  }
  
  /**
   * @deprecated
   */
  public void setOOBInline(boolean paramBoolean)
    throws SocketException
  {
    this.delegate.setOOBInline(paramBoolean);
  }
  
  /**
   * @deprecated
   */
  public void setPerformancePreferences(int paramInt1, int paramInt2, int paramInt3)
  {
    this.delegate.setPerformancePreferences(paramInt1, paramInt2, paramInt3);
  }
  
  /**
   * @deprecated
   */
  public synchronized void setReceiveBufferSize(int paramInt)
    throws SocketException
  {
    this.delegate.setReceiveBufferSize(paramInt);
  }
  
  /**
   * @deprecated
   */
  public void setReuseAddress(boolean paramBoolean)
    throws SocketException
  {
    this.delegate.setReuseAddress(paramBoolean);
  }
  
  /**
   * @deprecated
   */
  public synchronized void setSendBufferSize(int paramInt)
    throws SocketException
  {
    this.delegate.setSendBufferSize(paramInt);
  }
  
  /**
   * @deprecated
   */
  public void setSoLinger(boolean paramBoolean, int paramInt)
    throws SocketException
  {
    this.delegate.setSoLinger(paramBoolean, paramInt);
  }
  
  /**
   * @deprecated
   */
  public synchronized void setSoTimeout(int paramInt)
    throws SocketException
  {
    this.delegate.setSoTimeout(paramInt);
  }
  
  /**
   * @deprecated
   */
  public void setTcpNoDelay(boolean paramBoolean)
    throws SocketException
  {
    this.delegate.setTcpNoDelay(paramBoolean);
  }
  
  /**
   * @deprecated
   */
  public void setTrafficClass(int paramInt)
    throws SocketException
  {
    this.delegate.setTrafficClass(paramInt);
  }
  
  /**
   * @deprecated
   */
  public String toString()
  {
    return this.delegate.toString();
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.SSLSocket
 * JD-Core Version:    0.7.0.1
 */