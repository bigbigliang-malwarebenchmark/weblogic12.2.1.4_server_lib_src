package com.rsa.ssl;

/**
 * @deprecated
 */
public final class SuiteBMode
{
  private SuiteBMode.SecurityLevel securityLevel;
  private SuiteBMode.EnforcementLevel enforcementLevel;
  private int lookup;
  private static final SuiteBMode[] LOOKUP = new SuiteBMode[4];
  /**
   * @deprecated
   */
  public static final SuiteBMode SUITEB_MODE = new SuiteBMode(SuiteBMode.SecurityLevel.LEVEL_192_AND_128, SuiteBMode.EnforcementLevel.STRICT, 0);
  /**
   * @deprecated
   */
  public static final SuiteBMode NON_SUITEB_MODE = new SuiteBMode(SuiteBMode.SecurityLevel.NONE, SuiteBMode.EnforcementLevel.PREFERRED, 1);
  /**
   * @deprecated
   */
  public static final SuiteBMode SUITEB_MODE_128 = new SuiteBMode(SuiteBMode.SecurityLevel.LEVEL_128, SuiteBMode.EnforcementLevel.STRICT, 2);
  /**
   * @deprecated
   */
  public static final SuiteBMode SUITEB_MODE_192 = new SuiteBMode(SuiteBMode.SecurityLevel.LEVEL_192, SuiteBMode.EnforcementLevel.STRICT, 3);
  
  private SuiteBMode(SuiteBMode.SecurityLevel paramSecurityLevel, SuiteBMode.EnforcementLevel paramEnforcementLevel, int paramInt)
  {
    if (paramInt != -1)
    {
      LOOKUP[paramInt] = this;
      this.lookup = paramInt;
    }
    if ((paramSecurityLevel == null) || (paramEnforcementLevel == null)) {
      throw new IllegalArgumentException("Suite B securityLevel or enforcementLevel have not been specified");
    }
    this.enforcementLevel = paramEnforcementLevel;
    this.securityLevel = paramSecurityLevel;
  }
  
  /**
   * @deprecated
   */
  public SuiteBMode(SuiteBMode.SecurityLevel paramSecurityLevel, SuiteBMode.EnforcementLevel paramEnforcementLevel)
  {
    this(paramSecurityLevel, paramEnforcementLevel, -1);
  }
  
  /**
   * @deprecated
   */
  public String getName()
  {
    return toString();
  }
  
  /**
   * @deprecated
   */
  public int getValue()
  {
    return this.lookup;
  }
  
  /**
   * @deprecated
   */
  public String toString()
  {
    return this.securityLevel + "/" + this.enforcementLevel.toString();
  }
  
  /**
   * @deprecated
   */
  public static boolean isSuiteBMode(SuiteBMode paramSuiteBMode)
  {
    return (paramSuiteBMode != null) && (paramSuiteBMode.enforcementLevel == SuiteBMode.EnforcementLevel.STRICT) && (paramSuiteBMode.securityLevel != SuiteBMode.SecurityLevel.NONE);
  }
  
  /**
   * @deprecated
   */
  public static SuiteBMode lookup(int paramInt)
  {
    if ((paramInt >= 0) || (paramInt <= 3)) {
      return LOOKUP[paramInt];
    }
    throw new IllegalArgumentException("This value is not representing one of the public static SuiteBModes : " + paramInt);
  }
  
  /**
   * @deprecated
   */
  public SuiteBMode.SecurityLevel getSecurityLevel()
  {
    return this.securityLevel;
  }
  
  /**
   * @deprecated
   */
  public SuiteBMode.EnforcementLevel getEnforcementLevel()
  {
    return this.enforcementLevel;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.SuiteBMode
 * JD-Core Version:    0.7.0.1
 */