package com.rsa.ssl;

import com.rsa.jsse.FIPS140Mode;
import com.rsa.jsse.SuiteBMode;
import com.rsa.jsse.engine.util.c;
import com.rsa.jsse.engine.util.f;
import com.rsa.ssl.ciphers.DHE_DSS_With_3DES_EDE_CBC_SHA;
import com.rsa.ssl.ciphers.DHE_DSS_With_AES_128_CBC_SHA;
import com.rsa.ssl.ciphers.DHE_DSS_With_AES_128_CBC_SHA256;
import com.rsa.ssl.ciphers.DHE_DSS_With_AES_128_GCM_SHA256;
import com.rsa.ssl.ciphers.DHE_DSS_With_AES_256_CBC_SHA;
import com.rsa.ssl.ciphers.DHE_DSS_With_AES_256_CBC_SHA256;
import com.rsa.ssl.ciphers.DHE_DSS_With_AES_256_GCM_SHA384;
import com.rsa.ssl.ciphers.DHE_DSS_With_DES_CBC_SHA;
import com.rsa.ssl.ciphers.DHE_RSA_With_3DES_EDE_CBC_SHA;
import com.rsa.ssl.ciphers.DHE_RSA_With_AES_128_CBC_SHA;
import com.rsa.ssl.ciphers.DHE_RSA_With_AES_128_CBC_SHA256;
import com.rsa.ssl.ciphers.DHE_RSA_With_AES_128_GCM_SHA256;
import com.rsa.ssl.ciphers.DHE_RSA_With_AES_256_CBC_SHA;
import com.rsa.ssl.ciphers.DHE_RSA_With_AES_256_CBC_SHA256;
import com.rsa.ssl.ciphers.DHE_RSA_With_AES_256_GCM_SHA384;
import com.rsa.ssl.ciphers.DHE_RSA_With_DES_CBC_SHA;
import com.rsa.ssl.ciphers.DH_Anon_With_3DES_EDE_CBC_SHA;
import com.rsa.ssl.ciphers.DH_Anon_With_AES_128_CBC_SHA;
import com.rsa.ssl.ciphers.DH_Anon_With_AES_128_CBC_SHA256;
import com.rsa.ssl.ciphers.DH_Anon_With_AES_128_GCM_SHA256;
import com.rsa.ssl.ciphers.DH_Anon_With_AES_256_CBC_SHA;
import com.rsa.ssl.ciphers.DH_Anon_With_AES_256_CBC_SHA256;
import com.rsa.ssl.ciphers.DH_Anon_With_AES_256_GCM_SHA384;
import com.rsa.ssl.ciphers.DH_Anon_With_DES_CBC_SHA;
import com.rsa.ssl.ciphers.DH_Anon_With_RC4_MD5;
import com.rsa.ssl.ciphers.DH_DSS_With_3DES_EDE_CBC_SHA;
import com.rsa.ssl.ciphers.DH_DSS_With_AES_128_CBC_SHA;
import com.rsa.ssl.ciphers.DH_DSS_With_AES_128_CBC_SHA256;
import com.rsa.ssl.ciphers.DH_DSS_With_AES_128_GCM_SHA256;
import com.rsa.ssl.ciphers.DH_DSS_With_AES_256_CBC_SHA;
import com.rsa.ssl.ciphers.DH_DSS_With_AES_256_CBC_SHA256;
import com.rsa.ssl.ciphers.DH_DSS_With_AES_256_GCM_SHA384;
import com.rsa.ssl.ciphers.DH_DSS_With_DES_CBC_SHA;
import com.rsa.ssl.ciphers.DH_RSA_With_3DES_EDE_CBC_SHA;
import com.rsa.ssl.ciphers.DH_RSA_With_AES_128_CBC_SHA;
import com.rsa.ssl.ciphers.DH_RSA_With_AES_128_CBC_SHA256;
import com.rsa.ssl.ciphers.DH_RSA_With_AES_128_GCM_SHA256;
import com.rsa.ssl.ciphers.DH_RSA_With_AES_256_CBC_SHA;
import com.rsa.ssl.ciphers.DH_RSA_With_AES_256_CBC_SHA256;
import com.rsa.ssl.ciphers.DH_RSA_With_AES_256_GCM_SHA384;
import com.rsa.ssl.ciphers.DH_RSA_With_DES_CBC_SHA;
import com.rsa.ssl.ciphers.ECDHE_ECDSA_With_3DES_EDE_CBC_SHA;
import com.rsa.ssl.ciphers.ECDHE_ECDSA_With_AES_128_CBC_SHA;
import com.rsa.ssl.ciphers.ECDHE_ECDSA_With_AES_128_CBC_SHA256;
import com.rsa.ssl.ciphers.ECDHE_ECDSA_With_AES_128_GCM_SHA256;
import com.rsa.ssl.ciphers.ECDHE_ECDSA_With_AES_256_CBC_SHA;
import com.rsa.ssl.ciphers.ECDHE_ECDSA_With_AES_256_CBC_SHA384;
import com.rsa.ssl.ciphers.ECDHE_ECDSA_With_AES_256_GCM_SHA384;
import com.rsa.ssl.ciphers.ECDHE_ECDSA_With_Null_SHA;
import com.rsa.ssl.ciphers.ECDHE_ECDSA_With_RC4_128_SHA;
import com.rsa.ssl.ciphers.ECDHE_RSA_With_3DES_EDE_CBC_SHA;
import com.rsa.ssl.ciphers.ECDHE_RSA_With_AES_128_CBC_SHA;
import com.rsa.ssl.ciphers.ECDHE_RSA_With_AES_128_CBC_SHA256;
import com.rsa.ssl.ciphers.ECDHE_RSA_With_AES_128_GCM_SHA256;
import com.rsa.ssl.ciphers.ECDHE_RSA_With_AES_256_CBC_SHA;
import com.rsa.ssl.ciphers.ECDHE_RSA_With_AES_256_CBC_SHA384;
import com.rsa.ssl.ciphers.ECDHE_RSA_With_AES_256_GCM_SHA384;
import com.rsa.ssl.ciphers.ECDHE_RSA_With_Null_SHA;
import com.rsa.ssl.ciphers.ECDHE_RSA_With_RC4_128_SHA;
import com.rsa.ssl.ciphers.ECDH_Anon_With_3DES_EDE_CBC_SHA;
import com.rsa.ssl.ciphers.ECDH_Anon_With_AES_128_CBC_SHA;
import com.rsa.ssl.ciphers.ECDH_Anon_With_AES_256_CBC_SHA;
import com.rsa.ssl.ciphers.ECDH_Anon_With_Null_SHA;
import com.rsa.ssl.ciphers.ECDH_Anon_With_RC4_128_SHA;
import com.rsa.ssl.ciphers.ECDH_ECDSA_With_3DES_EDE_CBC_SHA;
import com.rsa.ssl.ciphers.ECDH_ECDSA_With_AES_128_CBC_SHA;
import com.rsa.ssl.ciphers.ECDH_ECDSA_With_AES_128_CBC_SHA256;
import com.rsa.ssl.ciphers.ECDH_ECDSA_With_AES_128_GCM_SHA256;
import com.rsa.ssl.ciphers.ECDH_ECDSA_With_AES_256_CBC_SHA;
import com.rsa.ssl.ciphers.ECDH_ECDSA_With_AES_256_CBC_SHA384;
import com.rsa.ssl.ciphers.ECDH_ECDSA_With_AES_256_GCM_SHA384;
import com.rsa.ssl.ciphers.ECDH_ECDSA_With_Null_SHA;
import com.rsa.ssl.ciphers.ECDH_ECDSA_With_RC4_128_SHA;
import com.rsa.ssl.ciphers.ECDH_RSA_With_3DES_EDE_CBC_SHA;
import com.rsa.ssl.ciphers.ECDH_RSA_With_AES_128_CBC_SHA;
import com.rsa.ssl.ciphers.ECDH_RSA_With_AES_128_CBC_SHA256;
import com.rsa.ssl.ciphers.ECDH_RSA_With_AES_128_GCM_SHA256;
import com.rsa.ssl.ciphers.ECDH_RSA_With_AES_256_CBC_SHA;
import com.rsa.ssl.ciphers.ECDH_RSA_With_AES_256_CBC_SHA384;
import com.rsa.ssl.ciphers.ECDH_RSA_With_AES_256_GCM_SHA384;
import com.rsa.ssl.ciphers.ECDH_RSA_With_Null_SHA;
import com.rsa.ssl.ciphers.ECDH_RSA_With_RC4_128_SHA;
import com.rsa.ssl.ciphers.Null_With_Null_Null;
import com.rsa.ssl.ciphers.RSA_With_3DES_EDE_CBC_SHA;
import com.rsa.ssl.ciphers.RSA_With_AES_128_CBC_SHA;
import com.rsa.ssl.ciphers.RSA_With_AES_128_CBC_SHA256;
import com.rsa.ssl.ciphers.RSA_With_AES_128_GCM_SHA256;
import com.rsa.ssl.ciphers.RSA_With_AES_256_CBC_SHA;
import com.rsa.ssl.ciphers.RSA_With_AES_256_CBC_SHA256;
import com.rsa.ssl.ciphers.RSA_With_AES_256_GCM_SHA384;
import com.rsa.ssl.ciphers.RSA_With_DES_CBC_SHA;
import com.rsa.ssl.ciphers.RSA_With_Null_MD5;
import com.rsa.ssl.ciphers.RSA_With_Null_SHA;
import com.rsa.ssl.ciphers.RSA_With_Null_SHA256;
import com.rsa.ssl.ciphers.RSA_With_RC4_MD5;
import com.rsa.ssl.ciphers.RSA_With_RC4_SHA;
import com.rsa.sslj.x.aE;
import com.rsa.sslj.x.as;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * @deprecated
 */
public final class CipherSuiteLists
{
  private static final Map ALL_CIPHERS_MAP = new HashMap(100);
  
  private static void addCipher(CipherSuite paramCipherSuite)
  {
    ALL_CIPHERS_MAP.put(paramCipherSuite.getJsseCipherSuiteName(0), paramCipherSuite);
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] All_Ciphers()
  {
    List localList = Arrays.asList(new Object[] { aE.b, aE.c, aE.d, aE.e });
    String[] arrayOfString = c.a(as.c(localList));
    return jsseNamesToCipherSuites(arrayOfString);
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] Default_Ciphers()
  {
    String[] arrayOfString = c.a(as.a(FIPS140Mode.FIPS140_MODE, SuiteBMode.NON_SUITEB_MODE));
    return jsseNamesToCipherSuites(arrayOfString);
  }
  
  private static CipherSuite[] jsseNamesToCipherSuites(String[] paramArrayOfString)
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < paramArrayOfString.length; i++)
    {
      CipherSuite localCipherSuite = (CipherSuite)ALL_CIPHERS_MAP.get(paramArrayOfString[i]);
      if (localCipherSuite != null) {
        localArrayList.add(localCipherSuite);
      }
    }
    return (CipherSuite[])localArrayList.toArray(new CipherSuite[0]);
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] FIPS_Ciphers()
  {
    String[] arrayOfString = c.a(as.b(FIPS140Mode.FIPS140_MODE, SuiteBMode.NON_SUITEB_MODE));
    return jsseNamesToCipherSuites(arrayOfString);
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] SUITEB_Ciphers()
  {
    return new CipherSuite[] { ECDHE_ECDSA_With_AES_256_GCM_SHA384.INSTANCE, ECDHE_ECDSA_With_AES_256_CBC_SHA384.INSTANCE, ECDHE_ECDSA_With_AES_128_GCM_SHA256.INSTANCE, ECDHE_ECDSA_With_AES_128_CBC_SHA256.INSTANCE };
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] SUITEB_MODE_192_Ciphers()
  {
    return new CipherSuite[] { ECDHE_ECDSA_With_AES_256_GCM_SHA384.INSTANCE, ECDHE_ECDSA_With_AES_256_CBC_SHA384.INSTANCE };
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] SUITEB_MODE_128_Ciphers()
  {
    return new CipherSuite[] { ECDHE_ECDSA_With_AES_128_GCM_SHA256.INSTANCE, ECDHE_ECDSA_With_AES_128_CBC_SHA256.INSTANCE };
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] RSA_With_All()
  {
    return new CipherSuite[] { RSA_With_AES_128_CBC_SHA.INSTANCE, RSA_With_AES_256_CBC_SHA.INSTANCE, RSA_With_3DES_EDE_CBC_SHA.INSTANCE, RSA_With_DES_CBC_SHA.INSTANCE, RSA_With_RC4_MD5.INSTANCE, RSA_With_RC4_SHA.INSTANCE, RSA_With_Null_MD5.INSTANCE, RSA_With_Null_SHA.INSTANCE };
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] RSA_NonExport_With_All()
  {
    return new CipherSuite[] { RSA_With_AES_128_CBC_SHA.INSTANCE, RSA_With_AES_256_CBC_SHA.INSTANCE, RSA_With_3DES_EDE_CBC_SHA.INSTANCE, RSA_With_DES_CBC_SHA.INSTANCE, RSA_With_RC4_MD5.INSTANCE, RSA_With_RC4_SHA.INSTANCE };
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] RSA_With_Null()
  {
    return new CipherSuite[] { RSA_With_Null_MD5.INSTANCE, RSA_With_Null_SHA.INSTANCE };
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] DH_With_All()
  {
    return new CipherSuite[] { DH_RSA_With_AES_128_CBC_SHA.INSTANCE, DH_DSS_With_AES_128_CBC_SHA.INSTANCE, DH_RSA_With_AES_256_CBC_SHA.INSTANCE, DH_DSS_With_AES_256_CBC_SHA.INSTANCE, DH_RSA_With_3DES_EDE_CBC_SHA.INSTANCE, DH_DSS_With_3DES_EDE_CBC_SHA.INSTANCE, DH_RSA_With_DES_CBC_SHA.INSTANCE, DH_DSS_With_DES_CBC_SHA.INSTANCE, DH_Anon_With_AES_128_CBC_SHA.INSTANCE, DH_Anon_With_AES_256_CBC_SHA.INSTANCE, DH_Anon_With_3DES_EDE_CBC_SHA.INSTANCE, DH_Anon_With_DES_CBC_SHA.INSTANCE, DH_Anon_With_RC4_MD5.INSTANCE };
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] DH_NonExport_With_All()
  {
    return new CipherSuite[] { DH_RSA_With_AES_128_CBC_SHA.INSTANCE, DH_DSS_With_AES_128_CBC_SHA.INSTANCE, DH_RSA_With_AES_256_CBC_SHA.INSTANCE, DH_DSS_With_AES_256_CBC_SHA.INSTANCE, DH_RSA_With_3DES_EDE_CBC_SHA.INSTANCE, DH_DSS_With_3DES_EDE_CBC_SHA.INSTANCE, DH_RSA_With_DES_CBC_SHA.INSTANCE, DH_DSS_With_DES_CBC_SHA.INSTANCE, DH_Anon_With_AES_128_CBC_SHA.INSTANCE, DH_Anon_With_AES_256_CBC_SHA.INSTANCE, DH_Anon_With_3DES_EDE_CBC_SHA.INSTANCE, DH_Anon_With_DES_CBC_SHA.INSTANCE, DH_Anon_With_RC4_MD5.INSTANCE };
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] DH_Anon_With_All()
  {
    return new CipherSuite[] { DH_Anon_With_AES_128_CBC_SHA.INSTANCE, DH_Anon_With_AES_256_CBC_SHA.INSTANCE, DH_Anon_With_3DES_EDE_CBC_SHA.INSTANCE, DH_Anon_With_DES_CBC_SHA.INSTANCE, DH_Anon_With_RC4_MD5.INSTANCE };
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] DHE_With_All()
  {
    return new CipherSuite[] { DHE_RSA_With_AES_128_CBC_SHA.INSTANCE, DHE_DSS_With_AES_128_CBC_SHA.INSTANCE, DHE_RSA_With_AES_256_CBC_SHA.INSTANCE, DHE_DSS_With_AES_256_CBC_SHA.INSTANCE, DHE_RSA_With_3DES_EDE_CBC_SHA.INSTANCE, DHE_DSS_With_3DES_EDE_CBC_SHA.INSTANCE, DHE_RSA_With_DES_CBC_SHA.INSTANCE, DHE_DSS_With_DES_CBC_SHA.INSTANCE };
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] All_SSLv2()
  {
    return new CipherSuite[] { new RSA_With_RC4_MD5() };
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] Default_SSLv2()
  {
    return new CipherSuite[] { new RSA_With_RC4_MD5() };
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] All_SSLv3()
  {
    List localList = Arrays.asList(new Object[] { aE.b });
    String[] arrayOfString = c.a(as.c(localList));
    return jsseNamesToCipherSuites(arrayOfString);
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] Default_SSLv3()
  {
    List localList = Arrays.asList(new Object[] { aE.b });
    String[] arrayOfString = c.a(as.a(FIPS140Mode.FIPS140_MODE, SuiteBMode.NON_SUITEB_MODE, localList));
    return jsseNamesToCipherSuites(arrayOfString);
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] All_TLSv1()
  {
    List localList = Arrays.asList(new Object[] { aE.c });
    String[] arrayOfString = c.a(as.c(localList));
    return jsseNamesToCipherSuites(arrayOfString);
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] Default_TLSv1()
  {
    List localList = Arrays.asList(new Object[] { aE.c });
    String[] arrayOfString = c.a(as.a(FIPS140Mode.FIPS140_MODE, SuiteBMode.NON_SUITEB_MODE, localList));
    return jsseNamesToCipherSuites(arrayOfString);
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] All_TLSv1_1()
  {
    List localList = Arrays.asList(new Object[] { aE.d });
    String[] arrayOfString = c.a(as.c(localList));
    return jsseNamesToCipherSuites(arrayOfString);
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] Default_TLSv1_1()
  {
    List localList = Arrays.asList(new Object[] { aE.d });
    String[] arrayOfString = c.a(as.a(FIPS140Mode.FIPS140_MODE, SuiteBMode.NON_SUITEB_MODE, localList));
    return jsseNamesToCipherSuites(arrayOfString);
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] All_TLSv1_2()
  {
    List localList = Arrays.asList(new Object[] { aE.e });
    String[] arrayOfString = c.a(as.c(localList));
    return jsseNamesToCipherSuites(arrayOfString);
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] Default_TLSv1_2()
  {
    List localList = Arrays.asList(new Object[] { aE.c, aE.d, aE.e });
    String[] arrayOfString = c.a(as.a(FIPS140Mode.FIPS140_MODE, SuiteBMode.NON_SUITEB_MODE, localList));
    return jsseNamesToCipherSuites(arrayOfString);
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite[] makeCipherSuiteList(String paramString)
    throws SSLException
  {
    if (paramString.equals("Default_Ciphers")) {
      return Default_Ciphers();
    }
    if (paramString.equals("Default_TLSv1")) {
      return Default_TLSv1();
    }
    if (paramString.equals("Default_TLSv1_1")) {
      return Default_TLSv1_1();
    }
    if (paramString.equals("Default_TLSv1_2")) {
      return Default_TLSv1_2();
    }
    if (paramString.equals("Default_SSLv3")) {
      return Default_SSLv3();
    }
    if (paramString.equals("Default_SSLv2")) {
      return Default_SSLv3();
    }
    if (paramString.equals("All_TLSv1")) {
      return All_TLSv1();
    }
    if (paramString.equals("All_TLSv1_1")) {
      return All_TLSv1_1();
    }
    if (paramString.equals("All_TLSv1_2")) {
      return All_TLSv1_2();
    }
    if (paramString.equals("All_SSLv3")) {
      return All_SSLv3();
    }
    if (paramString.equals("All_SSLv2")) {
      return All_SSLv2();
    }
    if (paramString.equals("All_Ciphers")) {
      return All_Ciphers();
    }
    if (paramString.equals("RSA_With_All")) {
      return RSA_With_All();
    }
    if (paramString.equals("RSA_NonExport_With_All")) {
      return RSA_NonExport_With_All();
    }
    if (paramString.equals("RSA_With_Null")) {
      return RSA_With_Null();
    }
    if (paramString.equals("DH_With_All")) {
      return DH_With_All();
    }
    if (paramString.equals("DH_NonExport_With_All")) {
      return DH_NonExport_With_All();
    }
    if (paramString.equals("DH_Anon_With_All")) {
      return DH_Anon_With_All();
    }
    if (paramString.equals("DHE_With_All")) {
      return DHE_With_All();
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ":");
    CipherSuite[] arrayOfCipherSuite = new CipherSuite[localStringTokenizer.countTokens()];
    for (int i = 0; localStringTokenizer.hasMoreTokens(); i++)
    {
      String str = localStringTokenizer.nextToken();
      Iterator localIterator = ALL_CIPHERS_MAP.values().iterator();
      while (localIterator.hasNext())
      {
        CipherSuite localCipherSuite = (CipherSuite)localIterator.next();
        if (str.equals(localCipherSuite.getCipherSuiteName()))
        {
          arrayOfCipherSuite[i] = localCipherSuite;
          break;
        }
      }
      if (arrayOfCipherSuite[i] == null) {
        throw new RuntimeException("Unrecognized cipher suite: " + str);
      }
    }
    return arrayOfCipherSuite;
  }
  
  /**
   * @deprecated
   */
  public static CipherSuite getCipherSuite(String paramString)
  {
    return (CipherSuite)ALL_CIPHERS_MAP.get(paramString);
  }
  
  static
  {
    if ((f.a()) || (f.b()))
    {
      addCipher(ECDHE_ECDSA_With_AES_256_GCM_SHA384.INSTANCE);
      addCipher(ECDHE_ECDSA_With_AES_256_CBC_SHA384.INSTANCE);
      addCipher(ECDHE_ECDSA_With_AES_256_CBC_SHA.INSTANCE);
      addCipher(ECDHE_RSA_With_AES_256_GCM_SHA384.INSTANCE);
      addCipher(ECDHE_RSA_With_AES_256_CBC_SHA384.INSTANCE);
      addCipher(ECDHE_RSA_With_AES_256_CBC_SHA.INSTANCE);
      addCipher(ECDH_ECDSA_With_AES_256_GCM_SHA384.INSTANCE);
      addCipher(ECDH_ECDSA_With_AES_256_CBC_SHA384.INSTANCE);
      addCipher(ECDH_ECDSA_With_AES_256_CBC_SHA.INSTANCE);
      addCipher(ECDH_RSA_With_AES_256_GCM_SHA384.INSTANCE);
      addCipher(ECDH_RSA_With_AES_256_CBC_SHA384.INSTANCE);
      addCipher(ECDH_RSA_With_AES_256_CBC_SHA.INSTANCE);
      addCipher(ECDHE_ECDSA_With_AES_128_GCM_SHA256.INSTANCE);
      addCipher(ECDHE_ECDSA_With_AES_128_CBC_SHA256.INSTANCE);
      addCipher(ECDHE_ECDSA_With_AES_128_CBC_SHA.INSTANCE);
      addCipher(ECDHE_RSA_With_AES_128_GCM_SHA256.INSTANCE);
      addCipher(ECDHE_RSA_With_AES_128_CBC_SHA256.INSTANCE);
      addCipher(ECDHE_RSA_With_AES_128_CBC_SHA.INSTANCE);
      addCipher(ECDH_ECDSA_With_AES_128_GCM_SHA256.INSTANCE);
      addCipher(ECDH_ECDSA_With_AES_128_CBC_SHA256.INSTANCE);
      addCipher(ECDH_ECDSA_With_AES_128_CBC_SHA.INSTANCE);
      addCipher(ECDH_RSA_With_AES_128_GCM_SHA256.INSTANCE);
      addCipher(ECDH_RSA_With_AES_128_CBC_SHA256.INSTANCE);
      addCipher(ECDH_RSA_With_AES_128_CBC_SHA.INSTANCE);
      addCipher(ECDHE_ECDSA_With_3DES_EDE_CBC_SHA.INSTANCE);
      addCipher(ECDHE_RSA_With_3DES_EDE_CBC_SHA.INSTANCE);
      addCipher(ECDH_ECDSA_With_3DES_EDE_CBC_SHA.INSTANCE);
      addCipher(ECDH_RSA_With_3DES_EDE_CBC_SHA.INSTANCE);
      addCipher(ECDHE_ECDSA_With_RC4_128_SHA.INSTANCE);
      addCipher(ECDHE_RSA_With_RC4_128_SHA.INSTANCE);
      addCipher(ECDH_ECDSA_With_RC4_128_SHA.INSTANCE);
      addCipher(ECDH_RSA_With_RC4_128_SHA.INSTANCE);
    }
    addCipher(DHE_RSA_With_AES_256_GCM_SHA384.INSTANCE);
    addCipher(DHE_DSS_With_AES_256_GCM_SHA384.INSTANCE);
    addCipher(DHE_RSA_With_AES_256_CBC_SHA256.INSTANCE);
    addCipher(DHE_DSS_With_AES_256_CBC_SHA256.INSTANCE);
    addCipher(DHE_RSA_With_AES_256_CBC_SHA.INSTANCE);
    addCipher(DHE_DSS_With_AES_256_CBC_SHA.INSTANCE);
    addCipher(RSA_With_AES_256_GCM_SHA384.INSTANCE);
    addCipher(DH_DSS_With_AES_256_GCM_SHA384.INSTANCE);
    addCipher(RSA_With_AES_256_CBC_SHA256.INSTANCE);
    addCipher(DH_RSA_With_AES_256_GCM_SHA384.INSTANCE);
    addCipher(DH_DSS_With_AES_256_CBC_SHA256.INSTANCE);
    addCipher(RSA_With_AES_256_CBC_SHA.INSTANCE);
    addCipher(DH_RSA_With_AES_256_CBC_SHA256.INSTANCE);
    addCipher(DH_RSA_With_AES_256_CBC_SHA.INSTANCE);
    addCipher(DH_DSS_With_AES_256_CBC_SHA.INSTANCE);
    addCipher(DHE_RSA_With_AES_128_GCM_SHA256.INSTANCE);
    addCipher(DHE_DSS_With_AES_128_GCM_SHA256.INSTANCE);
    addCipher(DHE_RSA_With_AES_128_CBC_SHA256.INSTANCE);
    addCipher(DHE_DSS_With_AES_128_CBC_SHA256.INSTANCE);
    addCipher(DHE_RSA_With_AES_128_CBC_SHA.INSTANCE);
    addCipher(DHE_DSS_With_AES_128_CBC_SHA.INSTANCE);
    addCipher(DHE_DSS_With_AES_128_CBC_SHA.INSTANCE);
    addCipher(RSA_With_AES_128_GCM_SHA256.INSTANCE);
    addCipher(RSA_With_AES_128_CBC_SHA256.INSTANCE);
    addCipher(RSA_With_AES_128_CBC_SHA.INSTANCE);
    addCipher(DH_RSA_With_AES_128_GCM_SHA256.INSTANCE);
    addCipher(DH_DSS_With_AES_128_GCM_SHA256.INSTANCE);
    addCipher(DH_RSA_With_AES_128_CBC_SHA256.INSTANCE);
    addCipher(DH_DSS_With_AES_128_CBC_SHA256.INSTANCE);
    addCipher(DH_RSA_With_AES_128_CBC_SHA.INSTANCE);
    addCipher(DH_DSS_With_AES_128_CBC_SHA.INSTANCE);
    addCipher(DHE_RSA_With_3DES_EDE_CBC_SHA.INSTANCE);
    addCipher(DHE_DSS_With_3DES_EDE_CBC_SHA.INSTANCE);
    addCipher(RSA_With_3DES_EDE_CBC_SHA.INSTANCE);
    addCipher(DH_RSA_With_3DES_EDE_CBC_SHA.INSTANCE);
    addCipher(DH_DSS_With_3DES_EDE_CBC_SHA.INSTANCE);
    addCipher(RSA_With_RC4_SHA.INSTANCE);
    addCipher(RSA_With_RC4_MD5.INSTANCE);
    addCipher(DHE_RSA_With_DES_CBC_SHA.INSTANCE);
    addCipher(DHE_DSS_With_DES_CBC_SHA.INSTANCE);
    addCipher(RSA_With_DES_CBC_SHA.INSTANCE);
    addCipher(DH_DSS_With_DES_CBC_SHA.INSTANCE);
    addCipher(DH_RSA_With_DES_CBC_SHA.INSTANCE);
    addCipher(DH_Anon_With_DES_CBC_SHA.INSTANCE);
    if (f.a()) {
      addCipher(ECDH_Anon_With_AES_256_CBC_SHA.INSTANCE);
    }
    addCipher(DH_Anon_With_AES_256_GCM_SHA384.INSTANCE);
    addCipher(DH_Anon_With_AES_256_CBC_SHA256.INSTANCE);
    addCipher(DH_Anon_With_AES_256_CBC_SHA.INSTANCE);
    if (f.a()) {
      addCipher(ECDH_Anon_With_AES_128_CBC_SHA.INSTANCE);
    }
    addCipher(DH_Anon_With_AES_128_GCM_SHA256.INSTANCE);
    addCipher(DH_Anon_With_AES_128_CBC_SHA256.INSTANCE);
    addCipher(DH_Anon_With_AES_128_CBC_SHA.INSTANCE);
    if (f.a()) {
      addCipher(ECDH_Anon_With_3DES_EDE_CBC_SHA.INSTANCE);
    }
    addCipher(DH_Anon_With_3DES_EDE_CBC_SHA.INSTANCE);
    if (f.a()) {
      addCipher(ECDH_Anon_With_RC4_128_SHA.INSTANCE);
    }
    addCipher(DH_Anon_With_RC4_MD5.INSTANCE);
    if (f.a())
    {
      addCipher(ECDHE_ECDSA_With_Null_SHA.INSTANCE);
      addCipher(ECDHE_ECDSA_With_Null_SHA.INSTANCE);
      addCipher(ECDHE_RSA_With_Null_SHA.INSTANCE);
      addCipher(ECDH_ECDSA_With_Null_SHA.INSTANCE);
      addCipher(ECDH_RSA_With_Null_SHA.INSTANCE);
    }
    addCipher(RSA_With_Null_SHA256.INSTANCE);
    addCipher(RSA_With_Null_SHA.INSTANCE);
    addCipher(RSA_With_Null_MD5.INSTANCE);
    if (f.a()) {
      addCipher(ECDH_Anon_With_Null_SHA.INSTANCE);
    }
    addCipher(Null_With_Null_Null.INSTANCE);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.CipherSuiteLists
 * JD-Core Version:    0.7.0.1
 */