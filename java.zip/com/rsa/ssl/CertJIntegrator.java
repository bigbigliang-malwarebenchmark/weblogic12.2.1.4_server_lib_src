package com.rsa.ssl;

import com.rsa.certj.CertJ;
import com.rsa.certj.CertJException;
import com.rsa.certj.DatabaseService;
import com.rsa.certj.Provider;
import com.rsa.certj.cert.CRL;
import com.rsa.certj.cert.CertificateException;
import com.rsa.certj.cert.X500Name;
import com.rsa.certj.cert.X509Certificate;
import com.rsa.certj.cert.X509V3Extensions;
import com.rsa.certj.cert.extensions.BasicConstraints;
import com.rsa.certj.cert.extensions.KeyUsage;
import com.rsa.certj.cert.extensions.X509V3Extension;
import com.rsa.certj.provider.db.MemoryDB;
import com.rsa.certj.provider.path.PKIXCertPath;
import com.rsa.certj.provider.random.DefaultRandom;
import com.rsa.certj.provider.revocation.CRLCertStatus;
import com.rsa.certj.spi.path.CertPathCtx;
import com.rsa.jsafe.JSAFE_PrivateKey;
import com.rsa.ssl.external.VerifyUtils;
import java.util.Date;
import java.util.Vector;

/**
 * @deprecated
 */
public class CertJIntegrator
{
  private static final String CANNOT_VERIFY_CERTIFICATE = "Cannot verify certificate.";
  private static final String ERROR_CA_CERTS = "Cannot load CA certificates from database.";
  private DatabaseService databaseService;
  private CertJ certJ;
  private CertPathCtx certPathCtx;
  
  /**
   * @deprecated
   */
  public CertJIntegrator(DatabaseService paramDatabaseService, CertJ paramCertJ)
  {
    this.databaseService = paramDatabaseService;
    this.certJ = paramCertJ;
  }
  
  /**
   * @deprecated
   */
  public CertJIntegrator(CertJ paramCertJ)
    throws SSLException
  {
    try
    {
      this.certJ = paramCertJ;
      this.databaseService = ((DatabaseService)this.certJ.bindServices(1));
    }
    catch (Exception localException)
    {
      throw new SSLException("Cannot create a CertJIntegrator");
    }
  }
  
  /**
   * @deprecated
   */
  public CertJIntegrator(DatabaseService paramDatabaseService, CertJ paramCertJ, CertPathCtx paramCertPathCtx)
  {
    this.databaseService = paramDatabaseService;
    this.certJ = paramCertJ;
    this.certPathCtx = paramCertPathCtx;
  }
  
  /**
   * @deprecated
   */
  public CertJIntegrator()
    throws SSLException
  {
    try
    {
      Provider[] arrayOfProvider = { new MemoryDB("MyDB"), new PKIXCertPath("PKIX path"), new CRLCertStatus("CRL status"), new DefaultRandom("RSARandom") };
      this.certJ = new CertJ(arrayOfProvider);
      this.databaseService = ((DatabaseService)this.certJ.bindServices(1));
    }
    catch (Exception localException)
    {
      throw new SSLException("Cannot create a CertJIntegrator");
    }
  }
  
  /**
   * @deprecated
   */
  public void setDatabaseService(DatabaseService paramDatabaseService)
  {
    this.databaseService = paramDatabaseService;
  }
  
  /**
   * @deprecated
   */
  public void setCertJ(CertJ paramCertJ)
    throws SSLException
  {
    try
    {
      this.certJ = paramCertJ;
      this.databaseService = ((DatabaseService)this.certJ.bindServices(1));
    }
    catch (CertJException localCertJException)
    {
      throw new SSLException("Can't bind database service: " + localCertJException.getMessage());
    }
  }
  
  /**
   * @deprecated
   */
  public void setCertPathCtx(CertPathCtx paramCertPathCtx)
    throws SSLException
  {
    this.certPathCtx = paramCertPathCtx;
  }
  
  /**
   * @deprecated
   */
  public DatabaseService getDatabaseService()
  {
    return this.databaseService;
  }
  
  /**
   * @deprecated
   */
  public CertJ getCertJObject()
  {
    return this.certJ;
  }
  
  /**
   * @deprecated
   */
  public CertPathCtx getCertPathCtx()
  {
    return this.certPathCtx;
  }
  
  /**
   * @deprecated
   */
  public X509Certificate[] loadCertificateChain(X509Certificate paramX509Certificate, X509Certificate[] paramArrayOfX509Certificate)
    throws SSLException
  {
    X509Certificate[] arrayOfX509Certificate;
    try
    {
      Vector localVector = new Vector();
      if (this.certPathCtx == null) {
        this.certPathCtx = new CertPathCtx(0, paramArrayOfX509Certificate, (byte[][])null, new Date(), this.databaseService);
      }
      if (this.certJ.buildCertPath(this.certPathCtx, paramX509Certificate, localVector, null, null, null))
      {
        arrayOfX509Certificate = (X509Certificate[])localVector.toArray();
      }
      else
      {
        arrayOfX509Certificate = new X509Certificate[1];
        arrayOfX509Certificate[0] = paramX509Certificate;
      }
    }
    catch (Exception localException)
    {
      throw new SSLException("Cannot load certificate chain from database.");
    }
    return arrayOfX509Certificate;
  }
  
  /**
   * @deprecated
   */
  public X509Certificate[] loadCACerts(X500Name[] paramArrayOfX500Name)
    throws SSLException
  {
    Vector localVector = new Vector();
    try
    {
      for (int i = 0; i < paramArrayOfX500Name.length; i++) {
        this.databaseService.selectCertificateBySubject(paramArrayOfX500Name[i], localVector);
      }
    }
    catch (Exception localException)
    {
      throw new SSLException("Cannot load CA certificates from database.");
    }
    return (X509Certificate[])localVector.toArray();
  }
  
  /**
   * @deprecated
   */
  public X509Certificate[] loadCACerts()
    throws SSLException
  {
    Vector localVector = new Vector();
    try
    {
      X509Certificate localX509Certificate1 = (X509Certificate)this.databaseService.firstCertificate();
      if (hasBasicConstraintsExtension(localX509Certificate1)) {
        localVector.addElement(localX509Certificate1);
      }
    }
    catch (Exception localException1) {}
    try
    {
      while (this.databaseService.hasMoreCertificates()) {
        try
        {
          X509Certificate localX509Certificate2 = (X509Certificate)this.databaseService.nextCertificate();
          if (hasBasicConstraintsExtension(localX509Certificate2)) {
            localVector.addElement(localX509Certificate2);
          }
        }
        catch (Exception localException2) {}
      }
    }
    catch (Exception localException3)
    {
      throw new SSLException("Cannot load CA certificates from database.");
    }
    return (X509Certificate[])localVector.toArray();
  }
  
  private boolean hasBasicConstraintsExtension(X509Certificate paramX509Certificate)
  {
    X509V3Extensions localX509V3Extensions = paramX509Certificate.getExtensions();
    if (localX509V3Extensions != null)
    {
      X509V3Extension localX509V3Extension;
      try
      {
        localX509V3Extension = localX509V3Extensions.getExtensionByType(19);
      }
      catch (CertificateException localCertificateException)
      {
        return false;
      }
      if ((localX509V3Extension != null) && (((BasicConstraints)localX509V3Extension).getCA())) {
        return true;
      }
    }
    return false;
  }
  
  /**
   * @deprecated
   */
  public JSAFE_PrivateKey loadPrivateKey(X509Certificate paramX509Certificate)
    throws SSLException
  {
    try
    {
      return this.databaseService.selectPrivateKeyByCertificate(paramX509Certificate);
    }
    catch (Exception localException)
    {
      throw new SSLException("Cannot load private key from database.");
    }
  }
  
  /**
   * @deprecated
   */
  public CRL[] loadCRLs(X500Name paramX500Name, Date paramDate)
    throws SSLException
  {
    Vector localVector = new Vector();
    try
    {
      this.databaseService.selectCRLByIssuerAndTime(paramX500Name, paramDate, localVector);
    }
    catch (Exception localException)
    {
      throw new SSLException("Cannot load CRL from database.");
    }
    if (localVector.isEmpty()) {
      return null;
    }
    return (CRL[])localVector.toArray();
  }
  
  /**
   * @deprecated
   */
  public int verifyCertificate(SSLParams paramSSLParams, X509Certificate[] paramArrayOfX509Certificate, CipherSuite paramCipherSuite)
    throws SSLException
  {
    if ((paramArrayOfX509Certificate == null) || (paramArrayOfX509Certificate.length == 0)) {
      return -1;
    }
    X509Certificate[] arrayOfX509Certificate = paramSSLParams.getCACertificates();
    try
    {
      Provider[] arrayOfProvider = { new PKIXCertPath("Path provider"), new MemoryDB("Memory DB provider"), new CRLCertStatus("CRL Cert Status provider") };
      CertJ localCertJ = new CertJ(arrayOfProvider);
      localCertJ.setDevice(paramSSLParams.getDevice());
      DatabaseService localDatabaseService = (DatabaseService)localCertJ.bindService(1, "Memory DB provider");
      addCRLs(localDatabaseService);
      if (!checkStrongKey(paramArrayOfX509Certificate[0], paramSSLParams)) {
        return -1;
      }
      for (int i = 1; i < paramArrayOfX509Certificate.length; i++)
      {
        if (!checkStrongKey(paramArrayOfX509Certificate[i], paramSSLParams)) {
          return -1;
        }
        localDatabaseService.insertCertificate(paramArrayOfX509Certificate[i]);
      }
      for (i = 0; i < arrayOfX509Certificate.length; i++) {
        localDatabaseService.insertCertificate(arrayOfX509Certificate[i]);
      }
      i = 96;
      if (this.databaseService.firstCRL() == null) {
        i |= 0x4;
      }
      CertPathCtx localCertPathCtx = new CertPathCtx(i, arrayOfX509Certificate, (byte[][])null, new Date(), localDatabaseService);
      Vector localVector = new Vector();
      boolean bool = localCertJ.buildCertPath(localCertPathCtx, paramArrayOfX509Certificate[0], localVector, null, null, null);
      if (!bool) {
        return -1;
      }
      Object[] arrayOfObject = localVector.toArray();
      for (int j = 0; j < arrayOfObject.length; j++) {
        if (!checkAdditionalConstraints((X509Certificate)arrayOfObject[j], j, paramCipherSuite)) {
          return -1;
        }
      }
      X509Certificate localX509Certificate = (X509Certificate)localVector.get(localVector.size() - 1);
      for (int k = 0; k < arrayOfX509Certificate.length; k++) {
        if (localX509Certificate.equals(arrayOfX509Certificate[k])) {
          return k;
        }
      }
      return -1;
    }
    catch (CertJException localCertJException)
    {
      throw new SSLException("Cannot verify certificate.");
    }
    catch (CertificateException localCertificateException)
    {
      throw new SSLException("Cannot verify certificate.");
    }
  }
  
  private boolean checkAdditionalConstraints(X509Certificate paramX509Certificate, int paramInt, CipherSuite paramCipherSuite)
    throws CertificateException
  {
    if ((!VerifyUtils.checkBasicConstraints(paramX509Certificate, paramInt)) || (VerifyUtils.areKeyLimitsViolated(paramX509Certificate))) {
      return false;
    }
    return checkKeyUsage(paramX509Certificate, paramInt, paramCipherSuite);
  }
  
  private boolean checkStrongKey(X509Certificate paramX509Certificate, SSLParams paramSSLParams)
    throws CertificateException
  {
    if (paramSSLParams.isCompatibilityTypeSet(CompatibilityType.WEAK_KEYS_ENABLED)) {
      return true;
    }
    return !VerifyUtils.isPublicExponentWeak(paramX509Certificate);
  }
  
  private void addCRLs(DatabaseService paramDatabaseService)
    throws CertJException
  {
    this.databaseService.setupCRLIterator();
    while (this.databaseService.hasMoreCRLs()) {
      paramDatabaseService.insertCRL(this.databaseService.nextCRL());
    }
  }
  
  private boolean checkKeyUsage(X509Certificate paramX509Certificate, int paramInt, CipherSuite paramCipherSuite)
    throws CertificateException
  {
    X509V3Extensions localX509V3Extensions = paramX509Certificate.getExtensions();
    if (localX509V3Extensions == null) {
      return true;
    }
    KeyUsage localKeyUsage = (KeyUsage)localX509V3Extensions.getExtensionByType(15);
    if (localKeyUsage == null) {
      return true;
    }
    if (!localKeyUsage.getCriticality()) {
      return true;
    }
    if (paramInt > 0) {
      return localKeyUsage.verifyKeyUsage(67108864);
    }
    if (("RSA".equals(paramCipherSuite.getAsymmetricAlgorithm())) || ("RSA".equals(paramCipherSuite.getSignAlgorithm()))) {
      return (localKeyUsage.verifyKeyUsage(536870912)) || (localKeyUsage.verifyKeyUsage(268435456)) || (localKeyUsage.verifyKeyUsage(-2147483648));
    }
    return localKeyUsage.verifyKeyUsage(-2147483648);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.CertJIntegrator
 * JD-Core Version:    0.7.0.1
 */