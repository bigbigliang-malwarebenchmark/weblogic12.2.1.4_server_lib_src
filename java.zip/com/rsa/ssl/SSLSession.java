package com.rsa.ssl;

import com.rsa.certj.cert.X509Certificate;
import com.rsa.jsafe.JSAFE_SecureRandom;
import com.rsa.sslj.x.cr;
import com.rsa.sslj.x.cs;
import com.rsa.sslj.x.ct;
import com.rsa.sslj.x.cu;
import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * @deprecated
 */
public class SSLSession
{
  private byte[] sessionID;
  private String sessionString;
  private String address;
  private int port;
  private byte[] masterSecret;
  private long time;
  private long lastAccessTime;
  private int version;
  private CipherSuite negotiatedCipherSuite;
  /**
   * @deprecated
   */
  transient X509Certificate[] serverCertChain;
  /**
   * @deprecated
   */
  transient X509Certificate[] clientCertChain;
  private SuiteBMode.ConnectionStatus suiteBConnectionStatus;
  
  /**
   * @deprecated
   */
  public SSLSession(byte[] paramArrayOfByte1, String paramString, long paramLong, byte[] paramArrayOfByte2, CipherSuite paramCipherSuite, X509Certificate[] paramArrayOfX509Certificate1, X509Certificate[] paramArrayOfX509Certificate2, SSLParams paramSSLParams, int paramInt)
  {
    this(paramArrayOfByte1, paramString, 443, paramLong, paramArrayOfByte2, paramCipherSuite, paramArrayOfX509Certificate1, paramArrayOfX509Certificate2, paramSSLParams, paramInt);
  }
  
  /**
   * @deprecated
   */
  public SSLSession(byte[] paramArrayOfByte1, String paramString, int paramInt1, long paramLong, byte[] paramArrayOfByte2, CipherSuite paramCipherSuite, X509Certificate[] paramArrayOfX509Certificate1, X509Certificate[] paramArrayOfX509Certificate2, SSLParams paramSSLParams, int paramInt2)
  {
    this(paramArrayOfByte1, paramString, paramInt1, paramLong, paramArrayOfByte2, paramCipherSuite, paramArrayOfX509Certificate1, paramArrayOfX509Certificate2, paramSSLParams, paramInt2, SuiteBMode.ConnectionStatus.NOT_SUITEB);
  }
  
  /**
   * @deprecated
   */
  public SSLSession(byte[] paramArrayOfByte1, String paramString, int paramInt1, long paramLong, byte[] paramArrayOfByte2, CipherSuite paramCipherSuite, X509Certificate[] paramArrayOfX509Certificate1, X509Certificate[] paramArrayOfX509Certificate2, SSLParams paramSSLParams, int paramInt2, SuiteBMode.ConnectionStatus paramConnectionStatus)
  {
    if (paramArrayOfByte1 == null)
    {
      this.sessionID = new byte[32];
      paramSSLParams.getRandom().nextBytes(this.sessionID);
    }
    else
    {
      this.sessionID = cr.a(paramArrayOfByte1);
    }
    this.time = paramLong;
    this.sessionString = cs.a(this.sessionID);
    this.address = paramString;
    this.port = paramInt1;
    this.masterSecret = cr.a(paramArrayOfByte2);
    this.serverCertChain = paramArrayOfX509Certificate1;
    this.clientCertChain = paramArrayOfX509Certificate2;
    this.version = paramInt2;
    this.negotiatedCipherSuite = paramCipherSuite;
    this.suiteBConnectionStatus = paramConnectionStatus;
  }
  
  /**
   * @deprecated
   */
  public SSLSession(byte[] paramArrayOfByte, SSLParams paramSSLParams, int paramInt)
  {
    this(paramArrayOfByte, ct.a(), System.currentTimeMillis(), null, null, null, null, paramSSLParams, paramInt);
  }
  
  /**
   * @deprecated
   */
  public void setTime(long paramLong)
  {
    this.time = paramLong;
  }
  
  /**
   * @deprecated
   */
  public long getTime()
  {
    return this.time;
  }
  
  /**
   * @deprecated
   */
  public void setLastAccessTime(long paramLong)
  {
    this.lastAccessTime = paramLong;
  }
  
  /**
   * @deprecated
   */
  public long getLastAccessTime()
  {
    if (this.lastAccessTime > 0L) {
      return this.lastAccessTime;
    }
    return this.time;
  }
  
  /**
   * @deprecated
   */
  public void setVersion(int paramInt)
  {
    this.version = paramInt;
  }
  
  /**
   * @deprecated
   */
  public int getVersion()
  {
    return this.version;
  }
  
  /**
   * @deprecated
   */
  public byte[] getID()
  {
    return cr.a(this.sessionID);
  }
  
  /**
   * @deprecated
   */
  public String getIDString()
  {
    return this.sessionString;
  }
  
  /**
   * @deprecated
   */
  public String getHost()
  {
    String str = null;
    try
    {
      str = InetAddress.getByName(this.address).getHostName();
    }
    catch (UnknownHostException localUnknownHostException) {}
    return str;
  }
  
  /**
   * @deprecated
   */
  public String getAddress()
  {
    return this.address;
  }
  
  /**
   * @deprecated
   */
  public int getPort()
  {
    return this.port;
  }
  
  /**
   * @deprecated
   */
  public void setMasterSecret(byte[] paramArrayOfByte)
  {
    cu.a(this.masterSecret);
    this.masterSecret = cr.a(paramArrayOfByte);
  }
  
  /**
   * @deprecated
   */
  public byte[] getMasterSecret()
  {
    return cr.a(this.masterSecret);
  }
  
  /**
   * @deprecated
   */
  public void setServerCertChain(X509Certificate[] paramArrayOfX509Certificate)
  {
    this.serverCertChain = new X509Certificate[paramArrayOfX509Certificate.length];
    System.arraycopy(paramArrayOfX509Certificate, 0, this.serverCertChain, 0, paramArrayOfX509Certificate.length);
  }
  
  /**
   * @deprecated
   */
  public X509Certificate[] getServerCertChain()
  {
    return this.serverCertChain;
  }
  
  /**
   * @deprecated
   */
  public void setClientCertChain(X509Certificate[] paramArrayOfX509Certificate)
  {
    this.clientCertChain = new X509Certificate[paramArrayOfX509Certificate.length];
    System.arraycopy(paramArrayOfX509Certificate, 0, this.clientCertChain, 0, paramArrayOfX509Certificate.length);
  }
  
  /**
   * @deprecated
   */
  public X509Certificate[] getClientCertChain()
  {
    return this.clientCertChain;
  }
  
  /**
   * @deprecated
   */
  public CipherSuite getNegotiatedCipherSuite()
  {
    return this.negotiatedCipherSuite;
  }
  
  /**
   * @deprecated
   */
  public CipherSuite getNegotiatedCipehrSuite()
  {
    return this.negotiatedCipherSuite;
  }
  
  /**
   * @deprecated
   */
  public void clearSensitiveData()
  {
    cu.a(this.masterSecret);
    cu.a(this.sessionID);
    this.time = 0L;
  }
  
  /**
   * @deprecated
   */
  public SuiteBMode.ConnectionStatus getSuiteBConnectionStatus()
  {
    return this.suiteBConnectionStatus;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.SSLSession
 * JD-Core Version:    0.7.0.1
 */