package com.rsa.ssl;

/**
 * @deprecated
 */
public final class AlgorithmType
{
  /**
   * @deprecated
   */
  public static final AlgorithmType MESSAGE_DIGEST = new AlgorithmType("MESSAGE_DIGEST");
  /**
   * @deprecated
   */
  public static final AlgorithmType SYMMETRIC_DECRYPTION = new AlgorithmType("SYMMETRIC_DECRYPTION");
  /**
   * @deprecated
   */
  public static final AlgorithmType SYMMETRIC_ENCRYPTION = new AlgorithmType("SYMMETRIC_ENCRYPTION");
  /**
   * @deprecated
   */
  public static final AlgorithmType ASYMMETRIC_ENCRYPTION = new AlgorithmType("ASYMMETRIC_ENCRYPTION");
  /**
   * @deprecated
   */
  public static final AlgorithmType ASYMMETRIC_DECRYPTION = new AlgorithmType("ASYMMETRIC_DECRYPTION");
  /**
   * @deprecated
   */
  public static final AlgorithmType SIGNING = new AlgorithmType("SIGNING");
  /**
   * @deprecated
   */
  public static final AlgorithmType VERIFICATION = new AlgorithmType("VERIFICATION");
  /**
   * @deprecated
   */
  public static final AlgorithmType KEY_PAIR_GENERATION = new AlgorithmType("KEY_PAIR_GENERATION");
  /**
   * @deprecated
   */
  public static final AlgorithmType RNG = new AlgorithmType("RNG");
  private final String displayName;
  
  private AlgorithmType(String paramString)
  {
    this.displayName = paramString;
  }
  
  /**
   * @deprecated
   */
  public String toString()
  {
    return this.displayName;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.AlgorithmType
 * JD-Core Version:    0.7.0.1
 */