package com.rsa.ssl;

/**
 * @deprecated
 */
public final class CompatibilityType
{
  /**
   * @deprecated
   */
  public static final CompatibilityType DH_NULL_SIGNATURE_REQUIRED = new CompatibilityType("DH_NULL_SIGNATURE_REQUIRED");
  /**
   * @deprecated
   */
  public static final CompatibilityType WEAK_KEYS_ENABLED = new CompatibilityType("WEAK_KEYS_ENABLED");
  /**
   * @deprecated
   */
  public static final CompatibilityType IGNORE_BAD_KEYPAIRS = new CompatibilityType("IGNORE_BAD_KEYPAIRS");
  /**
   * @deprecated
   */
  public static final CompatibilityType IGNORE_BAD_CERTS = new CompatibilityType("IGNORE_BAD_CERTS");
  /**
   * @deprecated
   */
  public static final CompatibilityType IGNORE_EXPIRED_CERTS = new CompatibilityType("IGNORE_EXPIRED_CERTS");
  private final String compatibilityPropertyName;
  
  private CompatibilityType(String paramString)
  {
    this.compatibilityPropertyName = paramString;
  }
  
  /**
   * @deprecated
   */
  public String toString()
  {
    return this.compatibilityPropertyName;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.CompatibilityType
 * JD-Core Version:    0.7.0.1
 */