package com.rsa.ssl;

import java.io.IOException;

/**
 * @deprecated
 */
public class AlertedException
  extends IOException
{
  /**
   * @deprecated
   */
  public static final int WARNING = 1;
  /**
   * @deprecated
   */
  public static final int FATAL = 2;
  private final int level;
  /**
   * @deprecated
   */
  public static final int SSL2_NO_CIPHER_ERROR = 1;
  /**
   * @deprecated
   */
  public static final int SSL2_NO_CERTIFICATE_ERROR = 2;
  /**
   * @deprecated
   */
  public static final int SSL2_BAD_CERTIFICATE_ERROR = 3;
  /**
   * @deprecated
   */
  public static final int SSL2_UNSUPPORTED_CERTIFICATE_TYPE_ERROR = 4;
  /**
   * @deprecated
   */
  public static final int CLOSE_NOTIFY = 0;
  /**
   * @deprecated
   */
  public static final int UNEXPECTED_MESSAGE = 10;
  /**
   * @deprecated
   */
  public static final int BAD_RECORD_MAC = 20;
  /**
   * @deprecated
   */
  public static final int DECRYPTION_FAILED = 21;
  /**
   * @deprecated
   */
  public static final int RECORD_OVERFLOW = 22;
  /**
   * @deprecated
   */
  public static final int DECOMPRESSION_FAILURE = 30;
  /**
   * @deprecated
   */
  public static final int HANDSHAKE_FAILURE = 40;
  /**
   * @deprecated
   */
  public static final int NO_CERTIFICATE = 41;
  /**
   * @deprecated
   */
  public static final int BAD_CERTIFICATE = 42;
  /**
   * @deprecated
   */
  public static final int UNSUPPORTED_CERTIFICATE = 43;
  /**
   * @deprecated
   */
  public static final int CERTIFICATE_REVOKED = 44;
  /**
   * @deprecated
   */
  public static final int CERTIFICATE_EXPIRED = 45;
  /**
   * @deprecated
   */
  public static final int CERTIFICATE_UNKNOWN = 46;
  /**
   * @deprecated
   */
  public static final int ILLEGAL_PARAMETER = 47;
  /**
   * @deprecated
   */
  public static final int UNKNOWN_CA = 48;
  /**
   * @deprecated
   */
  public static final int ACCESS_DENIED = 49;
  /**
   * @deprecated
   */
  public static final int DECODE_ERROR = 50;
  /**
   * @deprecated
   */
  public static final int DECRYPT_ERROR = 51;
  /**
   * @deprecated
   */
  public static final int EXPORT_RESTRICTION = 60;
  /**
   * @deprecated
   */
  public static final int PROTOCOL_VERSION = 70;
  /**
   * @deprecated
   */
  public static final int INSUFFICIENT_SECURITY = 71;
  /**
   * @deprecated
   */
  public static final int INTERNAL_ERROR = 80;
  /**
   * @deprecated
   */
  public static final int USER_CANCELED = 90;
  /**
   * @deprecated
   */
  public static final int NO_RENEGOTIATION = 100;
  private final int description;
  
  /**
   * @deprecated
   */
  public AlertedException(String paramString, int paramInt1, int paramInt2)
  {
    super(paramString);
    this.level = paramInt1;
    this.description = paramInt2;
  }
  
  /**
   * @deprecated
   */
  public int getLevel()
  {
    return this.level;
  }
  
  /**
   * @deprecated
   */
  public int getDescription()
  {
    return this.description;
  }
  
  /**
   * @deprecated
   */
  public static String getDescription(int paramInt)
  {
    switch (paramInt)
    {
    case 1: 
      return "No Cipher Error";
    case 2: 
      return "No Certificate Error";
    case 3: 
      return "Bad Certificate Error";
    case 4: 
      return "Unsupported Certificate Type Error";
    case 0: 
      return "Close Notify";
    case 10: 
      return "Unexpected Message";
    case 20: 
      return "Bad Record Mac";
    case 30: 
      return "Decompression Failure";
    case 21: 
      return "Decryption Failed";
    case 40: 
      return "Handshake Failure.  No supported cipher suites";
    case 41: 
      return "No Certificate";
    case 42: 
      return "Bad Certificate";
    case 43: 
      return "Unsupported Certificate";
    case 44: 
      return "Certificate Revoked";
    case 45: 
      return "Certificate Expired";
    case 46: 
      return "Certificate Unknown";
    case 47: 
      return "Illegal Parameter";
    case 80: 
      return "Internal Error";
    }
    return "";
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.AlertedException
 * JD-Core Version:    0.7.0.1
 */