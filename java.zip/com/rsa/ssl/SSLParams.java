package com.rsa.ssl;

import com.rsa.certj.cert.CertificateException;
import com.rsa.certj.cert.X509Certificate;
import com.rsa.jsafe.JSAFE_Exception;
import com.rsa.jsafe.JSAFE_PrivateKey;
import com.rsa.jsafe.JSAFE_SecureRandom;
import com.rsa.jsafe.JSAFE_Session;
import com.rsa.jsafe.JSAFE_SessionSpec;
import com.rsa.jsse.b;
import com.rsa.ssl.external.Truster;
import com.rsa.sslj.x.cB;
import com.rsa.sslj.x.cC;
import com.rsa.sslj.x.cF;
import com.rsa.sslj.x.cG;
import com.rsa.sslj.x.cH;
import com.rsa.sslj.x.cI;
import com.rsa.sslj.x.cJ;
import com.rsa.sslj.x.cv;
import com.rsa.sslj.x.cw;
import com.rsa.sslj.x.cy;
import com.rsa.sslj.x.cz;
import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Vector;

/**
 * @deprecated
 */
public class SSLParams
{
  /**
   * @deprecated
   */
  public static final int SSLV2 = 2;
  /**
   * @deprecated
   */
  public static final int SSLV3 = 768;
  /**
   * @deprecated
   */
  public static final int TLSV1 = 769;
  /**
   * @deprecated
   */
  public static final int TLSV1_1 = 770;
  /**
   * @deprecated
   */
  public static final int TLSV1_2 = 771;
  /**
   * @deprecated
   */
  public static final int DEBUG_NONE = 0;
  /**
   * @deprecated
   */
  public static final int DEBUG_STATE = 1;
  /**
   * @deprecated
   */
  public static final int DEBUG_DATA = 2;
  /**
   * @deprecated
   */
  public static final int DEBUG_EXTRA = 4;
  /**
   * @deprecated
   */
  public static final int DEBUG_MULTITHREADED = 8;
  /**
   * @deprecated
   */
  public static final int CLIENT_AUTH_NONE = 0;
  /**
   * @deprecated
   */
  public static final int CLIENT_AUTH_REQUESTED = 1;
  /**
   * @deprecated
   */
  public static final int CLIENT_AUTH_REQUIRED = 2;
  private final Vector compatibilityTypeVector = new Vector(1);
  private DeviceSelector deviceSelector = new DeviceSelector();
  private SuiteBMode suiteBMode;
  private boolean buffered;
  /**
   * @deprecated
   */
  cC sslParamsDelegate;
  private Truster truster;
  
  /**
   * @deprecated
   */
  public SSLParams()
  {
    this(new cC());
    this.suiteBMode = SuiteBMode.NON_SUITEB_MODE;
  }
  
  /**
   * @deprecated
   */
  public void setExternalSessionCache(byte[] paramArrayOfByte, SSLSessionCache paramSSLSessionCache)
  {
    if (paramArrayOfByte == null) {
      throw new IllegalArgumentException("Context ID must not be null.");
    }
    if (paramSSLSessionCache == null) {
      throw new IllegalArgumentException("SSLSessionCache must not be null.");
    }
    this.sslParamsDelegate.a(paramArrayOfByte, paramSSLSessionCache);
  }
  
  /**
   * @deprecated
   */
  public SSLParams(FIPS140Mode paramFIPS140Mode)
  {
    this(new cC(paramFIPS140Mode));
    this.suiteBMode = SuiteBMode.NON_SUITEB_MODE;
  }
  
  /**
   * @deprecated
   */
  public SSLParams(SuiteBMode paramSuiteBMode)
  {
    this(new cC(paramSuiteBMode));
    this.suiteBMode = paramSuiteBMode;
  }
  
  /**
   * @deprecated
   */
  public SSLParams(FIPS140Mode paramFIPS140Mode, SuiteBMode paramSuiteBMode)
  {
    this(new cC(paramFIPS140Mode, paramSuiteBMode));
    this.suiteBMode = paramSuiteBMode;
  }
  
  /**
   * @deprecated
   */
  public SSLParams(FIPS140Mode paramFIPS140Mode, FIPS140Role paramFIPS140Role)
  {
    this(new cC(paramFIPS140Mode, paramFIPS140Role));
    this.suiteBMode = SuiteBMode.NON_SUITEB_MODE;
  }
  
  /**
   * @deprecated
   */
  public SSLParams(FIPS140Mode paramFIPS140Mode, FIPS140Role paramFIPS140Role, SuiteBMode paramSuiteBMode)
  {
    this(new cC(paramFIPS140Mode, paramFIPS140Role, paramSuiteBMode));
    this.suiteBMode = paramSuiteBMode;
  }
  
  private SSLParams(cC paramcC)
  {
    this.sslParamsDelegate = paramcC;
    this.sslParamsDelegate.a(this);
  }
  
  /**
   * @deprecated
   */
  public synchronized void setCipherSuites(CipherSuite[] paramArrayOfCipherSuite)
    throws SSLException
  {
    this.sslParamsDelegate.i.a(paramArrayOfCipherSuite);
  }
  
  /**
   * @deprecated
   */
  public synchronized CipherSuite[] getCipherSuites()
    throws SSLException
  {
    return this.sslParamsDelegate.i.a();
  }
  
  /**
   * @deprecated
   */
  public synchronized CipherSuite[] getServerCipherSuites()
    throws SSLException
  {
    return this.sslParamsDelegate.i.c();
  }
  
  /**
   * @deprecated
   */
  public String getDevice()
  {
    return this.deviceSelector.getDefaultDevice();
  }
  
  /**
   * @deprecated
   */
  public synchronized void setDevice(String paramString)
    throws SSLException
  {
    setDeviceSelector(new DeviceSelector(paramString));
  }
  
  /**
   * @deprecated
   */
  public DeviceSelector getDeviceSelector()
  {
    return this.deviceSelector;
  }
  
  /**
   * @deprecated
   */
  public synchronized void setDeviceSelector(DeviceSelector paramDeviceSelector)
    throws SSLException
  {
    this.deviceSelector = paramDeviceSelector;
  }
  
  /**
   * @deprecated
   */
  public synchronized JSAFE_Session[] getDeviceSessions()
  {
    return this.sslParamsDelegate.n.a();
  }
  
  /**
   * @deprecated
   */
  public synchronized void setDeviceSessions(JSAFE_Session[] paramArrayOfJSAFE_Session)
  {
    this.sslParamsDelegate.n.a(paramArrayOfJSAFE_Session);
  }
  
  /**
   * @deprecated
   */
  public synchronized void setDeviceSessions(JSAFE_SessionSpec[] paramArrayOfJSAFE_SessionSpec)
    throws SSLException
  {
    if (paramArrayOfJSAFE_SessionSpec == null) {
      throw new IllegalArgumentException("Null parameter value is not allowed");
    }
    int i = paramArrayOfJSAFE_SessionSpec.length;
    JSAFE_Session[] arrayOfJSAFE_Session = new JSAFE_Session[i];
    try
    {
      for (int j = 0; j < i; j++) {
        arrayOfJSAFE_Session[j] = JSAFE_Session.getInstance(paramArrayOfJSAFE_SessionSpec[j]);
      }
    }
    catch (JSAFE_Exception localJSAFE_Exception)
    {
      throw new SSLException("Unable to create device sessions: " + localJSAFE_Exception.getMessage());
    }
    setDeviceSessions(arrayOfJSAFE_Session);
  }
  
  /**
   * @deprecated
   */
  public synchronized void closeAllDeviceSessions()
  {
    this.sslParamsDelegate.n.b();
  }
  
  /**
   * @deprecated
   */
  public void setCompressionMethods(CompressionMethod[] paramArrayOfCompressionMethod) {}
  
  /**
   * @deprecated
   */
  public CompressionMethod[] getCompressionMethods()
  {
    return null;
  }
  
  /**
   * @deprecated
   */
  public void setCACertificates(byte[][] paramArrayOfByte)
    throws SSLException
  {
    this.sslParamsDelegate.g.a(paramArrayOfByte);
  }
  
  /**
   * @deprecated
   */
  public void setCACertificates(X509Certificate[] paramArrayOfX509Certificate)
    throws SSLException
  {
    byte[][] arrayOfByte = new byte[paramArrayOfX509Certificate.length][];
    for (int i = 0; i < paramArrayOfX509Certificate.length; i++) {
      arrayOfByte[i] = cJ.a(paramArrayOfX509Certificate[i]);
    }
    setCACertificates(arrayOfByte);
  }
  
  /**
   * @deprecated
   */
  public void addCACertificate(byte[] paramArrayOfByte)
    throws SSLException
  {
    try
    {
      this.sslParamsDelegate.g.a(paramArrayOfByte);
    }
    catch (Exception localException)
    {
      throw new SSLException(localException);
    }
  }
  
  /**
   * @deprecated
   */
  public void addCACertificate(X509Certificate paramX509Certificate)
    throws SSLException
  {
    addCACertificate(cJ.a(paramX509Certificate));
  }
  
  /**
   * @deprecated
   */
  public void removeCACertificate(byte[] paramArrayOfByte)
    throws SSLException
  {
    this.sslParamsDelegate.g.b(paramArrayOfByte);
  }
  
  /**
   * @deprecated
   */
  public void removeCACertificate(X509Certificate paramX509Certificate)
    throws SSLException
  {
    removeCACertificate(cJ.a(paramX509Certificate));
  }
  
  /**
   * @deprecated
   */
  public X509Certificate[] getCACertificates()
  {
    try
    {
      byte[][] arrayOfByte = this.sslParamsDelegate.g.b();
      return cJ.a(arrayOfByte);
    }
    catch (Exception localException)
    {
      throw new RuntimeException(localException);
    }
  }
  
  /**
   * @deprecated
   */
  public synchronized void setMaximumCacheTime(long paramLong)
    throws SSLException
  {
    this.sslParamsDelegate.o.a(paramLong);
  }
  
  /**
   * @deprecated
   */
  public synchronized long getMaximumCacheTime()
  {
    return this.sslParamsDelegate.o.a();
  }
  
  /**
   * @deprecated
   */
  public synchronized void purgeSessionCache(long paramLong)
    throws SSLException
  {
    this.sslParamsDelegate.o.b(paramLong);
  }
  
  /**
   * @deprecated
   */
  public void removeSession(SSLSession paramSSLSession)
  {
    if (paramSSLSession == null) {
      return;
    }
    removeSession(paramSSLSession.getID());
  }
  
  /**
   * @deprecated
   */
  public void removeSession(byte[] paramArrayOfByte)
  {
    this.sslParamsDelegate.o.a(paramArrayOfByte);
  }
  
  /**
   * @deprecated
   */
  public synchronized void cacheSession(SSLSession paramSSLSession)
    throws SSLException
  {
    this.sslParamsDelegate.o.a(paramSSLSession);
  }
  
  /**
   * @deprecated
   */
  public SSLSession getSession(byte[] paramArrayOfByte)
    throws SSLException
  {
    return this.sslParamsDelegate.o.b(paramArrayOfByte);
  }
  
  /**
   * @deprecated
   */
  public SSLSession getSession(String paramString)
    throws SSLException
  {
    return this.sslParamsDelegate.o.a(paramString);
  }
  
  /**
   * @deprecated
   */
  public SSLSession getSessionByAddress(String paramString)
    throws SSLException
  {
    return this.sslParamsDelegate.o.b(paramString);
  }
  
  /**
   * @deprecated
   */
  public Enumeration getIds()
    throws SSLException
  {
    return this.sslParamsDelegate.o.b();
  }
  
  /**
   * @deprecated
   */
  public void setVersions(int[] paramArrayOfInt)
    throws SSLException
  {
    this.sslParamsDelegate.e.a(paramArrayOfInt);
  }
  
  /**
   * @deprecated
   */
  public int[] getVersions()
  {
    return this.sslParamsDelegate.e.a();
  }
  
  /**
   * @deprecated
   */
  public boolean isSSL3OrTLSEnabled()
  {
    return true;
  }
  
  /**
   * @deprecated
   */
  public void setMaximumInputPacketSize(int paramInt)
    throws SSLException
  {
    if (paramInt < 1) {
      throw new SSLException("Invalid packet size.");
    }
    if (paramInt < 16384) {
      throw new SSLException("Packet size is too small.");
    }
    this.sslParamsDelegate.k = paramInt;
  }
  
  /**
   * @deprecated
   */
  public int getMaximumInputPacketSize()
  {
    return this.sslParamsDelegate.k;
  }
  
  /**
   * @deprecated
   */
  public void setRenegotiationAllowed(boolean paramBoolean)
  {
    this.sslParamsDelegate.l = paramBoolean;
  }
  
  /**
   * @deprecated
   */
  public boolean getRenegotiationAllowed()
  {
    return this.sslParamsDelegate.l;
  }
  
  /**
   * @deprecated
   */
  public void addCertificateChainAndKey(byte[][] paramArrayOfByte, byte[] paramArrayOfByte1, char[] paramArrayOfChar)
    throws SSLException
  {
    if (paramArrayOfChar == null)
    {
      X509Certificate[] arrayOfX509Certificate;
      try
      {
        arrayOfX509Certificate = cJ.a(paramArrayOfByte);
      }
      catch (CertificateException localCertificateException)
      {
        throw new SSLException(localCertificateException);
      }
      paramArrayOfChar = retrievePassPhrase(arrayOfX509Certificate);
    }
    this.sslParamsDelegate.f.a(paramArrayOfByte, paramArrayOfByte1, paramArrayOfChar);
  }
  
  /**
   * @deprecated
   */
  public synchronized void addCertificateChainAndKey(X509Certificate[] paramArrayOfX509Certificate, JSAFE_PrivateKey paramJSAFE_PrivateKey)
    throws SSLException
  {
    this.sslParamsDelegate.f.a(paramArrayOfX509Certificate, paramJSAFE_PrivateKey);
  }
  
  /**
   * @deprecated
   */
  public synchronized void addCertificateChainAndKey(X509Certificate[] paramArrayOfX509Certificate, byte[] paramArrayOfByte, char[] paramArrayOfChar)
    throws SSLException
  {
    if (paramArrayOfChar == null) {
      paramArrayOfChar = retrievePassPhrase(paramArrayOfX509Certificate);
    }
    this.sslParamsDelegate.f.a(paramArrayOfX509Certificate, paramArrayOfByte, paramArrayOfChar);
  }
  
  /**
   * @deprecated
   */
  public char[] retrievePassPhrase(X509Certificate[] paramArrayOfX509Certificate)
  {
    return new char[0];
  }
  
  /**
   * @deprecated
   */
  public JSAFE_SecureRandom getRandom()
  {
    return this.sslParamsDelegate.h.b();
  }
  
  /**
   * @deprecated
   */
  public void setRandom(JSAFE_SecureRandom paramJSAFE_SecureRandom)
    throws IllegalArgumentException
  {
    this.sslParamsDelegate.h.a(paramJSAFE_SecureRandom);
  }
  
  /**
   * @deprecated
   */
  public void seedRandom(byte[] paramArrayOfByte)
  {
    this.sslParamsDelegate.h.a(paramArrayOfByte);
  }
  
  /**
   * @deprecated
   */
  public JSAFE_SecureRandom getNewRandom()
    throws SSLException
  {
    return this.sslParamsDelegate.h.a();
  }
  
  /**
   * @deprecated
   */
  public void setClientAuthentication(int paramInt)
    throws SSLException
  {
    this.sslParamsDelegate.j.a(paramInt);
  }
  
  /**
   * @deprecated
   */
  public int getClientAuthentication()
  {
    return this.sslParamsDelegate.j.a();
  }
  
  /**
   * @deprecated
   */
  public void setTruster(Truster paramTruster)
  {
    this.truster = paramTruster;
  }
  
  /**
   * @deprecated
   */
  public Truster getTruster()
  {
    return this.truster;
  }
  
  /**
   * @deprecated
   */
  public void setCertPathValidationAlgorithm(CertPathValidationAlgorithm paramCertPathValidationAlgorithm)
  {
    this.sslParamsDelegate.m = paramCertPathValidationAlgorithm;
  }
  
  /**
   * @deprecated
   */
  public CertPathValidationAlgorithm getCertPathValidationAlgorithm()
  {
    return this.sslParamsDelegate.m;
  }
  
  /**
   * @deprecated
   */
  public void setBuffered(boolean paramBoolean)
  {
    this.buffered = paramBoolean;
  }
  
  /**
   * @deprecated
   */
  public boolean getBuffered()
  {
    return this.buffered;
  }
  
  /**
   * @deprecated
   */
  public static void setDebug(int paramInt)
  {
    cy.a(paramInt);
  }
  
  /**
   * @deprecated
   */
  public static int getDebug()
  {
    return cy.a();
  }
  
  /**
   * @deprecated
   */
  public static boolean getDebugState()
  {
    return (getDebug() & 0x1) != 0;
  }
  
  /**
   * @deprecated
   */
  public static boolean getDebugMultithreaded()
  {
    return (getDebug() & 0x8) != 0;
  }
  
  /**
   * @deprecated
   */
  public static boolean getDebugData()
  {
    return (getDebug() & 0x2) != 0;
  }
  
  /**
   * @deprecated
   */
  public static boolean getDebugExtra()
  {
    return (getDebug() & 0x4) != 0;
  }
  
  /**
   * @deprecated
   */
  public static void setDebugOutput(OutputStream paramOutputStream) {}
  
  /**
   * @deprecated
   */
  public static void setDebugOutput(String paramString, boolean paramBoolean)
    throws FileNotFoundException
  {
    cy.a(paramString, paramBoolean);
  }
  
  /**
   * @deprecated
   */
  public static void closeLogStream() {}
  
  /**
   * @deprecated
   */
  public static PrintStream getDebugOutput()
  {
    return null;
  }
  
  /**
   * @deprecated
   */
  public void addCompatibilityType(CompatibilityType paramCompatibilityType)
  {
    if (!this.compatibilityTypeVector.contains(paramCompatibilityType)) {
      this.compatibilityTypeVector.addElement(paramCompatibilityType);
    }
  }
  
  /**
   * @deprecated
   */
  public void removeCompatibilityType(CompatibilityType paramCompatibilityType)
  {
    if (this.compatibilityTypeVector.contains(paramCompatibilityType)) {
      this.compatibilityTypeVector.removeElement(paramCompatibilityType);
    }
  }
  
  /**
   * @deprecated
   */
  public boolean isCompatibilityTypeSet(CompatibilityType paramCompatibilityType)
  {
    return this.compatibilityTypeVector.contains(paramCompatibilityType);
  }
  
  /**
   * @deprecated
   */
  public void setIgnoreNonFips140CipherSuites(boolean paramBoolean) {}
  
  /**
   * @deprecated
   */
  public FIPS140Mode getFIPS140Mode()
  {
    return FIPS140Mode.lookup(this.sslParamsDelegate.c.getValue());
  }
  
  /**
   * @deprecated
   */
  public FIPS140Role getFIPS140Role()
  {
    return FIPS140Role.lookup(this.sslParamsDelegate.a.b().getValue());
  }
  
  /**
   * @deprecated
   */
  public SuiteBMode getSuiteBMode()
  {
    return this.suiteBMode;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.SSLParams
 * JD-Core Version:    0.7.0.1
 */