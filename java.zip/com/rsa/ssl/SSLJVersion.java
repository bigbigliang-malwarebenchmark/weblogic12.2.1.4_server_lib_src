package com.rsa.ssl;

import java.io.PrintStream;

/**
 * @deprecated
 */
public final class SSLJVersion
{
  /**
   * @deprecated
   */
  public static String getVersionString()
  {
    return com.rsa.jsse.SSLJVersion.getVersionString();
  }
  
  /**
   * @deprecated
   */
  public static String getProductID()
  {
    return com.rsa.jsse.SSLJVersion.getProductID();
  }
  
  /**
   * @deprecated
   */
  public static String getBuiltOn()
  {
    return com.rsa.jsse.SSLJVersion.getBuiltOn();
  }
  
  /**
   * @deprecated
   */
  public static boolean isEval()
  {
    return com.rsa.jsse.SSLJVersion.isEval();
  }
  
  /**
   * @deprecated
   */
  public static boolean isFIPS140Compliant()
  {
    return com.rsa.jsse.SSLJVersion.isFIPS140Compliant();
  }
  
  /**
   * @deprecated
   */
  public static void main(String[] paramArrayOfString)
  {
    System.out.println(getProductID());
    if (isFIPS140Compliant()) {
      System.out.println("FIPS 140 compliant crypto available");
    } else {
      System.out.println("Non-FIPS 140 compliant crypto available");
    }
    System.out.println("Production (non-evaluation) toolkit");
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.SSLJVersion
 * JD-Core Version:    0.7.0.1
 */