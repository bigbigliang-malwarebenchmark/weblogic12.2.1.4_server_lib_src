package com.rsa.ssl;

import com.rsa.jsafe.JSAFE_PrivateKey;
import com.rsa.jsafe.JSAFE_PublicKey;
import com.rsa.jsafe.JSAFE_SecureRandom;
import com.rsa.jsafe.JSAFE_Session;

/**
 * @deprecated
 */
public abstract interface CipherSuite
{
  /**
   * @deprecated
   */
  public static final int SSLV2 = 1;
  /**
   * @deprecated
   */
  public static final int SSLV3 = 2;
  /**
   * @deprecated
   */
  public static final int TLSV1 = 3;
  /**
   * @deprecated
   */
  public static final int TLSV11 = 3;
  /**
   * @deprecated
   */
  public static final int TLSV12 = 3;
  /**
   * @deprecated
   */
  public static final byte[] pad_1 = new byte[0];
  /**
   * @deprecated
   */
  public static final byte[] pad_2 = new byte[0];
  /**
   * @deprecated
   */
  public static final String PKCS1_BLOCK2_PADDING = "PKCS1Block02Pad";
  /**
   * @deprecated
   */
  public static final String PKCS1_BLOCK2_SSL_PADDING = "PKCS1BlockSSLPad";
  
  /**
   * @deprecated
   */
  public abstract void setDeviceSelector(DeviceSelector paramDeviceSelector);
  
  /**
   * @deprecated
   */
  public abstract DeviceSelector getDeviceSelector();
  
  /**
   * @deprecated
   */
  public abstract void setDevice(String paramString);
  
  /**
   * @deprecated
   */
  public abstract void setDeviceSessions(JSAFE_Session[] paramArrayOfJSAFE_Session);
  
  /**
   * @deprecated
   */
  public abstract JSAFE_Session[] getDeviceSessions();
  
  /**
   * @deprecated
   */
  public abstract void closeAllDeviceSessions();
  
  /**
   * @deprecated
   */
  public abstract int setWriteKey(byte[] paramArrayOfByte, int paramInt);
  
  /**
   * @deprecated
   */
  public abstract int setReadKey(byte[] paramArrayOfByte, int paramInt);
  
  /**
   * @deprecated
   */
  public abstract int setMACReadSecret(byte[] paramArrayOfByte, int paramInt);
  
  /**
   * @deprecated
   */
  public abstract int setMACWriteSecret(byte[] paramArrayOfByte, int paramInt);
  
  /**
   * @deprecated
   */
  public abstract void setPrivateKey(byte[] paramArrayOfByte, int paramInt, char[] paramArrayOfChar);
  
  /**
   * @deprecated
   */
  public abstract void setPrivateKey(JSAFE_PrivateKey paramJSAFE_PrivateKey);
  
  /**
   * @deprecated
   */
  public abstract JSAFE_PrivateKey getPrivateKey();
  
  /**
   * @deprecated
   */
  public abstract void setPeerPublicKey(byte[] paramArrayOfByte, int paramInt);
  
  /**
   * @deprecated
   */
  public abstract void setPeerPublicKey(JSAFE_PublicKey paramJSAFE_PublicKey);
  
  /**
   * @deprecated
   */
  public abstract void setSignPublicKey(JSAFE_PublicKey paramJSAFE_PublicKey);
  
  /**
   * @deprecated
   */
  public abstract void setSignPublicKey(byte[] paramArrayOfByte, int paramInt);
  
  /**
   * @deprecated
   */
  public abstract JSAFE_PublicKey getSignPublicKey();
  
  /**
   * @deprecated
   */
  public abstract int encryptBlock(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3);
  
  /**
   * @deprecated
   */
  public abstract int decryptBlock(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3);
  
  /**
   * @deprecated
   */
  public abstract int sign(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, JSAFE_SecureRandom paramJSAFE_SecureRandom);
  
  /**
   * @deprecated
   */
  public abstract boolean verify(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4);
  
  /**
   * @deprecated
   */
  public abstract byte[][] generateKeyPair(JSAFE_SecureRandom paramJSAFE_SecureRandom);
  
  /**
   * @deprecated
   */
  public abstract int encryptAsymmetric(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, JSAFE_SecureRandom paramJSAFE_SecureRandom);
  
  /**
   * @deprecated
   */
  public abstract byte[][] getDHParams(JSAFE_SecureRandom paramJSAFE_SecureRandom);
  
  /**
   * @deprecated
   */
  public abstract byte[] getDHPublicValue(JSAFE_SecureRandom paramJSAFE_SecureRandom);
  
  /**
   * @deprecated
   */
  public abstract byte[] getSharedSecret(JSAFE_SecureRandom paramJSAFE_SecureRandom, byte[] paramArrayOfByte);
  
  /**
   * @deprecated
   */
  public abstract int getPublicKeyStrength();
  
  /**
   * @deprecated
   */
  public abstract int getPrivateKeyStrength();
  
  /**
   * @deprecated
   */
  public abstract void setPrivateKeyStrength(int paramInt);
  
  /**
   * @deprecated
   */
  public abstract int decryptAsymmetric(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3);
  
  /**
   * @deprecated
   */
  public abstract int getSymmetricBlockSize();
  
  /**
   * @deprecated
   */
  public abstract String getSymmetricAlgorithm();
  
  /**
   * @deprecated
   */
  public abstract int getSymmetricKeySize();
  
  /**
   * @deprecated
   */
  public abstract int getIVSize();
  
  /**
   * @deprecated
   */
  public abstract int getMACSize();
  
  /**
   * @deprecated
   */
  public abstract int setWriteIV(byte[] paramArrayOfByte, int paramInt);
  
  /**
   * @deprecated
   */
  public abstract int setReadIV(byte[] paramArrayOfByte, int paramInt);
  
  /**
   * @deprecated
   */
  public abstract byte[] getWriteIV();
  
  /**
   * @deprecated
   */
  public abstract byte[] getReadIV();
  
  /**
   * @deprecated
   */
  public abstract int getEncryptedBufferSize(int paramInt);
  
  /**
   * @deprecated
   */
  public abstract int HMAC(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt3, boolean paramBoolean);
  
  /**
   * @deprecated
   */
  public abstract int hash(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, boolean paramBoolean, long paramLong);
  
  /**
   * @deprecated
   */
  public abstract int MAC(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, byte paramByte, boolean paramBoolean);
  
  /**
   * @deprecated
   */
  public abstract String getCipherSuiteName();
  
  /**
   * @deprecated
   */
  public abstract String getJsseCipherSuiteName(int paramInt);
  
  /**
   * @deprecated
   */
  public abstract String getAsymmetricAlgorithm();
  
  /**
   * @deprecated
   */
  public abstract String getMDAlgorithm();
  
  /**
   * @deprecated
   */
  public abstract boolean isExportable();
  
  /**
   * @deprecated
   */
  public abstract boolean isAnonymous();
  
  /**
   * @deprecated
   */
  public abstract boolean isEphemeral();
  
  /**
   * @deprecated
   */
  public abstract boolean isRSA();
  
  /**
   * @deprecated
   */
  public abstract byte[] getID(int paramInt);
  
  /**
   * @deprecated
   */
  public abstract String getSignAlgorithm();
  
  /**
   * @deprecated
   */
  public abstract CipherSuite makeNewCipher();
  
  /**
   * @deprecated
   */
  public abstract void clearSensitiveData();
  
  /**
   * @deprecated
   */
  public abstract boolean sendServerKeyExchange();
  
  /**
   * @deprecated
   */
  public abstract boolean receiveServerKeyExchange();
  
  /**
   * @deprecated
   */
  public abstract boolean isFips140Supported();
  
  /**
   * @deprecated
   */
  public abstract void setAsymmetricPaddingScheme(String paramString);
  
  /**
   * @deprecated
   */
  public abstract boolean isLegacy();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.CipherSuite
 * JD-Core Version:    0.7.0.1
 */