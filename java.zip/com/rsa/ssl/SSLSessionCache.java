package com.rsa.ssl;

/**
 * @deprecated
 */
public abstract class SSLSessionCache
{
  /**
   * @deprecated
   */
  public abstract void putSession(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  /**
   * @deprecated
   */
  public abstract byte[] getSession(byte[] paramArrayOfByte);
  
  /**
   * @deprecated
   */
  public abstract void removeSession(byte[] paramArrayOfByte);
  
  /**
   * @deprecated
   */
  public void onError(byte[] paramArrayOfByte, SSLSessionCache.ErrorType paramErrorType, String paramString) {}
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.SSLSessionCache
 * JD-Core Version:    0.7.0.1
 */