package com.rsa.ssl;

/**
 * @deprecated
 */
public final class FIPS140Mode
{
  private static final FIPS140Mode[] LOOKUP = new FIPS140Mode[5];
  /**
   * @deprecated
   */
  public static final FIPS140Mode FIPS140_MODE = new FIPS140Mode("FIPS140", 0);
  /**
   * @deprecated
   */
  public static final FIPS140Mode NON_FIPS140_MODE = new FIPS140Mode("NON_FIPS140", 1);
  /**
   * @deprecated
   */
  public static final FIPS140Mode FIPS140_SSL_MODE = new FIPS140Mode("FIPS140_SSL", 2);
  /**
   * @deprecated
   */
  public static final FIPS140Mode FIPS140_ECC_MODE = FIPS140_MODE;
  /**
   * @deprecated
   */
  public static final FIPS140Mode FIPS140_SSL_ECC_MODE = FIPS140_SSL_MODE;
  private int mode;
  private String name;
  
  private FIPS140Mode(String paramString, int paramInt)
  {
    this.mode = paramInt;
    this.name = paramString;
    LOOKUP[paramInt] = this;
  }
  
  /**
   * @deprecated
   */
  public String getName()
  {
    return this.name;
  }
  
  /**
   * @deprecated
   */
  public int getValue()
  {
    return this.mode;
  }
  
  /**
   * @deprecated
   */
  public String toString()
  {
    return this.name;
  }
  
  /**
   * @deprecated
   */
  public static FIPS140Mode lookup(int paramInt)
  {
    return LOOKUP[paramInt];
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.FIPS140Mode
 * JD-Core Version:    0.7.0.1
 */