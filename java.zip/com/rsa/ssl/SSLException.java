package com.rsa.ssl;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * @deprecated
 */
public class SSLException
  extends IOException
{
  /**
   * @deprecated
   */
  public SSLException() {}
  
  /**
   * @deprecated
   */
  public SSLException(String paramString)
  {
    super(paramString);
  }
  
  /**
   * @deprecated
   */
  public SSLException(Throwable paramThrowable)
  {
    super(createStackTraceMessage(paramThrowable));
  }
  
  /**
   * @deprecated
   */
  public SSLException(String paramString, Throwable paramThrowable)
  {
    super(paramString + "   " + createStackTraceMessage(paramThrowable));
  }
  
  private static String createStackTraceMessage(Throwable paramThrowable)
  {
    StringWriter localStringWriter = new StringWriter();
    paramThrowable.printStackTrace(new PrintWriter(localStringWriter));
    return localStringWriter.toString();
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.SSLException
 * JD-Core Version:    0.7.0.1
 */