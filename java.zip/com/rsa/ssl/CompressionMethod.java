package com.rsa.ssl;

/**
 * @deprecated
 */
public abstract interface CompressionMethod
{
  /**
   * @deprecated
   */
  public abstract int compressBlock(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws SSLException;
  
  /**
   * @deprecated
   */
  public abstract int getCompressedBufferSize(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  /**
   * @deprecated
   */
  public abstract int decompressBlock(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws SSLException;
  
  /**
   * @deprecated
   */
  public abstract int getDecompressedBufferSize(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws SSLException;
  
  /**
   * @deprecated
   */
  public abstract String getCompressionMethodName();
  
  /**
   * @deprecated
   */
  public abstract int getID(int paramInt);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.CompressionMethod
 * JD-Core Version:    0.7.0.1
 */