package com.rsa.ssl.ciphers;

import com.rsa.ssl.CipherSuite;

/**
 * @deprecated
 */
public class DH_Anon_With_AES_256_GCM_SHA384
  extends CipherSuiteImple
{
  public static final String CIPHERSUITE_NAME = "DH_Anon_With_AES_256_GCM_SHA384";
  private static final String JSSE_CIPHERSUITE_NAME = createJsseName("TLS", "DH_Anon_With_AES_256_GCM_SHA384");
  public static final CipherSuite INSTANCE = new DH_Anon_With_AES_256_GCM_SHA384();
  
  public DH_Anon_With_AES_256_GCM_SHA384()
  {
    super("DH_Anon_With_AES_256_GCM_SHA384", JSSE_CIPHERSUITE_NAME, "DH", null, "AES256/GCM/NoPad", "SHA384", false, true, false, true);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.ciphers.DH_Anon_With_AES_256_GCM_SHA384
 * JD-Core Version:    0.7.0.1
 */