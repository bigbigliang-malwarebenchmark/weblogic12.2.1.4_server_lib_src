package com.rsa.ssl.ciphers;

import com.rsa.jsafe.JSAFE_PrivateKey;
import com.rsa.jsafe.JSAFE_PublicKey;
import com.rsa.jsafe.JSAFE_SecureRandom;
import com.rsa.jsafe.JSAFE_Session;
import com.rsa.ssl.CipherSuite;
import com.rsa.ssl.DeviceSelector;

public abstract class CipherSuiteImple
  implements CipherSuite
{
  private String signAlgorithm;
  private String symmetricAlgorithm;
  private String mdAlgorithm;
  private String keyExchAlgorithm;
  private boolean exportable;
  private boolean anonymous;
  private boolean ephemeral;
  private boolean fips140Supp;
  private String cipherSuiteName;
  private String jsseCipherSuiteName;
  
  CipherSuiteImple(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    this.cipherSuiteName = paramString1;
    this.jsseCipherSuiteName = paramString2;
    this.signAlgorithm = paramString4;
    this.symmetricAlgorithm = paramString5;
    this.keyExchAlgorithm = paramString3;
    this.mdAlgorithm = paramString6;
    this.exportable = paramBoolean1;
    this.anonymous = paramBoolean2;
    this.ephemeral = paramBoolean3;
    this.fips140Supp = paramBoolean4;
  }
  
  public String getCipherSuiteName()
  {
    return this.cipherSuiteName;
  }
  
  public String getJsseCipherSuiteName(int paramInt)
  {
    return this.jsseCipherSuiteName;
  }
  
  public String getAsymmetricAlgorithm()
  {
    return this.keyExchAlgorithm;
  }
  
  public String getSymmetricAlgorithm()
  {
    return this.symmetricAlgorithm;
  }
  
  public String getSignAlgorithm()
  {
    return this.signAlgorithm;
  }
  
  public String getMDAlgorithm()
  {
    return this.mdAlgorithm;
  }
  
  public boolean isExportable()
  {
    return this.exportable;
  }
  
  public boolean isAnonymous()
  {
    return this.anonymous;
  }
  
  public boolean isEphemeral()
  {
    return this.ephemeral;
  }
  
  public boolean isFips140Supported()
  {
    return this.fips140Supp;
  }
  
  public boolean isRSA()
  {
    return ("RSA".equals(this.keyExchAlgorithm)) || ("RSA".equals(this.signAlgorithm));
  }
  
  public boolean isLegacy()
  {
    return false;
  }
  
  protected static String createJsseName(String paramString1, String paramString2)
  {
    return paramString1 + "_" + paramString2.toUpperCase().replaceFirst("ANON", "anon");
  }
  
  public void setDeviceSelector(DeviceSelector paramDeviceSelector) {}
  
  public DeviceSelector getDeviceSelector()
  {
    return null;
  }
  
  public void setDevice(String paramString) {}
  
  public void setDeviceSessions(JSAFE_Session[] paramArrayOfJSAFE_Session) {}
  
  public JSAFE_Session[] getDeviceSessions()
  {
    return null;
  }
  
  public void closeAllDeviceSessions() {}
  
  public int setWriteKey(byte[] paramArrayOfByte, int paramInt)
  {
    return 0;
  }
  
  public int setReadKey(byte[] paramArrayOfByte, int paramInt)
  {
    return 0;
  }
  
  public int setMACReadSecret(byte[] paramArrayOfByte, int paramInt)
  {
    return 0;
  }
  
  public int setMACWriteSecret(byte[] paramArrayOfByte, int paramInt)
  {
    return 0;
  }
  
  public void setPrivateKey(byte[] paramArrayOfByte, int paramInt, char[] paramArrayOfChar) {}
  
  public void setPrivateKey(JSAFE_PrivateKey paramJSAFE_PrivateKey) {}
  
  public JSAFE_PrivateKey getPrivateKey()
  {
    return null;
  }
  
  public void setPeerPublicKey(byte[] paramArrayOfByte, int paramInt) {}
  
  public void setPeerPublicKey(JSAFE_PublicKey paramJSAFE_PublicKey) {}
  
  public void setSignPublicKey(JSAFE_PublicKey paramJSAFE_PublicKey) {}
  
  public void setSignPublicKey(byte[] paramArrayOfByte, int paramInt) {}
  
  public JSAFE_PublicKey getSignPublicKey()
  {
    return null;
  }
  
  public int encryptBlock(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    return 0;
  }
  
  public int decryptBlock(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    return 0;
  }
  
  public int sign(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, JSAFE_SecureRandom paramJSAFE_SecureRandom)
  {
    return 0;
  }
  
  public boolean verify(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4)
  {
    return false;
  }
  
  public byte[][] generateKeyPair(JSAFE_SecureRandom paramJSAFE_SecureRandom)
  {
    return (byte[][])null;
  }
  
  public int encryptAsymmetric(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, JSAFE_SecureRandom paramJSAFE_SecureRandom)
  {
    return 0;
  }
  
  public byte[][] getDHParams(JSAFE_SecureRandom paramJSAFE_SecureRandom)
  {
    return (byte[][])null;
  }
  
  public byte[] getDHPublicValue(JSAFE_SecureRandom paramJSAFE_SecureRandom)
  {
    return null;
  }
  
  public byte[] getSharedSecret(JSAFE_SecureRandom paramJSAFE_SecureRandom, byte[] paramArrayOfByte)
  {
    return null;
  }
  
  public int getPublicKeyStrength()
  {
    return 0;
  }
  
  public int getPrivateKeyStrength()
  {
    return 0;
  }
  
  public void setPrivateKeyStrength(int paramInt) {}
  
  public int decryptAsymmetric(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    return 0;
  }
  
  public int getSymmetricBlockSize()
  {
    return 0;
  }
  
  public int getSymmetricKeySize()
  {
    return 0;
  }
  
  public int getIVSize()
  {
    return 0;
  }
  
  public int getMACSize()
  {
    return 0;
  }
  
  public int setWriteIV(byte[] paramArrayOfByte, int paramInt)
  {
    return 0;
  }
  
  public int setReadIV(byte[] paramArrayOfByte, int paramInt)
  {
    return 0;
  }
  
  public byte[] getWriteIV()
  {
    return null;
  }
  
  public byte[] getReadIV()
  {
    return null;
  }
  
  public int getEncryptedBufferSize(int paramInt)
  {
    return 0;
  }
  
  public int HMAC(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt3, boolean paramBoolean)
  {
    return 0;
  }
  
  public int hash(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, boolean paramBoolean, long paramLong)
  {
    return 0;
  }
  
  public int MAC(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, byte paramByte, boolean paramBoolean)
  {
    return 0;
  }
  
  public byte[] getID(int paramInt)
  {
    return null;
  }
  
  public CipherSuite makeNewCipher()
  {
    return null;
  }
  
  public void clearSensitiveData() {}
  
  public boolean sendServerKeyExchange()
  {
    return false;
  }
  
  public boolean receiveServerKeyExchange()
  {
    return false;
  }
  
  public void setAsymmetricPaddingScheme(String paramString) {}
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.ciphers.CipherSuiteImple
 * JD-Core Version:    0.7.0.1
 */