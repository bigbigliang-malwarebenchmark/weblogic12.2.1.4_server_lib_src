package com.rsa.ssl.ciphers;

import com.rsa.ssl.CipherSuite;

/**
 * @deprecated
 */
public final class DH_Anon_With_AES_256_CBC_SHA256
  extends CipherSuiteImple
{
  public static final String CIPHERSUITE_NAME = "DH_Anon_With_AES_256_CBC_SHA256";
  private static final String JSSE_CIPHERSUITE_NAME = createJsseName("TLS", "DH_Anon_With_AES_256_CBC_SHA256");
  public static final CipherSuite INSTANCE = new DH_Anon_With_AES_256_CBC_SHA256();
  
  public DH_Anon_With_AES_256_CBC_SHA256()
  {
    super("DH_Anon_With_AES_256_CBC_SHA256", JSSE_CIPHERSUITE_NAME, "DH", null, "AES256/CBC/NoPad", "SHA256", false, true, false, true);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.ciphers.DH_Anon_With_AES_256_CBC_SHA256
 * JD-Core Version:    0.7.0.1
 */