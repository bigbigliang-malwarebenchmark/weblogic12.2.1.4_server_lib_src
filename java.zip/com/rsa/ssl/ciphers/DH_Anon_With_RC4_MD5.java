package com.rsa.ssl.ciphers;

import com.rsa.ssl.CipherSuite;

/**
 * @deprecated
 */
public final class DH_Anon_With_RC4_MD5
  extends CipherSuiteImple
{
  public static final String CIPHERSUITE_NAME = "DH_Anon_With_RC4_MD5";
  private static final String JSSE_CIPHERSUITE_NAME = "SSL_DH_anon_WITH_RC4_128_MD5";
  public static final CipherSuite INSTANCE = new DH_Anon_With_RC4_MD5();
  
  public DH_Anon_With_RC4_MD5()
  {
    super("DH_Anon_With_RC4_MD5", "SSL_DH_anon_WITH_RC4_128_MD5", "DH", null, "RC4", "MD5", false, true, false, false);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.ciphers.DH_Anon_With_RC4_MD5
 * JD-Core Version:    0.7.0.1
 */