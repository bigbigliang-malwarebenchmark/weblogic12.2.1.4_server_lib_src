package com.rsa.ssl.ciphers;

import com.rsa.ssl.CipherSuite;

public final class DHE_RSA_With_AES_256_CBC_SHA256
  extends CipherSuiteImple
{
  public static final String CIPHERSUITE_NAME = "DHE_RSA_With_AES_256_CBC_SHA256";
  private static final String JSSE_CIPHERSUITE_NAME = createJsseName("TLS", "DHE_RSA_With_AES_256_CBC_SHA256");
  public static final CipherSuite INSTANCE = new DHE_RSA_With_AES_256_CBC_SHA256();
  
  public DHE_RSA_With_AES_256_CBC_SHA256()
  {
    super("DHE_RSA_With_AES_256_CBC_SHA256", JSSE_CIPHERSUITE_NAME, "DH", "RSA", "AES256/CBC/NoPad", "SHA256", false, false, true, true);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.ciphers.DHE_RSA_With_AES_256_CBC_SHA256
 * JD-Core Version:    0.7.0.1
 */