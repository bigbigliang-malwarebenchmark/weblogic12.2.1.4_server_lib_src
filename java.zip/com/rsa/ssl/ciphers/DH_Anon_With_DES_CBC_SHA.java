package com.rsa.ssl.ciphers;

import com.rsa.ssl.CipherSuite;

/**
 * @deprecated
 */
public final class DH_Anon_With_DES_CBC_SHA
  extends CipherSuiteImple
{
  public static final String CIPHERSUITE_NAME = "DH_Anon_With_DES_CBC_SHA";
  private static final String JSSE_CIPHERSUITE_NAME = createJsseName("SSL", "DH_Anon_With_DES_CBC_SHA");
  public static final CipherSuite INSTANCE = new DH_Anon_With_DES_CBC_SHA();
  
  public DH_Anon_With_DES_CBC_SHA()
  {
    super("DH_Anon_With_DES_CBC_SHA", JSSE_CIPHERSUITE_NAME, "DH", null, "DES/CBC/NoPad", "SHA1", false, true, false, true);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.ciphers.DH_Anon_With_DES_CBC_SHA
 * JD-Core Version:    0.7.0.1
 */