package com.rsa.ssl;

import java.util.Hashtable;

/**
 * @deprecated
 */
public class DeviceSelector
{
  private final Hashtable deviceMap;
  private final String defaultDevice;
  
  /**
   * @deprecated
   */
  public DeviceSelector()
  {
    this("Java");
  }
  
  /**
   * @deprecated
   */
  public DeviceSelector(String paramString)
  {
    this(new Hashtable(), paramString);
  }
  
  private DeviceSelector(Hashtable paramHashtable, String paramString)
  {
    this.deviceMap = paramHashtable;
    this.defaultDevice = paramString;
  }
  
  /**
   * @deprecated
   */
  public void setDevice(AlgorithmType paramAlgorithmType, String paramString)
  {
    this.deviceMap.put(paramAlgorithmType, paramString);
  }
  
  /**
   * @deprecated
   */
  public String getDevice(AlgorithmType paramAlgorithmType)
  {
    String str = (String)this.deviceMap.get(paramAlgorithmType);
    return str == null ? this.defaultDevice : str;
  }
  
  /**
   * @deprecated
   */
  public String getDefaultDevice()
  {
    return this.defaultDevice;
  }
  
  /**
   * @deprecated
   */
  public Object clone()
  {
    Hashtable localHashtable = (Hashtable)this.deviceMap.clone();
    return new DeviceSelector(localHashtable, this.defaultDevice);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.DeviceSelector
 * JD-Core Version:    0.7.0.1
 */