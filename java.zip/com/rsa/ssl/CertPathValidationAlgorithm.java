package com.rsa.ssl;

/**
 * @deprecated
 */
public final class CertPathValidationAlgorithm
{
  /**
   * @deprecated
   */
  public static final CertPathValidationAlgorithm X509V1 = new CertPathValidationAlgorithm("X509");
  /**
   * @deprecated
   */
  public static final CertPathValidationAlgorithm PKIX = new CertPathValidationAlgorithm("PKIX");
  /**
   * @deprecated
   */
  public static final CertPathValidationAlgorithm PKIX_SUITEB = new CertPathValidationAlgorithm("PKIX-SuiteB");
  /**
   * @deprecated
   */
  public static final CertPathValidationAlgorithm PKIX_SUITEBTLS = new CertPathValidationAlgorithm("PKIX-SuiteBTLS");
  private final String name;
  
  private CertPathValidationAlgorithm(String paramString)
  {
    this.name = paramString;
  }
  
  /**
   * @deprecated
   */
  public String toString()
  {
    return this.name;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.CertPathValidationAlgorithm
 * JD-Core Version:    0.7.0.1
 */