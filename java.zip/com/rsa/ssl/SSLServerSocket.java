package com.rsa.ssl;

import com.rsa.sslj.x.aT;
import com.rsa.sslj.x.cD;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.nio.channels.ServerSocketChannel;

/**
 * @deprecated
 */
public final class SSLServerSocket
  extends ServerSocket
{
  private SSLParams params;
  private javax.net.ssl.SSLServerSocket delegate;
  
  /**
   * @deprecated
   */
  public SSLServerSocket(int paramInt, SSLParams paramSSLParams)
    throws IOException
  {
    this.params = paramSSLParams;
    this.delegate = cD.a(paramInt, paramSSLParams.sslParamsDelegate);
  }
  
  /**
   * @deprecated
   */
  public SSLServerSocket(int paramInt1, int paramInt2, SSLParams paramSSLParams)
    throws IOException
  {
    this.params = paramSSLParams;
    this.delegate = cD.a(paramInt1, paramInt2, paramSSLParams.sslParamsDelegate);
  }
  
  /**
   * @deprecated
   */
  public SSLServerSocket(int paramInt1, int paramInt2, InetAddress paramInetAddress, SSLParams paramSSLParams)
    throws IOException
  {
    this.params = paramSSLParams;
    this.delegate = cD.a(paramInt1, paramInt2, paramInetAddress, paramSSLParams.sslParamsDelegate);
  }
  
  /**
   * @deprecated
   */
  public Socket accept()
    throws IOException
  {
    return new SSLSocket((aT)this.delegate.accept(), this.params);
  }
  
  /**
   * @deprecated
   */
  public InetAddress getInetAddress()
  {
    return this.delegate.getInetAddress();
  }
  
  /**
   * @deprecated
   */
  public int getLocalPort()
  {
    return this.delegate.getLocalPort();
  }
  
  /**
   * @deprecated
   */
  public void setParams(SSLParams paramSSLParams)
  {
    this.params = paramSSLParams;
  }
  
  /**
   * @deprecated
   */
  public void close()
    throws IOException
  {
    if (this.delegate != null) {
      this.delegate.close();
    }
  }
  
  /**
   * @deprecated
   */
  public void bind(SocketAddress paramSocketAddress, int paramInt)
    throws IOException
  {
    this.delegate.bind(paramSocketAddress, paramInt);
  }
  
  /**
   * @deprecated
   */
  public void bind(SocketAddress paramSocketAddress)
    throws IOException
  {
    this.delegate.bind(paramSocketAddress);
  }
  
  /**
   * @deprecated
   */
  public ServerSocketChannel getChannel()
  {
    return this.delegate.getChannel();
  }
  
  /**
   * @deprecated
   */
  public SocketAddress getLocalSocketAddress()
  {
    return this.delegate.getLocalSocketAddress();
  }
  
  /**
   * @deprecated
   */
  public synchronized int getReceiveBufferSize()
    throws SocketException
  {
    return this.delegate.getReceiveBufferSize();
  }
  
  /**
   * @deprecated
   */
  public boolean getReuseAddress()
    throws SocketException
  {
    return this.delegate.getReuseAddress();
  }
  
  /**
   * @deprecated
   */
  public synchronized int getSoTimeout()
    throws IOException
  {
    return this.delegate.getSoTimeout();
  }
  
  /**
   * @deprecated
   */
  public boolean isBound()
  {
    return this.delegate.isBound();
  }
  
  /**
   * @deprecated
   */
  public boolean isClosed()
  {
    return this.delegate.isClosed();
  }
  
  /**
   * @deprecated
   */
  public void setPerformancePreferences(int paramInt1, int paramInt2, int paramInt3)
  {
    this.delegate.setPerformancePreferences(paramInt1, paramInt2, paramInt3);
  }
  
  /**
   * @deprecated
   */
  public synchronized void setReceiveBufferSize(int paramInt)
    throws SocketException
  {
    this.delegate.setReceiveBufferSize(paramInt);
  }
  
  /**
   * @deprecated
   */
  public void setReuseAddress(boolean paramBoolean)
    throws SocketException
  {
    this.delegate.setReuseAddress(paramBoolean);
  }
  
  /**
   * @deprecated
   */
  public synchronized void setSoTimeout(int paramInt)
    throws SocketException
  {
    this.delegate.setSoTimeout(paramInt);
  }
  
  /**
   * @deprecated
   */
  public String toString()
  {
    return this.delegate.toString();
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.SSLServerSocket
 * JD-Core Version:    0.7.0.1
 */