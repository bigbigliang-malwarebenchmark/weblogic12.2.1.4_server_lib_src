package com.rsa.ssl;

import com.rsa.certj.cert.CertificateException;
import com.rsa.certj.cert.X509Certificate;
import com.rsa.jsafe.JSAFE_Exception;
import com.rsa.jsafe.JSAFE_PrivateKey;
import com.rsa.jsafe.JSAFE_SecretKey;
import com.rsa.jsafe.JSAFE_SecureRandom;
import com.rsa.jsafe.JSAFE_SymmetricCipher;
import com.rsa.sslj.x.cu;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * @deprecated
 */
public final class SSLUtils
{
  /**
   * @deprecated
   */
  public static X509Certificate loadCertificate(String paramString)
    throws SSLException
  {
    return loadCertificate(new File(paramString));
  }
  
  /**
   * @deprecated
   */
  public static X509Certificate loadCertificate(File paramFile)
    throws SSLException
  {
    FileInputStream localFileInputStream;
    try
    {
      localFileInputStream = new FileInputStream(paramFile);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      throw new SSLException(localFileNotFoundException.getMessage());
    }
    return loadCertificate(localFileInputStream);
  }
  
  /**
   * @deprecated
   */
  public static X509Certificate loadCertificate(InputStream paramInputStream)
    throws SSLException
  {
    X509Certificate localX509Certificate;
    try
    {
      byte[] arrayOfByte = new byte[paramInputStream.available()];
      paramInputStream.read(arrayOfByte);
      localX509Certificate = new X509Certificate(arrayOfByte, 0, 0);
      paramInputStream.close();
    }
    catch (IOException localIOException)
    {
      throw new SSLException(localIOException.getMessage());
    }
    catch (CertificateException localCertificateException)
    {
      throw new SSLException(localCertificateException.getMessage());
    }
    return localX509Certificate;
  }
  
  /**
   * @deprecated
   */
  public static X509Certificate[] loadCertificateChain(String paramString)
    throws SSLException
  {
    return loadCertificateChain(new File(paramString));
  }
  
  /**
   * @deprecated
   */
  public static X509Certificate[] loadCertificateChain(File paramFile)
    throws SSLException
  {
    FileInputStream localFileInputStream;
    try
    {
      localFileInputStream = new FileInputStream(paramFile);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      throw new SSLException(localFileNotFoundException.getMessage());
    }
    return loadCertificateChain(localFileInputStream);
  }
  
  /**
   * @deprecated
   */
  public static X509Certificate[] loadCertificateChain(InputStream paramInputStream)
    throws SSLException
  {
    byte[] arrayOfByte;
    try
    {
      arrayOfByte = new byte[paramInputStream.available()];
      paramInputStream.read(arrayOfByte);
      paramInputStream.close();
    }
    catch (IOException localIOException)
    {
      throw new SSLException("Can not load certificate: read error");
    }
    ArrayList localArrayList = new ArrayList(10);
    try
    {
      i = 0;
      do
      {
        X509Certificate localX509Certificate1 = new X509Certificate(arrayOfByte, i, 0);
        localArrayList.add(localX509Certificate1);
        i = X509Certificate.getNextBEROffset(arrayOfByte, i);
      } while (i < arrayOfByte.length);
    }
    catch (CertificateException localCertificateException1)
    {
      try
      {
        int i = 4;
        do
        {
          X509Certificate localX509Certificate2 = new X509Certificate(arrayOfByte, i + 4, 0);
          localArrayList.add(localX509Certificate2);
          i = X509Certificate.getNextBEROffset(arrayOfByte, i + 4);
        } while (i < arrayOfByte.length);
      }
      catch (CertificateException localCertificateException2)
      {
        throw new SSLException("Can not load certificateChain");
      }
    }
    X509Certificate[] arrayOfX509Certificate = new X509Certificate[localArrayList.size()];
    return (X509Certificate[])localArrayList.toArray(arrayOfX509Certificate);
  }
  
  /**
   * @deprecated
   */
  public static X509Certificate[] loadCertificateDirectory(String paramString)
    throws SSLException
  {
    return loadCertificateDirectory(new File(paramString));
  }
  
  /**
   * @deprecated
   */
  public static X509Certificate[] loadCertificateDirectory(File paramFile)
    throws SSLException
  {
    if (!paramFile.isDirectory()) {
      throw new SSLException(paramFile + " is not a directory");
    }
    ArrayList localArrayList = new ArrayList();
    String[] arrayOfString = paramFile.list();
    for (int i = 0; i < arrayOfString.length; i++) {
      try
      {
        X509Certificate localX509Certificate = loadCertificate(paramFile.toString() + File.separator + arrayOfString[i]);
        localArrayList.add(localX509Certificate);
      }
      catch (SSLException localSSLException) {}
    }
    X509Certificate[] arrayOfX509Certificate = new X509Certificate[localArrayList.size()];
    return (X509Certificate[])localArrayList.toArray(arrayOfX509Certificate);
  }
  
  /**
   * @deprecated
   */
  public static byte[] loadKey(String paramString)
    throws SSLException
  {
    return loadKey(new File(paramString));
  }
  
  /**
   * @deprecated
   */
  public static byte[] loadKey(File paramFile)
    throws SSLException
  {
    FileInputStream localFileInputStream;
    try
    {
      localFileInputStream = new FileInputStream(paramFile);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      throw new SSLException(localFileNotFoundException.getMessage());
    }
    return loadKey(localFileInputStream);
  }
  
  /**
   * @deprecated
   */
  public static byte[] loadKey(InputStream paramInputStream)
    throws SSLException
  {
    try
    {
      byte[] arrayOfByte1 = new byte[1024];
      int i = 0;
      int j;
      while ((j = paramInputStream.read(arrayOfByte1, i, arrayOfByte1.length - i)) != -1)
      {
        i += j;
        if (i == arrayOfByte1.length)
        {
          arrayOfByte2 = arrayOfByte1;
          arrayOfByte1 = new byte[arrayOfByte2.length * 2];
          System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, arrayOfByte2.length);
        }
      }
      byte[] arrayOfByte2 = new byte[i];
      System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i);
      paramInputStream.close();
      return arrayOfByte2;
    }
    catch (IOException localIOException)
    {
      throw new SSLException("Could not load key.");
    }
  }
  
  /**
   * @deprecated
   */
  public static void saveKey(JSAFE_PrivateKey paramJSAFE_PrivateKey, String paramString1, char[] paramArrayOfChar, JSAFE_SecureRandom paramJSAFE_SecureRandom, String paramString2)
    throws SSLException
  {
    saveKey(paramJSAFE_PrivateKey, new File(paramString1), paramArrayOfChar, paramJSAFE_SecureRandom, paramString2);
  }
  
  /**
   * @deprecated
   */
  public static void saveKey(JSAFE_PrivateKey paramJSAFE_PrivateKey, File paramFile, char[] paramArrayOfChar, JSAFE_SecureRandom paramJSAFE_SecureRandom, String paramString)
    throws SSLException
  {
    try
    {
      JSAFE_SymmetricCipher localJSAFE_SymmetricCipher = JSAFE_SymmetricCipher.getInstance("PBE/SHA1/RC4/PKCS12V1PBE-5-128", paramString);
      localJSAFE_SymmetricCipher.generateSalt(paramJSAFE_SecureRandom);
      JSAFE_SecretKey localJSAFE_SecretKey = localJSAFE_SymmetricCipher.getBlankKey();
      localJSAFE_SecretKey.setPassword(paramArrayOfChar, 0, paramArrayOfChar.length);
      cu.a(paramArrayOfChar);
      localJSAFE_SymmetricCipher.encryptInit(localJSAFE_SecretKey, paramJSAFE_SecureRandom);
      byte[] arrayOfByte = localJSAFE_SymmetricCipher.wrapPrivateKey(paramJSAFE_PrivateKey, true);
      FileOutputStream localFileOutputStream = new FileOutputStream(paramFile);
      localFileOutputStream.write(arrayOfByte);
      localFileOutputStream.close();
    }
    catch (IOException localIOException)
    {
      throw new SSLException("Could not save key");
    }
    catch (JSAFE_Exception localJSAFE_Exception)
    {
      throw new SSLException("An error occurred while saving the private key: " + localJSAFE_Exception.getMessage());
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.ssl.SSLUtils
 * JD-Core Version:    0.7.0.1
 */