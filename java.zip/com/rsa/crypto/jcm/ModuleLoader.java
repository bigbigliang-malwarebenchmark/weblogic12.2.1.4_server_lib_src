package com.rsa.crypto.jcm;

import com.rsa.crypto.CryptoException;
import com.rsa.crypto.ModuleConfig;
import com.rsa.crypto.ModuleProperties;
import com.rsa.crypto.SelfTestEventListener;
import com.rsa.jcm.f.a;
import com.rsa.jcm.f.cz;
import com.rsa.jcm.f.da;
import com.rsa.jcm.f.dc;
import com.rsa.jcm.f.dg;
import com.rsa.jcm.f.dg.a;
import com.rsa.jcm.f.dg.b;
import com.rsa.jcm.f.dm;
import java.io.File;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.ExecutorService;

public final class ModuleLoader
{
  private static final String a = "Jar file has to be passed in for FIPS140";
  private static final String b = "Module already loaded";
  private static a c;
  
  public static boolean isFIPS140Module()
  {
    return cz.ai();
  }
  
  public static synchronized ModuleConfig load()
  {
    
    if (c != null) {
      throw new CryptoException("Module already loaded");
    }
    c = new a();
    return c;
  }
  
  public static void ensureSelfTestsPassed() {}
  
  private static synchronized void a(File paramFile1, SelfTestEventListener paramSelfTestEventListener, ExecutorService paramExecutorService, File paramFile2)
  {
    dm.b(paramFile1, paramSelfTestEventListener, paramExecutorService, paramFile2 == null ? null : new dc(b(), paramFile2));
  }
  
  private static Class<?> a()
  {
    try
    {
      return Class.forName("com.rsa.cryptoj.jcm.CryptoJModulePropertiesFactory");
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new Error("Required Crypto-J jar not found.", localClassNotFoundException);
    }
  }
  
  private static dg b()
  {
    if (!isFIPS140Module()) {
      return null;
    }
    return c() ? new dg.a() : new dg.b();
  }
  
  private static boolean c()
  {
    try
    {
      Class.forName("android.app.Activity");
      return true;
    }
    catch (ClassNotFoundException localClassNotFoundException) {}
    return false;
  }
  
  static
  {
    if (isFIPS140Module()) {
      try
      {
        Class localClass = a();
        Method localMethod = localClass.getDeclaredMethod("getModuleProperties", new Class[] { Integer.TYPE, Boolean.TYPE });
        ModuleProperties localModuleProperties = (ModuleProperties)localMethod.invoke(null, new Object[] { Integer.valueOf(1), Boolean.valueOf(isFIPS140Module()) });
        File localFile1 = localModuleProperties.getJarFile();
        if (localFile1 == null) {
          throw new CryptoException("Jar file has to be passed in for FIPS140");
        }
        File localFile2 = localModuleProperties.getKatStatusFile();
        a(localFile1, localModuleProperties.getListener(), localModuleProperties.getSelfTestExecutor(), localFile2);
        int i = localModuleProperties.getLevel();
        da.j(i);
        List localList = localModuleProperties.getAdditionalAlgorithms();
        da.a(localList);
      }
      catch (Exception localException)
      {
        throw new CryptoException(localException);
      }
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.rsa.crypto.jcm.ModuleLoader
 * JD-Core Version:    0.7.0.1
 */