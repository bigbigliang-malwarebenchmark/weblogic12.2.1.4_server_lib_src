/*   1:    */ package com.oracle.core.registryhelper.utils;
/*   2:    */ 
/*   3:    */ import com.oracle.core.registryhelper.RegistryListener;
/*   4:    */ import java.io.Serializable;
/*   5:    */ import java.util.Collection;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.HashSet;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.Set;
/*  11:    */ 
/*  12:    */ public class MonitorableMap<K, V>
/*  13:    */   implements Map<K, V>, Serializable
/*  14:    */ {
/*  15:    */   private static final long serialVersionUID = -7912892707014214989L;
/*  16:    */   private final Map<K, V> backingMap;
/*  17: 30 */   private final HashSet<RegistryListener<Map.Entry<K, V>>> listeners = new HashSet();
/*  18:    */   
/*  19:    */   public MonitorableMap()
/*  20:    */   {
/*  21: 34 */     this(new HashMap());
/*  22:    */   }
/*  23:    */   
/*  24:    */   public MonitorableMap(Map<K, V> paramBackingMap)
/*  25:    */   {
/*  26: 38 */     if (paramBackingMap == null) {
/*  27: 39 */       throw new NullPointerException();
/*  28:    */     }
/*  29: 42 */     this.backingMap = paramBackingMap;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public synchronized void addListener(RegistryListener<Map.Entry<K, V>> listener)
/*  33:    */   {
/*  34: 52 */     if (listener == null) {
/*  35: 53 */       return;
/*  36:    */     }
/*  37: 56 */     Set<Map.Entry<K, V>> sets = this.backingMap.entrySet();
/*  38: 57 */     listener.init(sets);
/*  39:    */     
/*  40: 59 */     this.listeners.add(listener);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public synchronized void removeListener(RegistryListener<Map.Entry<K, V>> listener)
/*  44:    */   {
/*  45: 63 */     this.listeners.remove(listener);
/*  46:    */   }
/*  47:    */   
/*  48:    */   private void notifyRemove(Map.Entry<K, V> removed)
/*  49:    */   {
/*  50: 67 */     for (RegistryListener<Map.Entry<K, V>> listener : this.listeners) {
/*  51: 68 */       listener.removed(removed);
/*  52:    */     }
/*  53:    */   }
/*  54:    */   
/*  55:    */   private void notifyAdd(Map.Entry<K, V> added)
/*  56:    */   {
/*  57: 73 */     for (RegistryListener<Map.Entry<K, V>> listener : this.listeners) {
/*  58: 74 */       listener.added(added);
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   private void notifyModify(Map.Entry<K, V> oldValue, Map.Entry<K, V> newValue)
/*  63:    */   {
/*  64: 79 */     for (RegistryListener<Map.Entry<K, V>> listener : this.listeners) {
/*  65: 80 */       listener.modified(oldValue, newValue);
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   public synchronized void clear()
/*  70:    */   {
/*  71: 85 */     for (Map.Entry<K, V> entry : this.backingMap.entrySet()) {
/*  72: 86 */       notifyRemove(entry);
/*  73:    */     }
/*  74: 89 */     this.backingMap.clear();
/*  75:    */   }
/*  76:    */   
/*  77:    */   public boolean containsKey(Object key)
/*  78:    */   {
/*  79: 93 */     return this.backingMap.containsKey(key);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public boolean containsValue(Object value)
/*  83:    */   {
/*  84: 97 */     return this.backingMap.containsValue(value);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public Set<Map.Entry<K, V>> entrySet()
/*  88:    */   {
/*  89:101 */     return this.backingMap.entrySet();
/*  90:    */   }
/*  91:    */   
/*  92:    */   public V get(Object key)
/*  93:    */   {
/*  94:105 */     return this.backingMap.get(key);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean isEmpty()
/*  98:    */   {
/*  99:109 */     return this.backingMap.isEmpty();
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Set<K> keySet()
/* 103:    */   {
/* 104:113 */     return this.backingMap.keySet();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public V put(K key, V value)
/* 108:    */   {
/* 109:117 */     boolean isModify = false;
/* 110:118 */     Map.Entry<K, V> oldValue = null;
/* 111:119 */     K fKey = key;
/* 112:121 */     if (this.backingMap.containsKey(key))
/* 113:    */     {
/* 114:122 */       isModify = true;
/* 115:    */       
/* 116:124 */       V fOldValue = this.backingMap.get(key);
/* 117:    */       
/* 118:126 */       oldValue = new MonitorableMap.1(this, fKey, fOldValue);
/* 119:    */     }
/* 120:142 */     V fNewValue = value;
/* 121:143 */     Map.Entry<K, V> newValue = new MonitorableMap.2(this, fKey, fNewValue);
/* 122:159 */     if (isModify) {
/* 123:160 */       notifyModify(oldValue, newValue);
/* 124:    */     } else {
/* 125:163 */       notifyAdd(newValue);
/* 126:    */     }
/* 127:166 */     return this.backingMap.put(key, value);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public synchronized void putAll(Map<? extends K, ? extends V> t)
/* 131:    */   {
/* 132:170 */     if (t == null) {
/* 133:170 */       return;
/* 134:    */     }
/* 135:172 */     for (Map.Entry<? extends K, ? extends V> entry : t.entrySet()) {
/* 136:173 */       put(entry.getKey(), entry.getValue());
/* 137:    */     }
/* 138:    */   }
/* 139:    */   
/* 140:    */   public synchronized V remove(Object key)
/* 141:    */   {
/* 142:179 */     boolean contains = this.backingMap.containsKey(key);
/* 143:180 */     if (contains)
/* 144:    */     {
/* 145:181 */       Object fKey = key;
/* 146:182 */       V fValue = this.backingMap.get(key);
/* 147:    */       
/* 148:184 */       notifyRemove(new MonitorableMap.3(this, fKey, fValue));
/* 149:    */     }
/* 150:201 */     return this.backingMap.remove(key);
/* 151:    */   }
/* 152:    */   
/* 153:    */   public int size()
/* 154:    */   {
/* 155:205 */     return this.backingMap.size();
/* 156:    */   }
/* 157:    */   
/* 158:    */   public Collection<V> values()
/* 159:    */   {
/* 160:209 */     return this.backingMap.values();
/* 161:    */   }
/* 162:    */   
/* 163:    */   public String toString()
/* 164:    */   {
/* 165:213 */     return 
/* 166:214 */       "MonitorableMap(" + this.backingMap + "," + System.identityHashCode(this) + ")";
/* 167:    */   }
/* 168:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.core.registryhelper.utils.MonitorableMap
 * JD-Core Version:    0.7.0.1
 */