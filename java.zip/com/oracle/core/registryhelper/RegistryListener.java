package com.oracle.core.registryhelper;

import java.util.Collection;

public abstract interface RegistryListener<T>
{
  public abstract void init(Collection<T> paramCollection);
  
  public abstract void added(T paramT);
  
  public abstract void removed(T paramT);
  
  public abstract void modified(T paramT1, T paramT2);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.core.registryhelper.RegistryListener
 * JD-Core Version:    0.7.0.1
 */