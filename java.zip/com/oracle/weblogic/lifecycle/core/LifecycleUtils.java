/*   1:    */ package com.oracle.weblogic.lifecycle.core;
/*   2:    */ 
/*   3:    */ import com.oracle.weblogic.lifecycle.config.LifecycleConfigUtil;
/*   4:    */ import java.lang.reflect.Method;
/*   5:    */ import java.security.AccessController;
/*   6:    */ import weblogic.management.configuration.LifecycleManagerConfigMBean;
/*   7:    */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*   8:    */ import weblogic.security.service.PrivilegedActions;
/*   9:    */ 
/*  10:    */ public class LifecycleUtils
/*  11:    */ {
/*  12:    */   static final String WLSTYPE = "wls";
/*  13:    */   static final String OTDTYPE = "otd";
/*  14:    */   static final String DB = "database";
/*  15:    */   static final String OOB = "oob";
/*  16:    */   static final String SOURCE = "source";
/*  17:    */   static final String OP_TYPE = "operationtype";
/*  18:    */   static final String PHASE = "phase";
/*  19:    */   static final String PARTITION_SET = "partitionSet";
/*  20:    */   static final String ORIGINATING_PARTITION = "originatingPartition";
/*  21:    */   static final String NAME = "name";
/*  22:    */   static final String TYPE = "type";
/*  23:    */   static final String HOSTNAME = "hostname";
/*  24:    */   static final String PORT = "port";
/*  25:    */   static final String ID = "id";
/*  26:    */   static final String DOMAIN = "DOMAIN";
/*  27:    */   static final String OTDLIST = "otdlist";
/*  28:    */   static final String MANAGEDSERVER = "managedserver";
/*  29:    */   static final String ADDRESS = "address";
/*  30:    */   static final String IS_DELETE_RUNTIME = "isDeleteRuntime";
/*  31:    */   public static final String SOURCE_WLS = "wls";
/*  32:    */   private static final int DEFAULT_PERIODIC_SYNC_INTERVAL_IN_HOURS = 2;
/*  33:    */   private static final long DEFAULT_PROPAGATION_ACTIVATION_TIMEOUT = 180000L;
/*  34:    */   private static final long DEFAULT_SERVER_RUNTIME_TIMEOUT = 600000L;
/*  35:    */   
/*  36:    */   public static boolean isAppServer()
/*  37:    */   {
/*  38: 59 */     return LifecycleConfigUtil.isAppServer();
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static boolean isDebugEnabled()
/*  42:    */   {
/*  43: 68 */     return LifecycleConfigUtil.isDebugEnabled();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static void debug(String msg)
/*  47:    */   {
/*  48: 78 */     LifecycleConfigUtil.debug(msg, null);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static void debug(String msg, Throwable th)
/*  52:    */   {
/*  53: 89 */     LifecycleConfigUtil.debug(msg, th);
/*  54:    */   }
/*  55:    */   
/*  56:    */   static Boolean isAdmin()
/*  57:    */   {
/*  58: 95 */     if (isAppServer()) {
/*  59:    */       try
/*  60:    */       {
/*  61: 98 */         AuthenticatedSubject notFinal = null;
/*  62:    */         try
/*  63:    */         {
/*  64:100 */           notFinal = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
/*  65:    */         }
/*  66:    */         catch (Exception e)
/*  67:    */         {
/*  68:102 */           notFinal = null;
/*  69:    */         }
/*  70:104 */         if (notFinal != null)
/*  71:    */         {
/*  72:105 */           Class mgmtService = Class.forName("weblogic.management.provider.ManagementService");
/*  73:106 */           Class authSubj = Class.forName("weblogic.security.acl.internal.AuthenticatedSubject");
/*  74:107 */           Method rtAccess = mgmtService.getMethod("getRuntimeAccess", new Class[] { authSubj });
/*  75:108 */           Object returnObject = rtAccess.invoke(null, new Object[] { notFinal });
/*  76:    */           
/*  77:110 */           Class rtAccessClass = Class.forName("weblogic.management.provider.RuntimeAccess");
/*  78:111 */           Method isAdminMethod = rtAccessClass.getMethod("isAdminServer", new Class[0]);
/*  79:    */           
/*  80:113 */           Object returnObject1 = isAdminMethod.invoke(returnObject, new Object[0]);
/*  81:    */           
/*  82:115 */           return (Boolean)returnObject1;
/*  83:    */         }
/*  84:    */       }
/*  85:    */       catch (Exception ex)
/*  86:    */       {
/*  87:120 */         if (isDebugEnabled()) {
/*  88:121 */           debug("Caught Exception determining isAdmin", ex);
/*  89:    */         }
/*  90:123 */         return Boolean.valueOf(false);
/*  91:    */       }
/*  92:    */     }
/*  93:126 */     return Boolean.valueOf(false);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static int getPeriodicSyncInterval()
/*  97:    */   {
/*  98:134 */     if (!isAppServer()) {
/*  99:135 */       return -1;
/* 100:    */     }
/* 101:138 */     LifecycleManagerConfigMBean configMBean = LifecycleConfigUtil.getLifecycleManagerConfigMBean();
/* 102:139 */     if (configMBean != null) {
/* 103:140 */       return configMBean.getPeriodicSyncInterval();
/* 104:    */     }
/* 105:142 */     return 2;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public static long getPropagationActivateTimeout()
/* 109:    */   {
/* 110:149 */     if (isAppServer())
/* 111:    */     {
/* 112:150 */       LifecycleManagerConfigMBean configMBean = LifecycleConfigUtil.getLifecycleManagerConfigMBean();
/* 113:151 */       if (configMBean != null) {
/* 114:152 */         return configMBean.getPropagationActivateTimeout();
/* 115:    */       }
/* 116:    */     }
/* 117:156 */     return 180000L;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static long getServerRuntimeTimeout()
/* 121:    */   {
/* 122:163 */     if (isAppServer())
/* 123:    */     {
/* 124:164 */       LifecycleManagerConfigMBean configMBean = LifecycleConfigUtil.getLifecycleManagerConfigMBean();
/* 125:165 */       if (configMBean != null) {
/* 126:166 */         return configMBean.getServerRuntimeTimeout();
/* 127:    */       }
/* 128:    */     }
/* 129:169 */     return 600000L;
/* 130:    */   }
/* 131:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.weblogic.lifecycle.core.LifecycleUtils
 * JD-Core Version:    0.7.0.1
 */