package com.oracle.weblogic.lifecycle;

import javax.json.JsonObject;
import org.jvnet.hk2.annotations.Contract;

@Contract
public abstract interface Orchestrator
{
  public abstract Environment orchestrate(String paramString, JsonObject paramJsonObject)
    throws LifecycleException;
  
  public abstract Environment orchestrate(String paramString1, String paramString2, JsonObject paramJsonObject)
    throws LifecycleException;
  
  public abstract boolean deleteOrchestration(String paramString1, String paramString2)
    throws LifecycleException;
  
  public abstract boolean deleteOrchestration(String paramString, JsonObject paramJsonObject)
    throws LifecycleException;
  
  public abstract boolean deleteOrchestration(String paramString1, String paramString2, String paramString3)
    throws LifecycleException;
  
  public abstract boolean deleteOrchestration(String paramString1, String paramString2, String paramString3, String paramString4)
    throws LifecycleException;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.weblogic.lifecycle.Orchestrator
 * JD-Core Version:    0.7.0.1
 */