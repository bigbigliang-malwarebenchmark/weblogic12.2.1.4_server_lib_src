/*  1:   */ package com.oracle.classloader.util;
/*  2:   */ 
/*  3:   */ import java.security.MessageDigest;
/*  4:   */ import java.security.NoSuchAlgorithmException;
/*  5:   */ 
/*  6:   */ public class DigestBuilder
/*  7:   */ {
/*  8:   */   private static final String DIGEST_ALGORITHM = "SHA";
/*  9:18 */   private MessageDigest digest = getInstance();
/* 10:   */   
/* 11:   */   private static MessageDigest getInstance()
/* 12:   */   {
/* 13:   */     try
/* 14:   */     {
/* 15:22 */       return MessageDigest.getInstance("SHA");
/* 16:   */     }
/* 17:   */     catch (NoSuchAlgorithmException e)
/* 18:   */     {
/* 19:24 */       throw new Error(e);
/* 20:   */     }
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void update(String value)
/* 24:   */   {
/* 25:34 */     if (value == null) {
/* 26:35 */       this.digest.update((byte)0);
/* 27:   */     } else {
/* 28:37 */       this.digest.update(value.toString().getBytes());
/* 29:   */     }
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void update(int value)
/* 33:   */   {
/* 34:47 */     this.digest.update((byte)(value >> 24));
/* 35:48 */     this.digest.update((byte)(value >> 16));
/* 36:49 */     this.digest.update((byte)(value >> 8));
/* 37:50 */     this.digest.update((byte)(value >> 0));
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void update(long value)
/* 41:   */   {
/* 42:59 */     this.digest.update((byte)(int)(value >> 56));
/* 43:60 */     this.digest.update((byte)(int)(value >> 48));
/* 44:61 */     this.digest.update((byte)(int)(value >> 40));
/* 45:62 */     this.digest.update((byte)(int)(value >> 32));
/* 46:63 */     this.digest.update((byte)(int)(value >> 24));
/* 47:64 */     this.digest.update((byte)(int)(value >> 16));
/* 48:65 */     this.digest.update((byte)(int)(value >> 8));
/* 49:66 */     this.digest.update((byte)(int)(value >> 0));
/* 50:   */   }
/* 51:   */   
/* 52:   */   public byte[] digest()
/* 53:   */   {
/* 54:75 */     return this.digest.digest();
/* 55:   */   }
/* 56:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.util.DigestBuilder
 * JD-Core Version:    0.7.0.1
 */