/*   1:    */ package com.oracle.classloader.util;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ 
/*   5:    */ public class DirectoryMetaData
/*   6:    */ {
/*   7:    */   private File root;
/*   8:    */   private long maxLastModified;
/*   9:    */   private long totalFileLength;
/*  10:    */   private int maxDepth;
/*  11:    */   private int memberCount;
/*  12:    */   private int maxMembers;
/*  13:    */   
/*  14:    */   public DirectoryMetaData(File directory, int maxMembers)
/*  15:    */   {
/*  16: 32 */     this.root = directory;
/*  17: 33 */     if (this.root.isFile()) {
/*  18: 34 */       throw new IllegalStateException("Not a directory: " + this.root);
/*  19:    */     }
/*  20: 36 */     this.maxMembers = maxMembers;
/*  21: 37 */     scan(this.root, 0);
/*  22:    */   }
/*  23:    */   
/*  24:    */   private boolean scan(File file, int depth)
/*  25:    */   {
/*  26: 41 */     this.memberCount += 1;
/*  27: 42 */     if ((file != null) && (this.memberCount < this.maxMembers))
/*  28:    */     {
/*  29: 43 */       if (depth > this.maxDepth) {
/*  30: 44 */         this.maxDepth = depth;
/*  31:    */       }
/*  32: 46 */       long modTime = file.lastModified();
/*  33: 47 */       if (modTime > this.maxLastModified) {
/*  34: 48 */         this.maxLastModified = modTime;
/*  35:    */       }
/*  36: 50 */       if (file.isDirectory())
/*  37:    */       {
/*  38: 51 */         File[] list = file.listFiles();
/*  39: 52 */         if (list != null) {
/*  40: 53 */           for (File f : list) {
/*  41: 54 */             if (scan(f, depth + 1)) {
/*  42:    */               break;
/*  43:    */             }
/*  44:    */           }
/*  45:    */         }
/*  46:    */       }
/*  47:    */       else
/*  48:    */       {
/*  49: 60 */         this.totalFileLength += file.length();
/*  50:    */       }
/*  51: 62 */       return false;
/*  52:    */     }
/*  53: 64 */     return true;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public File getDirectory()
/*  57:    */   {
/*  58: 73 */     return this.root;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public long getMaxLastModified()
/*  62:    */   {
/*  63: 82 */     return this.maxLastModified;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public long getTotalFileLength()
/*  67:    */   {
/*  68: 91 */     return this.totalFileLength;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public long getMemberCount()
/*  72:    */   {
/*  73:100 */     return this.memberCount;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public long getMaxDepth()
/*  77:    */   {
/*  78:109 */     return this.maxDepth;
/*  79:    */   }
/*  80:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.util.DirectoryMetaData
 * JD-Core Version:    0.7.0.1
 */