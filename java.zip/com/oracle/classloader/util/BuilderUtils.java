/*   1:    */ package com.oracle.classloader.util;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.CodeSourceCache;
/*   4:    */ import com.oracle.classloader.CodeSourceList;
/*   5:    */ import com.oracle.classloader.PolicyClassLoader;
/*   6:    */ import com.oracle.classloader.SearchPolicy;
/*   7:    */ import com.oracle.classloader.index.EagerCodeSourceIndex;
/*   8:    */ import com.oracle.classloader.log.Logger;
/*   9:    */ import com.oracle.util.Matcher;
/*  10:    */ import java.io.File;
/*  11:    */ import java.io.IOException;
/*  12:    */ import java.net.URISyntaxException;
/*  13:    */ import java.util.ArrayList;
/*  14:    */ import java.util.Collections;
/*  15:    */ import java.util.List;
/*  16:    */ import java.util.Properties;
/*  17:    */ import java.util.regex.Pattern;
/*  18:    */ 
/*  19:    */ public class BuilderUtils
/*  20:    */ {
/*  21: 32 */   private static final Pattern COLON = Pattern.compile(":");
/*  22: 33 */   private static final Pattern SEMI_COLON = Pattern.compile(";");
/*  23:    */   private static final String VARIABLE_START = "${";
/*  24: 35 */   private static final int VARIABLE_START_LENGTH = "${".length();
/*  25:    */   private static final char VARIABLE_END = '}';
/*  26:    */   private static final String JAR_SUFFIX = ".jar";
/*  27:    */   private static final String ZIP_SUFFIX = ".zip";
/*  28: 39 */   private static final String WILD_PATH_SUFFIX = File.separatorChar + "*";
/*  29:    */   private static final String PACKAGE_PREFIX_SUFFIX = ".*";
/*  30:    */   private static final char PATTERN_PREFIX = '~';
/*  31:    */   private static final char PREFIX_SUFFIX = '*';
/*  32: 43 */   private static final boolean WINDOWS = File.separatorChar == '\\';
/*  33:    */   
/*  34:    */   public static List<File> parseClassPath(String classPath, Properties replacements, String logPrefix)
/*  35:    */   {
/*  36: 79 */     return splitToFiles(classPath, replacements, true, logPrefix);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static List<File> parseNativeLibraryPath(String libraryPath, Properties replacements, String logPrefix)
/*  40:    */   {
/*  41:103 */     return splitToFiles(libraryPath, replacements, false, logPrefix);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static List<Matcher<String>> parsePackageFilters(String filters)
/*  45:    */   {
/*  46:126 */     return getPackageExcludes(splitPath(filters, false));
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static PolicyClassLoader create(String name, ClassLoader parent, List<File> classPath)
/*  50:    */     throws URISyntaxException, IOException
/*  51:    */   {
/*  52:145 */     return create(name, parent, null, classPath, null);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static PolicyClassLoader create(String name, ClassLoader parent, List<Matcher<String>> parentExcludes, List<File> classPath, List<File> nativePath)
/*  56:    */     throws URISyntaxException, IOException
/*  57:    */   {
/*  58:170 */     if ((name == null) || (name.length() == 0)) {
/*  59:171 */       throw new IllegalArgumentException("empty name");
/*  60:    */     }
/*  61:173 */     if (classPath == null) {
/*  62:174 */       throw new IllegalArgumentException("empty classPath");
/*  63:    */     }
/*  64:176 */     SearchPolicy searchPolicy = getSearchPolicy(parent, parentExcludes, classPath);
/*  65:177 */     return new PolicyClassLoader(name, searchPolicy, nativePath);
/*  66:    */   }
/*  67:    */   
/*  68:    */   static List<String> splitPath(String path, boolean allowColon)
/*  69:    */   {
/*  70:188 */     if (path == null) {
/*  71:188 */       return Collections.emptyList();
/*  72:    */     }
/*  73:    */     String[] elements;
/*  74:190 */     if (path.indexOf(';') >= 0)
/*  75:    */     {
/*  76:191 */       elements = SEMI_COLON.split(path);
/*  77:    */     }
/*  78:    */     else
/*  79:    */     {
/*  80:    */       String[] elements;
/*  81:192 */       if ((allowColon) && (!WINDOWS)) {
/*  82:193 */         elements = COLON.split(path);
/*  83:    */       } else {
/*  84:195 */         return toList(path);
/*  85:    */       }
/*  86:    */     }
/*  87:    */     String[] elements;
/*  88:197 */     if (elements.length == 1) {
/*  89:198 */       return toList(elements[0]);
/*  90:    */     }
/*  91:200 */     List<String> result = new ArrayList(elements.length);
/*  92:201 */     for (String e : elements) {
/*  93:202 */       if (e != null)
/*  94:    */       {
/*  95:203 */         e = e.trim();
/*  96:204 */         if (e.length() > 0) {
/*  97:205 */           result.add(e);
/*  98:    */         }
/*  99:    */       }
/* 100:    */     }
/* 101:209 */     return result;
/* 102:    */   }
/* 103:    */   
/* 104:    */   private static SearchPolicy getSearchPolicy(ClassLoader parent, List<Matcher<String>> parentExcludes, List<File> classPath)
/* 105:    */     throws URISyntaxException, IOException
/* 106:    */   {
/* 107:215 */     File[] cp = (File[])classPath.toArray(new File[classPath.size()]);
/* 108:216 */     CodeSourceList codeSources = new CodeSourceList(CodeSourceCache.getCache(), EagerCodeSourceIndex.FACTORY, cp);
/* 109:217 */     SearchPolicy parentPolicy = SearchPolicy.createParent(parent, toArray(parentExcludes));
/* 110:218 */     return SearchPolicy.createStandard(parentPolicy, codeSources);
/* 111:    */   }
/* 112:    */   
/* 113:    */   private static Matcher<String>[] toArray(List<Matcher<String>> matchers)
/* 114:    */   {
/* 115:223 */     if (matchers == null) {
/* 116:223 */       return null;
/* 117:    */     }
/* 118:224 */     Matcher<String>[] result = (Matcher[])new Matcher[matchers.size()];
/* 119:225 */     return (Matcher[])matchers.toArray(result);
/* 120:    */   }
/* 121:    */   
/* 122:    */   private static List<String> toList(String value)
/* 123:    */   {
/* 124:229 */     if (value == null) {
/* 125:229 */       return Collections.emptyList();
/* 126:    */     }
/* 127:230 */     value = value.trim();
/* 128:231 */     if (value.length() == 0) {
/* 129:231 */       return Collections.emptyList();
/* 130:    */     }
/* 131:232 */     return Collections.singletonList(value);
/* 132:    */   }
/* 133:    */   
/* 134:    */   private static List<File> splitToFiles(String path, Properties replacements, boolean isClassPath, String logPrefix)
/* 135:    */   {
/* 136:239 */     List<String> paths = splitPath(path, true);
/* 137:240 */     List<File> files = new ArrayList(paths.size());
/* 138:241 */     for (String p : paths)
/* 139:    */     {
/* 140:242 */       String target = replace(p, replacements);
/* 141:243 */       if (target.endsWith(WILD_PATH_SUFFIX))
/* 142:    */       {
/* 143:244 */         if (isClassPath)
/* 144:    */         {
/* 145:245 */           File d = new File(target.substring(0, target.length() - 1));
/* 146:246 */           if (isValid(d, false, logPrefix)) {
/* 147:247 */             for (File f : d.listFiles()) {
/* 148:248 */               if ((f.getName().endsWith(".jar")) && (isValid(f, true, logPrefix))) {
/* 149:249 */                 files.add(f);
/* 150:    */               }
/* 151:    */             }
/* 152:    */           }
/* 153:    */         }
/* 154:    */         else
/* 155:    */         {
/* 156:254 */           logInvalid(target, logPrefix, " wildcard not supported.");
/* 157:    */         }
/* 158:    */       }
/* 159:    */       else
/* 160:    */       {
/* 161:257 */         File f = new File(target);
/* 162:258 */         if (isValid(f, isClassPath, logPrefix)) {
/* 163:259 */           files.add(f);
/* 164:    */         }
/* 165:    */       }
/* 166:    */     }
/* 167:263 */     return files;
/* 168:    */   }
/* 169:    */   
/* 170:    */   public static boolean isValid(File file, boolean allowJarZip, String logPrefix)
/* 171:    */   {
/* 172:275 */     if (!file.isAbsolute()) {
/* 173:276 */       return logInvalid(file, logPrefix, "is not absolute.");
/* 174:    */     }
/* 175:278 */     if (!file.exists()) {
/* 176:279 */       return logInvalid(file, logPrefix, "does not exist.");
/* 177:    */     }
/* 178:281 */     if (!file.canRead()) {
/* 179:282 */       return logInvalid(file, logPrefix, "is not readable.");
/* 180:    */     }
/* 181:284 */     if ((!file.isFile()) && (!file.isDirectory())) {
/* 182:285 */       return logInvalid(file, logPrefix, "is not a file or directory.");
/* 183:    */     }
/* 184:287 */     if (allowJarZip)
/* 185:    */     {
/* 186:288 */       if (file.isFile())
/* 187:    */       {
/* 188:289 */         String name = file.getName();
/* 189:290 */         if ((!name.endsWith(".jar")) && (!name.endsWith(".zip"))) {
/* 190:291 */           return logInvalid(file, logPrefix, "is not a .jar or a .zip file.");
/* 191:    */         }
/* 192:    */       }
/* 193:    */     }
/* 194:295 */     else if (!file.isDirectory()) {
/* 195:296 */       return logInvalid(file, logPrefix, "is not a directory.");
/* 196:    */     }
/* 197:299 */     return true;
/* 198:    */   }
/* 199:    */   
/* 200:    */   private static boolean logInvalid(File file, String logPrefix, String logSuffix)
/* 201:    */   {
/* 202:303 */     return logInvalid(file.toString(), logPrefix, logSuffix);
/* 203:    */   }
/* 204:    */   
/* 205:    */   private static boolean logInvalid(String path, String logPrefix, String logSuffix)
/* 206:    */   {
/* 207:307 */     Logger.logWarning(logPrefix + ": " + path + " " + logSuffix);
/* 208:308 */     return false;
/* 209:    */   }
/* 210:    */   
/* 211:    */   private static String replace(String value, Properties replacements)
/* 212:    */   {
/* 213:312 */     if (value != null)
/* 214:    */     {
/* 215:313 */       int start = value.indexOf("${");
/* 216:314 */       if (start >= 0)
/* 217:    */       {
/* 218:315 */         int end = value.indexOf('}', start + 1);
/* 219:316 */         if (end > start)
/* 220:    */         {
/* 221:317 */           if (replacements == null) {
/* 222:317 */             replacements = System.getProperties();
/* 223:    */           }
/* 224:318 */           StringBuilder b = new StringBuilder();
/* 225:319 */           if (start > 0) {
/* 226:320 */             b.append(value.substring(0, start));
/* 227:    */           }
/* 228:322 */           String key = value.substring(start + VARIABLE_START_LENGTH, end);
/* 229:323 */           String replacement = replacements.getProperty(key);
/* 230:324 */           if (replacement == null)
/* 231:    */           {
/* 232:325 */             replacement = System.getenv(key);
/* 233:326 */             if (replacement == null) {
/* 234:327 */               throw new IllegalArgumentException("Property '" + key + "' not set.");
/* 235:    */             }
/* 236:    */           }
/* 237:330 */           b.append(replacement);
/* 238:331 */           b.append(value.substring(end + 1));
/* 239:332 */           return replace(b.toString(), replacements);
/* 240:    */         }
/* 241:    */       }
/* 242:    */     }
/* 243:336 */     return value;
/* 244:    */   }
/* 245:    */   
/* 246:    */   private static List<Matcher<String>> getPackageExcludes(List<String> packageFilters)
/* 247:    */   {
/* 248:340 */     if ((packageFilters == null) || (packageFilters.isEmpty())) {
/* 249:340 */       return Collections.emptyList();
/* 250:    */     }
/* 251:341 */     List<Matcher<String>> result = new ArrayList(packageFilters.size());
/* 252:342 */     for (String filter : packageFilters)
/* 253:    */     {
/* 254:343 */       int length = filter.length();
/* 255:344 */       if (filter.charAt(0) == '~') {
/* 256:345 */         result.add(new BuilderUtils.PatternMatcher(filter.substring(1)));
/* 257:346 */       } else if (filter.endsWith(".*")) {
/* 258:347 */         result.add(new BuilderUtils.PackageMatcher(filter.substring(0, length - 1)));
/* 259:348 */       } else if (filter.charAt(length - 1) == '*') {
/* 260:349 */         result.add(new BuilderUtils.PrefixMatcher(filter.substring(0, length - 1)));
/* 261:    */       } else {
/* 262:351 */         result.add(new BuilderUtils.ExactMatcher(filter));
/* 263:    */       }
/* 264:    */     }
/* 265:354 */     return result;
/* 266:    */   }
/* 267:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.util.BuilderUtils
 * JD-Core Version:    0.7.0.1
 */