/*  1:   */ package com.oracle.classloader.util;
/*  2:   */ 
/*  3:   */ import com.oracle.classloader.CodeSourceCache;
/*  4:   */ import com.oracle.classloader.CodeSourceList;
/*  5:   */ import com.oracle.classloader.PolicyClassLoader;
/*  6:   */ import com.oracle.classloader.SearchPolicy;
/*  7:   */ import com.oracle.classloader.index.EagerCodeSourceIndex;
/*  8:   */ import com.oracle.util.Matcher;
/*  9:   */ import java.io.IOException;
/* 10:   */ import java.net.URISyntaxException;
/* 11:   */ import java.net.URL;
/* 12:   */ 
/* 13:   */ public class ClassLoaderFactory
/* 14:   */ {
/* 15:   */   public static PolicyClassLoader createEager(String name, ClassLoader parent, URL... codeSources)
/* 16:   */     throws URISyntaxException, IOException
/* 17:   */   {
/* 18:36 */     CodeSourceList codeSourceList = new CodeSourceList(CodeSourceCache.getCache(), EagerCodeSourceIndex.FACTORY, codeSources);
/* 19:37 */     SearchPolicy searchPolicy = SearchPolicy.createStandard(SearchPolicy.createParent(parent, new Matcher[0]), codeSourceList);
/* 20:38 */     return new PolicyClassLoader(name, searchPolicy);
/* 21:   */   }
/* 22:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.util.ClassLoaderFactory
 * JD-Core Version:    0.7.0.1
 */