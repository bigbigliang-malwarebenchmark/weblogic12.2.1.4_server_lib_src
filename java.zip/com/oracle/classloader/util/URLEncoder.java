/*   1:    */ package com.oracle.classloader.util;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.net.MalformedURLException;
/*   5:    */ import java.net.URL;
/*   6:    */ import java.util.BitSet;
/*   7:    */ 
/*   8:    */ public class URLEncoder
/*   9:    */ {
/*  10: 18 */   private static final BitSet ESCAPE = ;
/*  11:    */   
/*  12:    */   public static URL toURL(File file)
/*  13:    */     throws MalformedURLException
/*  14:    */   {
/*  15: 27 */     String path = file.getAbsolutePath();
/*  16: 28 */     if (File.separatorChar != '/') {
/*  17: 29 */       path = path.replace(File.separatorChar, '/');
/*  18:    */     }
/*  19: 31 */     if (!path.startsWith("/")) {
/*  20: 32 */       path = "/" + path;
/*  21:    */     }
/*  22: 34 */     if ((!path.endsWith("/")) && (file.isDirectory())) {
/*  23: 35 */       path = path + "/";
/*  24:    */     }
/*  25: 37 */     return new URL("file", "", encodePath(path));
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static File toFile(URL url)
/*  29:    */   {
/*  30: 46 */     return new File(decodePath(url.getPath()));
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static String encodePath(String path)
/*  34:    */   {
/*  35: 55 */     int resultLen = 0;
/*  36: 56 */     char[] result = new char[path.length() * 2 + 16];
/*  37: 57 */     char[] input = path.toCharArray();
/*  38: 58 */     int inputLen = path.length();
/*  39: 59 */     for (int i = 0; i < inputLen; i++)
/*  40:    */     {
/*  41: 60 */       char c = input[i];
/*  42: 61 */       if ((c == '/') || (c == File.separatorChar))
/*  43:    */       {
/*  44: 62 */         result[(resultLen++)] = '/';
/*  45:    */       }
/*  46: 64 */       else if (c <= '')
/*  47:    */       {
/*  48: 65 */         if (((c >= 'a') && (c <= 'z')) || ((c >= 'A') && (c <= 'Z')) || ((c >= '0') && (c <= '9'))) {
/*  49: 68 */           result[(resultLen++)] = c;
/*  50: 69 */         } else if (ESCAPE.get(c)) {
/*  51: 70 */           resultLen = escape(result, c, resultLen);
/*  52:    */         } else {
/*  53: 72 */           result[(resultLen++)] = c;
/*  54:    */         }
/*  55:    */       }
/*  56: 74 */       else if (c > '߿')
/*  57:    */       {
/*  58: 75 */         resultLen = escape(result, (char)(0xE0 | c >> '\f' & 0xF), resultLen);
/*  59: 76 */         resultLen = escape(result, (char)(0x80 | c >> '\006' & 0x3F), resultLen);
/*  60: 77 */         resultLen = escape(result, (char)(0x80 | c & 0x3F), resultLen);
/*  61:    */       }
/*  62:    */       else
/*  63:    */       {
/*  64: 79 */         resultLen = escape(result, (char)(0xC0 | c >> '\006' & 0x1F), resultLen);
/*  65: 80 */         resultLen = escape(result, (char)(0x80 | c & 0x3F), resultLen);
/*  66:    */       }
/*  67: 83 */       if (resultLen + 9 > result.length)
/*  68:    */       {
/*  69: 84 */         int newLen = result.length * 2 + 16;
/*  70: 85 */         if (newLen < 0) {
/*  71: 86 */           newLen = 2147483647;
/*  72:    */         }
/*  73: 88 */         char[] buf = new char[newLen];
/*  74: 89 */         System.arraycopy(result, 0, buf, 0, resultLen);
/*  75: 90 */         result = buf;
/*  76:    */       }
/*  77:    */     }
/*  78: 93 */     return new String(result, 0, resultLen);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static String decodePath(String path)
/*  82:    */   {
/*  83:102 */     if (path.contains("%"))
/*  84:    */     {
/*  85:103 */       StringBuilder result = new StringBuilder();
/*  86:104 */       int index = 0;
/*  87:105 */       while (index < path.length())
/*  88:    */       {
/*  89:106 */         char c = path.charAt(index);
/*  90:108 */         if (c != '%') {
/*  91:109 */           index++;
/*  92:    */         } else {
/*  93:    */           try
/*  94:    */           {
/*  95:112 */             c = unescape(path, index);
/*  96:113 */             index += 3;
/*  97:114 */             if ((c & 0x80) != 0) {
/*  98:115 */               switch (c >> '\004')
/*  99:    */               {
/* 100:    */               case 12: 
/* 101:    */               case 13: 
/* 102:118 */                 char c2 = unescape(path, index);
/* 103:119 */                 index += 3;
/* 104:120 */                 c = (char)((c & 0x1F) << '\006' | c2 & 0x3F);
/* 105:121 */                 break;
/* 106:    */               case 14: 
/* 107:124 */                 char c2 = unescape(path, index);
/* 108:125 */                 index += 3;
/* 109:126 */                 char c3 = unescape(path, index);
/* 110:127 */                 index += 3;
/* 111:128 */                 c = (char)((c & 0xF) << '\f' | (c2 & 0x3F) << '\006' | c3 & 0x3F);
/* 112:    */                 
/* 113:    */ 
/* 114:131 */                 break;
/* 115:    */               default: 
/* 116:134 */                 throw new IllegalArgumentException();
/* 117:    */               }
/* 118:    */             }
/* 119:    */           }
/* 120:    */           catch (NumberFormatException e)
/* 121:    */           {
/* 122:138 */             throw new IllegalArgumentException();
/* 123:    */           }
/* 124:    */         }
/* 125:141 */         result.append(c);
/* 126:    */       }
/* 127:143 */       return result.toString();
/* 128:    */     }
/* 129:145 */     return path;
/* 130:    */   }
/* 131:    */   
/* 132:    */   private static int escape(char[] array, char c, int index)
/* 133:    */   {
/* 134:150 */     array[(index++)] = '%';
/* 135:151 */     array[(index++)] = Character.forDigit(c >> '\004' & 0xF, 16);
/* 136:152 */     array[(index++)] = Character.forDigit(c & 0xF, 16);
/* 137:153 */     return index;
/* 138:    */   }
/* 139:    */   
/* 140:    */   private static char unescape(String s, int i)
/* 141:    */   {
/* 142:157 */     return (char)Integer.parseInt(s.substring(i + 1, i + 3), 16);
/* 143:    */   }
/* 144:    */   
/* 145:    */   private static BitSet getCharsToEscape()
/* 146:    */   {
/* 147:161 */     BitSet result = new BitSet(256);
/* 148:162 */     result.set(61);
/* 149:163 */     result.set(59);
/* 150:164 */     result.set(63);
/* 151:165 */     result.set(35);
/* 152:166 */     result.set(32);
/* 153:167 */     result.set(60);
/* 154:168 */     result.set(62);
/* 155:169 */     result.set(37);
/* 156:170 */     result.set(34);
/* 157:171 */     result.set(123);
/* 158:172 */     result.set(125);
/* 159:173 */     result.set(124);
/* 160:174 */     result.set(92);
/* 161:175 */     result.set(94);
/* 162:176 */     result.set(91);
/* 163:177 */     result.set(93);
/* 164:178 */     result.set(96);
/* 165:179 */     for (int i = 0; i < 32; i++) {
/* 166:180 */       result.set(i);
/* 167:    */     }
/* 168:182 */     result.set(127);
/* 169:183 */     return result;
/* 170:    */   }
/* 171:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.util.URLEncoder
 * JD-Core Version:    0.7.0.1
 */