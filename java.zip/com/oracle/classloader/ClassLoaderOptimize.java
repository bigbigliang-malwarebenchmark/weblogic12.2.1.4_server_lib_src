package com.oracle.classloader;

public abstract interface ClassLoaderOptimize
{
  public abstract void optimize();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.ClassLoaderOptimize
 * JD-Core Version:    0.7.0.1
 */