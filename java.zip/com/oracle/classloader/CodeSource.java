/*   1:    */ package com.oracle.classloader;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.util.DigestBuilder;
/*   4:    */ import com.oracle.classloader.util.URLEncoder;
/*   5:    */ import java.io.File;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.net.MalformedURLException;
/*   8:    */ import java.net.URI;
/*   9:    */ import java.net.URISyntaxException;
/*  10:    */ import java.net.URL;
/*  11:    */ import java.security.CodeSigner;
/*  12:    */ import java.util.ArrayList;
/*  13:    */ import java.util.Collection;
/*  14:    */ import java.util.HashSet;
/*  15:    */ import java.util.List;
/*  16:    */ import java.util.Set;
/*  17:    */ import java.util.jar.Attributes;
/*  18:    */ import java.util.jar.Attributes.Name;
/*  19:    */ import java.util.jar.Manifest;
/*  20:    */ import java.util.regex.Pattern;
/*  21:    */ 
/*  22:    */ public abstract class CodeSource
/*  23:    */ {
/*  24: 36 */   private static final Pattern SPACE_SEPARATOR = Pattern.compile(" ");
/*  25:    */   private URI location;
/*  26:    */   private volatile boolean manifestProcessed;
/*  27:    */   private List<CodeSource> manifestClassPath;
/*  28:    */   private java.security.CodeSource securityCodeSource;
/*  29:    */   private boolean isInCache;
/*  30:    */   private String[] packages;
/*  31:    */   
/*  32:    */   protected CodeSource(URI location)
/*  33:    */   {
/*  34: 53 */     this.location = location;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public URI getLocation()
/*  38:    */   {
/*  39: 61 */     return this.location;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public String toString()
/*  43:    */   {
/*  44: 69 */     return this.location.toString();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public abstract long getLastModifiedTime();
/*  48:    */   
/*  49:    */   public synchronized java.security.CodeSource getNativeSecurityCodeSource()
/*  50:    */     throws MalformedURLException
/*  51:    */   {
/*  52: 86 */     if (this.securityCodeSource == null) {
/*  53: 87 */       this.securityCodeSource = createNativeCodeSource();
/*  54:    */     }
/*  55: 89 */     return this.securityCodeSource;
/*  56:    */   }
/*  57:    */   
/*  58:    */   protected java.security.CodeSource createNativeCodeSource()
/*  59:    */     throws MalformedURLException
/*  60:    */   {
/*  61: 93 */     return new CodeSource.NativeCodeSource(this, getLocation().toURL(), getCodeSigners());
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static URI findLocation(java.security.CodeSource codeSource)
/*  65:    */     throws URISyntaxException
/*  66:    */   {
/*  67:111 */     if ((codeSource instanceof CodeSource.NativeCodeSource)) {
/*  68:112 */       return ((CodeSource.NativeCodeSource)codeSource).getCodeSource().getLocation();
/*  69:    */     }
/*  70:115 */     return codeSource.getLocation().toURI();
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void updateSignature(DigestBuilder digest)
/*  74:    */   {
/*  75:126 */     digest.update(this.location.toString());
/*  76:127 */     digest.update(getLastModifiedTime());
/*  77:    */   }
/*  78:    */   
/*  79:    */   public List<CodeSource> getManifestClassPath(CodeSourceCache cache)
/*  80:    */     throws URISyntaxException, IOException
/*  81:    */   {
/*  82:137 */     if (!this.manifestProcessed)
/*  83:    */     {
/*  84:138 */       this.manifestProcessed = true;
/*  85:139 */       this.manifestClassPath = buildManifestClassPath(cache, getManifest());
/*  86:    */     }
/*  87:141 */     return this.manifestClassPath;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public abstract Manifest getManifest()
/*  91:    */     throws IOException;
/*  92:    */   
/*  93:    */   public synchronized String[] getPackageNames()
/*  94:    */     throws TooManyPackagesException
/*  95:    */   {
/*  96:154 */     if (this.packages == null)
/*  97:    */     {
/*  98:155 */       Set<String> set = new HashSet();
/*  99:156 */       addPackageNames(set);
/* 100:157 */       String[] result = new String[set.size()];
/* 101:158 */       this.packages = ((String[])set.toArray(result));
/* 102:    */     }
/* 103:160 */     return this.packages;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public abstract Collection<String> getResources();
/* 107:    */   
/* 108:    */   public abstract URL getResource(String paramString);
/* 109:    */   
/* 110:    */   public abstract boolean getResourceData(String paramString, CodeSourceBuffer paramCodeSourceBuffer);
/* 111:    */   
/* 112:    */   protected abstract void addPackageNames(Set<String> paramSet)
/* 113:    */     throws TooManyPackagesException;
/* 114:    */   
/* 115:    */   protected abstract CodeSigner[] getCodeSigners();
/* 116:    */   
/* 117:    */   private List<CodeSource> buildManifestClassPath(CodeSourceCache cache, Manifest manifest)
/* 118:    */     throws URISyntaxException
/* 119:    */   {
/* 120:202 */     if (manifest != null)
/* 121:    */     {
/* 122:203 */       Attributes attributes = manifest.getMainAttributes();
/* 123:204 */       if (attributes != null)
/* 124:    */       {
/* 125:205 */         String path = attributes.getValue(Attributes.Name.CLASS_PATH);
/* 126:206 */         if (path != null)
/* 127:    */         {
/* 128:207 */           String ourPath = URLEncoder.decodePath(getLocation().getPath());
/* 129:208 */           int lastSlash = ourPath.lastIndexOf('/');
/* 130:209 */           if (lastSlash > 0)
/* 131:    */           {
/* 132:210 */             String[] paths = SPACE_SEPARATOR.split(path);
/* 133:211 */             List<CodeSource> result = new ArrayList(paths.length);
/* 134:212 */             String ourParentPath = ourPath.substring(0, lastSlash);
/* 135:213 */             for (String pathEntry : paths) {
/* 136:214 */               if (!pathEntry.isEmpty())
/* 137:    */               {
/* 138:216 */                 CodeSource cs = getCodeSource(cache, ourParentPath, pathEntry);
/* 139:217 */                 if (cs != null) {
/* 140:218 */                   result.add(cs);
/* 141:    */                 }
/* 142:    */               }
/* 143:    */             }
/* 144:221 */             return result;
/* 145:    */           }
/* 146:    */         }
/* 147:    */       }
/* 148:    */     }
/* 149:226 */     return null;
/* 150:    */   }
/* 151:    */   
/* 152:    */   protected CodeSource getCodeSource(CodeSourceCache cache, String parentPath, String relativePath)
/* 153:    */     throws URISyntaxException
/* 154:    */   {
/* 155:    */     File file;
/* 156:    */     File file;
/* 157:239 */     if (relativePath.startsWith("file:"))
/* 158:    */     {
/* 159:240 */       file = new File(relativePath.substring(5));
/* 160:    */     }
/* 161:    */     else
/* 162:    */     {
/* 163:    */       File file;
/* 164:241 */       if ((relativePath.startsWith("/")) || (relativePath.startsWith("\\"))) {
/* 165:242 */         file = new File(relativePath);
/* 166:    */       } else {
/* 167:244 */         file = new File(parentPath, relativePath);
/* 168:    */       }
/* 169:    */     }
/* 170:246 */     return cache.get(file);
/* 171:    */   }
/* 172:    */   
/* 173:    */   boolean isInCache()
/* 174:    */   {
/* 175:255 */     return this.isInCache;
/* 176:    */   }
/* 177:    */   
/* 178:    */   void setInCache(boolean isInCache)
/* 179:    */   {
/* 180:263 */     this.isInCache = isInCache;
/* 181:    */   }
/* 182:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.CodeSource
 * JD-Core Version:    0.7.0.1
 */