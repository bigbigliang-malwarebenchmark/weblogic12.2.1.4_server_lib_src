package com.oracle.classloader;

import java.util.Iterator;

public abstract interface CodeSourceIterator
  extends Iterator<CodeSource>
{
  public abstract int getCurrentIndex();
  
  public abstract boolean shouldDefineCurrentPackage();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.CodeSourceIterator
 * JD-Core Version:    0.7.0.1
 */