/*   1:    */ package com.oracle.classloader.log;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.FileOutputStream;
/*   5:    */ import java.io.OutputStream;
/*   6:    */ import java.util.logging.Formatter;
/*   7:    */ import java.util.logging.Level;
/*   8:    */ import java.util.logging.LogRecord;
/*   9:    */ import java.util.logging.StreamHandler;
/*  10:    */ 
/*  11:    */ public class LogStreamHandler
/*  12:    */   extends StreamHandler
/*  13:    */   implements Handler
/*  14:    */ {
/*  15:    */   private boolean doNotClose;
/*  16:    */   private volatile StringBuilder buffer;
/*  17:    */   
/*  18:    */   public LogStreamHandler()
/*  19:    */   {
/*  20: 30 */     this(System.out);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public LogStreamHandler(File file)
/*  24:    */     throws Exception
/*  25:    */   {
/*  26: 39 */     this(file == null ? null : new FileOutputStream(file, false), getDefaultFormatter());
/*  27:    */   }
/*  28:    */   
/*  29:    */   public LogStreamHandler(OutputStream out)
/*  30:    */   {
/*  31: 47 */     this(out, getDefaultFormatter());
/*  32:    */   }
/*  33:    */   
/*  34:    */   public LogStreamHandler(OutputStream out, Formatter formatter)
/*  35:    */   {
/*  36: 58 */     super(getStream(out), formatter);
/*  37: 59 */     setLevel(Level.ALL);
/*  38: 60 */     if ((out == null) || (out == System.out) || (out == System.err)) {
/*  39: 61 */       this.doNotClose = true;
/*  40:    */     }
/*  41:    */   }
/*  42:    */   
/*  43:    */   public StringBuilder setBuffer(StringBuilder buffer)
/*  44:    */   {
/*  45: 72 */     StringBuilder result = this.buffer;
/*  46: 73 */     this.buffer = buffer;
/*  47: 74 */     return result;
/*  48:    */   }
/*  49:    */   
/*  50:    */   private static Formatter getDefaultFormatter()
/*  51:    */   {
/*  52: 78 */     return new SimpleLogFormatter();
/*  53:    */   }
/*  54:    */   
/*  55:    */   private static OutputStream getStream(OutputStream out)
/*  56:    */   {
/*  57: 82 */     if (out == null) {
/*  58: 83 */       out = System.out;
/*  59:    */     }
/*  60: 85 */     return out;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void publish(LogRecord record)
/*  64:    */   {
/*  65: 97 */     StringBuilder b = this.buffer;
/*  66: 98 */     if (b == null)
/*  67:    */     {
/*  68: 99 */       super.publish(record);
/*  69:100 */       flush();
/*  70:    */     }
/*  71:    */     else
/*  72:    */     {
/*  73:    */       try
/*  74:    */       {
/*  75:103 */         b.append(getFormatter().format(record));
/*  76:    */       }
/*  77:    */       catch (Exception ex)
/*  78:    */       {
/*  79:105 */         reportError(null, ex, 5);
/*  80:    */       }
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void close()
/*  85:    */   {
/*  86:115 */     if (this.doNotClose) {
/*  87:116 */       flush();
/*  88:    */     } else {
/*  89:118 */       super.close();
/*  90:    */     }
/*  91:    */   }
/*  92:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.log.LogStreamHandler
 * JD-Core Version:    0.7.0.1
 */