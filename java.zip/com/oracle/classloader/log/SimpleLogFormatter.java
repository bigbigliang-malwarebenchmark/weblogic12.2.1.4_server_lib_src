/*  1:   */ package com.oracle.classloader.log;
/*  2:   */ 
/*  3:   */ import java.io.PrintWriter;
/*  4:   */ import java.io.StringWriter;
/*  5:   */ import java.text.DateFormat;
/*  6:   */ import java.text.SimpleDateFormat;
/*  7:   */ import java.util.Date;
/*  8:   */ import java.util.logging.Formatter;
/*  9:   */ import java.util.logging.Level;
/* 10:   */ import java.util.logging.LogRecord;
/* 11:   */ 
/* 12:   */ public class SimpleLogFormatter
/* 13:   */   extends Formatter
/* 14:   */ {
/* 15:21 */   public static final String EOL = System.getProperty("line.separator");
/* 16:22 */   private static Date date = new Date();
/* 17:23 */   private static DateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy h:mm:ss aaa z");
/* 18:   */   
/* 19:   */   public String format(LogRecord record)
/* 20:   */   {
/* 21:26 */     StringBuilder sb = new StringBuilder();
/* 22:27 */     String message = record.getMessage() == null ? "" : formatMessage(record);
/* 23:28 */     date.setTime(record.getMillis());
/* 24:29 */     sb.append('<');
/* 25:30 */     sb.append(dateFormat.format(date));
/* 26:31 */     sb.append("> ");
/* 27:32 */     int level = record.getLevel().intValue();
/* 28:33 */     sb.append('<');
/* 29:34 */     sb.append(record.getLevel().getLocalizedName());
/* 30:35 */     sb.append("> ");
/* 31:36 */     String caller = record.getSourceClassName();
/* 32:37 */     if (caller != null)
/* 33:   */     {
/* 34:38 */       sb.append('<');
/* 35:39 */       sb.append(caller);
/* 36:40 */       sb.append("> ");
/* 37:   */     }
/* 38:42 */     sb.append(message);
/* 39:43 */     sb.append(EOL);
/* 40:44 */     Throwable thrown = record.getThrown();
/* 41:45 */     if (thrown != null) {
/* 42:   */       try
/* 43:   */       {
/* 44:47 */         StringWriter sw = new StringWriter();
/* 45:48 */         PrintWriter pw = new PrintWriter(sw);
/* 46:49 */         thrown.printStackTrace(pw);
/* 47:50 */         pw.close();
/* 48:51 */         sb.append(sw.toString());
/* 49:   */       }
/* 50:   */       catch (Exception localException) {}
/* 51:   */     }
/* 52:56 */     return sb.toString();
/* 53:   */   }
/* 54:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.log.SimpleLogFormatter
 * JD-Core Version:    0.7.0.1
 */