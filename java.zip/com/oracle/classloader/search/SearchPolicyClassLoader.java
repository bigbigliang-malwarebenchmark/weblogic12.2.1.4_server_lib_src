/*   1:    */ package com.oracle.classloader.search;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.PolicyClassLoader;
/*   4:    */ import com.oracle.classloader.SearchPolicy;
/*   5:    */ import com.oracle.classloader.log.Logger;
/*   6:    */ import com.oracle.util.Matcher;
/*   7:    */ import java.net.URL;
/*   8:    */ import java.util.List;
/*   9:    */ 
/*  10:    */ public class SearchPolicyClassLoader
/*  11:    */   extends SearchPolicy
/*  12:    */ {
/*  13:    */   private final PolicyClassLoader delegate;
/*  14:    */   private final Matcher<String>[] excludes;
/*  15:    */   
/*  16:    */   @SafeVarargs
/*  17:    */   public SearchPolicyClassLoader(PolicyClassLoader delegate, Matcher<String>... packageExcludes)
/*  18:    */   {
/*  19: 32 */     if (delegate == null) {
/*  20: 33 */       throw new IllegalStateException("Support for null delegate not implemented.");
/*  21:    */     }
/*  22: 35 */     this.delegate = delegate;
/*  23: 36 */     this.excludes = packageExcludes;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public ClassLoader getFirstDelegate()
/*  27:    */   {
/*  28: 44 */     return this.delegate.getSearchPolicy().getFirstDelegate();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public List<Matcher<String>> addParentExcludes(List<Matcher<String>> result)
/*  32:    */   {
/*  33: 55 */     if (this.excludes != null) {
/*  34: 56 */       for (Matcher<String> e : this.excludes) {
/*  35: 57 */         result.add(e);
/*  36:    */       }
/*  37:    */     }
/*  38: 60 */     return result;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public URL getResource(String resourcePath, String packageName)
/*  42:    */   {
/*  43: 70 */     if (isIncluded(packageName)) {
/*  44: 71 */       synchronized (this.delegate)
/*  45:    */       {
/*  46: 72 */         return this.delegate.getSearchPolicy().getResource(resourcePath, packageName);
/*  47:    */       }
/*  48:    */     }
/*  49: 75 */     return null;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void addResources(String resourcePath, String packageName, List<URL> result)
/*  53:    */   {
/*  54: 85 */     if (isIncluded(packageName)) {
/*  55: 86 */       this.delegate.getSearchPolicy().addResources(resourcePath, packageName, result);
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Class<?> loadClass(String className, String packageName)
/*  60:    */   {
/*  61: 97 */     Class<?> result = null;
/*  62: 98 */     if (isIncluded(packageName)) {
/*  63: 99 */       synchronized (this.delegate)
/*  64:    */       {
/*  65:100 */         result = this.delegate.findCachedClass(className);
/*  66:101 */         if (result == null)
/*  67:    */         {
/*  68:102 */           result = this.delegate.getSearchPolicy().loadClass(className, packageName);
/*  69:103 */           if ((result == null) && (Logger.willLogFinest())) {
/*  70:104 */             Logger.logFinest(className + " not found in delegate of '" + getDelegatingLoader().getName() + "'");
/*  71:    */           }
/*  72:    */         }
/*  73:    */       }
/*  74:    */     }
/*  75:109 */     return result;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public String toString()
/*  79:    */   {
/*  80:117 */     return SearchClassLoaderMatcher.toString(this.excludes);
/*  81:    */   }
/*  82:    */   
/*  83:    */   private boolean isIncluded(String packageName)
/*  84:    */   {
/*  85:121 */     if (this.excludes != null) {
/*  86:122 */       for (Matcher<String> exclude : this.excludes) {
/*  87:123 */         if (exclude.matches(packageName)) {
/*  88:123 */           return false;
/*  89:    */         }
/*  90:    */       }
/*  91:    */     }
/*  92:126 */     return true;
/*  93:    */   }
/*  94:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.search.SearchPolicyClassLoader
 * JD-Core Version:    0.7.0.1
 */