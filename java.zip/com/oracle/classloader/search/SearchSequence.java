/*   1:    */ package com.oracle.classloader.search;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.PolicyClassLoader;
/*   4:    */ import com.oracle.classloader.SearchPolicy;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.net.URISyntaxException;
/*   7:    */ import java.net.URL;
/*   8:    */ import java.security.AccessControlContext;
/*   9:    */ import java.security.PermissionCollection;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.List;
/*  12:    */ 
/*  13:    */ public class SearchSequence
/*  14:    */   extends SearchPolicy
/*  15:    */ {
/*  16:    */   private final SearchPolicy[] sequence;
/*  17:    */   
/*  18:    */   public SearchSequence(SearchPolicy... sequence)
/*  19:    */   {
/*  20: 32 */     this.sequence = unwrap(sequence);
/*  21:    */   }
/*  22:    */   
/*  23:    */   private static SearchPolicy[] unwrap(SearchPolicy[] sequence)
/*  24:    */   {
/*  25: 36 */     List<SearchPolicy> s = new ArrayList();
/*  26: 37 */     for (SearchPolicy sp : sequence) {
/*  27: 38 */       if ((sp instanceof SearchSequence)) {
/*  28: 39 */         for (SearchPolicy spi : ((SearchSequence)sp).sequence) {
/*  29: 40 */           s.add(spi);
/*  30:    */         }
/*  31:    */       } else {
/*  32: 43 */         s.add(sp);
/*  33:    */       }
/*  34:    */     }
/*  35: 46 */     return (SearchPolicy[])s.toArray(new SearchPolicy[s.size()]);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setDelegatingLoader(PolicyClassLoader loader)
/*  39:    */   {
/*  40: 55 */     super.setDelegatingLoader(loader);
/*  41: 56 */     for (SearchPolicy sp : this.sequence) {
/*  42: 57 */       sp.setDelegatingLoader(loader);
/*  43:    */     }
/*  44:    */   }
/*  45:    */   
/*  46:    */   public SearchSequence append(SearchPolicy searchPolicy)
/*  47:    */   {
/*  48: 62 */     return new SearchSequence(new SearchPolicy[] { searchPolicy, this });
/*  49:    */   }
/*  50:    */   
/*  51:    */   public ClassLoader getFirstDelegate()
/*  52:    */   {
/*  53: 70 */     for (SearchPolicy sp : this.sequence)
/*  54:    */     {
/*  55: 71 */       ClassLoader delegate = sp.getFirstDelegate();
/*  56: 72 */       if (delegate != null) {
/*  57: 73 */         return delegate;
/*  58:    */       }
/*  59:    */     }
/*  60: 75 */     return null;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public List<com.oracle.classloader.CodeSource> addCodeSources(List<com.oracle.classloader.CodeSource> result, boolean all)
/*  64:    */   {
/*  65: 86 */     for (SearchPolicy sp : this.sequence) {
/*  66: 87 */       sp.addCodeSources(result, all);
/*  67:    */     }
/*  68: 89 */     return result;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public URL getResource(String resourcePath, String packageName)
/*  72:    */   {
/*  73: 99 */     URL result = null;
/*  74:100 */     for (SearchPolicy sp : this.sequence)
/*  75:    */     {
/*  76:101 */       result = sp.getResource(resourcePath, packageName);
/*  77:102 */       if (result != null) {
/*  78:    */         break;
/*  79:    */       }
/*  80:    */     }
/*  81:106 */     return result;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void addResources(String resourcePath, String packageName, List<URL> result)
/*  85:    */   {
/*  86:116 */     for (SearchPolicy sp : this.sequence) {
/*  87:117 */       sp.addResources(resourcePath, packageName, result);
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   public Class<?> loadClass(String className, String packageName)
/*  92:    */   {
/*  93:128 */     Class<?> result = null;
/*  94:129 */     for (SearchPolicy sp : this.sequence)
/*  95:    */     {
/*  96:130 */       result = sp.loadClass(className, packageName);
/*  97:131 */       if (result != null) {
/*  98:    */         break;
/*  99:    */       }
/* 100:    */     }
/* 101:135 */     return result;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void generatePermissions(AccessControlContext acc, PermissionCollection perms, java.security.CodeSource codeSource)
/* 105:    */     throws IOException, URISyntaxException
/* 106:    */   {
/* 107:140 */     for (SearchPolicy sp : this.sequence) {
/* 108:141 */       sp.generatePermissions(acc, perms, codeSource);
/* 109:    */     }
/* 110:    */   }
/* 111:    */   
/* 112:    */   public String toString()
/* 113:    */   {
/* 114:150 */     StringBuilder builder = new StringBuilder();
/* 115:151 */     for (int i = 0; i < this.sequence.length; i++)
/* 116:    */     {
/* 117:152 */       if (i > 0) {
/* 118:153 */         builder.append(" --> ");
/* 119:    */       }
/* 120:155 */       builder.append(this.sequence[i]);
/* 121:    */     }
/* 122:157 */     return builder.toString();
/* 123:    */   }
/* 124:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.search.SearchSequence
 * JD-Core Version:    0.7.0.1
 */