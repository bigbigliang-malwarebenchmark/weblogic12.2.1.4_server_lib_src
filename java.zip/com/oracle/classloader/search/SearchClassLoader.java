/*  1:   */ package com.oracle.classloader.search;
/*  2:   */ 
/*  3:   */ import com.oracle.classloader.PolicyClassLoader;
/*  4:   */ import com.oracle.classloader.SearchPolicy;
/*  5:   */ import com.oracle.classloader.log.Logger;
/*  6:   */ import java.io.IOException;
/*  7:   */ import java.net.URL;
/*  8:   */ import java.util.Enumeration;
/*  9:   */ import java.util.List;
/* 10:   */ 
/* 11:   */ public class SearchClassLoader
/* 12:   */   extends SearchPolicy
/* 13:   */ {
/* 14:   */   private final ClassLoader delegate;
/* 15:   */   
/* 16:   */   public SearchClassLoader(ClassLoader delegate)
/* 17:   */   {
/* 18:29 */     if (delegate == null) {
/* 19:30 */       throw new IllegalStateException("Support for null delegate not implemented.");
/* 20:   */     }
/* 21:32 */     this.delegate = delegate;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public ClassLoader getFirstDelegate()
/* 25:   */   {
/* 26:40 */     return this.delegate;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public URL getResource(String resourcePath, String packageName)
/* 30:   */   {
/* 31:50 */     return this.delegate.getResource(resourcePath);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void addResources(String resourcePath, String packageName, List<URL> result)
/* 35:   */   {
/* 36:   */     try
/* 37:   */     {
/* 38:61 */       Enumeration<URL> e = this.delegate.getResources(resourcePath);
/* 39:62 */       while (e.hasMoreElements()) {
/* 40:63 */         result.add(e.nextElement());
/* 41:   */       }
/* 42:   */     }
/* 43:   */     catch (IOException e)
/* 44:   */     {
/* 45:66 */       if (Logger.willLogFine()) {
/* 46:67 */         Logger.logFine(
/* 47:68 */           "Caught " + e.toString() + " searching for " + resourcePath + " in '" + getDelegatingLoader().getName() + "'");
/* 48:   */       }
/* 49:   */     }
/* 50:   */   }
/* 51:   */   
/* 52:   */   public Class<?> loadClass(String className, String packageName)
/* 53:   */   {
/* 54:80 */     Class<?> result = null;
/* 55:   */     try
/* 56:   */     {
/* 57:82 */       result = this.delegate.loadClass(className);
/* 58:   */     }
/* 59:   */     catch (ClassNotFoundException c)
/* 60:   */     {
/* 61:84 */       if (Logger.willLogFinest()) {
/* 62:85 */         Logger.logFinest(className + " not found in delegate of '" + getDelegatingLoader().getName() + "'");
/* 63:   */       }
/* 64:   */     }
/* 65:88 */     return result;
/* 66:   */   }
/* 67:   */   
/* 68:   */   public String toString()
/* 69:   */   {
/* 70:96 */     return "Parents";
/* 71:   */   }
/* 72:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.search.SearchClassLoader
 * JD-Core Version:    0.7.0.1
 */