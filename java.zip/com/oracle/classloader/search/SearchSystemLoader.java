/*   1:    */ package com.oracle.classloader.search;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.SearchPolicy;
/*   4:    */ import com.oracle.classloader.log.Logger;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.net.URL;
/*   7:    */ import java.util.Enumeration;
/*   8:    */ import java.util.List;
/*   9:    */ 
/*  10:    */ public class SearchSystemLoader
/*  11:    */   extends SearchPolicy
/*  12:    */ {
/*  13:    */   private static final String PCL_PACKAGE = "com.oracle.classloader";
/*  14:    */   private final ClassLoader jreExtensionsLoader;
/*  15:    */   private final ClassLoader originalSystemLoader;
/*  16:    */   
/*  17:    */   public SearchSystemLoader(ClassLoader originalSystemLoader)
/*  18:    */   {
/*  19: 33 */     if (originalSystemLoader == null) {
/*  20: 34 */       throw new IllegalStateException("Support for null delegate not implemented.");
/*  21:    */     }
/*  22: 36 */     this.originalSystemLoader = originalSystemLoader;
/*  23: 37 */     this.jreExtensionsLoader = originalSystemLoader.getParent();
/*  24:    */   }
/*  25:    */   
/*  26:    */   private ClassLoader getDelegate(String packageName)
/*  27:    */   {
/*  28: 41 */     return packageName.startsWith("com.oracle.classloader") ? this.originalSystemLoader : this.jreExtensionsLoader;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public ClassLoader getFirstDelegate()
/*  32:    */   {
/*  33: 49 */     return this.originalSystemLoader;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public URL getResource(String resourcePath, String packageName)
/*  37:    */   {
/*  38: 59 */     long bt = System.nanoTime();
/*  39:    */     try
/*  40:    */     {
/*  41: 62 */       return this.jreExtensionsLoader.getResource(resourcePath);
/*  42:    */     }
/*  43:    */     finally
/*  44:    */     {
/*  45: 64 */       recordParentDelegationStats(bt);
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void addResources(String resourcePath, String packageName, List<URL> result)
/*  50:    */   {
/*  51: 75 */     long bt = System.nanoTime();
/*  52:    */     try
/*  53:    */     {
/*  54: 78 */       Enumeration<URL> e = this.jreExtensionsLoader.getResources(resourcePath);
/*  55: 79 */       while (e.hasMoreElements()) {
/*  56: 80 */         result.add(e.nextElement());
/*  57:    */       }
/*  58:    */     }
/*  59:    */     catch (IOException e)
/*  60:    */     {
/*  61: 83 */       if (Logger.willLogFine()) {
/*  62: 84 */         Logger.logFine("Caught " + e.toString() + " searching for " + resourcePath);
/*  63:    */       }
/*  64:    */     }
/*  65:    */     finally
/*  66:    */     {
/*  67: 87 */       recordParentDelegationStats(bt);
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:    */   public Class<?> loadClass(String className, String packageName)
/*  72:    */   {
/*  73: 98 */     long bt = System.nanoTime();
/*  74: 99 */     Class<?> result = null;
/*  75:    */     try
/*  76:    */     {
/*  77:101 */       result = getDelegate(packageName).loadClass(className);
/*  78:    */     }
/*  79:    */     catch (ClassNotFoundException c)
/*  80:    */     {
/*  81:103 */       if (Logger.willLogFinest()) {
/*  82:104 */         Logger.logFinest(className + " not found in delegate.");
/*  83:    */       }
/*  84:    */     }
/*  85:    */     finally
/*  86:    */     {
/*  87:107 */       recordParentDelegationStats(bt);
/*  88:    */     }
/*  89:109 */     return result;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public String toString()
/*  93:    */   {
/*  94:117 */     return "Parents";
/*  95:    */   }
/*  96:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.search.SearchSystemLoader
 * JD-Core Version:    0.7.0.1
 */