/*   1:    */ package com.oracle.classloader.search;
/*   2:    */ 
/*   3:    */ import com.oracle.util.Matcher;
/*   4:    */ import java.net.URL;
/*   5:    */ import java.util.List;
/*   6:    */ 
/*   7:    */ public class SearchClassLoaderMatcher
/*   8:    */   extends SearchClassLoader
/*   9:    */ {
/*  10:    */   private final Matcher<String>[] excludes;
/*  11:    */   
/*  12:    */   @SafeVarargs
/*  13:    */   public SearchClassLoaderMatcher(ClassLoader delegate, Matcher<String>... packageExcludes)
/*  14:    */   {
/*  15: 27 */     super(delegate);
/*  16: 28 */     this.excludes = packageExcludes;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public List<Matcher<String>> addParentExcludes(List<Matcher<String>> result)
/*  20:    */   {
/*  21: 39 */     if (this.excludes != null) {
/*  22: 40 */       for (Matcher<String> e : this.excludes) {
/*  23: 41 */         result.add(e);
/*  24:    */       }
/*  25:    */     }
/*  26: 44 */     return result;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public URL getResource(String resourcePath, String packageName)
/*  30:    */   {
/*  31: 54 */     if (isIncluded(packageName)) {
/*  32: 55 */       return super.getResource(resourcePath, packageName);
/*  33:    */     }
/*  34: 57 */     return null;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public Class<?> loadClass(String className, String packageName)
/*  38:    */   {
/*  39: 67 */     Class<?> result = null;
/*  40: 68 */     if (isIncluded(packageName)) {
/*  41: 69 */       result = super.loadClass(className, packageName);
/*  42:    */     }
/*  43: 71 */     return result;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public String toString()
/*  47:    */   {
/*  48: 79 */     return toString(this.excludes);
/*  49:    */   }
/*  50:    */   
/*  51:    */   static String toString(Matcher<String>[] excludes)
/*  52:    */   {
/*  53: 83 */     if (excludes == null) {
/*  54: 83 */       return "Parents";
/*  55:    */     }
/*  56: 84 */     StringBuilder b = new StringBuilder();
/*  57: 85 */     b.append("Parents(excludes: ");
/*  58: 86 */     for (int i = 0; i < excludes.length; i++)
/*  59:    */     {
/*  60: 87 */       if (i > 0) {
/*  61: 87 */         b.append(", ");
/*  62:    */       }
/*  63: 88 */       b.append(excludes[i]);
/*  64:    */     }
/*  65: 90 */     b.append(")");
/*  66: 91 */     return b.toString();
/*  67:    */   }
/*  68:    */   
/*  69:    */   private boolean isIncluded(String packageName)
/*  70:    */   {
/*  71: 95 */     if (this.excludes != null) {
/*  72: 96 */       for (Matcher<String> exclude : this.excludes) {
/*  73: 97 */         if (exclude.matches(packageName)) {
/*  74: 97 */           return false;
/*  75:    */         }
/*  76:    */       }
/*  77:    */     }
/*  78:100 */     return true;
/*  79:    */   }
/*  80:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.search.SearchClassLoaderMatcher
 * JD-Core Version:    0.7.0.1
 */