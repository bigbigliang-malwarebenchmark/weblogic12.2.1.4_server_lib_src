/*  1:   */ package com.oracle.classloader.search;
/*  2:   */ 
/*  3:   */ import com.oracle.classloader.SearchPolicy;
/*  4:   */ import java.net.URL;
/*  5:   */ import java.util.HashMap;
/*  6:   */ import java.util.List;
/*  7:   */ import java.util.Map;
/*  8:   */ 
/*  9:   */ public class SearchKnownClasses
/* 10:   */   extends SearchPolicy
/* 11:   */ {
/* 12:   */   private final String name;
/* 13:   */   private final Map<String, Class<?>> map;
/* 14:   */   
/* 15:   */   public SearchKnownClasses(String name, List<Class<?>> classes)
/* 16:   */   {
/* 17:31 */     this.name = name;
/* 18:32 */     this.map = new HashMap(classes.size());
/* 19:33 */     for (Class<?> c : classes) {
/* 20:34 */       this.map.put(c.getName(), c);
/* 21:   */     }
/* 22:   */   }
/* 23:   */   
/* 24:   */   public URL getResource(String resourcePath, String packageName)
/* 25:   */   {
/* 26:46 */     return null;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void addResources(String resourcePath, String packageName, List<URL> result) {}
/* 30:   */   
/* 31:   */   public Class<?> loadClass(String className, String packageName)
/* 32:   */   {
/* 33:67 */     return (Class)this.map.get(className);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public String toString()
/* 37:   */   {
/* 38:76 */     return this.name;
/* 39:   */   }
/* 40:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.search.SearchKnownClasses
 * JD-Core Version:    0.7.0.1
 */