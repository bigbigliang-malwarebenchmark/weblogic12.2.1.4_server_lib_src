/*   1:    */ package com.oracle.classloader.search;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.CodeSourceBuffer;
/*   4:    */ import com.oracle.classloader.CodeSourceBufferPool;
/*   5:    */ import com.oracle.classloader.CodeSourceCache;
/*   6:    */ import com.oracle.classloader.CodeSourceIterator;
/*   7:    */ import com.oracle.classloader.CodeSourceList;
/*   8:    */ import com.oracle.classloader.PolicyClassLoader;
/*   9:    */ import com.oracle.classloader.SearchPolicy;
/*  10:    */ import com.oracle.classloader.log.Logger;
/*  11:    */ import java.io.File;
/*  12:    */ import java.io.FilePermission;
/*  13:    */ import java.io.IOException;
/*  14:    */ import java.net.URI;
/*  15:    */ import java.net.URISyntaxException;
/*  16:    */ import java.net.URL;
/*  17:    */ import java.net.URLDecoder;
/*  18:    */ import java.security.AccessControlContext;
/*  19:    */ import java.security.AccessController;
/*  20:    */ import java.security.Permission;
/*  21:    */ import java.security.PermissionCollection;
/*  22:    */ import java.util.List;
/*  23:    */ 
/*  24:    */ public class SearchCodeSources
/*  25:    */   extends SearchPolicy
/*  26:    */ {
/*  27:    */   private static final com.oracle.classloader.CodeSource FW_CODE_SOURCE;
/*  28:    */   
/*  29:    */   static
/*  30:    */   {
/*  31:    */     try
/*  32:    */     {
/*  33: 45 */       FW_CODE_SOURCE = CodeSourceCache.getCache().getFrameworkCodeSource();
/*  34:    */     }
/*  35:    */     catch (URISyntaxException e)
/*  36:    */     {
/*  37: 47 */       throw new RuntimeException(e);
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41: 51 */   private static final ClassLoader FW_LOADER = SearchCodeSources.class.getClassLoader();
/*  42: 52 */   private static final String FILE_ENC = System.getProperty("file.encoding", "UTF-8");
/*  43:    */   private final CodeSourceList list;
/*  44:    */   private final CodeSourceBufferPool bufferPool;
/*  45:    */   
/*  46:    */   public SearchCodeSources(CodeSourceList list)
/*  47:    */   {
/*  48: 62 */     this(list, new CodeSourceBufferPool());
/*  49:    */   }
/*  50:    */   
/*  51:    */   public SearchCodeSources(CodeSourceList list, CodeSourceBufferPool bufferPool)
/*  52:    */   {
/*  53: 71 */     this.list = list;
/*  54: 72 */     this.bufferPool = bufferPool;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public SearchCodeSources(CodeSourceList list, SearchCodeSources sources)
/*  58:    */   {
/*  59: 81 */     this.list = list;
/*  60: 82 */     this.bufferPool = sources.bufferPool;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public List<com.oracle.classloader.CodeSource> addCodeSources(List<com.oracle.classloader.CodeSource> result, boolean all)
/*  64:    */   {
/*  65: 94 */     this.list.getCodeSources(result, all);
/*  66: 95 */     return result;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public URL getResource(String resourcePath, String packageName)
/*  70:    */   {
/*  71:105 */     URL result = null;
/*  72:106 */     for (CodeSourceIterator iterator = this.list.iterator(packageName); iterator.hasNext();)
/*  73:    */     {
/*  74:107 */       com.oracle.classloader.CodeSource cs = (com.oracle.classloader.CodeSource)iterator.next();
/*  75:108 */       result = cs.getResource(resourcePath);
/*  76:109 */       if (result != null) {
/*  77:    */         break;
/*  78:    */       }
/*  79:    */     }
/*  80:113 */     return result;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void addResources(String resourcePath, String packageName, List<URL> result)
/*  84:    */   {
/*  85:123 */     for (CodeSourceIterator iterator = this.list.iterator(packageName); iterator.hasNext();)
/*  86:    */     {
/*  87:124 */       com.oracle.classloader.CodeSource cs = (com.oracle.classloader.CodeSource)iterator.next();
/*  88:125 */       URL resource = cs.getResource(resourcePath);
/*  89:126 */       if (resource != null) {
/*  90:127 */         result.add(resource);
/*  91:    */       }
/*  92:    */     }
/*  93:    */   }
/*  94:    */   
/*  95:    */   public Class<?> loadClass(String className, String packageName)
/*  96:    */   {
/*  97:141 */     long fbt = System.nanoTime();
/*  98:    */     
/*  99:143 */     String resourcePath = className.replace('.', '/') + ".class";
/* 100:144 */     CodeSourceBuffer buffer = (CodeSourceBuffer)this.bufferPool.take();
/* 101:    */     try
/* 102:    */     {
/* 103:146 */       for (CodeSourceIterator iterator = this.list.iterator(packageName); iterator.hasNext();)
/* 104:    */       {
/* 105:147 */         com.oracle.classloader.CodeSource cs = (com.oracle.classloader.CodeSource)iterator.next();
/* 106:148 */         if (cs.getResourceData(resourcePath, buffer))
/* 107:    */         {
/* 108:155 */           if (buffer.getCodeSource() == FW_CODE_SOURCE) {
/* 109:    */             try
/* 110:    */             {
/* 111:159 */               return FW_LOADER.loadClass(className);
/* 112:    */             }
/* 113:    */             catch (ClassNotFoundException e)
/* 114:    */             {
/* 115:161 */               throw new Error(e);
/* 116:    */             }
/* 117:    */           }
/* 118:167 */           int codeSourceIndex = iterator.getCurrentIndex();
/* 119:168 */           if (iterator.shouldDefineCurrentPackage()) {
/* 120:169 */             ensurePackageDefined(packageName, buffer, codeSourceIndex);
/* 121:    */           }
/* 122:172 */           recordFindClassStats(fbt);
/* 123:173 */           fbt = 0L;
/* 124:174 */           return defineClass(className, buffer, codeSourceIndex);
/* 125:    */         }
/* 126:    */       }
/* 127:181 */       this.bufferPool.recycle(buffer);
/* 128:182 */       if (fbt != 0L) {
/* 129:183 */         recordFindClassStats(fbt);
/* 130:    */       }
/* 131:    */     }
/* 132:    */     catch (IllegalArgumentException|IOException e)
/* 133:    */     {
/* 134:179 */       throw new RuntimeException(e);
/* 135:    */     }
/* 136:    */     finally
/* 137:    */     {
/* 138:181 */       this.bufferPool.recycle(buffer);
/* 139:182 */       if (fbt != 0L) {
/* 140:183 */         recordFindClassStats(fbt);
/* 141:    */       }
/* 142:    */     }
/* 143:186 */     if (Logger.willLogFinest()) {
/* 144:187 */       Logger.logFinest(className + " not found in code sources of '" + getDelegatingLoader().getName() + "'");
/* 145:    */     }
/* 146:190 */     return null;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public void generatePermissions(AccessControlContext acc, PermissionCollection perms, java.security.CodeSource codeSource)
/* 150:    */     throws IOException, URISyntaxException
/* 151:    */   {
/* 152:195 */     URI location = com.oracle.classloader.CodeSource.findLocation(codeSource);
/* 153:    */     
/* 154:197 */     String path = location.getPath().replace('/', File.separatorChar);
/* 155:198 */     path = URLDecoder.decode(path, FILE_ENC);
/* 156:200 */     if (path.endsWith(File.separator)) {
/* 157:201 */       path = path + "-";
/* 158:    */     }
/* 159:203 */     Permission p = new FilePermission(path, "read");
/* 160:205 */     if (!getDelegatingLoader().isPrivileged())
/* 161:    */     {
/* 162:206 */       SecurityManager sm = System.getSecurityManager();
/* 163:207 */       if (sm != null)
/* 164:    */       {
/* 165:208 */         Permission fp = p;
/* 166:209 */         AccessController.doPrivileged(new SearchCodeSources.1(this, sm, fp), acc);
/* 167:    */       }
/* 168:    */     }
/* 169:218 */     perms.add(p);
/* 170:    */   }
/* 171:    */   
/* 172:    */   public String toString()
/* 173:    */   {
/* 174:226 */     return "CodeSources";
/* 175:    */   }
/* 176:    */   
/* 177:    */   protected CodeSourceList getCodeSources()
/* 178:    */   {
/* 179:234 */     return this.list;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setDelegatingLoader(PolicyClassLoader loader)
/* 183:    */   {
/* 184:239 */     super.setDelegatingLoader(loader);
/* 185:240 */     long indexTime = this.list.detectIndexPhases(new SearchCodeSources.2(this, loader), new SearchCodeSources.3(this, loader));
/* 186:257 */     if (indexTime > 0L) {
/* 187:259 */       loader.informIndexingDone(indexTime);
/* 188:    */     }
/* 189:    */   }
/* 190:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.search.SearchCodeSources
 * JD-Core Version:    0.7.0.1
 */