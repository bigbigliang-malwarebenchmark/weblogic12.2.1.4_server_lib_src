/*  1:   */ package com.oracle.classloader;
/*  2:   */ 
/*  3:   */ public class CodeSourceBufferPool
/*  4:   */   extends Pool<CodeSourceBuffer>
/*  5:   */ {
/*  6:   */   protected CodeSourceBuffer create()
/*  7:   */   {
/*  8:11 */     return new CodeSourceBuffer();
/*  9:   */   }
/* 10:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.CodeSourceBufferPool
 * JD-Core Version:    0.7.0.1
 */