/*   1:    */ package com.oracle.classloader;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.log.Logger;
/*   4:    */ import com.oracle.classloader.util.DigestBuilder;
/*   5:    */ import com.oracle.util.Matcher;
/*   6:    */ import java.io.File;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.InputStream;
/*   9:    */ import java.lang.reflect.Constructor;
/*  10:    */ import java.lang.reflect.InvocationTargetException;
/*  11:    */ import java.lang.reflect.Method;
/*  12:    */ import java.net.URI;
/*  13:    */ import java.net.URL;
/*  14:    */ import java.security.CodeSigner;
/*  15:    */ import java.util.ArrayList;
/*  16:    */ import java.util.Collection;
/*  17:    */ import java.util.Enumeration;
/*  18:    */ import java.util.List;
/*  19:    */ import java.util.Locale;
/*  20:    */ import java.util.Set;
/*  21:    */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*  22:    */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*  23:    */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*  24:    */ import java.util.jar.JarEntry;
/*  25:    */ import java.util.jar.JarFile;
/*  26:    */ import java.util.jar.Manifest;
/*  27:    */ 
/*  28:    */ public class JarCodeSource
/*  29:    */   extends CodeSource
/*  30:    */   implements FileSource
/*  31:    */ {
/*  32:    */   private String base;
/*  33:    */   private File file;
/*  34:    */   private transient JarFile jar;
/*  35:    */   private final ReentrantReadWriteLock.ReadLock readLock;
/*  36:    */   private final ReentrantReadWriteLock.WriteLock writeLock;
/*  37:    */   private boolean signersChecked;
/*  38:    */   private boolean hasSignatureFiles;
/*  39:    */   private JarEntry firstClassEntry;
/*  40:    */   private CodeSigner[] signers;
/*  41:    */   private static final Object runtimeVersion;
/*  42:    */   private static final Constructor<?> jarFileConstructor;
/*  43: 54 */   private static final Boolean verifyArg = Boolean.TRUE;
/*  44: 55 */   private static final Integer modeArg = Integer.valueOf(1);
/*  45:    */   
/*  46:    */   static
/*  47:    */   {
/*  48: 58 */     Method runtimeVersionMethod = null;
/*  49:    */     try
/*  50:    */     {
/*  51: 60 */       runtimeVersionMethod = JarFile.class.getMethod("runtimeVersion", new Class[0]);
/*  52:    */     }
/*  53:    */     catch (NoSuchMethodException localNoSuchMethodException) {}
/*  54: 63 */     Object ver = null;
/*  55: 64 */     if (runtimeVersionMethod != null) {
/*  56:    */       try
/*  57:    */       {
/*  58: 66 */         ver = runtimeVersionMethod.invoke(null, new Object[0]);
/*  59:    */       }
/*  60:    */       catch (IllegalAccessException|IllegalArgumentException|InvocationTargetException e)
/*  61:    */       {
/*  62: 68 */         throw new RuntimeException(e);
/*  63:    */       }
/*  64:    */     }
/*  65: 71 */     runtimeVersion = ver;
/*  66:    */     
/*  67: 73 */     Constructor<?> c = null;
/*  68: 74 */     if (runtimeVersion != null) {
/*  69:    */       try
/*  70:    */       {
/*  71: 76 */         c = JarFile.class.getConstructor(new Class[] { File.class, Boolean.TYPE, Integer.TYPE, runtimeVersion.getClass() });
/*  72:    */       }
/*  73:    */       catch (NoSuchMethodException|SecurityException e)
/*  74:    */       {
/*  75: 78 */         throw new RuntimeException(e);
/*  76:    */       }
/*  77:    */     }
/*  78: 81 */     jarFileConstructor = c;
/*  79:    */   }
/*  80:    */   
/*  81:    */   protected JarCodeSource(URI uri, File jarFile)
/*  82:    */     throws IOException
/*  83:    */   {
/*  84: 91 */     super(uri);
/*  85: 92 */     this.base = (uri.toString() + '!' + '/');
/*  86: 93 */     this.file = jarFile;
/*  87: 94 */     this.jar = openJarFile(this.file);
/*  88: 95 */     ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
/*  89: 96 */     this.readLock = lock.readLock();
/*  90: 97 */     this.writeLock = lock.writeLock();
/*  91:    */   }
/*  92:    */   
/*  93:    */   private JarFile openJarFile(File file)
/*  94:    */     throws IOException
/*  95:    */   {
/*  96:102 */     if (jarFileConstructor != null) {
/*  97:    */       try
/*  98:    */       {
/*  99:107 */         return (JarFile)jarFileConstructor.newInstance(new Object[] { file, verifyArg, modeArg, runtimeVersion });
/* 100:    */       }
/* 101:    */       catch (InvocationTargetException ite)
/* 102:    */       {
/* 103:109 */         Throwable t = ite.getCause();
/* 104:110 */         if ((t instanceof IOException)) {
/* 105:111 */           throw ((IOException)t);
/* 106:    */         }
/* 107:112 */         if ((t instanceof RuntimeException)) {
/* 108:113 */           throw ((RuntimeException)t);
/* 109:    */         }
/* 110:115 */         throw new RuntimeException(t);
/* 111:    */       }
/* 112:    */       catch (InstantiationException|IllegalAccessException|IllegalArgumentException e)
/* 113:    */       {
/* 114:117 */         throw new RuntimeException(e);
/* 115:    */       }
/* 116:    */     }
/* 117:120 */     return new JarCodeSource.1(this, file);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public long getLastModifiedTime()
/* 121:    */   {
/* 122:137 */     return this.file.lastModified();
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void updateSignature(DigestBuilder digest)
/* 126:    */   {
/* 127:148 */     super.updateSignature(digest);
/* 128:149 */     digest.update(this.file.length());
/* 129:    */   }
/* 130:    */   
/* 131:    */   public Manifest getManifest()
/* 132:    */     throws IOException
/* 133:    */   {
/* 134:157 */     return this.jar.getManifest();
/* 135:    */   }
/* 136:    */   
/* 137:    */   public Collection<String> getResources()
/* 138:    */   {
/* 139:165 */     List<String> result = new ArrayList(128);
/* 140:166 */     for (Enumeration<JarEntry> e = getJarEntries(); e.hasMoreElements();)
/* 141:    */     {
/* 142:167 */       JarEntry entry = (JarEntry)e.nextElement();
/* 143:168 */       if (!entry.isDirectory()) {
/* 144:169 */         result.add(entry.getName());
/* 145:    */       }
/* 146:    */     }
/* 147:172 */     return result;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public Collection<String> getResources(Matcher<String> matcher)
/* 151:    */   {
/* 152:181 */     List<String> result = new ArrayList(128);
/* 153:182 */     for (Enumeration<JarEntry> e = getJarEntries(); e.hasMoreElements();)
/* 154:    */     {
/* 155:183 */       JarEntry entry = (JarEntry)e.nextElement();
/* 156:184 */       if (!entry.isDirectory())
/* 157:    */       {
/* 158:185 */         String path = entry.getName();
/* 159:186 */         if (matcher.matches(path)) {
/* 160:187 */           result.add(path);
/* 161:    */         }
/* 162:    */       }
/* 163:    */     }
/* 164:191 */     return result;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public URL getResource(String relativePath)
/* 168:    */   {
/* 169:200 */     JarEntry entry = getJarEntry(relativePath);
/* 170:201 */     if (entry != null) {
/* 171:205 */       return JarURLHandler.createJarURL(this, entry, this.base, relativePath, false);
/* 172:    */     }
/* 173:207 */     return null;
/* 174:    */   }
/* 175:    */   
/* 176:    */   public boolean getResourceData(String relativePath, CodeSourceBuffer buffer)
/* 177:    */   {
/* 178:    */     try
/* 179:    */     {
/* 180:220 */       JarEntry entry = getJarEntry(relativePath);
/* 181:221 */       if (entry != null)
/* 182:    */       {
/* 183:222 */         int size = (int)entry.getSize();
/* 184:223 */         InputStream in = getJarInputStream(entry);
/* 185:224 */         buffer.read(in, size);
/* 186:225 */         buffer.setCodeSource(this);
/* 187:226 */         buffer.setCertificates(entry.getCertificates());
/* 188:227 */         buffer.setSigners(entry.getCodeSigners());
/* 189:228 */         return true;
/* 190:    */       }
/* 191:    */     }
/* 192:    */     catch (IOException e)
/* 193:    */     {
/* 194:231 */       Logger.logWarning(e.getMessage());
/* 195:    */     }
/* 196:233 */     return false;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public File getFile()
/* 200:    */   {
/* 201:241 */     return this.file;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public JarFile getJarFile()
/* 205:    */   {
/* 206:246 */     return this.jar;
/* 207:    */   }
/* 208:    */   
/* 209:    */   protected CodeSigner[] getCodeSigners()
/* 210:    */   {
/* 211:254 */     if ((this.signers == null) && (!this.signersChecked))
/* 212:    */     {
/* 213:    */       try
/* 214:    */       {
/* 215:256 */         getPackageNames();
/* 216:    */       }
/* 217:    */       catch (TooManyPackagesException localTooManyPackagesException) {}
/* 218:258 */       if (this.firstClassEntry != null) {
/* 219:    */         try
/* 220:    */         {
/* 221:266 */           this.signers = getCodeSigners(this.firstClassEntry);
/* 222:267 */           if (this.signers == null) {
/* 223:272 */             for (e = getJarEntries(); e.hasMoreElements();)
/* 224:    */             {
/* 225:273 */               JarEntry entry = (JarEntry)e.nextElement();
/* 226:274 */               if (!entry.isDirectory())
/* 227:    */               {
/* 228:275 */                 String name = entry.getName();
/* 229:276 */                 if ((name.endsWith(".class")) && (!name.equals(this.firstClassEntry.getName())))
/* 230:    */                 {
/* 231:277 */                   this.signers = getCodeSigners(entry);
/* 232:278 */                   if (this.signers != null) {
/* 233:    */                     break;
/* 234:    */                   }
/* 235:    */                 }
/* 236:    */               }
/* 237:    */             }
/* 238:    */           }
/* 239:    */         }
/* 240:    */         catch (Throwable t)
/* 241:    */         {
/* 242:    */           Enumeration<JarEntry> e;
/* 243:286 */           Logger.logWarning("getCodeSigners failed", t);
/* 244:    */         }
/* 245:    */       }
/* 246:289 */       this.signersChecked = true;
/* 247:    */     }
/* 248:291 */     return this.signers;
/* 249:    */   }
/* 250:    */   
/* 251:    */   protected void addPackageNames(Set<String> packages)
/* 252:    */   {
/* 253:299 */     for (Enumeration<JarEntry> e = getJarEntries(); e.hasMoreElements();)
/* 254:    */     {
/* 255:300 */       JarEntry entry = (JarEntry)e.nextElement();
/* 256:301 */       String name = entry.getName();
/* 257:302 */       if (!entry.isDirectory()) {
/* 258:303 */         if ((!this.hasSignatureFiles) && (name.startsWith("META-INF/")))
/* 259:    */         {
/* 260:304 */           String min = name.toUpperCase(Locale.ENGLISH);
/* 261:305 */           if ((min.endsWith(".DSA")) || (min.endsWith(".RSA")) || (min.endsWith(".SF"))) {
/* 262:306 */             this.hasSignatureFiles = true;
/* 263:    */           }
/* 264:    */         }
/* 265:308 */         else if ((this.hasSignatureFiles) && (this.firstClassEntry == null) && (!entry.isDirectory()) && (name.endsWith(".class")))
/* 266:    */         {
/* 267:309 */           this.firstClassEntry = entry;
/* 268:    */         }
/* 269:    */       }
/* 270:312 */       String packageName = PolicyClassLoader.getResourcePackageName(name);
/* 271:313 */       packages.add(packageName);
/* 272:    */     }
/* 273:315 */     packages.add("");
/* 274:    */   }
/* 275:    */   
/* 276:    */   protected <T> T withJarFileNoException(JarCodeSource.Function<JarFile, T> function)
/* 277:    */   {
/* 278:    */     try
/* 279:    */     {
/* 280:320 */       return withJarFile(function);
/* 281:    */     }
/* 282:    */     catch (IOException io)
/* 283:    */     {
/* 284:322 */       throw new RuntimeException(io);
/* 285:    */     }
/* 286:    */   }
/* 287:    */   
/* 288:    */   protected Enumeration<JarEntry> getJarEntries()
/* 289:    */   {
/* 290:372 */     return (Enumeration)withJarFileNoException(new JarCodeSource.2(this));
/* 291:    */   }
/* 292:    */   
/* 293:    */   InputStream getJarInputStream(JarEntry entry)
/* 294:    */     throws IOException
/* 295:    */   {
/* 296:381 */     return (InputStream)withJarFile(new JarCodeSource.3(this, entry));
/* 297:    */   }
/* 298:    */   
/* 299:    */   JarEntry getJarEntry(String relativePath)
/* 300:    */   {
/* 301:390 */     return (JarEntry)withJarFileNoException(new JarCodeSource.4(this, relativePath));
/* 302:    */   }
/* 303:    */   
/* 304:    */   private CodeSigner[] getCodeSigners(JarEntry entry)
/* 305:    */     throws IOException
/* 306:    */   {
/* 307:401 */     byte[] buffer = new byte[(int)entry.getSize() + 32];
/* 308:402 */     InputStream in = getJarInputStream(entry);
/* 309:403 */     while (in.read(buffer) > 0) {}
/* 310:405 */     in.close();
/* 311:406 */     return entry.getCodeSigners();
/* 312:    */   }
/* 313:    */   
/* 314:    */   /* Error */
/* 315:    */   protected <T> T withJarFile(JarCodeSource.Function<JarFile, T> function)
/* 316:    */     throws IOException
/* 317:    */   {
/* 318:    */     // Byte code:
/* 319:    */     //   0: aconst_null
/* 320:    */     //   1: astore_2
/* 321:    */     //   2: aload_0
/* 322:    */     //   3: getfield 15	com/oracle/classloader/JarCodeSource:readLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;
/* 323:    */     //   6: invokevirtual 86	java/util/concurrent/locks/ReentrantReadWriteLock$ReadLock:lock	()V
/* 324:    */     //   9: aload_0
/* 325:    */     //   10: getfield 11	com/oracle/classloader/JarCodeSource:jar	Ljava/util/jar/JarFile;
/* 326:    */     //   13: astore_2
/* 327:    */     //   14: aload_1
/* 328:    */     //   15: aload_2
/* 329:    */     //   16: invokeinterface 87 2 0
/* 330:    */     //   21: astore_3
/* 331:    */     //   22: aload_0
/* 332:    */     //   23: getfield 15	com/oracle/classloader/JarCodeSource:readLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;
/* 333:    */     //   26: invokevirtual 88	java/util/concurrent/locks/ReentrantReadWriteLock$ReadLock:unlock	()V
/* 334:    */     //   29: aload_3
/* 335:    */     //   30: areturn
/* 336:    */     //   31: astore 4
/* 337:    */     //   33: aload_0
/* 338:    */     //   34: getfield 15	com/oracle/classloader/JarCodeSource:readLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;
/* 339:    */     //   37: invokevirtual 88	java/util/concurrent/locks/ReentrantReadWriteLock$ReadLock:unlock	()V
/* 340:    */     //   40: aload 4
/* 341:    */     //   42: athrow
/* 342:    */     //   43: astore_3
/* 343:    */     //   44: iconst_0
/* 344:    */     //   45: istore 4
/* 345:    */     //   47: iload 4
/* 346:    */     //   49: bipush 100
/* 347:    */     //   51: if_icmpge +97 -> 148
/* 348:    */     //   54: aload_0
/* 349:    */     //   55: getfield 17	com/oracle/classloader/JarCodeSource:writeLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/* 350:    */     //   58: invokevirtual 90	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:lock	()V
/* 351:    */     //   61: aload_2
/* 352:    */     //   62: ifnull +11 -> 73
/* 353:    */     //   65: aload_2
/* 354:    */     //   66: aload_0
/* 355:    */     //   67: getfield 11	com/oracle/classloader/JarCodeSource:jar	Ljava/util/jar/JarFile;
/* 356:    */     //   70: if_acmpne +27 -> 97
/* 357:    */     //   73: aload_0
/* 358:    */     //   74: aload_0
/* 359:    */     //   75: aload_0
/* 360:    */     //   76: getfield 9	com/oracle/classloader/JarCodeSource:file	Ljava/io/File;
/* 361:    */     //   79: invokespecial 10	com/oracle/classloader/JarCodeSource:openJarFile	(Ljava/io/File;)Ljava/util/jar/JarFile;
/* 362:    */     //   82: putfield 11	com/oracle/classloader/JarCodeSource:jar	Ljava/util/jar/JarFile;
/* 363:    */     //   85: goto +7 -> 92
/* 364:    */     //   88: astore 5
/* 365:    */     //   90: aload_3
/* 366:    */     //   91: athrow
/* 367:    */     //   92: aload_0
/* 368:    */     //   93: getfield 11	com/oracle/classloader/JarCodeSource:jar	Ljava/util/jar/JarFile;
/* 369:    */     //   96: astore_2
/* 370:    */     //   97: aload_1
/* 371:    */     //   98: aload_2
/* 372:    */     //   99: invokeinterface 87 2 0
/* 373:    */     //   104: astore 5
/* 374:    */     //   106: aload_0
/* 375:    */     //   107: getfield 17	com/oracle/classloader/JarCodeSource:writeLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/* 376:    */     //   110: invokevirtual 91	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/* 377:    */     //   113: aload 5
/* 378:    */     //   115: areturn
/* 379:    */     //   116: astore 5
/* 380:    */     //   118: aconst_null
/* 381:    */     //   119: astore_2
/* 382:    */     //   120: aload_0
/* 383:    */     //   121: getfield 17	com/oracle/classloader/JarCodeSource:writeLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/* 384:    */     //   124: invokevirtual 91	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/* 385:    */     //   127: goto +15 -> 142
/* 386:    */     //   130: astore 6
/* 387:    */     //   132: aload_0
/* 388:    */     //   133: getfield 17	com/oracle/classloader/JarCodeSource:writeLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/* 389:    */     //   136: invokevirtual 91	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/* 390:    */     //   139: aload 6
/* 391:    */     //   141: athrow
/* 392:    */     //   142: iinc 4 1
/* 393:    */     //   145: goto -98 -> 47
/* 394:    */     //   148: new 89	java/lang/IllegalStateException
/* 395:    */     //   151: dup
/* 396:    */     //   152: invokespecial 92	java/lang/IllegalStateException:<init>	()V
/* 397:    */     //   155: athrow
/* 398:    */     // Line number table:
/* 399:    */     //   Java source line #332	-> byte code offset #0
/* 400:    */     //   Java source line #334	-> byte code offset #2
/* 401:    */     //   Java source line #336	-> byte code offset #9
/* 402:    */     //   Java source line #337	-> byte code offset #14
/* 403:    */     //   Java source line #339	-> byte code offset #22
/* 404:    */     //   Java source line #337	-> byte code offset #29
/* 405:    */     //   Java source line #339	-> byte code offset #31
/* 406:    */     //   Java source line #340	-> byte code offset #40
/* 407:    */     //   Java source line #341	-> byte code offset #43
/* 408:    */     //   Java source line #346	-> byte code offset #44
/* 409:    */     //   Java source line #348	-> byte code offset #54
/* 410:    */     //   Java source line #350	-> byte code offset #61
/* 411:    */     //   Java source line #352	-> byte code offset #73
/* 412:    */     //   Java source line #355	-> byte code offset #85
/* 413:    */     //   Java source line #353	-> byte code offset #88
/* 414:    */     //   Java source line #354	-> byte code offset #90
/* 415:    */     //   Java source line #356	-> byte code offset #92
/* 416:    */     //   Java source line #359	-> byte code offset #97
/* 417:    */     //   Java source line #364	-> byte code offset #106
/* 418:    */     //   Java source line #359	-> byte code offset #113
/* 419:    */     //   Java source line #360	-> byte code offset #116
/* 420:    */     //   Java source line #361	-> byte code offset #118
/* 421:    */     //   Java source line #364	-> byte code offset #120
/* 422:    */     //   Java source line #365	-> byte code offset #127
/* 423:    */     //   Java source line #364	-> byte code offset #130
/* 424:    */     //   Java source line #365	-> byte code offset #139
/* 425:    */     //   Java source line #346	-> byte code offset #142
/* 426:    */     //   Java source line #367	-> byte code offset #148
/* 427:    */     // Local variable table:
/* 428:    */     //   start	length	slot	name	signature
/* 429:    */     //   0	156	0	this	JarCodeSource
/* 430:    */     //   0	156	1	function	JarCodeSource.Function<JarFile, T>
/* 431:    */     //   1	119	2	stableJar	JarFile
/* 432:    */     //   43	48	3	e	java.lang.IllegalStateException
/* 433:    */     //   31	10	4	localObject2	Object
/* 434:    */     //   45	98	4	count	int
/* 435:    */     //   88	26	5	i	IOException
/* 436:    */     //   116	3	5	i	java.lang.IllegalStateException
/* 437:    */     //   130	10	6	localObject3	Object
/* 438:    */     // Exception table:
/* 439:    */     //   from	to	target	type
/* 440:    */     //   9	22	31	finally
/* 441:    */     //   31	33	31	finally
/* 442:    */     //   2	29	43	java/lang/IllegalStateException
/* 443:    */     //   31	43	43	java/lang/IllegalStateException
/* 444:    */     //   73	85	88	java/io/IOException
/* 445:    */     //   97	106	116	java/lang/IllegalStateException
/* 446:    */     //   61	106	130	finally
/* 447:    */     //   116	120	130	finally
/* 448:    */     //   130	132	130	finally
/* 449:    */   }
/* 450:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.JarCodeSource
 * JD-Core Version:    0.7.0.1
 */