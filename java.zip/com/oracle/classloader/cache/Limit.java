/*  1:   */ package com.oracle.classloader.cache;
/*  2:   */ 
/*  3:   */ public class Limit
/*  4:   */ {
/*  5:   */   private static final String RUNNING = "@running";
/*  6:   */   protected boolean reached;
/*  7:   */   
/*  8:   */   public static Limit newLimit(String limit)
/*  9:   */   {
/* 10:23 */     if ((limit == null) || (limit.length() == 0) || (limit.equals("@running"))) {
/* 11:24 */       return new Limit();
/* 12:   */     }
/* 13:25 */     if (Character.isDigit(limit.charAt(0))) {
/* 14:26 */       return new Limit.Count(Integer.parseInt(limit));
/* 15:   */     }
/* 16:28 */     return new Limit.ClassName(limit);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setReached()
/* 20:   */   {
/* 21:36 */     this.reached = true;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public boolean isReached(String className)
/* 25:   */   {
/* 26:45 */     return this.reached;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String toString()
/* 30:   */   {
/* 31:49 */     return "external";
/* 32:   */   }
/* 33:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.cache.Limit
 * JD-Core Version:    0.7.0.1
 */