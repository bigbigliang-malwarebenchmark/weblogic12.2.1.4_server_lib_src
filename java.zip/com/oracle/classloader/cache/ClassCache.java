/*   1:    */ package com.oracle.classloader.cache;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.CodeSourceBuffer;
/*   4:    */ import com.oracle.classloader.CodeSourceIndex;
/*   5:    */ import com.oracle.classloader.CodeSourceList;
/*   6:    */ import com.oracle.classloader.PolicyClassLoader;
/*   7:    */ import com.oracle.classloader.SearchPolicy;
/*   8:    */ import com.oracle.classloader.index.EagerCodeSourceIndex;
/*   9:    */ import com.oracle.classloader.index.PackageIndices;
/*  10:    */ import com.oracle.classloader.log.Logger;
/*  11:    */ import com.oracle.classloader.search.SearchCodeSources;
/*  12:    */ import com.oracle.classloader.util.DigestBuilder;
/*  13:    */ import java.io.IOException;
/*  14:    */ import java.net.MalformedURLException;
/*  15:    */ import java.net.URISyntaxException;
/*  16:    */ import java.net.URL;
/*  17:    */ import java.util.List;
/*  18:    */ import java.util.Map;
/*  19:    */ 
/*  20:    */ public abstract class ClassCache
/*  21:    */   extends SearchCodeSources
/*  22:    */ {
/*  23: 42 */   private static final boolean JROCKIT = System.getProperty("java.vm.name").contains("JRockit");
/*  24:    */   private static final String JAVA_PACKAGE = "java.";
/*  25: 44 */   private static final String[] DIGEST_PROPERTIES = { "java.version", "java.vm.name", "java.vm.version", "os.name", "os.arch", "os.version" };
/*  26:    */   private long startTime;
/*  27:    */   private SearchPolicy searchDelegates;
/*  28:    */   private SearchPolicy searchCodeSources;
/*  29: 56 */   private ClassCache.State state = ClassCache.State.INITIALIZE;
/*  30:    */   private final boolean delayInitialize;
/*  31:    */   private Limit limit;
/*  32:    */   private int defineClassDepth;
/*  33:    */   private String initialClass;
/*  34:    */   
/*  35:    */   public ClassCache(SearchPolicy delegatePolicy, CodeSourceList codeSources, Limit limit)
/*  36:    */   {
/*  37: 94 */     this(delegatePolicy, codeSources, limit, false);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public ClassCache(SearchPolicy delegatePolicy, CodeSourceList codeSources, Limit limit, boolean delayInitialize)
/*  41:    */   {
/*  42:104 */     super(codeSources);
/*  43:105 */     if (codeSources.size() == 0) {
/*  44:106 */       throw new IllegalStateException("CodeSourceList may not be empty.");
/*  45:    */     }
/*  46:108 */     this.startTime = System.currentTimeMillis();
/*  47:109 */     this.limit = limit;
/*  48:110 */     this.searchDelegates = delegatePolicy;
/*  49:111 */     this.searchCodeSources = new SearchCodeSources(codeSources, this);
/*  50:112 */     this.delayInitialize = delayInitialize;
/*  51:    */   }
/*  52:    */   
/*  53:    */   protected SearchPolicy getDelegatePolicy()
/*  54:    */   {
/*  55:116 */     return this.searchDelegates;
/*  56:    */   }
/*  57:    */   
/*  58:    */   protected SearchPolicy getCodeSourcesPolicy()
/*  59:    */   {
/*  60:120 */     return this.searchCodeSources;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void setDelegatingLoader(PolicyClassLoader loader)
/*  64:    */   {
/*  65:132 */     super.setDelegatingLoader(loader);
/*  66:133 */     this.searchDelegates.setDelegatingLoader(loader);
/*  67:134 */     this.initialClass = "";
/*  68:135 */     if (!this.delayInitialize) {
/*  69:136 */       initialize();
/*  70:    */     }
/*  71:    */   }
/*  72:    */   
/*  73:    */   public URL getResource(String resourcePath, String packageName)
/*  74:    */   {
/*  75:146 */     URL result = null;
/*  76:147 */     switch (ClassCache.1.$SwitchMap$com$oracle$classloader$cache$ClassCache$State[this.state.ordinal()])
/*  77:    */     {
/*  78:    */     case 1: 
/*  79:149 */       result = this.searchDelegates.getResource(resourcePath, packageName);
/*  80:150 */       if (result == null) {
/*  81:151 */         result = super.getResource(resourcePath, packageName);
/*  82:    */       }
/*  83:    */       break;
/*  84:    */     case 2: 
/*  85:155 */       initialize();
/*  86:156 */       return getResource(resourcePath, packageName);
/*  87:    */     case 3: 
/*  88:158 */       return this.searchDelegates.getResource(resourcePath, packageName);
/*  89:    */     case 4: 
/*  90:160 */       result = this.searchDelegates.getResource(resourcePath, packageName);
/*  91:161 */       if (result == null) {
/*  92:162 */         result = super.getResource(resourcePath, packageName);
/*  93:    */       }
/*  94:    */       break;
/*  95:    */     }
/*  96:168 */     return result;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void addResources(String resourcePath, String packageName, List<URL> result)
/* 100:    */   {
/* 101:178 */     if (this.state == ClassCache.State.STORE)
/* 102:    */     {
/* 103:179 */       this.searchDelegates.addResources(resourcePath, packageName, result);
/* 104:180 */       super.addResources(resourcePath, packageName, result);
/* 105:    */     }
/* 106:    */   }
/* 107:    */   
/* 108:    */   public Class<?> loadClass(String className, String packageName)
/* 109:    */   {
/* 110:191 */     switch (ClassCache.1.$SwitchMap$com$oracle$classloader$cache$ClassCache$State[this.state.ordinal()])
/* 111:    */     {
/* 112:    */     case 5: 
/* 113:193 */       return this.searchDelegates.loadClass(className, packageName);
/* 114:    */     case 6: 
/* 115:197 */       if ((JROCKIT) && (packageName.startsWith("java."))) {
/* 116:198 */         return this.searchDelegates.loadClass(className, packageName);
/* 117:    */       }
/* 118:    */       try
/* 119:    */       {
/* 120:201 */         return loadNextClass(className, packageName);
/* 121:    */       }
/* 122:    */       catch (MalformedURLException|URISyntaxException e)
/* 123:    */       {
/* 124:203 */         throw new RuntimeException(e);
/* 125:    */       }
/* 126:    */     case 1: 
/* 127:208 */       return store(className, packageName);
/* 128:    */     case 2: 
/* 129:212 */       initialize();
/* 130:213 */       return loadClass(className, packageName);
/* 131:    */     case 3: 
/* 132:217 */       return this.searchDelegates.loadClass(className, packageName);
/* 133:    */     case 4: 
/* 134:220 */       Class<?> result = this.searchDelegates.loadClass(className, packageName);
/* 135:221 */       if (result == null) {
/* 136:222 */         result = super.loadClass(className, packageName);
/* 137:    */       }
/* 138:224 */       return result;
/* 139:    */     }
/* 140:227 */     throw new IllegalStateException(this.state.toString());
/* 141:    */   }
/* 142:    */   
/* 143:    */   private Class<?> store(String className, String packageName)
/* 144:    */   {
/* 145:235 */     Class<?> result = this.searchDelegates.loadClass(className, packageName);
/* 146:236 */     if (result == null) {
/* 147:241 */       result = super.loadClass(className, packageName);
/* 148:243 */     } else if (shouldRecord(className)) {
/* 149:249 */       if (!this.initialClass.equals(className)) {
/* 150:250 */         storeDelegateClassName(className);
/* 151:    */       }
/* 152:    */     }
/* 153:253 */     return result;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public String toString()
/* 157:    */   {
/* 158:261 */     return "Cache";
/* 159:    */   }
/* 160:    */   
/* 161:    */   protected Class<?> defineClass(String className, CodeSourceBuffer classData, int codeSourceIndex)
/* 162:    */   {
/* 163:271 */     int startPosition = -1;
/* 164:272 */     if (shouldRecord(className)) {
/* 165:    */       try
/* 166:    */       {
/* 167:274 */         startPosition = storeClass(className, classData, codeSourceIndex);
/* 168:    */       }
/* 169:    */       catch (Throwable t)
/* 170:    */       {
/* 171:276 */         shutdown(t);
/* 172:    */       }
/* 173:    */     }
/* 174:279 */     this.defineClassDepth += 1;
/* 175:    */     try
/* 176:    */     {
/* 177:281 */       return super.defineClass(className, classData, codeSourceIndex);
/* 178:    */     }
/* 179:    */     catch (LinkageError e)
/* 180:    */     {
/* 181:283 */       if (startPosition >= 0) {
/* 182:284 */         handleDefineError(e, startPosition);
/* 183:    */       }
/* 184:286 */       throw e;
/* 185:    */     }
/* 186:    */     finally
/* 187:    */     {
/* 188:288 */       this.defineClassDepth -= 1;
/* 189:    */     }
/* 190:    */   }
/* 191:    */   
/* 192:    */   private ClassCache.State initialize()
/* 193:    */   {
/* 194:    */     try
/* 195:    */     {
/* 196:301 */       if (this.state != ClassCache.State.INITIALIZE) {
/* 197:302 */         throw new IllegalStateException("Not in " + ClassCache.State.INITIALIZE);
/* 198:    */       }
/* 199:304 */       this.state = ClassCache.State.INITIALIZING;
/* 200:    */       
/* 201:306 */       DigestBuilder b = new DigestBuilder();
/* 202:307 */       byte[] digest = updateDigest(b).digest();
/* 203:308 */       if (open(digest)) {
/* 204:312 */         load();
/* 205:    */       } else {
/* 206:318 */         store(digest);
/* 207:    */       }
/* 208:    */     }
/* 209:    */     catch (ThreadDeath death)
/* 210:    */     {
/* 211:322 */       throw death;
/* 212:    */     }
/* 213:    */     catch (Throwable t)
/* 214:    */     {
/* 215:324 */       shutdown(t);
/* 216:    */     }
/* 217:327 */     return this.state;
/* 218:    */   }
/* 219:    */   
/* 220:    */   protected void store(byte[] digest)
/* 221:    */     throws Exception
/* 222:    */   {
/* 223:336 */     Logger.setCacheStoreLimit(this.limit);
/* 224:    */     
/* 225:    */ 
/* 226:    */ 
/* 227:340 */     initializeForStore(digest);
/* 228:341 */     this.state = ClassCache.State.STORE;
/* 229:    */     
/* 230:    */ 
/* 231:    */ 
/* 232:345 */     CodeSourceIndex index = new EagerCodeSourceIndex(getCodeSources());
/* 233:346 */     getCodeSources().resetIndex(index, true);
/* 234:    */     
/* 235:    */ 
/* 236:    */ 
/* 237:350 */     storeIndex(index);
/* 238:    */   }
/* 239:    */   
/* 240:    */   public ClassCache.State getState()
/* 241:    */   {
/* 242:358 */     return this.state;
/* 243:    */   }
/* 244:    */   
/* 245:    */   public void close()
/* 246:    */   {
/* 247:365 */     if (this.state != ClassCache.State.CLOSED) {
/* 248:366 */       shutdown(null);
/* 249:    */     }
/* 250:    */   }
/* 251:    */   
/* 252:    */   private void shutdown(Throwable error)
/* 253:    */   {
/* 254:    */     try
/* 255:    */     {
/* 256:372 */       close(error == null ? this.state : ClassCache.State.FAILED);
/* 257:373 */       setClosed(this.state == ClassCache.State.STORE, error);
/* 258:    */     }
/* 259:    */     catch (Throwable t)
/* 260:    */     {
/* 261:375 */       setClosed(this.state == ClassCache.State.STORE, t);
/* 262:    */     }
/* 263:    */   }
/* 264:    */   
/* 265:    */   protected void setClosed(boolean store, Throwable error)
/* 266:    */   {
/* 267:    */     
/* 268:389 */     if (error == null)
/* 269:    */     {
/* 270:390 */       if (Logger.willLogFine())
/* 271:    */       {
/* 272:391 */         long elapsedTime = System.currentTimeMillis() - this.startTime;
/* 273:392 */         Logger.logFine("Cache " + (store ? "store" : "load") + " completed in " + elapsedTime + "ms.");
/* 274:    */       }
/* 275:    */     }
/* 276:395 */     else if ((error.getMessage() != null) && (error.getMessage().startsWith("NoStack"))) {
/* 277:396 */       Logger.logWarning("Cache " + (store ? "store" : "load") + " failed: " + error);
/* 278:    */     } else {
/* 279:398 */       Logger.logWarning("Cache " + (store ? "store" : "load") + " failed.", error);
/* 280:    */     }
/* 281:404 */     this.state = ClassCache.State.CLOSED;
/* 282:    */   }
/* 283:    */   
/* 284:    */   protected DigestBuilder updateDigest(DigestBuilder builder)
/* 285:    */   {
/* 286:413 */     for (String propertyKey : DIGEST_PROPERTIES) {
/* 287:414 */       builder.update(System.getProperty(propertyKey));
/* 288:    */     }
/* 289:416 */     getCodeSources().updateSignature(builder);
/* 290:417 */     if (this.limit != null) {
/* 291:418 */       builder.update(this.limit.toString());
/* 292:    */     }
/* 293:420 */     return builder;
/* 294:    */   }
/* 295:    */   
/* 296:    */   public static boolean digestsEqual(byte[] digest1, byte[] digest2)
/* 297:    */   {
/* 298:430 */     if (digest1.length == digest2.length)
/* 299:    */     {
/* 300:431 */       for (int i = 0; i < digest1.length; i++) {
/* 301:432 */         if (digest1[i] != digest2[i]) {
/* 302:433 */           return false;
/* 303:    */         }
/* 304:    */       }
/* 305:436 */       return true;
/* 306:    */     }
/* 307:438 */     return false;
/* 308:    */   }
/* 309:    */   
/* 310:    */   private boolean shouldRecord(String classOrPackageName)
/* 311:    */   {
/* 312:442 */     if (this.state == ClassCache.State.STORE)
/* 313:    */     {
/* 314:443 */       if ((this.defineClassDepth == 0) && (reachedLimit(classOrPackageName)))
/* 315:    */       {
/* 316:444 */         close();
/* 317:445 */         return false;
/* 318:    */       }
/* 319:447 */       return true;
/* 320:    */     }
/* 321:450 */     return false;
/* 322:    */   }
/* 323:    */   
/* 324:    */   protected abstract boolean open(byte[] paramArrayOfByte)
/* 325:    */     throws IOException;
/* 326:    */   
/* 327:    */   protected abstract void initializeForLoad()
/* 328:    */     throws IOException, URISyntaxException;
/* 329:    */   
/* 330:    */   protected abstract void initializeForStore(byte[] paramArrayOfByte)
/* 331:    */     throws IOException;
/* 332:    */   
/* 333:    */   protected final boolean reachedLimit(String classOrPackageName)
/* 334:    */   {
/* 335:484 */     return this.limit.isReached(classOrPackageName);
/* 336:    */   }
/* 337:    */   
/* 338:    */   protected Limit getLimit()
/* 339:    */   {
/* 340:488 */     return this.limit;
/* 341:    */   }
/* 342:    */   
/* 343:    */   protected abstract void storeDelegateClassName(String paramString);
/* 344:    */   
/* 345:    */   protected abstract int storeClass(String paramString, CodeSourceBuffer paramCodeSourceBuffer, int paramInt);
/* 346:    */   
/* 347:    */   protected abstract void handleDefineError(LinkageError paramLinkageError, int paramInt);
/* 348:    */   
/* 349:    */   protected abstract void storeIndex(CodeSourceIndex paramCodeSourceIndex);
/* 350:    */   
/* 351:    */   protected void load()
/* 352:    */     throws Exception
/* 353:    */   {
/* 354:527 */     initializeForLoad();
/* 355:    */     
/* 356:    */ 
/* 357:    */ 
/* 358:    */ 
/* 359:532 */     this.state = ClassCache.State.LOAD_DELEGATE_CLASSES;
/* 360:533 */     loadDelegateClasses();
/* 361:    */     
/* 362:    */ 
/* 363:    */ 
/* 364:537 */     this.state = ClassCache.State.LOAD_INDEX;
/* 365:538 */     CodeSourceIndex index = loadIndex();
/* 366:539 */     getCodeSources().resetIndex(index, false);
/* 367:    */     
/* 368:    */ 
/* 369:    */ 
/* 370:543 */     this.state = ClassCache.State.LOAD_PACKAGES;
/* 371:544 */     definePackages(index);
/* 372:    */     
/* 373:    */ 
/* 374:    */ 
/* 375:548 */     this.state = ClassCache.State.LOAD_CLASSES;
/* 376:549 */     while (loadNextClass(null, null) != null) {}
/* 377:554 */     close();
/* 378:    */   }
/* 379:    */   
/* 380:    */   protected abstract void loadDelegateClasses()
/* 381:    */     throws ClassNotFoundException;
/* 382:    */   
/* 383:    */   protected abstract CodeSourceIndex loadIndex();
/* 384:    */   
/* 385:    */   protected abstract Class<?> loadNextClass(String paramString1, String paramString2)
/* 386:    */     throws MalformedURLException, URISyntaxException;
/* 387:    */   
/* 388:    */   protected void definePackages(CodeSourceIndex index)
/* 389:    */     throws IllegalArgumentException, IOException
/* 390:    */   {
/* 391:588 */     int defineCount = 0;
/* 392:589 */     boolean finer = Logger.willLogFiner();
/* 393:590 */     CodeSourceList codeSources = getCodeSources();
/* 394:591 */     Map<String, PackageIndices> map = index.getMap();
/* 395:592 */     for (String packageName : map.keySet())
/* 396:    */     {
/* 397:593 */       PackageIndices indices = (PackageIndices)map.get(packageName);
/* 398:594 */       int codeSourceIndex = indices.getPackageDefinedIndex();
/* 399:595 */       if (codeSourceIndex >= 0)
/* 400:    */       {
/* 401:596 */         if (finer) {
/* 402:597 */           Logger.logFiner("Cache define package: " + packageName);
/* 403:    */         }
/* 404:599 */         defineCount++;
/* 405:600 */         ensurePackageDefined(packageName, codeSources.getCodeSource(codeSourceIndex));
/* 406:    */       }
/* 407:    */     }
/* 408:603 */     if (Logger.willLogFine()) {
/* 409:604 */       Logger.logFine("Cache defined " + defineCount + " packages.");
/* 410:    */     }
/* 411:    */   }
/* 412:    */   
/* 413:    */   protected abstract void close(ClassCache.State paramState)
/* 414:    */     throws IOException;
/* 415:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.cache.ClassCache
 * JD-Core Version:    0.7.0.1
 */