/*   1:    */ package com.oracle.classloader.cache;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.CodeSourceBuffer;
/*   4:    */ import com.oracle.classloader.CodeSourceCache;
/*   5:    */ import com.oracle.classloader.CodeSourceIndex;
/*   6:    */ import com.oracle.classloader.CodeSourceList;
/*   7:    */ import com.oracle.classloader.PolicyClassLoader;
/*   8:    */ import com.oracle.classloader.SearchPolicy;
/*   9:    */ import com.oracle.classloader.index.EagerCodeSourceIndex;
/*  10:    */ import com.oracle.classloader.index.PackageIndices;
/*  11:    */ import com.oracle.classloader.log.Logger;
/*  12:    */ import java.io.ByteArrayOutputStream;
/*  13:    */ import java.io.File;
/*  14:    */ import java.io.IOException;
/*  15:    */ import java.io.InputStream;
/*  16:    */ import java.io.ObjectInputStream;
/*  17:    */ import java.io.ObjectOutputStream;
/*  18:    */ import java.io.RandomAccessFile;
/*  19:    */ import java.lang.reflect.Method;
/*  20:    */ import java.net.MalformedURLException;
/*  21:    */ import java.net.URI;
/*  22:    */ import java.net.URISyntaxException;
/*  23:    */ import java.net.URL;
/*  24:    */ import java.nio.ByteBuffer;
/*  25:    */ import java.nio.MappedByteBuffer;
/*  26:    */ import java.nio.channels.FileChannel;
/*  27:    */ import java.nio.channels.FileChannel.MapMode;
/*  28:    */ import java.nio.channels.FileLock;
/*  29:    */ import java.security.ProtectionDomain;
/*  30:    */ import java.security.cert.Certificate;
/*  31:    */ import java.util.ArrayList;
/*  32:    */ import java.util.HashMap;
/*  33:    */ import java.util.List;
/*  34:    */ import java.util.Map;
/*  35:    */ 
/*  36:    */ public class MappedFileClassCache
/*  37:    */   extends ClassCache
/*  38:    */ {
/*  39:    */   private static final int MAGIC = 439041101;
/*  40:    */   private static final int FOUR_K = 4096;
/*  41:100 */   private static final int PAGE_SIZE = getPageSize(4096);
/*  42:101 */   private static final int MAP_CHUNK_SIZE = PAGE_SIZE * 4096;
/*  43:    */   private static final int INT32_SIZE = 4;
/*  44:    */   private static final int INT16_SIZE = 2;
/*  45:    */   private static final int INT8_SIZE = 1;
/*  46:    */   private static final char ERROR = '\000';
/*  47:    */   private static final byte FALSE = 0;
/*  48:    */   private static final byte TRUE = 1;
/*  49:    */   private static final byte NO_CERTS = 0;
/*  50:    */   private static final byte STORED_CERTS = 1;
/*  51:    */   private static final byte NOT_STORED_CERTS = 2;
/*  52:    */   private final CodeSourceList codeSources;
/*  53:    */   private final File file;
/*  54:    */   private int fileLength;
/*  55:    */   private RandomAccessFile fileAccessor;
/*  56:    */   private FileChannel channel;
/*  57:    */   private FileLock lock;
/*  58:    */   private MappedByteBuffer map;
/*  59:    */   private int magicAndDigestLength;
/*  60:    */   private int delegateClassPosition;
/*  61:    */   private int classCount;
/*  62:    */   private int currentClass;
/*  63:    */   private CodeSourceBuffer defineBuffer;
/*  64:    */   private PolicyClassLoader loader;
/*  65:    */   private int capacity;
/*  66:    */   private int nextClassPosition;
/*  67:    */   private ProtectionDomain[] codeSourcePDs;
/*  68:    */   private byte[] digest;
/*  69:    */   private List<String> delegateClasses;
/*  70:    */   private CodeSourceIndex index;
/*  71:    */   private int totalDelegateClassNameLength;
/*  72:    */   private List<Certificate> allCerts;
/*  73:    */   private Map<Certificate, Integer> certToIndex;
/*  74:    */   private MappedFileClassCache.CertArray[] codeSourceCerts;
/*  75:    */   private List<MappedFileClassCache.CertArray> sparseCodeSourceCerts;
/*  76:    */   
/*  77:    */   public MappedFileClassCache(File cacheFile, Limit limit, SearchPolicy delegatePolicy, File... codeSources)
/*  78:    */     throws URISyntaxException, IOException
/*  79:    */   {
/*  80:155 */     this(cacheFile, limit, delegatePolicy, new CodeSourceList(CodeSourceCache.getCache(), codeSources));
/*  81:    */   }
/*  82:    */   
/*  83:    */   public MappedFileClassCache(File cacheFile, Limit limit, SearchPolicy delegatePolicy, CodeSourceList codeSources)
/*  84:    */   {
/*  85:167 */     this(cacheFile, limit, delegatePolicy, codeSources, false);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public MappedFileClassCache(File cacheFile, Limit limit, SearchPolicy delegatePolicy, CodeSourceList codeSources, boolean delayInitialize)
/*  89:    */   {
/*  90:179 */     super(delegatePolicy, codeSources, limit, delayInitialize);
/*  91:180 */     this.codeSources = codeSources;
/*  92:181 */     this.file = cacheFile;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public String toString()
/*  96:    */   {
/*  97:189 */     return "Cache (" + this.file + ")";
/*  98:    */   }
/*  99:    */   
/* 100:    */   protected boolean open(byte[] currentDigest)
/* 101:    */     throws IOException
/* 102:    */   {
/* 103:201 */     boolean cacheValid = false;
/* 104:203 */     if (Logger.willLogFine()) {
/* 105:204 */       Logger.logFine("Cache open " + this.file.getAbsolutePath());
/* 106:    */     }
/* 107:209 */     this.fileAccessor = new RandomAccessFile(this.file, "rw");
/* 108:210 */     this.channel = this.fileAccessor.getChannel();
/* 109:211 */     this.lock = this.channel.lock(0L, 2147483647L, true);
/* 110:    */     
/* 111:    */ 
/* 112:    */ 
/* 113:215 */     int digestLength = currentDigest.length;
/* 114:216 */     this.magicAndDigestLength = (digestLength + 4 + 2);
/* 115:217 */     this.fileLength = ((int)this.channel.size());
/* 116:    */     String logMessage;
/* 117:    */     String logMessage;
/* 118:218 */     if (this.fileLength > this.magicAndDigestLength)
/* 119:    */     {
/* 120:222 */       ByteBuffer digest = ByteBuffer.allocate(this.magicAndDigestLength);
/* 121:    */       String logMessage;
/* 122:223 */       if (this.channel.read(digest) == this.magicAndDigestLength)
/* 123:    */       {
/* 124:224 */         digest.flip();
/* 125:    */         String logMessage;
/* 126:228 */         if (digest.getInt() == 439041101)
/* 127:    */         {
/* 128:    */           String logMessage;
/* 129:232 */           if (digest.getChar() == digestLength)
/* 130:    */           {
/* 131:    */             String logMessage;
/* 132:236 */             if (digestsEqual(digest, currentDigest))
/* 133:    */             {
/* 134:240 */               cacheValid = true;
/* 135:241 */               logMessage = "Cache valid.";
/* 136:    */             }
/* 137:    */             else
/* 138:    */             {
/* 139:244 */               logMessage = "Cache invalid: digest.";
/* 140:    */             }
/* 141:    */           }
/* 142:    */           else
/* 143:    */           {
/* 144:247 */             logMessage = "Cache invalid: digest length.";
/* 145:    */           }
/* 146:    */         }
/* 147:    */         else
/* 148:    */         {
/* 149:250 */           logMessage = "Cache invalid: magic.";
/* 150:    */         }
/* 151:    */       }
/* 152:    */       else
/* 153:    */       {
/* 154:253 */         logMessage = "Cache invalid: truncated.";
/* 155:    */       }
/* 156:    */     }
/* 157:    */     else
/* 158:    */     {
/* 159:256 */       logMessage = "Cache invalid: empty.";
/* 160:    */     }
/* 161:259 */     if (Logger.willLogFine()) {
/* 162:260 */       Logger.logFine(logMessage);
/* 163:    */     }
/* 164:262 */     return cacheValid;
/* 165:    */   }
/* 166:    */   
/* 167:    */   protected void initializeForLoad()
/* 168:    */     throws IOException, URISyntaxException
/* 169:    */   {
/* 170:274 */     this.map = this.channel.map(FileChannel.MapMode.READ_ONLY, 0L, this.fileLength);
/* 171:    */     
/* 172:    */ 
/* 173:    */ 
/* 174:278 */     this.defineBuffer = new CodeSourceBuffer(this.map);
/* 175:279 */     this.loader = getDelegatingLoader();
/* 176:280 */     this.currentClass = 0;
/* 177:281 */     this.capacity = this.fileLength;
/* 178:    */     
/* 179:    */ 
/* 180:    */ 
/* 181:285 */     this.map.position(this.magicAndDigestLength);
/* 182:    */     
/* 183:    */ 
/* 184:    */ 
/* 185:289 */     this.delegateClassPosition = read32();
/* 186:290 */     this.classCount = read32();
/* 187:291 */     this.codeSourcePDs = readCertificates();
/* 188:292 */     this.nextClassPosition = this.map.position();
/* 189:    */     
/* 190:    */ 
/* 191:    */ 
/* 192:296 */     this.map.position(this.delegateClassPosition);
/* 193:    */   }
/* 194:    */   
/* 195:    */   protected void initializeForStore(byte[] digest)
/* 196:    */     throws IOException
/* 197:    */   {
/* 198:308 */     if (this.lock != null) {
/* 199:309 */       this.lock.release();
/* 200:    */     }
/* 201:311 */     this.lock = this.channel.lock(0L, 2147483647L, false);
/* 202:    */     
/* 203:    */ 
/* 204:    */ 
/* 205:315 */     this.channel.truncate(0L);
/* 206:316 */     this.fileAccessor.setLength(0L);
/* 207:317 */     this.digest = digest;
/* 208:318 */     this.delegateClasses = new ArrayList();
/* 209:319 */     this.index = null;
/* 210:320 */     this.classCount = 0;
/* 211:321 */     this.capacity = MAP_CHUNK_SIZE;
/* 212:322 */     initCertificates();
/* 213:323 */     this.map = this.channel.map(FileChannel.MapMode.READ_WRITE, 0L, this.capacity);
/* 214:324 */     this.map.clear();
/* 215:325 */     write32(-1);
/* 216:326 */     writeDigest();
/* 217:327 */     write32(-1);
/* 218:328 */     write32(-1);
/* 219:329 */     writeCertificates();
/* 220:    */   }
/* 221:    */   
/* 222:    */   protected void storeDelegateClassName(String className)
/* 223:    */   {
/* 224:337 */     this.totalDelegateClassNameLength += className.length();
/* 225:338 */     this.delegateClasses.add(className);
/* 226:339 */     if (Logger.willLogFiner()) {
/* 227:340 */       Logger.logFiner("Cache recorded delegate class: " + className);
/* 228:    */     }
/* 229:    */   }
/* 230:    */   
/* 231:    */   protected int storeClass(String className, CodeSourceBuffer buffer, int codeSourceIndex)
/* 232:    */   {
/* 233:354 */     byte certType = 0;
/* 234:355 */     Certificate[] certs = buffer.getCertificates();
/* 235:356 */     if (certs != null)
/* 236:    */     {
/* 237:358 */       MappedFileClassCache.CertArray ca = this.codeSourceCerts[codeSourceIndex];
/* 238:359 */       if ((ca != null) && (ca.matches(certs))) {
/* 239:360 */         certType = 1;
/* 240:    */       } else {
/* 241:363 */         certType = 2;
/* 242:    */       }
/* 243:    */     }
/* 244:369 */     int startPosition = this.map.position();
/* 245:370 */     ByteBuffer data = buffer.getData();
/* 246:371 */     int dataSize = data.limit();
/* 247:372 */     ensureCapacity(4 + 2 * className.length() + 4 + dataSize + 1);
/* 248:373 */     write16(codeSourceIndex + 1);
/* 249:374 */     writeString(className);
/* 250:375 */     write8(certType);
/* 251:376 */     write32(dataSize);
/* 252:377 */     this.map.put(data);
/* 253:378 */     data.position(0);
/* 254:379 */     this.classCount += 1;
/* 255:380 */     if (Logger.willLogFiner()) {
/* 256:381 */       Logger.logFiner("Cache recorded class: " + className);
/* 257:    */     }
/* 258:383 */     return startPosition;
/* 259:    */   }
/* 260:    */   
/* 261:    */   protected void handleDefineError(LinkageError defineError, int storeOffset)
/* 262:    */   {
/* 263:392 */     int currentPosition = this.map.position();
/* 264:393 */     this.map.position(storeOffset);
/* 265:394 */     this.map.putChar('\000');
/* 266:395 */     this.map.position(currentPosition);
/* 267:    */   }
/* 268:    */   
/* 269:    */   protected void storeIndex(CodeSourceIndex index)
/* 270:    */   {
/* 271:403 */     this.index = index;
/* 272:    */   }
/* 273:    */   
/* 274:    */   protected void loadDelegateClasses()
/* 275:    */     throws ClassNotFoundException
/* 276:    */   {
/* 277:411 */     boolean logFiner = Logger.willLogFiner();
/* 278:412 */     int delegateClassCount = read32();
/* 279:413 */     for (int i = 0; i < delegateClassCount; i++)
/* 280:    */     {
/* 281:414 */       String className = readString();
/* 282:415 */       if (logFiner) {
/* 283:416 */         Logger.logFiner("Cache load delegate class: " + className);
/* 284:    */       }
/* 285:418 */       Class.forName(className, false, this.loader);
/* 286:    */     }
/* 287:420 */     if (Logger.willLogFine()) {
/* 288:421 */       Logger.logFine("Cache loaded " + delegateClassCount + " delegate classes.");
/* 289:    */     }
/* 290:    */   }
/* 291:    */   
/* 292:    */   protected CodeSourceIndex loadIndex()
/* 293:    */   {
/* 294:429 */     boolean logFiner = Logger.willLogFiner();
/* 295:430 */     int count = read32();
/* 296:431 */     Map<String, PackageIndices> map = new HashMap(count);
/* 297:432 */     for (int i = 0; i < count; i++)
/* 298:    */     {
/* 299:433 */       String packageName = readString();
/* 300:434 */       int packageDefinedIndex = read32();
/* 301:435 */       int indexCount = read16();
/* 302:436 */       int[] indices = new int[indexCount];
/* 303:437 */       for (int j = 0; j < indexCount; j++) {
/* 304:438 */         indices[j] = read16();
/* 305:    */       }
/* 306:440 */       map.put(packageName, new PackageIndices(indices, packageDefinedIndex));
/* 307:441 */       if (logFiner) {
/* 308:442 */         Logger.logFiner("Cache loaded indices for: " + packageName);
/* 309:    */       }
/* 310:    */     }
/* 311:445 */     if (Logger.willLogFine()) {
/* 312:446 */       Logger.logFine("Cache loaded " + count + " package indices.");
/* 313:    */     }
/* 314:448 */     return new EagerCodeSourceIndex(getCodeSources(), map);
/* 315:    */   }
/* 316:    */   
/* 317:    */   protected Class loadNextClass(String expectedClassName, String packageName)
/* 318:    */     throws MalformedURLException, URISyntaxException
/* 319:    */   {
/* 320:460 */     if (this.currentClass++ < this.classCount)
/* 321:    */     {
/* 322:461 */       nextClassPosition();
/* 323:462 */       int codeSourceIndex = read16() - 1;
/* 324:463 */       String className = readString();
/* 325:464 */       ProtectionDomain pd = readProtectionDomain(codeSourceIndex, className);
/* 326:465 */       if (Logger.willLogFiner()) {
/* 327:466 */         Logger.logFiner("Cache load class: " + className);
/* 328:    */       }
/* 329:468 */       int classLength = read32();
/* 330:469 */       this.nextClassPosition = (this.map.position() + classLength);
/* 331:470 */       this.map.limit(this.nextClassPosition);
/* 332:471 */       if (codeSourceIndex >= 0)
/* 333:    */       {
/* 334:475 */         this.defineBuffer.setCodeSource(this.codeSources.getCodeSource(codeSourceIndex));
/* 335:476 */         return defineClass(className, this.defineBuffer, false, pd);
/* 336:    */       }
/* 337:498 */       if (expectedClassName != null)
/* 338:    */       {
/* 339:499 */         RuntimeException e = new IllegalStateException("Error during recursive define");
/* 340:500 */         Logger.logWarning("Cache load failed", e);
/* 341:501 */         throw e;
/* 342:    */       }
/* 343:507 */       return ClassCache.class;
/* 344:    */     }
/* 345:513 */     if (Logger.willLogFine()) {
/* 346:514 */       Logger.logFine("Cache loaded " + this.classCount + " classes.");
/* 347:    */     }
/* 348:516 */     return null;
/* 349:    */   }
/* 350:    */   
/* 351:    */   private void nextClassPosition()
/* 352:    */   {
/* 353:521 */     if (this.nextClassPosition > 0)
/* 354:    */     {
/* 355:522 */       this.map.limit(this.capacity);
/* 356:523 */       this.map.position(this.nextClassPosition);
/* 357:524 */       this.nextClassPosition = 0;
/* 358:    */     }
/* 359:    */   }
/* 360:    */   
/* 361:    */   protected void close(ClassCache.State state)
/* 362:    */     throws IOException
/* 363:    */   {
/* 364:    */     try
/* 365:    */     {
/* 366:535 */       if (state == ClassCache.State.STORE)
/* 367:    */       {
/* 368:536 */         writeDelegateClasses();
/* 369:537 */         writeIndex();
/* 370:538 */         writeMagic();
/* 371:    */       }
/* 372:540 */       MappedFileClassCache.MapCleaner.clean(this.map);
/* 373:541 */       this.map = null;
/* 374:542 */       if (this.fileAccessor != null)
/* 375:    */       {
/* 376:543 */         this.fileAccessor.close();
/* 377:544 */         this.fileAccessor = null;
/* 378:    */       }
/* 379:    */     }
/* 380:    */     catch (IOException e)
/* 381:    */     {
/* 382:    */       try
/* 383:    */       {
/* 384:548 */         this.fileAccessor.close();
/* 385:    */       }
/* 386:    */       catch (IOException e2)
/* 387:    */       {
/* 388:550 */         if (Logger.willLogFine()) {
/* 389:551 */           Logger.logFine("Close failed: " + e);
/* 390:    */         }
/* 391:    */       }
/* 392:554 */       this.map = null;
/* 393:555 */       this.fileAccessor = null;
/* 394:556 */       throw e;
/* 395:    */     }
/* 396:    */   }
/* 397:    */   
/* 398:    */   private void ensureCapacity(int required)
/* 399:    */   {
/* 400:561 */     if (this.map.remaining() < required) {
/* 401:562 */       grow();
/* 402:    */     }
/* 403:    */   }
/* 404:    */   
/* 405:    */   private void grow()
/* 406:    */   {
/* 407:567 */     this.map.force();
/* 408:    */     try
/* 409:    */     {
/* 410:569 */       int position = this.map.position();
/* 411:570 */       this.capacity += MAP_CHUNK_SIZE;
/* 412:571 */       this.map = this.channel.map(FileChannel.MapMode.READ_WRITE, 0L, this.capacity);
/* 413:572 */       this.map.position(position);
/* 414:573 */       if (Logger.willLogFine()) {
/* 415:574 */         Logger.logFine("Map grown to: " + this.capacity);
/* 416:    */       }
/* 417:    */     }
/* 418:    */     catch (IOException e)
/* 419:    */     {
/* 420:577 */       throw new Error(e);
/* 421:    */     }
/* 422:    */   }
/* 423:    */   
/* 424:    */   private byte read8()
/* 425:    */   {
/* 426:582 */     return this.map.get();
/* 427:    */   }
/* 428:    */   
/* 429:    */   private int read16()
/* 430:    */   {
/* 431:586 */     return this.map.getChar();
/* 432:    */   }
/* 433:    */   
/* 434:    */   private int read32()
/* 435:    */   {
/* 436:590 */     return this.map.getInt();
/* 437:    */   }
/* 438:    */   
/* 439:    */   private String readString()
/* 440:    */   {
/* 441:594 */     int strLength = read16();
/* 442:595 */     char[] string = new char[strLength];
/* 443:596 */     for (int i = 0; i < strLength; i++) {
/* 444:597 */       string[i] = this.map.getChar();
/* 445:    */     }
/* 446:599 */     return new String(string);
/* 447:    */   }
/* 448:    */   
/* 449:    */   private ProtectionDomain[] readCertificates()
/* 450:    */     throws IOException, URISyntaxException
/* 451:    */   {
/* 452:603 */     if (read8() == 0) {
/* 453:604 */       return null;
/* 454:    */     }
/* 455:    */     try
/* 456:    */     {
/* 457:610 */       ObjectInputStream in = new ObjectInputStream(newInputStream(this.map));
/* 458:611 */       int count = in.readInt();
/* 459:612 */       List<Certificate> certificates = new ArrayList(count);
/* 460:613 */       for (int i = 0; i < count; i++) {
/* 461:614 */         certificates.add((Certificate)in.readObject());
/* 462:    */       }
/* 463:619 */       CodeSourceCache cache = CodeSourceCache.getCache();
/* 464:620 */       ProtectionDomain[] result = new ProtectionDomain[this.codeSources.size()];
/* 465:621 */       count = read16();
/* 466:622 */       for (int i = 0; i < count; i++)
/* 467:    */       {
/* 468:623 */         int csIndex = read16();
/* 469:624 */         int arrayLen = read16();
/* 470:625 */         Certificate[] certs = new Certificate[arrayLen];
/* 471:626 */         for (int j = 0; j < arrayLen; j++) {
/* 472:627 */           certs[j] = ((Certificate)certificates.get(read16()));
/* 473:    */         }
/* 474:629 */         URL url = this.codeSources.getCodeSource(csIndex).getLocation().toURL();
/* 475:630 */         java.security.CodeSource cs = new java.security.CodeSource(url, certs);
/* 476:631 */         cs.getCodeSigners();
/* 477:632 */         result[csIndex] = this.loader.getProtectionDomain(cs);
/* 478:    */       }
/* 479:634 */       return result;
/* 480:    */     }
/* 481:    */     catch (ClassNotFoundException e)
/* 482:    */     {
/* 483:636 */       throw new Error(e);
/* 484:    */     }
/* 485:    */   }
/* 486:    */   
/* 487:    */   private ProtectionDomain readProtectionDomain(int codeSourceIndex, String className)
/* 488:    */     throws MalformedURLException, URISyntaxException
/* 489:    */   {
/* 490:641 */     byte certType = read8();
/* 491:642 */     if (certType == 0) {
/* 492:643 */       return null;
/* 493:    */     }
/* 494:644 */     if (certType == 1) {
/* 495:645 */       return this.codeSourcePDs[codeSourceIndex];
/* 496:    */     }
/* 497:646 */     if (certType == 2) {
/* 498:647 */       return this.loader.getProtectionDomain(this.codeSources.getCodeSource(codeSourceIndex).getNativeSecurityCodeSource());
/* 499:    */     }
/* 500:649 */     throw new Error("Unknown cert type: " + certType);
/* 501:    */   }
/* 502:    */   
/* 503:    */   private static InputStream newInputStream(ByteBuffer buffer)
/* 504:    */   {
/* 505:653 */     return new MappedFileClassCache.1(buffer);
/* 506:    */   }
/* 507:    */   
/* 508:    */   private void write8(byte value)
/* 509:    */   {
/* 510:671 */     this.map.put(value);
/* 511:    */   }
/* 512:    */   
/* 513:    */   private void write16(int value)
/* 514:    */   {
/* 515:675 */     if (value > 65535) {
/* 516:676 */       throw new Error("Overflow: " + value + " more than 16 bits.");
/* 517:    */     }
/* 518:678 */     this.map.putChar((char)value);
/* 519:    */   }
/* 520:    */   
/* 521:    */   private void write32(int value)
/* 522:    */   {
/* 523:682 */     this.map.putInt(value);
/* 524:    */   }
/* 525:    */   
/* 526:    */   private void writeString(String value)
/* 527:    */   {
/* 528:686 */     int strLength = value.length();
/* 529:687 */     write16(strLength);
/* 530:688 */     for (int i = 0; i < strLength; i++) {
/* 531:689 */       this.map.putChar(value.charAt(i));
/* 532:    */     }
/* 533:    */   }
/* 534:    */   
/* 535:    */   private void writeMagic()
/* 536:    */   {
/* 537:694 */     this.map.putInt(this.magicAndDigestLength, this.delegateClassPosition);
/* 538:695 */     this.map.putInt(this.magicAndDigestLength + 4, this.classCount);
/* 539:696 */     this.map.putInt(0, 439041101);
/* 540:697 */     if (Logger.willLogFine()) {
/* 541:698 */       Logger.logFine("Cache stored " + this.classCount + " classes.");
/* 542:    */     }
/* 543:    */   }
/* 544:    */   
/* 545:    */   private void writeDelegateClasses()
/* 546:    */   {
/* 547:703 */     this.delegateClassPosition = this.map.position();
/* 548:704 */     int count = this.delegateClasses.size();
/* 549:705 */     ensureCapacity(4 + count * 2 + this.totalDelegateClassNameLength);
/* 550:706 */     write32(count);
/* 551:707 */     for (String className : this.delegateClasses) {
/* 552:708 */       writeString(className);
/* 553:    */     }
/* 554:710 */     if (Logger.willLogFine()) {
/* 555:711 */       Logger.logFine("Cache stored " + count + " delegate classes.");
/* 556:    */     }
/* 557:    */   }
/* 558:    */   
/* 559:    */   private void writeIndex()
/* 560:    */   {
/* 561:716 */     Map<String, PackageIndices> map = this.index.getMap();
/* 562:717 */     int count = map.size();
/* 563:718 */     ensureCapacity(count * 32);
/* 564:719 */     write32(count);
/* 565:720 */     for (String packageName : map.keySet())
/* 566:    */     {
/* 567:721 */       PackageIndices indices = (PackageIndices)map.get(packageName);
/* 568:722 */       int packageDefinedIndex = indices.getPackageDefinedIndex();
/* 569:723 */       int indexCount = indices.size();
/* 570:724 */       ensureCapacity(packageName.length() + 2 * (indexCount + 4));
/* 571:725 */       writeString(packageName);
/* 572:726 */       write32(packageDefinedIndex);
/* 573:727 */       write16(indexCount);
/* 574:728 */       for (int i = 0; i < indexCount; i++) {
/* 575:729 */         write16(indices.get(i));
/* 576:    */       }
/* 577:    */     }
/* 578:732 */     if (Logger.willLogFine()) {
/* 579:733 */       Logger.logFine("Cache stored " + count + " package indices.");
/* 580:    */     }
/* 581:    */   }
/* 582:    */   
/* 583:    */   private void writeDigest()
/* 584:    */   {
/* 585:738 */     int length = this.digest.length;
/* 586:739 */     ensureCapacity(2 + length);
/* 587:740 */     write16(length);
/* 588:741 */     this.map.put(this.digest, 0, length);
/* 589:    */   }
/* 590:    */   
/* 591:    */   private void writeCertificates()
/* 592:    */     throws IOException
/* 593:    */   {
/* 594:745 */     if (this.allCerts == null)
/* 595:    */     {
/* 596:749 */       ensureCapacity(1);
/* 597:750 */       write8((byte)0);
/* 598:751 */       return;
/* 599:    */     }
/* 600:756 */     int count = this.allCerts.size();
/* 601:757 */     ByteArrayOutputStream bout = new ByteArrayOutputStream(count * 1024);
/* 602:758 */     ObjectOutputStream out = new ObjectOutputStream(bout);
/* 603:759 */     out.writeInt(count);
/* 604:760 */     for (Certificate allCert : this.allCerts) {
/* 605:761 */       out.writeObject(allCert);
/* 606:    */     }
/* 607:763 */     out.close();
/* 608:764 */     byte[] certStream = bout.toByteArray();
/* 609:    */     
/* 610:    */ 
/* 611:    */ 
/* 612:    */ 
/* 613:769 */     int storageSize = certStream.length + 1 + 2;
/* 614:770 */     for (MappedFileClassCache.CertArray ca : this.sparseCodeSourceCerts) {
/* 615:771 */       storageSize += ca.storageSize();
/* 616:    */     }
/* 617:773 */     ensureCapacity(storageSize);
/* 618:    */     
/* 619:    */ 
/* 620:    */ 
/* 621:777 */     write8((byte)1);
/* 622:778 */     this.map.put(certStream, 0, certStream.length);
/* 623:    */     
/* 624:    */ 
/* 625:    */ 
/* 626:782 */     write16(this.sparseCodeSourceCerts.size());
/* 627:783 */     for (MappedFileClassCache.CertArray ca : this.sparseCodeSourceCerts)
/* 628:    */     {
/* 629:784 */       write16(ca.codeSourceIndex);
/* 630:785 */       int length = ca.certIndices.length;
/* 631:786 */       write16(length);
/* 632:787 */       for (int i = 0; i < length; i++) {
/* 633:788 */         write16(ca.certIndices[i]);
/* 634:    */       }
/* 635:    */     }
/* 636:    */   }
/* 637:    */   
/* 638:    */   private void initCertificates()
/* 639:    */     throws MalformedURLException
/* 640:    */   {
/* 641:829 */     if (this.allCerts == null)
/* 642:    */     {
/* 643:830 */       int codeSourceCount = this.codeSources.size();
/* 644:831 */       for (int i = 0; i < codeSourceCount; i++)
/* 645:    */       {
/* 646:832 */         com.oracle.classloader.CodeSource cs = this.codeSources.getCodeSource(i);
/* 647:833 */         Certificate[] certs = cs.getNativeSecurityCodeSource().getCertificates();
/* 648:834 */         if (certs != null)
/* 649:    */         {
/* 650:835 */           if (this.allCerts == null)
/* 651:    */           {
/* 652:836 */             this.allCerts = new ArrayList();
/* 653:837 */             this.certToIndex = new HashMap();
/* 654:838 */             this.codeSourceCerts = new MappedFileClassCache.CertArray[codeSourceCount];
/* 655:839 */             this.sparseCodeSourceCerts = new ArrayList();
/* 656:    */           }
/* 657:841 */           for (Certificate c : certs) {
/* 658:842 */             if (!this.certToIndex.containsKey(c))
/* 659:    */             {
/* 660:843 */               int index = this.allCerts.size();
/* 661:844 */               this.allCerts.add(c);
/* 662:845 */               this.certToIndex.put(c, Integer.valueOf(index));
/* 663:    */             }
/* 664:    */           }
/* 665:848 */           MappedFileClassCache.CertArray ca = new MappedFileClassCache.CertArray(i, certs, this.certToIndex);
/* 666:849 */           this.codeSourceCerts[i] = ca;
/* 667:850 */           this.sparseCodeSourceCerts.add(ca);
/* 668:    */         }
/* 669:    */       }
/* 670:    */     }
/* 671:    */   }
/* 672:    */   
/* 673:    */   private static boolean digestsEqual(ByteBuffer digest, byte[] currentDigest)
/* 674:    */   {
/* 675:857 */     for (byte b : currentDigest) {
/* 676:858 */       if (b != digest.get()) {
/* 677:859 */         return false;
/* 678:    */       }
/* 679:    */     }
/* 680:862 */     return true;
/* 681:    */   }
/* 682:    */   
/* 683:    */   private static int getPageSize(int defaultSize)
/* 684:    */   {
/* 685:866 */     int result = defaultSize;
/* 686:    */     try
/* 687:    */     {
/* 688:868 */       Class c = Class.forName("java.nio.Bits");
/* 689:869 */       Method m = c.getDeclaredMethod("pageSize", new Class[0]);
/* 690:870 */       m.setAccessible(true);
/* 691:871 */       result = ((Integer)m.invoke(null, new Object[0])).intValue();
/* 692:    */     }
/* 693:    */     catch (ThreadDeath death)
/* 694:    */     {
/* 695:873 */       throw death;
/* 696:    */     }
/* 697:    */     catch (Throwable localThrowable) {}
/* 698:877 */     return result;
/* 699:    */   }
/* 700:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.cache.MappedFileClassCache
 * JD-Core Version:    0.7.0.1
 */