/*  1:   */ package com.oracle.classloader;
/*  2:   */ 
/*  3:   */ public class TooManyPackagesException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1L;
/*  7:   */   
/*  8:   */   public TooManyPackagesException() {}
/*  9:   */   
/* 10:   */   public TooManyPackagesException(String msg)
/* 11:   */   {
/* 12:18 */     super(msg);
/* 13:   */   }
/* 14:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.TooManyPackagesException
 * JD-Core Version:    0.7.0.1
 */