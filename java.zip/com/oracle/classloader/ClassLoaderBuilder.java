/*   1:    */ package com.oracle.classloader;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.cache.Limit;
/*   4:    */ import com.oracle.classloader.cache.MappedFileClassCache;
/*   5:    */ import com.oracle.classloader.index.EagerCodeSourceIndex;
/*   6:    */ import com.oracle.classloader.log.Logger;
/*   7:    */ import com.oracle.classloader.search.SearchSequence;
/*   8:    */ import com.oracle.classloader.util.BuilderUtils;
/*   9:    */ import com.oracle.util.Matcher;
/*  10:    */ import java.io.File;
/*  11:    */ import java.io.IOException;
/*  12:    */ import java.net.InetAddress;
/*  13:    */ import java.net.URISyntaxException;
/*  14:    */ import java.util.ArrayList;
/*  15:    */ import java.util.Arrays;
/*  16:    */ import java.util.List;
/*  17:    */ import java.util.Properties;
/*  18:    */ 
/*  19:    */ public class ClassLoaderBuilder
/*  20:    */ {
/*  21:    */   private static final String LOG_PREFIX = "ClassLoaderBuilder";
/*  22:    */   private static final String CACHE_SUFFIX = ".cache";
/*  23:    */   private String name;
/*  24:    */   private ClassLoader parent;
/*  25:    */   private Properties substitutions;
/*  26:    */   private List<File> classPath;
/*  27:    */   private List<File> nativePath;
/*  28:    */   private List<Matcher<String>> filters;
/*  29:    */   private File cacheFile;
/*  30:    */   private Limit cacheLimit;
/*  31:    */   private List<Class<?>> inject;
/*  32:    */   
/*  33:    */   public ClassLoaderBuilder(String name)
/*  34:    */   {
/*  35: 49 */     this(name, null);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public ClassLoaderBuilder(String name, Properties substitutions)
/*  39:    */   {
/*  40: 58 */     this.name = name;
/*  41: 59 */     this.substitutions = substitutions;
/*  42: 60 */     this.parent = ClassLoader.getSystemClassLoader();
/*  43:    */   }
/*  44:    */   
/*  45:    */   public ClassLoaderBuilder inject(Class<?>... classes)
/*  46:    */   {
/*  47: 69 */     if (this.inject == null)
/*  48:    */     {
/*  49: 70 */       this.inject = Arrays.asList(classes);
/*  50:    */     }
/*  51:    */     else
/*  52:    */     {
/*  53: 72 */       this.inject = new ArrayList(this.inject);
/*  54: 73 */       this.inject.addAll(Arrays.asList(classes));
/*  55:    */     }
/*  56: 75 */     return this;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public ClassLoaderBuilder parent(ClassLoader parent)
/*  60:    */   {
/*  61: 84 */     this.parent = parent;
/*  62: 85 */     return this;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public ClassLoaderBuilder classPath(String classPath)
/*  66:    */   {
/*  67:115 */     List<File> cp = BuilderUtils.parseClassPath(classPath, this.substitutions, "ClassLoaderBuilder");
/*  68:116 */     if (!cp.isEmpty()) {
/*  69:117 */       if (this.classPath == null) {
/*  70:118 */         this.classPath = cp;
/*  71:    */       } else {
/*  72:120 */         this.classPath.addAll(cp);
/*  73:    */       }
/*  74:    */     }
/*  75:123 */     return this;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public ClassLoaderBuilder classPath(List<File> classPath)
/*  79:    */   {
/*  80:132 */     if (this.classPath == null) {
/*  81:133 */       this.classPath = new ArrayList();
/*  82:    */     }
/*  83:135 */     for (File file : classPath) {
/*  84:136 */       if (BuilderUtils.isValid(file, true, "ClassLoaderBuilder")) {
/*  85:137 */         this.classPath.add(file);
/*  86:    */       }
/*  87:    */     }
/*  88:140 */     return this;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public ClassLoaderBuilder nativePath(String libraryPath)
/*  92:    */   {
/*  93:157 */     List<File> np = BuilderUtils.parseNativeLibraryPath(libraryPath, this.substitutions, "ClassLoaderBuilder");
/*  94:158 */     if (!np.isEmpty()) {
/*  95:159 */       if (this.nativePath == null) {
/*  96:160 */         this.nativePath = np;
/*  97:    */       } else {
/*  98:162 */         this.nativePath.addAll(np);
/*  99:    */       }
/* 100:    */     }
/* 101:165 */     return this;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public ClassLoaderBuilder nativePath(List<File> directories)
/* 105:    */   {
/* 106:174 */     if (this.nativePath == null) {
/* 107:175 */       this.nativePath = new ArrayList();
/* 108:    */     }
/* 109:177 */     for (File directory : directories) {
/* 110:178 */       if (BuilderUtils.isValid(directory, false, "ClassLoaderBuilder")) {
/* 111:179 */         this.nativePath.add(directory);
/* 112:    */       }
/* 113:    */     }
/* 114:182 */     return this;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public ClassLoaderBuilder filter(String filters)
/* 118:    */   {
/* 119:204 */     List<Matcher<String>> f = BuilderUtils.parsePackageFilters(filters);
/* 120:205 */     if (!f.isEmpty()) {
/* 121:206 */       if (this.filters == null) {
/* 122:207 */         this.filters = f;
/* 123:    */       } else {
/* 124:209 */         this.filters.addAll(f);
/* 125:    */       }
/* 126:    */     }
/* 127:212 */     return this;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public ClassLoaderBuilder filter(Matcher<String> filter)
/* 131:    */   {
/* 132:221 */     if (filter != null)
/* 133:    */     {
/* 134:222 */       if (this.filters == null) {
/* 135:223 */         this.filters = new ArrayList();
/* 136:    */       }
/* 137:225 */       this.filters.add(filter);
/* 138:    */     }
/* 139:227 */     return this;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public ClassLoaderBuilder cache(File cacheDir, Limit cacheLimit)
/* 143:    */   {
/* 144:237 */     this.cacheFile = getCacheFile(cacheDir);
/* 145:238 */     this.cacheLimit = cacheLimit;
/* 146:239 */     return this;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public PolicyClassLoader build()
/* 150:    */     throws URISyntaxException, IOException
/* 151:    */   {
/* 152:252 */     if ((this.name == null) || (this.name.length() == 0)) {
/* 153:253 */       throw new IllegalArgumentException("empty name");
/* 154:    */     }
/* 155:255 */     if (this.classPath == null) {
/* 156:256 */       throw new IllegalArgumentException("empty classPath");
/* 157:    */     }
/* 158:258 */     Matcher<String>[] excludes = null;
/* 159:259 */     if (this.filters != null) {
/* 160:260 */       excludes = (Matcher[])this.filters.toArray((Matcher[])new Matcher[this.filters.size()]);
/* 161:    */     }
/* 162:262 */     SearchPolicy parentPolicy = SearchPolicy.createParent(this.parent, excludes);
/* 163:263 */     File[] codeSources = (File[])this.classPath.toArray(new File[this.classPath.size()]);
/* 164:    */     SearchPolicy searchPolicy;
/* 165:    */     SearchPolicy searchPolicy;
/* 166:265 */     if (this.cacheFile == null)
/* 167:    */     {
/* 168:266 */       CodeSourceList list = new CodeSourceList(CodeSourceCache.getCache(), EagerCodeSourceIndex.FACTORY, codeSources);
/* 169:267 */       searchPolicy = SearchPolicy.createStandard(parentPolicy, list);
/* 170:    */     }
/* 171:    */     else
/* 172:    */     {
/* 173:269 */       CodeSourceList list = new CodeSourceList(CodeSourceCache.getCache(), codeSources);
/* 174:270 */       SearchPolicy cache = new MappedFileClassCache(this.cacheFile, this.cacheLimit, parentPolicy, list);
/* 175:271 */       searchPolicy = new SearchSequence(new SearchPolicy[] { cache });
/* 176:    */     }
/* 177:273 */     return new PolicyClassLoader(this.name, searchPolicy, this.nativePath);
/* 178:    */   }
/* 179:    */   
/* 180:    */   private File getCacheFile(File cacheDir)
/* 181:    */   {
/* 182:277 */     File result = null;
/* 183:278 */     if (cacheDir != null) {
/* 184:279 */       if (cacheDir.canWrite()) {
/* 185:280 */         result = new File(cacheDir, getCacheFileName());
/* 186:    */       } else {
/* 187:282 */         Logger.logWarning(cacheDir + " is not writable.");
/* 188:    */       }
/* 189:    */     }
/* 190:285 */     return result;
/* 191:    */   }
/* 192:    */   
/* 193:    */   private String getCacheFileName()
/* 194:    */   {
/* 195:289 */     StringBuilder b = new StringBuilder();
/* 196:290 */     b.append('.');
/* 197:    */     String hostName;
/* 198:    */     try
/* 199:    */     {
/* 200:295 */       hostName = InetAddress.getLocalHost().getHostName();
/* 201:    */     }
/* 202:    */     catch (Exception e)
/* 203:    */     {
/* 204:    */       String hostName;
/* 205:297 */       hostName = System.getenv("HOST");
/* 206:298 */       if (hostName == null) {
/* 207:299 */         hostName = System.getenv("COMPUTERNAME");
/* 208:    */       }
/* 209:    */     }
/* 210:302 */     if (hostName != null)
/* 211:    */     {
/* 212:303 */       b.append(hostName.toLowerCase());
/* 213:304 */       b.append('.');
/* 214:    */     }
/* 215:306 */     b.append(this.name.toLowerCase());
/* 216:307 */     b.append(".cache");
/* 217:308 */     return b.toString();
/* 218:    */   }
/* 219:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.ClassLoaderBuilder
 * JD-Core Version:    0.7.0.1
 */