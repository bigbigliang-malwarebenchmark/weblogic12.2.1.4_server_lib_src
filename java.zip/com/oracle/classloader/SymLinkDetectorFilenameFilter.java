/*  1:   */ package com.oracle.classloader;
/*  2:   */ 
/*  3:   */ import java.io.File;
/*  4:   */ import java.io.FilenameFilter;
/*  5:   */ import java.io.IOException;
/*  6:   */ import java.nio.file.Files;
/*  7:   */ import java.nio.file.Path;
/*  8:   */ import java.util.HashSet;
/*  9:   */ 
/* 10:   */ public class SymLinkDetectorFilenameFilter
/* 11:   */   implements FilenameFilter
/* 12:   */ {
/* 13:11 */   HashSet<Path> visitedPaths = new HashSet();
/* 14:   */   SymLinkDetectorFilenameFilter.Reporter reporter;
/* 15:   */   
/* 16:   */   public SymLinkDetectorFilenameFilter(SymLinkDetectorFilenameFilter.Reporter reporter)
/* 17:   */   {
/* 18:15 */     this.reporter = reporter;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean accept(File dir, String name)
/* 22:   */   {
/* 23:19 */     if ((name == null) || (name.isEmpty())) {
/* 24:   */       try
/* 25:   */       {
/* 26:21 */         Path p = dir.toPath();
/* 27:22 */         if (Files.isSymbolicLink(p))
/* 28:   */         {
/* 29:23 */           Path sympath = Files.readSymbolicLink(p);
/* 30:24 */           p = p.getParent().resolve(sympath).normalize();
/* 31:   */         }
/* 32:26 */         if (this.visitedPaths.contains(p))
/* 33:   */         {
/* 34:27 */           if (this.reporter != null) {
/* 35:27 */             this.reporter.symlinkCycleDetected(dir.getPath(), p.toFile().getCanonicalPath());
/* 36:   */           }
/* 37:28 */           throw new RuntimeException("Detected a cyclical symlink: " + dir.getPath() + " maps to " + p.toFile().getCanonicalPath());
/* 38:   */         }
/* 39:30 */         this.visitedPaths.add(p);
/* 40:   */       }
/* 41:   */       catch (IOException ioe)
/* 42:   */       {
/* 43:33 */         throw new RuntimeException(ioe);
/* 44:   */       }
/* 45:   */     }
/* 46:36 */     return true;
/* 47:   */   }
/* 48:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.SymLinkDetectorFilenameFilter
 * JD-Core Version:    0.7.0.1
 */