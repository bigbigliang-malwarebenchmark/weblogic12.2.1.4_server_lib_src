/*   1:    */ package com.oracle.classloader.weblogic;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.PolicyClassLoader;
/*   4:    */ import com.oracle.classloader.launch.LaunchConfiguration;
/*   5:    */ import java.io.File;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.lang.reflect.Method;
/*   8:    */ import java.net.URISyntaxException;
/*   9:    */ 
/*  10:    */ public class LaunchClassLoader
/*  11:    */   extends PolicyClassLoader
/*  12:    */ {
/*  13:    */   static
/*  14:    */   {
/*  15: 24 */     ClassLoader.registerAsParallelCapable();
/*  16: 25 */     PolicyClassLoader.setNeedLateInitializeLogging(true);
/*  17:    */   }
/*  18:    */   
/*  19: 28 */   static final boolean isJDK9OrAbove = isJDK9OrAbove();
/*  20:    */   public static final String INDEX_TYPE_KEY = "launch.index";
/*  21:    */   private static final String DEFAULT_INDEX_TYPE = "eager";
/*  22: 34 */   private boolean firstCall = true;
/*  23:    */   
/*  24:    */   public LaunchClassLoader(ClassLoader parent)
/*  25:    */   {
/*  26: 37 */     super("weblogic-launcher", new LaunchClassLoader.SystemLaunchConfiguration(null, parent));
/*  27: 38 */     getLaunchConfiguration().prepareEnvironment(this);
/*  28:    */   }
/*  29:    */   
/*  30:    */   private static String selectPathValue()
/*  31:    */   {
/*  32: 42 */     String value = System.getProperty("java.class.path");
/*  33: 43 */     if (value == null) {
/*  34: 44 */       value = System.getenv("CLASSPATH");
/*  35:    */     }
/*  36: 47 */     return value;
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected Class<?> loadClass(String className, boolean resolve)
/*  40:    */     throws ClassNotFoundException
/*  41:    */   {
/*  42: 51 */     boolean f = this.firstCall;
/*  43: 52 */     this.firstCall = false;
/*  44:    */     try
/*  45:    */     {
/*  46: 55 */       return super.loadClass(className, resolve);
/*  47:    */     }
/*  48:    */     finally
/*  49:    */     {
/*  50: 57 */       if (f) {
/*  51: 58 */         initializeLogging();
/*  52:    */       }
/*  53:    */     }
/*  54:    */   }
/*  55:    */   
/*  56:    */   private static boolean isJDK9OrAbove()
/*  57:    */   {
/*  58:    */     try
/*  59:    */     {
/*  60:114 */       Class<?> procC = Process.class;
/*  61:115 */       Method m = procC.getMethod("onExit", new Class[0]);
/*  62:116 */       return m != null;
/*  63:    */     }
/*  64:    */     catch (Throwable e) {}
/*  65:118 */     return false;
/*  66:    */   }
/*  67:    */   
/*  68:    */   private static File cacheFile()
/*  69:    */   {
/*  70:123 */     LaunchClassLoader.IndexType i = LaunchClassLoader.IndexType.EAGER;
/*  71:124 */     String index = System.getProperty("launch.index", "eager");
/*  72:125 */     if (index != null) {
/*  73:126 */       i = LaunchClassLoader.IndexType.valueOf(index.toUpperCase());
/*  74:    */     }
/*  75:127 */     if (LaunchClassLoader.IndexType.EAGER.equals(i)) {
/*  76:128 */       return null;
/*  77:    */     }
/*  78:131 */     String domainHome = System.getenv("DOMAIN_HOME");
/*  79:132 */     if ((domainHome == null) || (domainHome.isEmpty())) {
/*  80:133 */       domainHome = System.getProperty("user.dir");
/*  81:    */     }
/*  82:134 */     if ((domainHome == null) || (domainHome.isEmpty())) {
/*  83:135 */       return null;
/*  84:    */     }
/*  85:137 */     String serverName = System.getProperty("weblogic.Name");
/*  86:138 */     if ((serverName == null) || (serverName.isEmpty())) {
/*  87:139 */       return null;
/*  88:    */     }
/*  89:141 */     if (isJDK9OrAbove) {
/*  90:142 */       throw new IllegalArgumentException();
/*  91:    */     }
/*  92:144 */     File cacheDir = new File(domainHome + File.separator + "servers" + File.separator + serverName + File.separator + "cache" + File.separator + "classloader");
/*  93:147 */     if (!cacheDir.exists()) {
/*  94:148 */       cacheDir.mkdirs();
/*  95:    */     }
/*  96:151 */     return new File(cacheDir, "launcher.cache");
/*  97:    */   }
/*  98:    */   
/*  99:    */   private void appendToClassPathForInstrumentation(String codeSource)
/* 100:    */     throws URISyntaxException, IOException
/* 101:    */   {
/* 102:168 */     internalAppendToClassPathForInstrumentation(codeSource);
/* 103:    */   }
/* 104:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.weblogic.LaunchClassLoader
 * JD-Core Version:    0.7.0.1
 */