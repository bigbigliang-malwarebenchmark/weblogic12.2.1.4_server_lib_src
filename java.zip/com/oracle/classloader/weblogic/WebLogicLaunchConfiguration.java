/*   1:    */ package com.oracle.classloader.weblogic;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.CodeSourceCache;
/*   4:    */ import com.oracle.classloader.CodeSourceList;
/*   5:    */ import com.oracle.classloader.PolicyClassLoader;
/*   6:    */ import com.oracle.classloader.SearchPolicy;
/*   7:    */ import com.oracle.classloader.cache.ClassCache.CacheFailed;
/*   8:    */ import com.oracle.classloader.index.BackgroundCodeSourceIndex;
/*   9:    */ import com.oracle.classloader.launch.LaunchConfiguration;
/*  10:    */ import com.oracle.classloader.log.Logger;
/*  11:    */ import com.oracle.util.Matcher;
/*  12:    */ import java.io.File;
/*  13:    */ import java.io.IOException;
/*  14:    */ import java.net.MalformedURLException;
/*  15:    */ import java.net.URI;
/*  16:    */ import java.net.URISyntaxException;
/*  17:    */ import java.net.URL;
/*  18:    */ import java.net.URLClassLoader;
/*  19:    */ import java.util.ArrayList;
/*  20:    */ import java.util.Collection;
/*  21:    */ 
/*  22:    */ public class WebLogicLaunchConfiguration
/*  23:    */   extends LaunchConfiguration
/*  24:    */ {
/*  25:    */   private static final String MAIN_CLASS = "weblogic.internal.Server";
/*  26:    */   public static final String MAIN_CLASS_KEY = "launch.main.class";
/*  27:    */   public static final String CLASS_PATH_KEY = "launch.class.path";
/*  28:    */   public static final String USE_ENV_CLASSPATH_KEY = "launch.use.env.classpath";
/*  29: 34 */   private static String CLASS_PATH = System.getProperty("launch.class.path");
/*  30: 35 */   private static boolean IS_USE_ENV_CLASSPATH = "true".equalsIgnoreCase(
/*  31: 36 */     System.getProperty("launch.use.env.classpath", "false"));
/*  32:    */   private final ClassLoader parent;
/*  33:    */   
/*  34:    */   public WebLogicLaunchConfiguration(String[] mainClassArguments)
/*  35:    */   {
/*  36: 41 */     this(mainClassArguments, null);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public WebLogicLaunchConfiguration(String[] mainClassArguments, ClassLoader parent)
/*  40:    */   {
/*  41: 45 */     this(mainClassArguments, parent, getClassPath());
/*  42:    */   }
/*  43:    */   
/*  44:    */   public WebLogicLaunchConfiguration(String[] mainClassArguments, ClassLoader parent, URL[] classPath)
/*  45:    */   {
/*  46: 49 */     super(System.getProperty("launch.main.class", "weblogic.internal.Server"), mainClassArguments, classPath);
/*  47: 50 */     this.parent = (isUseClassPath() ? parent : parent.getParent());
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static boolean isUseClassPath()
/*  51:    */   {
/*  52: 54 */     return (IS_USE_ENV_CLASSPATH) || (CLASS_PATH != null);
/*  53:    */   }
/*  54:    */   
/*  55:    */   protected ClassLoader getParentClassLoader()
/*  56:    */   {
/*  57: 58 */     if (this.parent != null) {
/*  58: 59 */       return this.parent;
/*  59:    */     }
/*  60: 60 */     return super.getParentClassLoader();
/*  61:    */   }
/*  62:    */   
/*  63:    */   protected static URL[] getClassPath()
/*  64:    */   {
/*  65: 64 */     String path = IS_USE_ENV_CLASSPATH ? System.getenv("CLASSPATH") : CLASS_PATH;
/*  66: 65 */     return getClassPath(path);
/*  67:    */   }
/*  68:    */   
/*  69:    */   protected static URL[] getClassPath(String javaClassPath)
/*  70:    */   {
/*  71: 69 */     if (javaClassPath != null)
/*  72:    */     {
/*  73: 70 */       String[] paths = javaClassPath.split(File.pathSeparator);
/*  74: 71 */       Collection<URL> result = new ArrayList(paths.length);
/*  75:    */       try
/*  76:    */       {
/*  77: 73 */         for (int i = 0; i < paths.length; i++)
/*  78:    */         {
/*  79: 74 */           String path = paths[i];
/*  80: 77 */           if (path.endsWith("*"))
/*  81:    */           {
/*  82: 79 */             File directory = new File(path.substring(0, path.length() - 1));
/*  83: 80 */             if ((directory.exists()) && (directory.isDirectory()))
/*  84:    */             {
/*  85: 81 */               File[] containedJars = directory.listFiles(new WebLogicLaunchConfiguration.1());
/*  86: 86 */               if (containedJars != null) {
/*  87: 87 */                 for (File jar : containedJars) {
/*  88: 88 */                   result.add(jar.toURI().toURL());
/*  89:    */                 }
/*  90:    */               }
/*  91:    */             }
/*  92:    */           }
/*  93: 96 */           else if ((path != null) && (!path.trim().isEmpty()))
/*  94:    */           {
/*  95: 97 */             File f = new File(path);
/*  96: 98 */             if (f.exists()) {
/*  97: 99 */               result.add(f.toURI().toURL());
/*  98:    */             }
/*  99:    */           }
/* 100:    */         }
/* 101:    */       }
/* 102:    */       catch (MalformedURLException mul)
/* 103:    */       {
/* 104:103 */         throw new Error("Class path is malformed", mul);
/* 105:    */       }
/* 106:106 */       return (URL[])result.toArray(new URL[result.size()]);
/* 107:    */     }
/* 108:109 */     ClassLoader origSystem = WebLogicLaunchConfiguration.class.getClassLoader();
/* 109:110 */     if ((origSystem instanceof URLClassLoader)) {
/* 110:111 */       return ((URLClassLoader)origSystem).getURLs();
/* 111:    */     }
/* 112:114 */     throw new Error("Class path must be specified to launcher");
/* 113:    */   }
/* 114:    */   
/* 115:    */   protected PolicyClassLoader createLoader(SearchPolicy searchPolicy)
/* 116:    */   {
/* 117:    */     try
/* 118:    */     {
/* 119:125 */       return new PolicyClassLoader("launcher", searchPolicy);
/* 120:    */     }
/* 121:    */     catch (ClassCache.CacheFailed e)
/* 122:    */     {
/* 123:127 */       Logger.logWarning("Cache bulk-load failed, re-building", e.getCause());
/* 124:    */     }
/* 125:128 */     return new PolicyClassLoader("launcher", searchPolicy);
/* 126:    */   }
/* 127:    */   
/* 128:    */   protected CodeSourceList getCodeSourceList(URL... codeSources)
/* 129:    */     throws URISyntaxException, IOException
/* 130:    */   {
/* 131:141 */     return isEager() ? new CodeSourceList(
/* 132:142 */       CodeSourceCache.getCache(), BackgroundCodeSourceIndex.FACTORY, codeSources) : new CodeSourceList(
/* 133:143 */       CodeSourceCache.getCache(), codeSources);
/* 134:    */   }
/* 135:    */   
/* 136:    */   protected boolean isEager()
/* 137:    */   {
/* 138:147 */     return true;
/* 139:    */   }
/* 140:    */   
/* 141:    */   protected SearchPolicy getSearchPolicy(ClassLoader parent, CodeSourceList codeSources)
/* 142:    */   {
/* 143:158 */     return SearchPolicy.createStandard(SearchPolicy.createParent(parent, new Matcher[0]), codeSources);
/* 144:    */   }
/* 145:    */   
/* 146:    */   public boolean shouldTransferInitialSystemLoaderClasses()
/* 147:    */   {
/* 148:162 */     return false;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public boolean shouldResetThreadContextClassLoader()
/* 152:    */   {
/* 153:166 */     return false;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public boolean shouldResetClassPathProperty()
/* 157:    */   {
/* 158:170 */     return isUseClassPath();
/* 159:    */   }
/* 160:    */   
/* 161:    */   public boolean shouldPrependLauncherCodeSources()
/* 162:    */   {
/* 163:174 */     return (!LaunchClassLoader.isJDK9OrAbove) && (isUseClassPath());
/* 164:    */   }
/* 165:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.weblogic.WebLogicLaunchConfiguration
 * JD-Core Version:    0.7.0.1
 */