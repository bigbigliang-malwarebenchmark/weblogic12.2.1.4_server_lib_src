/*   1:    */ package com.oracle.classloader;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.log.Logger;
/*   4:    */ import com.oracle.classloader.util.DigestBuilder;
/*   5:    */ import java.io.File;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.net.URISyntaxException;
/*   8:    */ import java.net.URL;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.List;
/*  11:    */ 
/*  12:    */ public final class CodeSourceList
/*  13:    */ {
/*  14: 26 */   private final List<CodeSource> initial = new ArrayList();
/*  15: 27 */   private final List<CodeSource> expanded = new ArrayList();
/*  16:    */   private final CodeSourceCache cache;
/*  17:    */   private volatile CodeSourceIndex index;
/*  18:    */   
/*  19:    */   public CodeSourceList(CodeSourceCache cache, File... sources)
/*  20:    */     throws URISyntaxException, IOException
/*  21:    */   {
/*  22: 38 */     this(cache, CodeSourceIndex.FACTORY, sources);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public CodeSourceList(CodeSourceCache cache, URL... sources)
/*  26:    */     throws URISyntaxException, IOException
/*  27:    */   {
/*  28: 48 */     this(cache, CodeSourceIndex.FACTORY, sources);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public CodeSourceList(CodeSourceCache cache, CodeSourceIndexFactory indexFactory, File... sources)
/*  32:    */     throws URISyntaxException, IOException
/*  33:    */   {
/*  34: 59 */     this.cache = cache;
/*  35: 60 */     this.index = indexFactory.create(this);
/*  36: 61 */     addCodeSources(sources);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public CodeSourceList(CodeSourceCache cache, CodeSourceIndexFactory indexFactory, URL... sources)
/*  40:    */     throws URISyntaxException, IOException
/*  41:    */   {
/*  42: 72 */     this.cache = cache;
/*  43: 73 */     this.index = indexFactory.create(this);
/*  44: 74 */     addCodeSources(sources);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void resetIndex(CodeSourceIndex index, boolean update)
/*  48:    */   {
/*  49: 83 */     if (update) {
/*  50: 84 */       for (int i = 0; i < this.expanded.size(); i++)
/*  51:    */       {
/*  52: 85 */         CodeSource cs = (CodeSource)this.expanded.get(i);
/*  53: 86 */         index.update(cs, i);
/*  54:    */       }
/*  55:    */     }
/*  56: 90 */     this.index = index;
/*  57:    */   }
/*  58:    */   
/*  59:    */   private void buildIndex()
/*  60:    */   {
/*  61: 94 */     this.index.build();
/*  62:    */   }
/*  63:    */   
/*  64:    */   private void addCodeSources(File... sources)
/*  65:    */     throws URISyntaxException, IOException
/*  66:    */   {
/*  67:104 */     addCodeSources(true, sources);
/*  68:    */   }
/*  69:    */   
/*  70:    */   private void addCodeSources(boolean processManifest, File... sources)
/*  71:    */     throws URISyntaxException, IOException
/*  72:    */   {
/*  73:114 */     long startTime = System.currentTimeMillis();
/*  74:115 */     int startCount = size();
/*  75:116 */     for (File f : sources)
/*  76:    */     {
/*  77:117 */       CodeSource cs = this.cache.get(f);
/*  78:118 */       if (cs != null) {
/*  79:118 */         this.initial.add(cs);
/*  80:    */       }
/*  81:119 */       appendCodeSourceAndManifestClassPath(processManifest, cs);
/*  82:    */     }
/*  83:121 */     buildIndex();
/*  84:122 */     logUpdate(startTime, startCount);
/*  85:    */   }
/*  86:    */   
/*  87:    */   private void addCodeSources(URL... sources)
/*  88:    */     throws URISyntaxException, IOException
/*  89:    */   {
/*  90:132 */     long startTime = System.currentTimeMillis();
/*  91:133 */     int startCount = size();
/*  92:134 */     for (URL u : sources)
/*  93:    */     {
/*  94:135 */       CodeSource cs = this.cache.get(u.toURI());
/*  95:136 */       if (cs != null) {
/*  96:136 */         this.initial.add(cs);
/*  97:    */       }
/*  98:137 */       appendCodeSourceAndManifestClassPath(true, cs);
/*  99:    */     }
/* 100:139 */     buildIndex();
/* 101:140 */     logUpdate(startTime, startCount);
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void updateSignature(DigestBuilder digest)
/* 105:    */   {
/* 106:148 */     digest.update(this.expanded.size());
/* 107:149 */     for (CodeSource cs : this.expanded) {
/* 108:150 */       cs.updateSignature(digest);
/* 109:    */     }
/* 110:    */   }
/* 111:    */   
/* 112:    */   public List<CodeSource> getCodeSources(List<CodeSource> result, boolean all)
/* 113:    */   {
/* 114:162 */     result.addAll(all ? this.expanded : this.initial);
/* 115:163 */     return result;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public int size()
/* 119:    */   {
/* 120:171 */     return this.expanded.size();
/* 121:    */   }
/* 122:    */   
/* 123:    */   public CodeSource getCodeSource(int index)
/* 124:    */   {
/* 125:180 */     if (index >= 0) {
/* 126:181 */       return (CodeSource)this.expanded.get(index);
/* 127:    */     }
/* 128:183 */     return null;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public boolean contains(CodeSource source)
/* 132:    */   {
/* 133:193 */     return this.expanded.contains(source);
/* 134:    */   }
/* 135:    */   
/* 136:    */   private void append(CodeSource source)
/* 137:    */   {
/* 138:201 */     this.expanded.add(source);
/* 139:    */   }
/* 140:    */   
/* 141:    */   public CodeSourceIterator iterator(String packageName)
/* 142:    */   {
/* 143:210 */     return this.index.iterator(packageName);
/* 144:    */   }
/* 145:    */   
/* 146:    */   private void appendCodeSourceAndManifestClassPath(boolean processManifest, CodeSource source)
/* 147:    */     throws URISyntaxException, IOException
/* 148:    */   {
/* 149:214 */     if ((source != null) && (!contains(source)))
/* 150:    */     {
/* 151:215 */       append(source);
/* 152:216 */       if (processManifest)
/* 153:    */       {
/* 154:217 */         List<CodeSource> manifestPath = source.getManifestClassPath(this.cache);
/* 155:218 */         if (manifestPath != null) {
/* 156:219 */           for (CodeSource cs : manifestPath) {
/* 157:220 */             appendCodeSourceAndManifestClassPath(processManifest, cs);
/* 158:    */           }
/* 159:    */         }
/* 160:    */       }
/* 161:    */     }
/* 162:    */   }
/* 163:    */   
/* 164:    */   private void logUpdate(long startTime, int startSize)
/* 165:    */   {
/* 166:228 */     if (Logger.willLogFine())
/* 167:    */     {
/* 168:229 */       long elapsed = System.currentTimeMillis() - startTime;
/* 169:230 */       int count = size() - startSize;
/* 170:231 */       Logger.logFine(count + " code sources added/indexed in " + elapsed + "ms");
/* 171:    */     }
/* 172:    */   }
/* 173:    */   
/* 174:    */   public long detectIndexPhases(Runnable onIndexingStart, Runnable onIndexingFinish)
/* 175:    */   {
/* 176:236 */     return this.index.detectIndexPhases(onIndexingStart, onIndexingFinish);
/* 177:    */   }
/* 178:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.CodeSourceList
 * JD-Core Version:    0.7.0.1
 */