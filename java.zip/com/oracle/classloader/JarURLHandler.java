/*   1:    */ package com.oracle.classloader;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.util.URLEncoder;
/*   4:    */ import java.io.FileNotFoundException;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.net.MalformedURLException;
/*   7:    */ import java.net.URL;
/*   8:    */ import java.net.URLConnection;
/*   9:    */ import java.net.URLStreamHandler;
/*  10:    */ import java.util.jar.JarEntry;
/*  11:    */ 
/*  12:    */ public class JarURLHandler
/*  13:    */   extends URLStreamHandler
/*  14:    */ {
/*  15:    */   private static final String CONTENT_LENGTH_HEADER = "content-length";
/*  16:    */   private static final String CONTENT_TYPE_HEADER = "content-type";
/*  17:    */   private static final String LAST_MODIFIED_HEADER = "last-modified";
/*  18:    */   private static final String CLASS_CONTENT_TYPE = "application/octet-stream";
/*  19:    */   private final JarCodeSource codeSource;
/*  20:    */   private final JarEntry entry;
/*  21:    */   private final String resourcePath;
/*  22:    */   private URL url;
/*  23:    */   private final boolean useCaches;
/*  24:    */   
/*  25:    */   static URL createJarURL(JarCodeSource codeSource, JarEntry entry, String basePath, String resourcePath, boolean useCaches)
/*  26:    */   {
/*  27: 68 */     JarURLHandler handler = new JarURLHandler(codeSource, entry, resourcePath, useCaches);
/*  28:    */     try
/*  29:    */     {
/*  30: 70 */       URL result = new URL("jar", null, -1, basePath + URLEncoder.encodePath(resourcePath), handler);
/*  31: 71 */       handler.setURL(result);
/*  32: 72 */       return result;
/*  33:    */     }
/*  34:    */     catch (MalformedURLException e)
/*  35:    */     {
/*  36: 75 */       throw new Error(e);
/*  37:    */     }
/*  38:    */   }
/*  39:    */   
/*  40:    */   private JarURLHandler(JarCodeSource codeSource, JarEntry entry, String resourcePath, boolean useCaches)
/*  41:    */   {
/*  42: 87 */     this.codeSource = codeSource;
/*  43: 88 */     this.entry = entry;
/*  44: 89 */     this.resourcePath = resourcePath;
/*  45: 90 */     this.useCaches = useCaches;
/*  46:    */   }
/*  47:    */   
/*  48:    */   private void setURL(URL url)
/*  49:    */   {
/*  50: 94 */     this.url = url;
/*  51:    */   }
/*  52:    */   
/*  53:    */   protected URLConnection openConnection(URL u)
/*  54:    */     throws IOException
/*  55:    */   {
/*  56:116 */     if (u == this.url) {
/*  57:117 */       return new JarURLHandler.Connection(u, this.codeSource, this.entry, this.resourcePath, this.useCaches);
/*  58:    */     }
/*  59:119 */     String p = u.getPath();
/*  60:120 */     int bang = p.indexOf('!');
/*  61:121 */     if (bang >= 0)
/*  62:    */     {
/*  63:122 */       String path = p.substring(bang + 2);
/*  64:    */       
/*  65:124 */       JarEntry entry = this.codeSource.getJarEntry(path);
/*  66:125 */       if (entry != null) {
/*  67:126 */         return new JarURLHandler.Connection(u, this.codeSource, entry, path, this.useCaches);
/*  68:    */       }
/*  69:    */     }
/*  70:129 */     throw new FileNotFoundException(u.getFile());
/*  71:    */   }
/*  72:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.JarURLHandler
 * JD-Core Version:    0.7.0.1
 */