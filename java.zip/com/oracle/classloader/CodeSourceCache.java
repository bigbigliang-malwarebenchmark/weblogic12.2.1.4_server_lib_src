/*   1:    */ package com.oracle.classloader;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.log.Logger;
/*   4:    */ import com.oracle.classloader.util.URLEncoder;
/*   5:    */ import java.io.File;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.net.MalformedURLException;
/*   8:    */ import java.net.URI;
/*   9:    */ import java.net.URISyntaxException;
/*  10:    */ import java.net.URL;
/*  11:    */ import java.security.ProtectionDomain;
/*  12:    */ import java.util.HashMap;
/*  13:    */ import java.util.Iterator;
/*  14:    */ import java.util.Map;
/*  15:    */ import java.util.Map.Entry;
/*  16:    */ import java.util.Set;
/*  17:    */ 
/*  18:    */ public class CodeSourceCache
/*  19:    */ {
/*  20:    */   private static CodeSourceCache instance;
/*  21: 31 */   private Map<URI, CodeSource> codeSources = new HashMap();
/*  22:    */   private CodeSourceFactory factory;
/*  23:    */   private CodeSource frameworkCodeSource;
/*  24:    */   
/*  25:    */   public static synchronized CodeSourceCache getCache()
/*  26:    */     throws URISyntaxException
/*  27:    */   {
/*  28: 42 */     if (instance == null)
/*  29:    */     {
/*  30: 43 */       CodeSourceFactory factory = new CodeSourceFactory();
/*  31: 44 */       instance = new CodeSourceCache(factory);
/*  32:    */     }
/*  33: 46 */     return instance;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public CodeSourceCache(CodeSourceFactory factory)
/*  37:    */     throws URISyntaxException
/*  38:    */   {
/*  39: 56 */     this.factory = factory;
/*  40: 57 */     this.frameworkCodeSource = factory.create(getClass().getProtectionDomain().getCodeSource().getLocation().toURI());
/*  41:    */   }
/*  42:    */   
/*  43:    */   public CodeSourceFactory getFactory()
/*  44:    */   {
/*  45: 66 */     return this.factory;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public CodeSource getFrameworkCodeSource()
/*  49:    */   {
/*  50: 75 */     return this.frameworkCodeSource;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public CodeSource get(File file)
/*  54:    */     throws URISyntaxException
/*  55:    */   {
/*  56: 86 */     CodeSource result = null;
/*  57: 87 */     if ((file != null) && (file.exists()))
/*  58:    */     {
/*  59: 88 */       file = getCanonical(file);
/*  60:    */       try
/*  61:    */       {
/*  62: 90 */         URL url = URLEncoder.toURL(file);
/*  63: 91 */         result = get(url.toURI(), file);
/*  64:    */       }
/*  65:    */       catch (MalformedURLException e)
/*  66:    */       {
/*  67: 93 */         Logger.logWarning(e.toString());
/*  68:    */       }
/*  69:    */     }
/*  70: 95 */     else if (Logger.willLogFinest())
/*  71:    */     {
/*  72: 96 */       Logger.logFinest("Ignoring non-existent file: " + file);
/*  73:    */     }
/*  74: 98 */     return result;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public CodeSource get(URI location)
/*  78:    */   {
/*  79:108 */     return get(location, null);
/*  80:    */   }
/*  81:    */   
/*  82:    */   protected synchronized CodeSource get(URI location, File existingFile)
/*  83:    */   {
/*  84:119 */     CodeSource result = (CodeSource)this.codeSources.get(location);
/*  85:120 */     if (result == null)
/*  86:    */     {
/*  87:121 */       result = this.factory.create(location, existingFile);
/*  88:122 */       if (result != null)
/*  89:    */       {
/*  90:123 */         result.setInCache(true);
/*  91:124 */         this.codeSources.put(location, result);
/*  92:    */       }
/*  93:    */     }
/*  94:127 */     return result;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public synchronized void clear()
/*  98:    */   {
/*  99:134 */     Iterator<Map.Entry<URI, CodeSource>> iter = this.codeSources.entrySet().iterator();
/* 100:135 */     while (iter.hasNext())
/* 101:    */     {
/* 102:136 */       ((CodeSource)((Map.Entry)iter.next()).getValue()).setInCache(false);
/* 103:137 */       iter.remove();
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   public synchronized void remove(CodeSource codeSource)
/* 108:    */   {
/* 109:147 */     CodeSource removed = (CodeSource)this.codeSources.remove(codeSource.getLocation());
/* 110:148 */     if (removed != null) {
/* 111:149 */       removed.setInCache(false);
/* 112:    */     }
/* 113:    */   }
/* 114:    */   
/* 115:    */   protected File getCanonical(File file)
/* 116:    */   {
/* 117:    */     try
/* 118:    */     {
/* 119:162 */       file = file.getCanonicalFile();
/* 120:    */     }
/* 121:    */     catch (IOException e)
/* 122:    */     {
/* 123:164 */       StringBuilder buf = new StringBuilder();
/* 124:165 */       buf.append("Could not canonicalize '");
/* 125:166 */       buf.append(file);
/* 126:167 */       buf.append("' (");
/* 127:168 */       buf.append(e.getMessage());
/* 128:169 */       buf.append(").");
/* 129:170 */       Logger.logInfo(buf.toString());
/* 130:    */     }
/* 131:172 */     return file;
/* 132:    */   }
/* 133:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.CodeSourceCache
 * JD-Core Version:    0.7.0.1
 */