/*   1:    */ package com.oracle.classloader;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.index.PackageIndices;
/*   4:    */ import com.oracle.classloader.log.Logger;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.Map;
/*   7:    */ 
/*   8:    */ public abstract class CodeSourceIndex
/*   9:    */ {
/*  10: 25 */   public static final CodeSourceIndexFactory FACTORY = new CodeSourceIndex.1();
/*  11:    */   private final CodeSourceList codeSources;
/*  12:    */   private final Map<String, PackageIndices> map;
/*  13: 48 */   private int[] unindexable = null;
/*  14: 50 */   private long buildTime = 0L;
/*  15: 51 */   private Runnable onIndexingStart = null;
/*  16: 52 */   private Runnable onIndexingFinish = null;
/*  17:    */   
/*  18:    */   protected CodeSourceIndex(CodeSourceList codeSources)
/*  19:    */   {
/*  20: 55 */     this(codeSources, new HashMap());
/*  21:    */   }
/*  22:    */   
/*  23:    */   protected CodeSourceIndex(CodeSourceList codeSources, Map<String, PackageIndices> map)
/*  24:    */   {
/*  25: 59 */     this.codeSources = codeSources;
/*  26: 60 */     this.map = map;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public abstract void update(CodeSource paramCodeSource, int paramInt);
/*  30:    */   
/*  31:    */   public void build()
/*  32:    */   {
/*  33: 72 */     startBuild();
/*  34: 73 */     long bt = System.nanoTime();
/*  35:    */     try
/*  36:    */     {
/*  37: 75 */       int size = this.codeSources.size();
/*  38: 76 */       for (int i = 0; i < size; i++)
/*  39:    */       {
/*  40: 77 */         CodeSource cs = this.codeSources.getCodeSource(i);
/*  41: 78 */         update(cs, i);
/*  42:    */       }
/*  43:    */     }
/*  44:    */     finally
/*  45:    */     {
/*  46: 81 */       finishBuild(bt);
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   protected synchronized void startBuild()
/*  51:    */   {
/*  52: 86 */     if (this.onIndexingStart != null) {
/*  53: 87 */       this.onIndexingStart.run();
/*  54:    */     }
/*  55:    */   }
/*  56:    */   
/*  57:    */   protected synchronized void finishBuild(long startTime)
/*  58:    */   {
/*  59: 91 */     this.buildTime = (System.nanoTime() - startTime);
/*  60: 92 */     if (this.onIndexingFinish != null) {
/*  61: 93 */       this.onIndexingFinish.run();
/*  62:    */     }
/*  63:    */   }
/*  64:    */   
/*  65:    */   public synchronized long detectIndexPhases(Runnable onIndexingStart, Runnable onIndexingFinish)
/*  66:    */   {
/*  67: 97 */     this.onIndexingStart = onIndexingStart;
/*  68: 98 */     this.onIndexingFinish = onIndexingFinish;
/*  69: 99 */     return this.buildTime;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public CodeSourceIterator iterator(String packageName)
/*  73:    */   {
/*  74:109 */     return new CodeSourceIndex.2(this);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public Map<String, PackageIndices> getMap()
/*  78:    */   {
/*  79:144 */     return this.map;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public int[] getUnindexable()
/*  83:    */   {
/*  84:148 */     return this.unindexable;
/*  85:    */   }
/*  86:    */   
/*  87:    */   protected void index(CodeSource codeSource, int codeSourceIndex)
/*  88:    */   {
/*  89:158 */     Map<String, PackageIndices> index = getMap();
/*  90:159 */     boolean finest = Logger.willLogFinest();
/*  91:160 */     if (Logger.willLogFiner()) {
/*  92:161 */       Logger.logFiner("Index update (" + index.size() + "): " + codeSource);
/*  93:    */     }
/*  94:    */     try
/*  95:    */     {
/*  96:164 */       for (String packageName : codeSource.getPackageNames())
/*  97:    */       {
/*  98:165 */         PackageIndices indices = (PackageIndices)index.get(packageName);
/*  99:166 */         if (indices == null)
/* 100:    */         {
/* 101:167 */           PackageIndices created = createPackageIndices();
/* 102:168 */           indices = putIfAbsent(index, packageName, created);
/* 103:169 */           if (indices == null) {
/* 104:170 */             indices = created;
/* 105:    */           }
/* 106:    */         }
/* 107:173 */         indices.append(codeSourceIndex);
/* 108:174 */         if (finest) {
/* 109:175 */           Logger.logFinest("   " + packageName + " (" + indices.size() + ")");
/* 110:    */         }
/* 111:    */       }
/* 112:    */     }
/* 113:    */     catch (TooManyPackagesException t)
/* 114:    */     {
/* 115:179 */       addUnindexable(codeSourceIndex);
/* 116:    */     }
/* 117:    */   }
/* 118:    */   
/* 119:    */   protected PackageIndices createPackageIndices()
/* 120:    */   {
/* 121:184 */     return new PackageIndices();
/* 122:    */   }
/* 123:    */   
/* 124:    */   protected PackageIndices putIfAbsent(Map<String, PackageIndices> index, String packageName, PackageIndices indices)
/* 125:    */   {
/* 126:189 */     return (PackageIndices)index.put(packageName, indices);
/* 127:    */   }
/* 128:    */   
/* 129:    */   protected void addUnindexable(int codeSourceIndex)
/* 130:    */   {
/* 131:193 */     if (this.unindexable == null)
/* 132:    */     {
/* 133:194 */       this.unindexable = new int[1];
/* 134:195 */       this.unindexable[0] = codeSourceIndex;
/* 135:    */     }
/* 136:    */     else
/* 137:    */     {
/* 138:197 */       int[] copy = new int[this.unindexable.length + 1];
/* 139:198 */       System.arraycopy(this.unindexable, 0, copy, 0, this.unindexable.length);
/* 140:199 */       copy[this.unindexable.length] = codeSourceIndex;
/* 141:200 */       this.unindexable = copy;
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   public boolean canPersist()
/* 146:    */   {
/* 147:210 */     return false;
/* 148:    */   }
/* 149:    */   
/* 150:    */   protected CodeSourceList getList()
/* 151:    */   {
/* 152:219 */     return this.codeSources;
/* 153:    */   }
/* 154:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.CodeSourceIndex
 * JD-Core Version:    0.7.0.1
 */