/*   1:    */ package com.oracle.classloader.launch;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.CodeSourceCache;
/*   4:    */ import com.oracle.classloader.CodeSourceList;
/*   5:    */ import com.oracle.classloader.PolicyClassLoader;
/*   6:    */ import com.oracle.classloader.SearchPolicy;
/*   7:    */ import com.oracle.classloader.cache.ClassCache.CacheFailed;
/*   8:    */ import com.oracle.classloader.cache.Limit;
/*   9:    */ import com.oracle.classloader.cache.MappedFileClassCache;
/*  10:    */ import com.oracle.classloader.index.EagerCodeSourceIndex;
/*  11:    */ import com.oracle.classloader.log.Logger;
/*  12:    */ import com.oracle.classloader.metrics.TimingSearchCodeSources;
/*  13:    */ import com.oracle.classloader.search.SearchClassLoader;
/*  14:    */ import com.oracle.classloader.search.SearchSequence;
/*  15:    */ import com.oracle.util.Matcher;
/*  16:    */ import java.io.File;
/*  17:    */ import java.io.IOException;
/*  18:    */ import java.net.MalformedURLException;
/*  19:    */ import java.net.URI;
/*  20:    */ import java.net.URISyntaxException;
/*  21:    */ import java.net.URL;
/*  22:    */ import java.security.CodeSource;
/*  23:    */ import java.security.ProtectionDomain;
/*  24:    */ 
/*  25:    */ public class PropertiesLaunchConfiguration
/*  26:    */   extends LaunchConfiguration
/*  27:    */ {
/*  28:    */   public static final String MAIN_CLASS_KEY = "launch.main.class";
/*  29:    */   public static final String CLASS_PATH_KEY = "launch.class.path";
/*  30:    */   public static final String COMPLETION_KEY = "launch.complete";
/*  31:    */   public static final String TIMING_KEY = "launch.timing";
/*  32:    */   public static final String RESET_SYSTEM_KEY = "launch.reset.system.loader";
/*  33:    */   public static final String DEFAULT_SYSTEM_KEY_VAL = "true";
/*  34:    */   public static final String INDEX_TYPE_KEY = "launch.index";
/*  35:    */   public static final String CLEAR_CACHE_KEY = "launch.clear.cache";
/*  36:    */   public static final String CACHE_DIR_KEY = "launch.cache.dir";
/*  37:    */   public static final String CACHE_FILE_DEFAULT_NAME = ".launcher.cache";
/*  38:    */   public static final String CACHE_FILE_NAME_KEY = "cache.file.name";
/*  39: 49 */   private static final File CACHE_FILE = ;
/*  40:    */   private static final String DEFAULT_INDEX_TYPE = "cache";
/*  41:    */   
/*  42:    */   private static File getCacheFile()
/*  43:    */   {
/*  44: 53 */     File result = null;
/*  45: 54 */     File resultDir = null;
/*  46: 55 */     String path = System.getProperty("launch.cache.dir");
/*  47: 56 */     if (path != null)
/*  48:    */     {
/*  49: 57 */       resultDir = new File(path);
/*  50: 58 */       if (!resultDir.exists()) {
/*  51: 59 */         resultDir.mkdirs();
/*  52:    */       }
/*  53:    */     }
/*  54:    */     else
/*  55:    */     {
/*  56: 62 */       ProtectionDomain pd = PropertiesLaunchConfiguration.class.getProtectionDomain();
/*  57: 63 */       if (pd != null)
/*  58:    */       {
/*  59: 64 */         CodeSource cs = pd.getCodeSource();
/*  60: 65 */         if (cs != null)
/*  61:    */         {
/*  62: 66 */           path = cs.getLocation().getPath();
/*  63: 67 */           File pcl = new File(path);
/*  64: 68 */           resultDir = pcl.getParentFile().getParentFile();
/*  65:    */         }
/*  66:    */       }
/*  67:    */     }
/*  68: 72 */     if (resultDir == null) {
/*  69: 73 */       resultDir = new File(System.getProperty("java.home"));
/*  70:    */     }
/*  71: 75 */     if (resultDir.canWrite())
/*  72:    */     {
/*  73: 76 */       String cacheFileName = System.getProperty("cache.file.name", ".launcher.cache");
/*  74: 77 */       result = new File(resultDir, cacheFileName);
/*  75:    */     }
/*  76:    */     else
/*  77:    */     {
/*  78: 79 */       Logger.logWarning(resultDir + " is not writable. Fix or set -Dlaunch.cache.dir to writable dir.");
/*  79:    */     }
/*  80: 81 */     return result;
/*  81:    */   }
/*  82:    */   
/*  83: 92 */   private PropertiesLaunchConfiguration.IndexType INDEX_TYPE = getIndexType();
/*  84:    */   
/*  85:    */   private static PropertiesLaunchConfiguration.IndexType getIndexType()
/*  86:    */   {
/*  87: 95 */     PropertiesLaunchConfiguration.IndexType result = PropertiesLaunchConfiguration.IndexType.LINEAR;
/*  88: 96 */     String indexType = System.getProperty("launch.index", "cache");
/*  89: 97 */     if (indexType != null)
/*  90:    */     {
/*  91: 98 */       result = PropertiesLaunchConfiguration.IndexType.valueOf(indexType.toUpperCase());
/*  92: 99 */       if ((result == PropertiesLaunchConfiguration.IndexType.CACHEBUILD) && (CACHE_FILE != null))
/*  93:    */       {
/*  94:100 */         CACHE_FILE.delete();
/*  95:101 */         result = PropertiesLaunchConfiguration.IndexType.CACHE;
/*  96:    */       }
/*  97:    */     }
/*  98:104 */     return result;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public PropertiesLaunchConfiguration(String[] mainClassArguments)
/* 102:    */   {
/* 103:113 */     super(getProperty("launch.main.class"), mainClassArguments, getClassPath());
/* 104:114 */     if (Logger.willLogFine()) {
/* 105:115 */       Logger.logFine("Launcher index: " + this.INDEX_TYPE);
/* 106:    */     }
/* 107:    */   }
/* 108:    */   
/* 109:    */   public boolean shouldResetSystemClassLoader()
/* 110:    */   {
/* 111:126 */     return getBooleanProperty("launch.reset.system.loader");
/* 112:    */   }
/* 113:    */   
/* 114:    */   protected CodeSourceList getCodeSourceList(URL... codeSources)
/* 115:    */     throws URISyntaxException, IOException
/* 116:    */   {
/* 117:138 */     switch (PropertiesLaunchConfiguration.1.$SwitchMap$com$oracle$classloader$launch$PropertiesLaunchConfiguration$IndexType[this.INDEX_TYPE.ordinal()])
/* 118:    */     {
/* 119:    */     case 1: 
/* 120:140 */       return new CodeSourceList(CodeSourceCache.getCache(), codeSources);
/* 121:    */     case 2: 
/* 122:142 */       throw new IllegalStateException("No longer supported.");
/* 123:    */     case 3: 
/* 124:144 */       return new CodeSourceList(CodeSourceCache.getCache(), EagerCodeSourceIndex.FACTORY, codeSources);
/* 125:    */     case 4: 
/* 126:146 */       return new CodeSourceList(CodeSourceCache.getCache(), codeSources);
/* 127:    */     }
/* 128:148 */     throw new IllegalStateException();
/* 129:    */   }
/* 130:    */   
/* 131:    */   protected SearchPolicy getSearchPolicy(ClassLoader parent, CodeSourceList codeSources)
/* 132:    */   {
/* 133:160 */     String completion = System.getProperty("launch.complete");
/* 134:161 */     if ((this.INDEX_TYPE == PropertiesLaunchConfiguration.IndexType.CACHE) && (CACHE_FILE != null))
/* 135:    */     {
/* 136:162 */       SearchPolicy parentPolicy = new SearchClassLoader(parent);
/* 137:163 */       return new SearchSequence(new SearchPolicy[] { new MappedFileClassCache(CACHE_FILE, Limit.newLimit(completion), parentPolicy, codeSources) });
/* 138:    */     }
/* 139:164 */     if ((completion != null) && (System.getProperty("launch.timing") != null))
/* 140:    */     {
/* 141:165 */       SearchPolicy parentPolicy = new SearchClassLoader(parent);
/* 142:166 */       return new SearchSequence(new SearchPolicy[] { parentPolicy, new TimingSearchCodeSources(codeSources, completion) });
/* 143:    */     }
/* 144:168 */     return SearchPolicy.createStandard(SearchPolicy.createParent(parent, new Matcher[0]), codeSources);
/* 145:    */   }
/* 146:    */   
/* 147:    */   protected PolicyClassLoader createLoader(SearchPolicy searchPolicy)
/* 148:    */   {
/* 149:    */     try
/* 150:    */     {
/* 151:179 */       return new PolicyClassLoader("launcher", searchPolicy);
/* 152:    */     }
/* 153:    */     catch (ClassCache.CacheFailed e)
/* 154:    */     {
/* 155:181 */       Logger.logWarning("Cache bulk-load failed, re-building", e.getCause());
/* 156:    */     }
/* 157:182 */     return new PolicyClassLoader("launcher", searchPolicy);
/* 158:    */   }
/* 159:    */   
/* 160:    */   private static URL[] getClassPath()
/* 161:    */   {
/* 162:187 */     String[] paths = getProperty("launch.class.path").split(File.pathSeparator);
/* 163:188 */     URL[] result = new URL[paths.length];
/* 164:    */     try
/* 165:    */     {
/* 166:190 */       for (int i = 0; i < paths.length; i++) {
/* 167:191 */         result[i] = new File(paths[i]).toURI().toURL();
/* 168:    */       }
/* 169:    */     }
/* 170:    */     catch (MalformedURLException murl)
/* 171:    */     {
/* 172:194 */       throw new Error("Class path is malformed", murl);
/* 173:    */     }
/* 174:196 */     return result;
/* 175:    */   }
/* 176:    */   
/* 177:    */   private static boolean getBooleanProperty(String key)
/* 178:    */   {
/* 179:200 */     return "true".equalsIgnoreCase(System.getProperty(key, "true"));
/* 180:    */   }
/* 181:    */   
/* 182:    */   private static String getProperty(String key)
/* 183:    */   {
/* 184:204 */     String result = System.getProperty(key);
/* 185:205 */     if (result == null) {
/* 186:206 */       throw new Error("System property '" + key + "' must be defined.");
/* 187:    */     }
/* 188:208 */     return result;
/* 189:    */   }
/* 190:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.launch.PropertiesLaunchConfiguration
 * JD-Core Version:    0.7.0.1
 */