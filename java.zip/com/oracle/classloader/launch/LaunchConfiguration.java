/*   1:    */ package com.oracle.classloader.launch;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.CodeSource;
/*   4:    */ import com.oracle.classloader.CodeSourceCache;
/*   5:    */ import com.oracle.classloader.CodeSourceList;
/*   6:    */ import com.oracle.classloader.PolicyClassLoader;
/*   7:    */ import com.oracle.classloader.SearchPolicy;
/*   8:    */ import com.oracle.classloader.log.Logger;
/*   9:    */ import com.oracle.classloader.model.DefinedClasses;
/*  10:    */ import com.oracle.util.Matcher;
/*  11:    */ import java.io.File;
/*  12:    */ import java.io.IOException;
/*  13:    */ import java.lang.reflect.Method;
/*  14:    */ import java.net.MalformedURLException;
/*  15:    */ import java.net.URI;
/*  16:    */ import java.net.URISyntaxException;
/*  17:    */ import java.net.URL;
/*  18:    */ import java.net.URLClassLoader;
/*  19:    */ import java.util.ArrayList;
/*  20:    */ import java.util.List;
/*  21:    */ 
/*  22:    */ public class LaunchConfiguration
/*  23:    */ {
/*  24:    */   private String mainClassName;
/*  25:    */   private String[] mainClassArguments;
/*  26:    */   private URL[] codeSources;
/*  27:    */   private static final String BACKUP_SYSTEM_CLASS_LOADER_FIELD = "system.loader.field";
/*  28:    */   private static final String CLASS_PATH_KEY = "java.class.path";
/*  29:    */   private static final String MAIN_METHOD_NAME = "main";
/*  30:    */   
/*  31:    */   public LaunchConfiguration(String mainClassName, String[] mainClassArguments, URL... codeSources)
/*  32:    */   {
/*  33: 49 */     this.mainClassName = mainClassName;
/*  34: 50 */     this.mainClassArguments = mainClassArguments;
/*  35: 51 */     this.codeSources = codeSources;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public PolicyClassLoader createLoader()
/*  39:    */     throws URISyntaxException, IOException
/*  40:    */   {
/*  41: 62 */     return createLoader(createSearchPolicy());
/*  42:    */   }
/*  43:    */   
/*  44:    */   public SearchPolicy createSearchPolicy()
/*  45:    */     throws URISyntaxException, IOException
/*  46:    */   {
/*  47: 73 */     ClassLoader parent = getParentClassLoader();
/*  48: 74 */     URL[] allSources = shouldPrependLauncherCodeSources() ? prependLauncherCodeSources(this.codeSources) : this.codeSources;
/*  49: 75 */     CodeSourceList codeSourceList = getCodeSourceList(allSources);
/*  50: 76 */     return getSearchPolicy(parent, codeSourceList);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void prepareEnvironment(PolicyClassLoader loader)
/*  54:    */   {
/*  55: 85 */     if (shouldResetThreadContextClassLoader()) {
/*  56: 86 */       resetThreadContextClassLoader(loader);
/*  57:    */     }
/*  58: 88 */     if (shouldResetSystemClassLoader()) {
/*  59: 89 */       throw new IllegalStateException("Resetting system class loader no longer supported.  Please use java.system.class.loader");
/*  60:    */     }
/*  61: 91 */     if (shouldResetClassPathProperty()) {
/*  62: 92 */       resetClassPathProperty();
/*  63:    */     }
/*  64: 94 */     if (shouldTransferInitialSystemLoaderClasses()) {
/*  65: 95 */       transferInitialSystemLoaderClasses(loader);
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   public Class launch(PolicyClassLoader loader)
/*  70:    */     throws Exception
/*  71:    */   {
/*  72:106 */     Class mainClass = loader.loadClass(getMainClassName());
/*  73:107 */     Method mainMethod = mainClass.getDeclaredMethod("main", new Class[] { [Ljava.lang.String.class });
/*  74:108 */     if (Logger.willLogFine()) {
/*  75:109 */       Logger.logFinest("Launcher: invoking " + mainMethod);
/*  76:    */     }
/*  77:111 */     mainMethod.invoke(null, new Object[] { getMainClassArguments() });
/*  78:112 */     return mainClass;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public String getMainClassName()
/*  82:    */   {
/*  83:121 */     return this.mainClassName;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public String[] getMainClassArguments()
/*  87:    */   {
/*  88:130 */     return this.mainClassArguments;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public boolean shouldResetThreadContextClassLoader()
/*  92:    */   {
/*  93:140 */     return true;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public boolean shouldPrependLauncherCodeSources()
/*  97:    */   {
/*  98:144 */     return true;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public boolean shouldResetSystemClassLoader()
/* 102:    */   {
/* 103:154 */     return false;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public boolean shouldResetClassPathProperty()
/* 107:    */   {
/* 108:164 */     return true;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public boolean shouldTransferInitialSystemLoaderClasses()
/* 112:    */   {
/* 113:177 */     return true;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public String getClassPathPropertyValue()
/* 117:    */   {
/* 118:186 */     StringBuilder b = new StringBuilder(4096);
/* 119:187 */     for (URL f : this.codeSources)
/* 120:    */     {
/* 121:188 */       if (b.length() > 0) {
/* 122:189 */         b.append(File.pathSeparatorChar);
/* 123:    */       }
/* 124:191 */       String p = f.getPath();
/* 125:192 */       if ("\\".equals(File.separator)) {
/* 126:195 */         if ((p.length() >= 3) && (p.charAt(0) == '/') && (p.charAt(2) == ':')) {
/* 127:196 */           p = p.substring(1);
/* 128:    */         }
/* 129:    */       }
/* 130:198 */       b.append(p);
/* 131:    */     }
/* 132:200 */     return b.toString();
/* 133:    */   }
/* 134:    */   
/* 135:    */   protected ClassLoader getParentClassLoader()
/* 136:    */   {
/* 137:209 */     ClassLoader system = ClassLoader.getSystemClassLoader();
/* 138:210 */     return system.getParent();
/* 139:    */   }
/* 140:    */   
/* 141:    */   protected URL[] prependLauncherCodeSources(URL[] originalSources)
/* 142:    */     throws MalformedURLException, URISyntaxException
/* 143:    */   {
/* 144:223 */     List<URL> files = new ArrayList(64);
/* 145:    */     
/* 146:    */ 
/* 147:    */ 
/* 148:227 */     ClassLoader loader = getClass().getClassLoader();
/* 149:228 */     if ((loader instanceof URLClassLoader))
/* 150:    */     {
/* 151:229 */       systemCodeSources = ((URLClassLoader)loader).getURLs();
/* 152:230 */       if (systemCodeSources != null)
/* 153:    */       {
/* 154:231 */         addOurCodeSource = shouldTransferInitialSystemLoaderClasses();
/* 155:232 */         fwURL = CodeSourceCache.getCache().getFrameworkCodeSource().getLocation();
/* 156:233 */         for (URL u : systemCodeSources) {
/* 157:234 */           if ((addOurCodeSource) || (!u.toURI().equals(fwURL)))
/* 158:    */           {
/* 159:235 */             files.add(u);
/* 160:236 */             if (Logger.willLogFiner()) {
/* 161:237 */               Logger.logFiner("Added" + u + " to " + "java.class.path" + ".");
/* 162:    */             }
/* 163:    */           }
/* 164:    */         }
/* 165:    */       }
/* 166:    */     }
/* 167:    */     else
/* 168:    */     {
/* 169:243 */       Logger.logWarning("Cannot access code-sources of " + loader);
/* 170:    */     }
/* 171:248 */     URL[] systemCodeSources = originalSources;boolean addOurCodeSource = systemCodeSources.length;
/* 172:248 */     for (URI fwURL = 0; fwURL < addOurCodeSource; fwURL++)
/* 173:    */     {
/* 174:248 */       URL f = systemCodeSources[fwURL];
/* 175:249 */       files.add(f);
/* 176:    */     }
/* 177:252 */     return (URL[])files.toArray(new URL[files.size()]);
/* 178:    */   }
/* 179:    */   
/* 180:    */   protected CodeSourceList getCodeSourceList(URL... codeSources)
/* 181:    */     throws URISyntaxException, IOException
/* 182:    */   {
/* 183:264 */     return new CodeSourceList(CodeSourceCache.getCache(), codeSources);
/* 184:    */   }
/* 185:    */   
/* 186:    */   protected SearchPolicy getSearchPolicy(ClassLoader parent, CodeSourceList codeSources)
/* 187:    */   {
/* 188:275 */     return SearchPolicy.createStandard(SearchPolicy.createParent(parent, new Matcher[0]), codeSources);
/* 189:    */   }
/* 190:    */   
/* 191:    */   protected PolicyClassLoader createLoader(SearchPolicy searchPolicy)
/* 192:    */   {
/* 193:285 */     return new PolicyClassLoader("launcher", searchPolicy);
/* 194:    */   }
/* 195:    */   
/* 196:    */   public void resetThreadContextClassLoader(ClassLoader loader)
/* 197:    */   {
/* 198:294 */     Thread.currentThread().setContextClassLoader(loader);
/* 199:295 */     if (Logger.willLogFinest()) {
/* 200:296 */       Logger.logFinest("Launcher: reset thread context loader.");
/* 201:    */     }
/* 202:    */   }
/* 203:    */   
/* 204:    */   public void resetClassPathProperty()
/* 205:    */   {
/* 206:304 */     String classPath = getClassPathPropertyValue();
/* 207:305 */     System.setProperty("java.class.path", classPath);
/* 208:306 */     if (Logger.willLogFinest()) {
/* 209:307 */       Logger.logFinest("Launcher: reset java.class.path = " + classPath);
/* 210:    */     }
/* 211:    */   }
/* 212:    */   
/* 213:    */   public void transferInitialSystemLoaderClasses(PolicyClassLoader loader)
/* 214:    */   {
/* 215:318 */     ClassLoader systemLoader = getClass().getClassLoader();
/* 216:319 */     List<Class> definedClasses = DefinedClasses.getClassesDefinedBy(systemLoader);
/* 217:    */   }
/* 218:    */   
/* 219:    */   protected String getBackupSystemClassLoaderFieldName()
/* 220:    */   {
/* 221:330 */     String result = System.getProperty("system.loader.field");
/* 222:331 */     if (result == null) {
/* 223:335 */       result = "applicationClassLoader";
/* 224:    */     }
/* 225:337 */     return result;
/* 226:    */   }
/* 227:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.launch.LaunchConfiguration
 * JD-Core Version:    0.7.0.1
 */