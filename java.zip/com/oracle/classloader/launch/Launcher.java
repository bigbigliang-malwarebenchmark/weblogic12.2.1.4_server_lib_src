/*  1:   */ package com.oracle.classloader.launch;
/*  2:   */ 
/*  3:   */ import com.oracle.classloader.PolicyClassLoader;
/*  4:   */ import com.oracle.classloader.log.Logger;
/*  5:   */ import java.io.IOException;
/*  6:   */ import java.net.URISyntaxException;
/*  7:   */ 
/*  8:   */ public class Launcher
/*  9:   */ {
/* 10:   */   private LaunchConfiguration config;
/* 11:   */   private PolicyClassLoader loader;
/* 12:   */   
/* 13:   */   public static void main(String[] args)
/* 14:   */   {
/* 15:   */     try
/* 16:   */     {
/* 17:40 */       LaunchConfiguration c = new PropertiesLaunchConfiguration(args);
/* 18:41 */       Launcher launcher = new Launcher(c);
/* 19:42 */       launcher.launch();
/* 20:   */     }
/* 21:   */     catch (Exception e)
/* 22:   */     {
/* 23:44 */       Logger.logWarning("Launch failed.", e);
/* 24:   */     }
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Launcher(LaunchConfiguration config)
/* 28:   */     throws URISyntaxException, IOException
/* 29:   */   {
/* 30:56 */     this.config = config;
/* 31:57 */     this.loader = config.createLoader();
/* 32:58 */     config.prepareEnvironment(this.loader);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public Class launch()
/* 36:   */     throws Exception
/* 37:   */   {
/* 38:67 */     return this.config.launch(this.loader);
/* 39:   */   }
/* 40:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.launch.Launcher
 * JD-Core Version:    0.7.0.1
 */