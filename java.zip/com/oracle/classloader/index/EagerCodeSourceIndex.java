/*   1:    */ package com.oracle.classloader.index;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.CodeSource;
/*   4:    */ import com.oracle.classloader.CodeSourceIndex;
/*   5:    */ import com.oracle.classloader.CodeSourceIndexFactory;
/*   6:    */ import com.oracle.classloader.CodeSourceIterator;
/*   7:    */ import com.oracle.classloader.CodeSourceList;
/*   8:    */ import java.util.Map;
/*   9:    */ 
/*  10:    */ public class EagerCodeSourceIndex
/*  11:    */   extends CodeSourceIndex
/*  12:    */ {
/*  13: 22 */   public static final CodeSourceIndexFactory FACTORY = new EagerCodeSourceIndex.1();
/*  14:    */   
/*  15:    */   public EagerCodeSourceIndex(CodeSourceList codeSources)
/*  16:    */   {
/*  17: 36 */     super(codeSources);
/*  18:    */   }
/*  19:    */   
/*  20:    */   public EagerCodeSourceIndex(CodeSourceList codeSources, Map<String, PackageIndices> index)
/*  21:    */   {
/*  22: 45 */     super(codeSources, index);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public void update(CodeSource codeSource, int codeSourceIndex)
/*  26:    */   {
/*  27: 55 */     index(codeSource, codeSourceIndex);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public CodeSourceIterator iterator(String packageName)
/*  31:    */   {
/*  32: 65 */     return new EagerCodeSourceIndex.PackageIndexedIterator(this, packageName);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public boolean canPersist()
/*  36:    */   {
/*  37:145 */     return true;
/*  38:    */   }
/*  39:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.index.EagerCodeSourceIndex
 * JD-Core Version:    0.7.0.1
 */