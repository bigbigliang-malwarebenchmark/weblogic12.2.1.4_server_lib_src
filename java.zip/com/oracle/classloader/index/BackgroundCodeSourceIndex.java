/*   1:    */ package com.oracle.classloader.index;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.CodeSource;
/*   4:    */ import com.oracle.classloader.CodeSourceIndex;
/*   5:    */ import com.oracle.classloader.CodeSourceIndexFactory;
/*   6:    */ import com.oracle.classloader.CodeSourceIterator;
/*   7:    */ import com.oracle.classloader.CodeSourceList;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.concurrent.ConcurrentHashMap;
/*  10:    */ import java.util.concurrent.ConcurrentMap;
/*  11:    */ import java.util.concurrent.atomic.AtomicInteger;
/*  12:    */ import java.util.concurrent.locks.Lock;
/*  13:    */ import java.util.concurrent.locks.ReadWriteLock;
/*  14:    */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*  15:    */ 
/*  16:    */ public class BackgroundCodeSourceIndex
/*  17:    */   extends CodeSourceIndex
/*  18:    */ {
/*  19: 29 */   public static CodeSourceIndexFactory FACTORY = new BackgroundCodeSourceIndex.1();
/*  20: 38 */   private final boolean isDelayIndexToFirstCall = true;
/*  21: 39 */   private boolean firstCall = true;
/*  22: 40 */   private final AtomicInteger idxIteration = new AtomicInteger(0);
/*  23: 41 */   private final ReadWriteLock packageIndicesLock = new ReentrantReadWriteLock();
/*  24:    */   
/*  25:    */   public BackgroundCodeSourceIndex(CodeSourceList codeSources)
/*  26:    */   {
/*  27: 44 */     super(codeSources, new ConcurrentHashMap());
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void update(CodeSource codeSource, int codeSourceIndex)
/*  31:    */   {
/*  32: 56 */     index(codeSource, codeSourceIndex);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void build() {}
/*  36:    */   
/*  37:    */   private void buildInternal()
/*  38:    */   {
/*  39: 65 */     startBuild();
/*  40: 66 */     long bt = System.nanoTime();
/*  41:    */     try
/*  42:    */     {
/*  43: 68 */       CodeSourceList codeSources = getList();
/*  44: 69 */       int size = codeSources.size();
/*  45:    */       int i;
/*  46: 71 */       while ((i = this.idxIteration.getAndIncrement()) < size)
/*  47:    */       {
/*  48: 72 */         CodeSource cs = codeSources.getCodeSource(i);
/*  49: 73 */         update(cs, i);
/*  50:    */       }
/*  51:    */     }
/*  52:    */     finally
/*  53:    */     {
/*  54: 76 */       finishBuild(bt);
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   private void doIndexing()
/*  59:    */   {
/*  60: 81 */     Runnable run = new BackgroundCodeSourceIndex.2(this);
/*  61:    */     
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75: 96 */     Thread background = new Thread(run);
/*  76: 97 */     background.setDaemon(true);
/*  77: 98 */     background.start();
/*  78:    */   }
/*  79:    */   
/*  80:    */   protected void addUnindexable(int codeSourceIndex)
/*  81:    */   {
/*  82:103 */     Lock lock = this.packageIndicesLock.writeLock();
/*  83:104 */     lock.lock();
/*  84:    */     try
/*  85:    */     {
/*  86:106 */       super.addUnindexable(codeSourceIndex);
/*  87:    */       
/*  88:108 */       lock.unlock();
/*  89:    */     }
/*  90:    */     finally
/*  91:    */     {
/*  92:108 */       lock.unlock();
/*  93:    */     }
/*  94:    */   }
/*  95:    */   
/*  96:    */   public int[] getUnindexable()
/*  97:    */   {
/*  98:113 */     Lock lock = this.packageIndicesLock.readLock();
/*  99:114 */     lock.lock();
/* 100:    */     try
/* 101:    */     {
/* 102:116 */       return super.getUnindexable();
/* 103:    */     }
/* 104:    */     finally
/* 105:    */     {
/* 106:118 */       lock.unlock();
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   protected PackageIndices createPackageIndices()
/* 111:    */   {
/* 112:200 */     return new BackgroundCodeSourceIndex.ConcurrentPackageIndices(this);
/* 113:    */   }
/* 114:    */   
/* 115:    */   protected PackageIndices putIfAbsent(Map<String, PackageIndices> index, String packageName, PackageIndices indices)
/* 116:    */   {
/* 117:204 */     return (PackageIndices)((ConcurrentMap)index).putIfAbsent(packageName, indices);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public CodeSourceIterator iterator(String packageName)
/* 121:    */   {
/* 122:215 */     boolean f = this.firstCall;
/* 123:216 */     this.firstCall = false;
/* 124:    */     try
/* 125:    */     {
/* 126:219 */       return new BackgroundCodeSourceIndex.PackageIndexedIterator(this, packageName);
/* 127:    */     }
/* 128:    */     finally
/* 129:    */     {
/* 130:221 */       if (f) {
/* 131:222 */         doIndexing();
/* 132:    */       }
/* 133:    */     }
/* 134:    */   }
/* 135:    */   
/* 136:    */   public ConcurrentMap<String, PackageIndices> getMap()
/* 137:    */   {
/* 138:227 */     return (ConcurrentMap)super.getMap();
/* 139:    */   }
/* 140:    */   
/* 141:    */   public boolean canPersist()
/* 142:    */   {
/* 143:341 */     return true;
/* 144:    */   }
/* 145:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.index.BackgroundCodeSourceIndex
 * JD-Core Version:    0.7.0.1
 */