/*    1:     */ package com.oracle.classloader.model;
/*    2:     */ 
/*    3:     */ import java.io.IOException;
/*    4:     */ import java.io.InputStream;
/*    5:     */ import java.io.StringWriter;
/*    6:     */ import java.io.Writer;
/*    7:     */ import java.lang.reflect.Modifier;
/*    8:     */ import java.util.ArrayList;
/*    9:     */ import java.util.Collections;
/*   10:     */ import java.util.HashMap;
/*   11:     */ import java.util.HashSet;
/*   12:     */ import java.util.Iterator;
/*   13:     */ import java.util.List;
/*   14:     */ import java.util.Map;
/*   15:     */ import java.util.Set;
/*   16:     */ 
/*   17:     */ public class ClassFormatter
/*   18:     */ {
/*   19:     */   private boolean includeAccessMethods;
/*   20:     */   private int classAccess;
/*   21:     */   private String className;
/*   22:     */   private String superClassName;
/*   23:  37 */   private List<String> interfaceNames = new ArrayList();
/*   24:  38 */   private List<ClassFormatter.Field> fields = new ArrayList();
/*   25:  39 */   private List<ClassFormatter.Method> methods = new ArrayList();
/*   26:  40 */   private List<ClassFormatter.Annotation> classAnnotations = new ArrayList();
/*   27:     */   private ClassFormatter.Member currentMember;
/*   28:     */   private ClassFormatter.Annotation currentAnnotation;
/*   29:     */   private boolean isInterface;
/*   30:     */   private String unqualifiedClassName;
/*   31:     */   private String packageName;
/*   32:  52 */   private Map<String, String> unqualifiedNameToPackage = new HashMap();
/*   33:  53 */   private Set<String> imports = new HashSet();
/*   34:     */   private static final int ANNOTATION = 8192;
/*   35:     */   private static final int ENUM = 16384;
/*   36:     */   private static final int SYNTHETIC = 4096;
/*   37:     */   
/*   38:     */   public static String formatAsText(Class cls, boolean includeAccessMethods)
/*   39:     */     throws IOException
/*   40:     */   {
/*   41:  63 */     return initFormatter(getClassStream(cls), includeAccessMethods).toString();
/*   42:     */   }
/*   43:     */   
/*   44:     */   public static String formatAsText(InputStream classData, boolean includeAccessMethods)
/*   45:     */     throws IOException
/*   46:     */   {
/*   47:  74 */     return initFormatter(classData, includeAccessMethods).toString();
/*   48:     */   }
/*   49:     */   
/*   50:     */   public static String formatAsHTML(InputStream classData, boolean includeAccessMethods)
/*   51:     */     throws IOException
/*   52:     */   {
/*   53:  85 */     return initHTMLFormatter(classData, includeAccessMethods).toString();
/*   54:     */   }
/*   55:     */   
/*   56:     */   public static String formatAsHTML(Class cls, boolean includeAccessMethods)
/*   57:     */     throws IOException
/*   58:     */   {
/*   59:  96 */     return initHTMLFormatter(getClassStream(cls), includeAccessMethods).toString();
/*   60:     */   }
/*   61:     */   
/*   62:     */   public void write(Writer out)
/*   63:     */     throws IOException
/*   64:     */   {
/*   65: 105 */     writeClass(out);
/*   66:     */   }
/*   67:     */   
/*   68:     */   public String toString()
/*   69:     */   {
/*   70:     */     try
/*   71:     */     {
/*   72: 115 */       Writer w = new StringWriter();
/*   73: 116 */       writeClass(w);
/*   74:     */     }
/*   75:     */     catch (Exception e)
/*   76:     */     {
/*   77: 118 */       return e.toString();
/*   78:     */     }
/*   79:     */     Writer w;
/*   80: 120 */     return w.toString();
/*   81:     */   }
/*   82:     */   
/*   83:     */   public static InputStream getClassStream(Class c)
/*   84:     */   {
/*   85: 129 */     String path = c.getName().replace('.', '/') + ".class";
/*   86: 130 */     ClassLoader loader = c.getClassLoader();
/*   87: 131 */     if (loader == null) {
/*   88: 132 */       return ClassLoader.getSystemResourceAsStream(path);
/*   89:     */     }
/*   90: 134 */     return loader.getResourceAsStream(path);
/*   91:     */   }
/*   92:     */   
/*   93:     */   private static ClassFormatter initFormatter(InputStream classData, boolean includeAccess)
/*   94:     */     throws IOException
/*   95:     */   {
/*   96: 138 */     return new ClassFormatter(classData, includeAccess);
/*   97:     */   }
/*   98:     */   
/*   99:     */   private static ClassFormatter initHTMLFormatter(InputStream classData, boolean includeAccess)
/*  100:     */     throws IOException
/*  101:     */   {
/*  102: 142 */     return new ClassFormatter.HTMLClassFormatter(classData, includeAccess);
/*  103:     */   }
/*  104:     */   
/*  105:     */   protected ClassFormatter(InputStream classData, boolean includeAccessMethods)
/*  106:     */     throws IOException
/*  107:     */   {
/*  108: 146 */     this.includeAccessMethods = includeAccessMethods;
/*  109: 147 */     ClassReader.visit(classData, new ClassFormatter.Visitor(this, null));
/*  110:     */   }
/*  111:     */   
/*  112:     */   private void prepare()
/*  113:     */   {
/*  114: 151 */     this.includeAccessMethods = "true".equals(System.getProperty("include.access.methods"));
/*  115: 152 */     this.isInterface = Modifier.isInterface(this.classAccess);
/*  116: 153 */     this.unqualifiedClassName = getUnqualifiedClassName(this.className);
/*  117: 154 */     this.packageName = getPackageName(this.className);
/*  118: 155 */     computeImports();
/*  119:     */   }
/*  120:     */   
/*  121:     */   private void computeImports()
/*  122:     */   {
/*  123: 159 */     for (String unqualifiedName : this.unqualifiedNameToPackage.keySet())
/*  124:     */     {
/*  125: 160 */       String packageName = (String)this.unqualifiedNameToPackage.get(unqualifiedName);
/*  126: 161 */       if ((packageName != null) && 
/*  127: 162 */         (!packageName.equals(this.packageName)) && 
/*  128: 163 */         (!packageName.equals("java.lang"))) {
/*  129: 164 */         this.imports.add(packageName + "." + unqualifiedName);
/*  130:     */       }
/*  131:     */     }
/*  132:     */   }
/*  133:     */   
/*  134:     */   private String toClass(String name)
/*  135:     */   {
/*  136: 170 */     String result = name.replace('/', '.');
/*  137: 171 */     int len = result.length();
/*  138: 172 */     if ((result.charAt(0) == 'L') && (result.charAt(len - 1) == ';')) {
/*  139: 173 */       result = result.substring(1, len - 1);
/*  140:     */     }
/*  141: 175 */     return recordClass(result);
/*  142:     */   }
/*  143:     */   
/*  144:     */   private String recordClass(String className)
/*  145:     */   {
/*  146: 179 */     String pkgName = getPackageName(className);
/*  147: 180 */     String unqualifiedName = getUnqualifiedClassName(className);
/*  148: 181 */     if ((pkgName != null) && (!this.unqualifiedNameToPackage.containsKey(unqualifiedName))) {
/*  149: 182 */       this.unqualifiedNameToPackage.put(unqualifiedName, pkgName);
/*  150:     */     }
/*  151: 184 */     return className;
/*  152:     */   }
/*  153:     */   
/*  154:     */   private ClassFormatter.TypeName getReturnType(String descriptor)
/*  155:     */   {
/*  156: 272 */     int index = descriptor.lastIndexOf(')');
/*  157: 273 */     return new ClassFormatter.TypeName(this, descriptor.substring(index + 1));
/*  158:     */   }
/*  159:     */   
/*  160:     */   private List<ClassFormatter.TypeName> getParameterTypes(String descriptor)
/*  161:     */   {
/*  162: 277 */     List<ClassFormatter.TypeName> result = new ArrayList();
/*  163: 278 */     String args = descriptor.substring(1, descriptor.lastIndexOf(')'));
/*  164: 279 */     int start = 0;
/*  165: 280 */     while (start < args.length())
/*  166:     */     {
/*  167: 281 */       char c = args.charAt(start);
/*  168: 282 */       int end = start + 1;
/*  169: 283 */       while (c == '[') {
/*  170: 284 */         c = args.charAt(end++);
/*  171:     */       }
/*  172: 286 */       if (c == 'L') {
/*  173: 287 */         end = args.indexOf(';', start) + 1;
/*  174:     */       }
/*  175: 289 */       String argDescriptor = args.substring(start, end);
/*  176: 290 */       result.add(new ClassFormatter.TypeName(this, argDescriptor));
/*  177: 291 */       start = end;
/*  178:     */     }
/*  179: 293 */     return result;
/*  180:     */   }
/*  181:     */   
/*  182:     */   private static String getPackageName(String fullName)
/*  183:     */   {
/*  184: 297 */     String result = null;
/*  185: 298 */     int last = fullName.lastIndexOf('.');
/*  186: 299 */     if (last > 0) {
/*  187: 300 */       result = fullName.substring(0, last);
/*  188:     */     }
/*  189: 302 */     return result;
/*  190:     */   }
/*  191:     */   
/*  192:     */   private static String getUnqualifiedClassName(String fullName)
/*  193:     */   {
/*  194: 306 */     String result = fullName;
/*  195: 307 */     int last = fullName.lastIndexOf('.');
/*  196: 308 */     if (last > 0) {
/*  197: 309 */       result = fullName.substring(last + 1);
/*  198:     */     }
/*  199: 311 */     return result;
/*  200:     */   }
/*  201:     */   
/*  202:     */   public static boolean isAnnotation(int mod)
/*  203:     */   {
/*  204: 326 */     return (mod & 0x2000) != 0;
/*  205:     */   }
/*  206:     */   
/*  207:     */   public static boolean isSynthetic(int mod)
/*  208:     */   {
/*  209: 337 */     return (mod & 0x1000) != 0;
/*  210:     */   }
/*  211:     */   
/*  212:     */   public static boolean isEnum(int mod)
/*  213:     */   {
/*  214: 348 */     return (mod & 0x4000) != 0;
/*  215:     */   }
/*  216:     */   
/*  217:     */   private String classModifiersToString(int access)
/*  218:     */   {
/*  219: 352 */     StringBuffer buf = new StringBuffer();
/*  220: 353 */     if (Modifier.isPublic(access)) {
/*  221: 354 */       append("public", buf);
/*  222:     */     }
/*  223: 356 */     if (Modifier.isFinal(access)) {
/*  224: 357 */       append("final", buf);
/*  225:     */     }
/*  226: 360 */     if (isAnnotation(access))
/*  227:     */     {
/*  228: 361 */       append("@interface", buf);
/*  229:     */     }
/*  230: 362 */     else if (Modifier.isInterface(access))
/*  231:     */     {
/*  232: 363 */       append("interface", buf);
/*  233:     */     }
/*  234: 364 */     else if (isEnum(access))
/*  235:     */     {
/*  236: 365 */       append("enum", buf);
/*  237:     */     }
/*  238:     */     else
/*  239:     */     {
/*  240: 367 */       if (Modifier.isAbstract(access)) {
/*  241: 368 */         append("abstract", buf);
/*  242:     */       }
/*  243: 370 */       append("class", buf);
/*  244:     */     }
/*  245: 372 */     return buf.toString();
/*  246:     */   }
/*  247:     */   
/*  248:     */   private String memberModifiersToString(int access, boolean field)
/*  249:     */   {
/*  250: 376 */     StringBuffer buf = new StringBuffer();
/*  251: 377 */     if (Modifier.isPublic(access)) {
/*  252: 378 */       append("public", buf);
/*  253: 379 */     } else if (Modifier.isProtected(access)) {
/*  254: 380 */       append("protected", buf);
/*  255: 381 */     } else if (Modifier.isPrivate(access)) {
/*  256: 382 */       append("private", buf);
/*  257:     */     }
/*  258: 385 */     if (Modifier.isStatic(access)) {
/*  259: 386 */       append("static", buf);
/*  260:     */     }
/*  261: 389 */     if ((!field) && (Modifier.isAbstract(access))) {
/*  262: 390 */       append("abstract", buf);
/*  263:     */     }
/*  264: 393 */     if (Modifier.isFinal(access)) {
/*  265: 394 */       append("final", buf);
/*  266:     */     }
/*  267: 397 */     if (field)
/*  268:     */     {
/*  269: 398 */       if (Modifier.isTransient(access)) {
/*  270: 399 */         append("transient", buf);
/*  271:     */       }
/*  272: 402 */       if (Modifier.isVolatile(access)) {
/*  273: 403 */         append("volatile", buf);
/*  274:     */       }
/*  275: 406 */       if (Modifier.isStrict(access)) {
/*  276: 407 */         append("strictfp", buf);
/*  277:     */       }
/*  278: 410 */       if (Modifier.isVolatile(access)) {
/*  279: 411 */         append("volatile", buf);
/*  280:     */       }
/*  281:     */     }
/*  282:     */     else
/*  283:     */     {
/*  284: 414 */       if (Modifier.isSynchronized(access)) {
/*  285: 415 */         append("synchronized", buf);
/*  286:     */       }
/*  287: 418 */       if (Modifier.isNative(access)) {
/*  288: 419 */         append("native", buf);
/*  289:     */       }
/*  290:     */     }
/*  291: 422 */     return buf.toString();
/*  292:     */   }
/*  293:     */   
/*  294:     */   private void writeClass(Writer out)
/*  295:     */     throws IOException
/*  296:     */   {
/*  297: 906 */     if (this.packageName != null)
/*  298:     */     {
/*  299: 907 */       writeKeyword("package", out);
/*  300: 908 */       out.write(32);
/*  301: 909 */       out.write(this.packageName);
/*  302: 910 */       out.write(59);
/*  303: 911 */       writeEOL(out);
/*  304: 912 */       writeEOL(out);
/*  305:     */     }
/*  306: 917 */     List<String> theImports = new ArrayList(this.imports);
/*  307: 918 */     Collections.sort(theImports);
/*  308: 919 */     for (Iterator localIterator = theImports.iterator(); localIterator.hasNext();)
/*  309:     */     {
/*  310: 919 */       theImport = (String)localIterator.next();
/*  311: 920 */       writeKeyword("import", out);
/*  312: 921 */       out.write(32);
/*  313: 922 */       writeClassName(null, theImport, out);
/*  314: 923 */       out.write(59);
/*  315: 924 */       writeEOL(out);
/*  316:     */     }
/*  317:     */     String theImport;
/*  318: 926 */     if (!this.imports.isEmpty()) {
/*  319: 927 */       writeEOL(out);
/*  320:     */     }
/*  321: 932 */     writeAnnotations(this.classAnnotations, false, out);
/*  322:     */     
/*  323:     */ 
/*  324:     */ 
/*  325: 936 */     writeKeyword(classModifiersToString(this.classAccess), out);
/*  326: 937 */     out.write(32);
/*  327: 938 */     writeClassName(this.unqualifiedClassName, null, out);
/*  328: 940 */     if ((this.superClassName != null) && (!this.superClassName.equals("java.lang.Object")))
/*  329:     */     {
/*  330: 941 */       out.write(32);
/*  331: 942 */       writeKeyword("extends", out);
/*  332: 943 */       out.write(32);
/*  333: 944 */       writeClassName(this.superClassName, out);
/*  334:     */     }
/*  335: 947 */     if (!this.interfaceNames.isEmpty())
/*  336:     */     {
/*  337: 948 */       out.write(32);
/*  338: 949 */       writeKeyword("implements", out);
/*  339: 950 */       out.write(32);
/*  340: 951 */       for (int i = 0; i < this.interfaceNames.size(); i++)
/*  341:     */       {
/*  342: 952 */         if (i > 0) {
/*  343: 952 */           out.write(", ");
/*  344:     */         }
/*  345: 953 */         writeClassName((String)this.interfaceNames.get(i), out);
/*  346:     */       }
/*  347:     */     }
/*  348: 957 */     out.write(" {");
/*  349: 958 */     writeEOL(out);
/*  350:     */     
/*  351:     */ 
/*  352:     */ 
/*  353: 962 */     boolean hasFields = false;
/*  354: 963 */     for (ClassFormatter.Field field : this.fields)
/*  355:     */     {
/*  356: 964 */       field.write(out);
/*  357: 965 */       writeEOL(out);
/*  358: 966 */       hasFields = true;
/*  359:     */     }
/*  360: 968 */     if (hasFields) {
/*  361: 969 */       writeEOL(out);
/*  362:     */     }
/*  363: 974 */     for (ClassFormatter.Method method : this.methods) {
/*  364: 975 */       if (method.include())
/*  365:     */       {
/*  366: 976 */         method.write(out);
/*  367: 977 */         writeEOL(out);
/*  368:     */       }
/*  369:     */     }
/*  370: 981 */     out.write(125);
/*  371: 982 */     writeEOL(out);
/*  372:     */   }
/*  373:     */   
/*  374:     */   private void writeAnnotations(List<ClassFormatter.Annotation> annotations, boolean indent, Writer out)
/*  375:     */     throws IOException
/*  376:     */   {
/*  377: 986 */     for (ClassFormatter.Annotation a : annotations) {
/*  378: 987 */       writeAnnotation(a, indent, out);
/*  379:     */     }
/*  380:     */   }
/*  381:     */   
/*  382:     */   protected void writeAnnotation(ClassFormatter.Annotation annotation, boolean indent, Writer out)
/*  383:     */     throws IOException
/*  384:     */   {
/*  385: 992 */     if (indent) {
/*  386: 992 */       writeIndent(out);
/*  387:     */     }
/*  388: 993 */     annotation.write(out);
/*  389: 994 */     writeEOL(out);
/*  390:     */   }
/*  391:     */   
/*  392:     */   protected void writeKeyword(String keyWord, Writer out)
/*  393:     */     throws IOException
/*  394:     */   {
/*  395: 998 */     out.write(keyWord);
/*  396:     */   }
/*  397:     */   
/*  398:     */   protected void writeFieldName(String fieldName, Writer out)
/*  399:     */     throws IOException
/*  400:     */   {
/*  401:1002 */     out.write(fieldName);
/*  402:     */   }
/*  403:     */   
/*  404:     */   protected void writeIndent(Writer out)
/*  405:     */     throws IOException
/*  406:     */   {
/*  407:1006 */     out.write("    ");
/*  408:     */   }
/*  409:     */   
/*  410:     */   protected void writeEOL(Writer out)
/*  411:     */     throws IOException
/*  412:     */   {
/*  413:1010 */     out.write("\n");
/*  414:     */   }
/*  415:     */   
/*  416:     */   protected void writeClassName(String unqualifiedName, String fullyQualifiedName, Writer out)
/*  417:     */     throws IOException
/*  418:     */   {
/*  419:1014 */     if (unqualifiedName == null) {
/*  420:1015 */       out.write(fullyQualifiedName);
/*  421:     */     } else {
/*  422:1017 */       out.write(unqualifiedName);
/*  423:     */     }
/*  424:     */   }
/*  425:     */   
/*  426:     */   private void writeClassName(String className, Writer out)
/*  427:     */     throws IOException
/*  428:     */   {
/*  429:1052 */     String unqualifiedName = getUnqualifiedClassName(className);
/*  430:1053 */     if (this.imports.contains(className))
/*  431:     */     {
/*  432:1054 */       writeClassName(unqualifiedName, className, out);
/*  433:     */     }
/*  434:     */     else
/*  435:     */     {
/*  436:1056 */       String packageName = getPackageName(className);
/*  437:1060 */       if ((unqualifiedName != null) && (packageName != null)) {
/*  438:1062 */         if ((packageName.equals(this.packageName)) || (packageName.equals("java.lang")))
/*  439:     */         {
/*  440:1066 */           writeClassName(unqualifiedName, className, out); return;
/*  441:     */         }
/*  442:     */       }
/*  443:1072 */       writeClassName(null, className, out);
/*  444:     */     }
/*  445:     */   }
/*  446:     */   
/*  447:     */   private static void append(String str, StringBuffer buf)
/*  448:     */   {
/*  449:1078 */     if (buf.length() > 0) {
/*  450:1079 */       buf.append(' ');
/*  451:     */     }
/*  452:1081 */     buf.append(str);
/*  453:     */   }
/*  454:     */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.model.ClassFormatter
 * JD-Core Version:    0.7.0.1
 */