/*  1:   */ package com.oracle.classloader.model;
/*  2:   */ 
/*  3:   */ import com.oracle.classloader.log.Logger;
/*  4:   */ import java.lang.reflect.Field;
/*  5:   */ import java.util.Collections;
/*  6:   */ import java.util.Map;
/*  7:   */ 
/*  8:   */ public abstract class DefinedPackages
/*  9:   */ {
/* 10:   */   private static DefinedPackages accessor;
/* 11:   */   
/* 12:   */   public static Map<String, Package> getFrom(ClassLoader loader)
/* 13:   */   {
/* 14:31 */     if (accessor == null) {
/* 15:32 */       accessor = getAccessor();
/* 16:   */     }
/* 17:   */     try
/* 18:   */     {
/* 19:35 */       synchronized (loader)
/* 20:   */       {
/* 21:36 */         return accessor.doGet(loader);
/* 22:   */       }
/* 23:39 */       return Collections.emptyMap();
/* 24:   */     }
/* 25:   */     catch (Throwable e) {}
/* 26:   */   }
/* 27:   */   
/* 28:   */   protected abstract Map<String, Package> doGet(ClassLoader paramClassLoader)
/* 29:   */     throws Exception;
/* 30:   */   
/* 31:   */   private static DefinedPackages getAccessor()
/* 32:   */   {
/* 33:46 */     DefinedPackages result = null;
/* 34:   */     try
/* 35:   */     {
/* 36:48 */       Field packages = ClassLoader.class.getDeclaredField("packages");
/* 37:49 */       packages.setAccessible(true);
/* 38:50 */       if (Map.class.isAssignableFrom(packages.getType())) {
/* 39:51 */         result = new DefinedPackages.MapAccessor(packages);
/* 40:   */       }
/* 41:   */     }
/* 42:   */     catch (Throwable t)
/* 43:   */     {
/* 44:54 */       Logger.logWarning("Cannot access defined packages.", t);
/* 45:   */     }
/* 46:56 */     if (result == null) {
/* 47:57 */       result = new DefinedPackages.Empty(null);
/* 48:   */     }
/* 49:59 */     return result;
/* 50:   */   }
/* 51:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.model.DefinedPackages
 * JD-Core Version:    0.7.0.1
 */