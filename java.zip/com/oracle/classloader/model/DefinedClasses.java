/*  1:   */ package com.oracle.classloader.model;
/*  2:   */ 
/*  3:   */ import com.oracle.classloader.log.Logger;
/*  4:   */ import java.lang.reflect.Field;
/*  5:   */ import java.net.URL;
/*  6:   */ import java.security.CodeSource;
/*  7:   */ import java.security.ProtectionDomain;
/*  8:   */ import java.util.Collections;
/*  9:   */ import java.util.List;
/* 10:   */ 
/* 11:   */ public abstract class DefinedClasses
/* 12:   */ {
/* 13:   */   private static DefinedClasses accessor;
/* 14:   */   
/* 15:   */   public static List<Class> getClassesDefinedBy(ClassLoader loader)
/* 16:   */   {
/* 17:   */     try
/* 18:   */     {
/* 19:32 */       return getAccessor().doGet(loader);
/* 20:   */     }
/* 21:   */     catch (Throwable e) {}
/* 22:34 */     return Collections.emptyList();
/* 23:   */   }
/* 24:   */   
/* 25:   */   private static synchronized DefinedClasses getAccessor()
/* 26:   */   {
/* 27:39 */     if (accessor == null)
/* 28:   */     {
/* 29:   */       try
/* 30:   */       {
/* 31:41 */         Field classes = ClassLoader.class.getDeclaredField("classes");
/* 32:42 */         classes.setAccessible(true);
/* 33:46 */         if (List.class.isAssignableFrom(classes.getType()))
/* 34:   */         {
/* 35:47 */           accessor = new DefinedClasses.ListAccessor(classes);
/* 36:   */         }
/* 37:48 */         else if (classes.getType() == Class.class)
/* 38:   */         {
/* 39:52 */           Field next = Class.class.getDeclaredField("nextClass");
/* 40:53 */           next.setAccessible(true);
/* 41:54 */           accessor = new DefinedClasses.LinkedClass(classes, next);
/* 42:   */         }
/* 43:   */       }
/* 44:   */       catch (Throwable t)
/* 45:   */       {
/* 46:57 */         StringBuilder b = new StringBuilder();
/* 47:58 */         String jarPath = DefinedClasses.class.getProtectionDomain().getCodeSource().getLocation().getPath();
/* 48:59 */         b.append("Cannot access defined classes, please use '-javaagent:");
/* 49:60 */         b.append(jarPath);
/* 50:61 */         b.append("'.");
/* 51:62 */         Logger.logWarning(b.toString(), t);
/* 52:   */       }
/* 53:64 */       if (accessor == null) {
/* 54:65 */         accessor = new DefinedClasses.Empty(null);
/* 55:   */       }
/* 56:   */     }
/* 57:68 */     return accessor;
/* 58:   */   }
/* 59:   */   
/* 60:   */   protected abstract List<Class> doGet(ClassLoader paramClassLoader)
/* 61:   */     throws Exception;
/* 62:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.model.DefinedClasses
 * JD-Core Version:    0.7.0.1
 */