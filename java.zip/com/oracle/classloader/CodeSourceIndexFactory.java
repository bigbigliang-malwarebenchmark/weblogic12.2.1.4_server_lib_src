package com.oracle.classloader;

public abstract interface CodeSourceIndexFactory
{
  public abstract CodeSourceIndex create(CodeSourceList paramCodeSourceList);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.CodeSourceIndexFactory
 * JD-Core Version:    0.7.0.1
 */