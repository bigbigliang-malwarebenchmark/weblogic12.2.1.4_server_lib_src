/*  1:   */ package com.oracle.classloader;
/*  2:   */ 
/*  3:   */ import com.oracle.classloader.log.Logger;
/*  4:   */ import com.oracle.classloader.util.URLEncoder;
/*  5:   */ import java.io.File;
/*  6:   */ import java.net.URI;
/*  7:   */ import java.net.URL;
/*  8:   */ 
/*  9:   */ public class CodeSourceFactory
/* 10:   */ {
/* 11:   */   public CodeSource create(URI location)
/* 12:   */   {
/* 13:29 */     return create(location, null);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public CodeSource create(URI location, File file)
/* 17:   */   {
/* 18:   */     try
/* 19:   */     {
/* 20:41 */       return create(location.toURL().getProtocol(), location, file);
/* 21:   */     }
/* 22:   */     catch (ThreadDeath death)
/* 23:   */     {
/* 24:43 */       throw death;
/* 25:   */     }
/* 26:   */     catch (Throwable t)
/* 27:   */     {
/* 28:45 */       Logger.logWarning(t.getMessage());
/* 29:   */     }
/* 30:47 */     return null;
/* 31:   */   }
/* 32:   */   
/* 33:   */   protected CodeSource create(String protocol, URI location, File file)
/* 34:   */     throws Exception
/* 35:   */   {
/* 36:59 */     CodeSource result = null;
/* 37:60 */     if (file != null)
/* 38:   */     {
/* 39:61 */       if (file.isFile()) {
/* 40:62 */         result = new JarCodeSource(location, file);
/* 41:63 */       } else if (file.isDirectory()) {
/* 42:64 */         result = new DirectoryCodeSource(location, file);
/* 43:   */       }
/* 44:   */     }
/* 45:66 */     else if ((protocol.equals("file")) || (protocol.equals("jar"))) {
/* 46:67 */       return create(protocol, location, URLEncoder.toFile(location.toURL()));
/* 47:   */     }
/* 48:69 */     return result;
/* 49:   */   }
/* 50:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.CodeSourceFactory
 * JD-Core Version:    0.7.0.1
 */