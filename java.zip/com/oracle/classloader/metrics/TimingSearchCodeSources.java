/*  1:   */ package com.oracle.classloader.metrics;
/*  2:   */ 
/*  3:   */ import com.oracle.classloader.CodeSourceBuffer;
/*  4:   */ import com.oracle.classloader.CodeSourceList;
/*  5:   */ import com.oracle.classloader.PolicyClassLoader;
/*  6:   */ import com.oracle.classloader.log.Logger;
/*  7:   */ import com.oracle.classloader.search.SearchCodeSources;
/*  8:   */ 
/*  9:   */ public class TimingSearchCodeSources
/* 10:   */   extends SearchCodeSources
/* 11:   */ {
/* 12:   */   private String classNameLimit;
/* 13:   */   private int classCountLimit;
/* 14:   */   private int classCount;
/* 15:   */   private boolean reachedLimit;
/* 16:   */   
/* 17:   */   public TimingSearchCodeSources(CodeSourceList list, String launchCompletion)
/* 18:   */   {
/* 19:32 */     super(list);
/* 20:33 */     if ((launchCompletion == null) || (launchCompletion.length() == 0))
/* 21:   */     {
/* 22:34 */       this.classCountLimit = 2147483647;
/* 23:35 */       this.classNameLimit = "";
/* 24:   */     }
/* 25:36 */     else if (Character.isDigit(launchCompletion.charAt(0)))
/* 26:   */     {
/* 27:37 */       this.classCountLimit = Integer.parseInt(launchCompletion);
/* 28:38 */       this.classNameLimit = "";
/* 29:   */     }
/* 30:   */     else
/* 31:   */     {
/* 32:40 */       this.classCountLimit = 2147483647;
/* 33:41 */       this.classNameLimit = launchCompletion;
/* 34:   */     }
/* 35:   */   }
/* 36:   */   
/* 37:   */   protected Class<?> defineClass(String className, CodeSourceBuffer classData, int codeSourceIndex)
/* 38:   */   {
/* 39:53 */     if (((!this.reachedLimit) && (this.classCount++ >= this.classCountLimit)) || (className.equals(this.classNameLimit)))
/* 40:   */     {
/* 41:54 */       long elapsedTime = System.currentTimeMillis() - getDelegatingLoader().getCreationTime();
/* 42:55 */       Logger.logInfo("Reached limit '" + className + "' in " + elapsedTime + "ms.");
/* 43:56 */       this.reachedLimit = true;
/* 44:   */     }
/* 45:58 */     return super.defineClass(className, classData, codeSourceIndex);
/* 46:   */   }
/* 47:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.metrics.TimingSearchCodeSources
 * JD-Core Version:    0.7.0.1
 */