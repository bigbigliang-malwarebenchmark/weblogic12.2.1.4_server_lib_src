/*   1:    */ package com.oracle.classloader;
/*   2:    */ 
/*   3:    */ import com.oracle.classloader.log.Logger;
/*   4:    */ import com.oracle.classloader.util.DigestBuilder;
/*   5:    */ import com.oracle.classloader.util.DirectoryMetaData;
/*   6:    */ import com.oracle.classloader.util.URLEncoder;
/*   7:    */ import com.oracle.util.Matcher;
/*   8:    */ import java.io.File;
/*   9:    */ import java.io.FileInputStream;
/*  10:    */ import java.io.FilenameFilter;
/*  11:    */ import java.io.IOException;
/*  12:    */ import java.io.InputStream;
/*  13:    */ import java.net.MalformedURLException;
/*  14:    */ import java.net.URI;
/*  15:    */ import java.net.URL;
/*  16:    */ import java.security.CodeSigner;
/*  17:    */ import java.util.ArrayList;
/*  18:    */ import java.util.Collection;
/*  19:    */ import java.util.List;
/*  20:    */ import java.util.Set;
/*  21:    */ import java.util.jar.Manifest;
/*  22:    */ 
/*  23:    */ public class DirectoryCodeSource
/*  24:    */   extends CodeSource
/*  25:    */   implements FileSource
/*  26:    */ {
/*  27:    */   private static final String MANIFEST_PATH = "META-INF/MANIFEST.MF";
/*  28:    */   private static final int MAX_SCAN = 1024;
/*  29:    */   private static final String MAX_DEPTH_PROPERTY = "com.oracle.classloader.directory.max_depth";
/*  30:    */   private static final String MAX_ITEMS_PROPERTY = "com.oracle.classloader.directory.max_items";
/*  31: 42 */   private static final Long MAX_DEPTH = Long.valueOf(System.getProperty("com.oracle.classloader.directory.max_depth", "500"));
/*  32: 43 */   private static final Long MAX_ITEMS = Long.valueOf(System.getProperty("com.oracle.classloader.directory.max_items", "500000"));
/*  33:    */   private File directory;
/*  34:    */   private Manifest manifest;
/*  35:    */   private DirectoryMetaData metaData;
/*  36:    */   
/*  37:    */   protected DirectoryCodeSource(URI uri, File directory)
/*  38:    */     throws IOException
/*  39:    */   {
/*  40: 60 */     super(uri);
/*  41: 61 */     this.directory = directory.getCanonicalFile();
/*  42: 62 */     this.manifest = loadManifest(directory);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public long getLastModifiedTime()
/*  46:    */   {
/*  47: 73 */     return getMetaData().getMaxLastModified();
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void updateSignature(DigestBuilder digest)
/*  51:    */   {
/*  52: 86 */     super.updateSignature(digest);
/*  53: 87 */     DirectoryMetaData meta = getMetaData();
/*  54: 88 */     digest.update(meta.getMemberCount());
/*  55: 89 */     digest.update(meta.getTotalFileLength());
/*  56: 90 */     digest.update(meta.getMaxDepth());
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Manifest getManifest()
/*  60:    */   {
/*  61: 99 */     return this.manifest;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public URL getResource(String relativePath)
/*  65:    */   {
/*  66:111 */     if (getFile(relativePath) != null) {
/*  67:    */       try
/*  68:    */       {
/*  69:113 */         String basePath = getLocation().getPath();
/*  70:114 */         String encodedRelativePath = URLEncoder.encodePath(relativePath);
/*  71:115 */         return new URL("file", "", basePath + encodedRelativePath);
/*  72:    */       }
/*  73:    */       catch (MalformedURLException e)
/*  74:    */       {
/*  75:117 */         throw new Error(e);
/*  76:    */       }
/*  77:    */     }
/*  78:120 */     return null;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public boolean getResourceData(String relativePath, CodeSourceBuffer buffer)
/*  82:    */   {
/*  83:    */     try
/*  84:    */     {
/*  85:137 */       File file = getFile(relativePath);
/*  86:138 */       if (file != null)
/*  87:    */       {
/*  88:139 */         InputStream stream = new FileInputStream(file);
/*  89:140 */         int size = stream.available();
/*  90:141 */         buffer.read(stream, size);
/*  91:142 */         buffer.setCodeSource(this);
/*  92:143 */         return true;
/*  93:    */       }
/*  94:    */     }
/*  95:    */     catch (IOException e)
/*  96:    */     {
/*  97:146 */       Logger.logWarning(e.getMessage());
/*  98:    */     }
/*  99:148 */     return false;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public File getFile()
/* 103:    */   {
/* 104:157 */     return this.directory;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public File getFile(String relativePath)
/* 108:    */   {
/* 109:161 */     File result = null;
/* 110:162 */     if ((relativePath != null) && (relativePath.length() > 0))
/* 111:    */     {
/* 112:163 */       File file = new File(this.directory, relativePath);
/* 113:164 */       if (file.exists()) {
/* 114:165 */         if (relativePath.contains("..")) {
/* 115:    */           try
/* 116:    */           {
/* 117:168 */             String expanded = file.getCanonicalPath();
/* 118:169 */             if (expanded.startsWith(this.directory.getPath())) {
/* 119:170 */               result = file;
/* 120:    */             }
/* 121:    */           }
/* 122:    */           catch (IOException localIOException) {}
/* 123:    */         } else {
/* 124:176 */           result = file;
/* 125:    */         }
/* 126:    */       }
/* 127:    */     }
/* 128:180 */     return result;
/* 129:    */   }
/* 130:    */   
/* 131:    */   protected void addPackageNames(Set<String> packages)
/* 132:    */     throws TooManyPackagesException
/* 133:    */   {
/* 134:192 */     boolean detectSymlinks = Boolean.parseBoolean(System.getProperty("com.oracle.classloader.detectSymlinks", "false"));
/* 135:193 */     FilenameFilter filenameFilter = detectSymlinks ? new SymLinkDetectorFilenameFilter(null) : null;
/* 136:    */     
/* 137:195 */     String[] files = this.directory.list();
/* 138:196 */     if (files != null) {
/* 139:    */       try
/* 140:    */       {
/* 141:199 */         if (files.length == 0)
/* 142:    */         {
/* 143:200 */           addNames(this.directory, filenameFilter, "", "", packages, null, true);
/* 144:201 */           return;
/* 145:    */         }
/* 146:203 */         for (String file : files) {
/* 147:204 */           addNames(this.directory, filenameFilter, "", file, packages, null, true);
/* 148:    */         }
/* 149:    */       }
/* 150:    */       catch (OutOfMemoryError o)
/* 151:    */       {
/* 152:207 */         packages.clear();
/* 153:208 */         throw new TooManyPackagesException();
/* 154:    */       }
/* 155:    */     }
/* 156:    */   }
/* 157:    */   
/* 158:    */   public Collection<String> getResources()
/* 159:    */   {
/* 160:214 */     List<String> result = new ArrayList(128);
/* 161:215 */     addPaths(result);
/* 162:216 */     return result;
/* 163:    */   }
/* 164:    */   
/* 165:    */   protected boolean addPaths(List<String> list)
/* 166:    */   {
/* 167:220 */     File directory = getFile();
/* 168:221 */     String[] files = directory.list();
/* 169:222 */     if (files != null) {
/* 170:223 */       for (String file : files) {
/* 171:224 */         appendPaths(directory, "", file, list);
/* 172:    */       }
/* 173:    */     }
/* 174:227 */     return false;
/* 175:    */   }
/* 176:    */   
/* 177:    */   private void appendPaths(File rootDir, String rootPath, String fileName, List<String> list)
/* 178:    */   {
/* 179:231 */     String relativePath = rootPath + fileName;
/* 180:232 */     File absoluteFile = new File(rootDir, fileName);
/* 181:233 */     if (absoluteFile.isDirectory())
/* 182:    */     {
/* 183:234 */       if (!relativePath.endsWith("/")) {
/* 184:235 */         relativePath = relativePath + '/';
/* 185:    */       }
/* 186:237 */       list.add(relativePath);
/* 187:238 */       String[] files = absoluteFile.list();
/* 188:239 */       if (files != null) {
/* 189:241 */         for (String file : files) {
/* 190:242 */           appendPaths(absoluteFile, relativePath, file, list);
/* 191:    */         }
/* 192:    */       }
/* 193:    */     }
/* 194:    */     else
/* 195:    */     {
/* 196:247 */       list.add(relativePath);
/* 197:    */     }
/* 198:    */   }
/* 199:    */   
/* 200:    */   protected CodeSigner[] getCodeSigners()
/* 201:    */   {
/* 202:257 */     return null;
/* 203:    */   }
/* 204:    */   
/* 205:    */   private void addNames(File rootDir, FilenameFilter filenameFilter, String relativeDirPath, String fileName, Set<String> names, Matcher<String> matcher, boolean pkg)
/* 206:    */     throws TooManyPackagesException
/* 207:    */   {
/* 208:262 */     addNames(rootDir, filenameFilter, relativeDirPath, fileName, names, matcher, pkg, 0L);
/* 209:    */   }
/* 210:    */   
/* 211:    */   private void addNames(File rootDir, FilenameFilter filenameFilter, String relativeDirPath, String fileName, Set<String> names, Matcher<String> matcher, boolean pkg, long depth)
/* 212:    */     throws TooManyPackagesException
/* 213:    */   {
/* 214:267 */     if (depth++ > MAX_DEPTH.longValue())
/* 215:    */     {
/* 216:268 */       String warning = "Directory scanning exceeded maximum depth: " + MAX_DEPTH + ". Configure with system property " + "com.oracle.classloader.directory.max_depth";
/* 217:    */       
/* 218:270 */       Logger.logWarning(warning);
/* 219:271 */       throw new TooManyPackagesException(warning);
/* 220:    */     }
/* 221:274 */     String relativePath = relativeDirPath + '/' + fileName;
/* 222:275 */     File absoluteFile = new File(rootDir, relativePath);
/* 223:276 */     if (absoluteFile.isDirectory())
/* 224:    */     {
/* 225:277 */       if ((filenameFilter == null) || (filenameFilter.accept(absoluteFile, null)))
/* 226:    */       {
/* 227:278 */         File[] files = absoluteFile.listFiles();
/* 228:279 */         if ((files != null) && (files.length > 0))
/* 229:    */         {
/* 230:282 */           boolean addedFile = false;
/* 231:283 */           for (File file : files) {
/* 232:284 */             if ((file.isFile()) && (!addedFile))
/* 233:    */             {
/* 234:285 */               addNames(rootDir, filenameFilter, relativePath, file.getName(), names, matcher, pkg, depth);
/* 235:286 */               addedFile = true;
/* 236:    */             }
/* 237:    */             else
/* 238:    */             {
/* 239:288 */               addNames(rootDir, filenameFilter, relativePath, file.getName(), names, matcher, pkg, depth);
/* 240:    */             }
/* 241:    */           }
/* 242:    */         }
/* 243:292 */         names.add(relativePath.replace('/', '.'));
/* 244:    */       }
/* 245:    */     }
/* 246:295 */     else if (pkg) {
/* 247:296 */       names.add(relativeDirPath.replace('/', '.'));
/* 248:297 */     } else if ((matcher == null) || (matcher.matches(relativePath))) {
/* 249:298 */       names.add(relativePath);
/* 250:    */     }
/* 251:302 */     if (names.size() > MAX_ITEMS.longValue())
/* 252:    */     {
/* 253:303 */       String warning = "Directory scanning exceeded maximum items: " + MAX_ITEMS + ". Configure with system property " + "com.oracle.classloader.directory.max_items";
/* 254:    */       
/* 255:305 */       Logger.logWarning(warning);
/* 256:306 */       throw new TooManyPackagesException(warning);
/* 257:    */     }
/* 258:    */   }
/* 259:    */   
/* 260:    */   private static Manifest loadManifest(File root)
/* 261:    */   {
/* 262:311 */     Manifest result = null;
/* 263:    */     try
/* 264:    */     {
/* 265:313 */       File manifestFile = new File(root, "META-INF/MANIFEST.MF");
/* 266:314 */       if (manifestFile.exists())
/* 267:    */       {
/* 268:315 */         InputStream in = new FileInputStream(manifestFile);
/* 269:316 */         result = new Manifest(in);
/* 270:317 */         in.close();
/* 271:    */       }
/* 272:    */     }
/* 273:    */     catch (Exception e)
/* 274:    */     {
/* 275:320 */       throw new Error(e);
/* 276:    */     }
/* 277:322 */     return result;
/* 278:    */   }
/* 279:    */   
/* 280:    */   private DirectoryMetaData getMetaData()
/* 281:    */   {
/* 282:326 */     if (this.metaData == null) {
/* 283:327 */       this.metaData = new DirectoryMetaData(this.directory, 1024);
/* 284:    */     }
/* 285:329 */     return this.metaData;
/* 286:    */   }
/* 287:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.classloader.DirectoryCodeSource
 * JD-Core Version:    0.7.0.1
 */