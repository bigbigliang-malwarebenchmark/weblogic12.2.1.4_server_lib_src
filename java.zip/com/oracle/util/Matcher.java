package com.oracle.util;

public abstract interface Matcher<T>
{
  public abstract boolean matches(T paramT);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.oracle.util.Matcher
 * JD-Core Version:    0.7.0.1
 */