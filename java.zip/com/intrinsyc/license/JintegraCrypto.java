package com.intrinsyc.license;

import com.intrinsyc.license.Acme.Crypto.a;
import com.intrinsyc.license.Acme.Crypto.d;

class JintegraCrypto
{
  protected d a = null;
  
  protected JintegraCrypto(String paramString)
  {
    this.a = new d(paramString);
  }
  
  protected String a(String paramString)
  {
    boolean bool = LicenseException.a;
    int i = paramString.length();
    int j = i % 8;
    if (!bool) {
      if (j > 0) {
        i += 8 - j;
      }
    }
    int k = i / 8;
    byte[] arrayOfByte1 = new byte[i];
    a.a(arrayOfByte1);
    byte[] arrayOfByte2 = new byte[i];
    a.a(arrayOfByte2);
    a.a(paramString.getBytes(), arrayOfByte2);
    int m = 0;
    if (bool) {}
    while (m < k)
    {
      this.a.a(arrayOfByte2, m * 8, arrayOfByte1, m * 8);
      m++;
    }
    return a.c(arrayOfByte1);
  }
  
  protected String b(String paramString)
  {
    String str = c(paramString);
    byte[] arrayOfByte1 = a.a(str);
    int i = arrayOfByte1.length;
    int j = i / 8;
    byte[] arrayOfByte2 = new byte[i];
    a.a(arrayOfByte2);
    int k = 0;
    if (LicenseException.a) {}
    while (k < j)
    {
      this.a.b(arrayOfByte1, k * 8, arrayOfByte2, k * 8);
      k++;
    }
    return a.e(arrayOfByte2);
  }
  
  private String c(String paramString)
  {
    return paramString.substring(1, paramString.length() - 1);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.JintegraCrypto
 * JD-Core Version:    0.7.0.1
 */