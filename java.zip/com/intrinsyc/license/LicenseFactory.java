package com.intrinsyc.license;

import com.linar.spi.License;
import java.util.Hashtable;

public class LicenseFactory
{
  protected static Hashtable a = new Hashtable();
  protected static final String b = "\002\004Yc\030\b\005U?Z\013\002Z9\021\006\031U";
  protected static final String c = "\002\004Yc\030\b\005U?Z\013\nB,F\002\004Y";
  
  public static License getLicense(Class paramClass)
  {
    try
    {
      return a(paramClass);
    }
    catch (Throwable localThrowable)
    {
      JintegraHelpers.a(localThrowable);
      if ((localThrowable instanceof LicenseException)) {
        throw new LicenseException(localThrowable.getMessage());
      }
      throw new LicenseException(a(""));
    }
  }
  
  private static License a(Class paramClass)
  {
    synchronized (a)
    {
      String str = paramClass.getName();
      str = str.substring(0, str.lastIndexOf("."));
      g localg1 = (g)a.get(str);
      if (null == localg1) {
        try
        {
          if ((str.equals(a("\002\004Yc\030\b\005U?Z\013\002Z9\021\006\031U"))) || (str.equals(a("\002\004Yc\030\b\005U?Z\013\nB,F\002\004Y"))))
          {
            locale = f.a(a("+\002Z9\021\006\031U"));
            locale.a();
            localg1 = locale.b();
            a.put(str, localg1);
            g localg3 = localg1;
            return localg3;
          }
          e locale = null;
          return locale;
        }
        catch (Throwable localThrowable)
        {
          JintegraHelpers.a(localThrowable);
          if ((localThrowable instanceof LicenseException)) {
            throw new LicenseException(localThrowable.getMessage());
          }
          throw new LicenseException(a(""));
        }
      }
      g localg2 = localg1;
      return localg2;
    }
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      107[52] = ((char)(0x4D ^ 0x74));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.LicenseFactory
 * JD-Core Version:    0.7.0.1
 */