package com.intrinsyc.license;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLConnection;

class JintegraLastCheck$IntChk
  implements Runnable
{
  String a;
  private final d b;
  
  JintegraLastCheck$IntChk(d paramd)
  {
    this.b = paramd;
    this.a = "";
  }
  
  public void run()
  {
    try
    {
      URLConnection localURLConnection = new URL(a("")).openConnection();
      HttpURLConnection localHttpURLConnection = (HttpURLConnection)localURLConnection;
      InetAddress localInetAddress = InetAddress.getLocalHost();
      String str1 = localInetAddress.getHostName();
      String str2 = localInetAddress.getHostAddress();
      localHttpURLConnection.setDoOutput(true);
      localHttpURLConnection.setDoInput(true);
      localHttpURLConnection.setRequestMethod(a("7\002r\007"));
      localHttpURLConnection.setRequestProperty(a("4\002`\003\001\0049H<."), a("E%U'0]b\016$7\020cH=4\025$O 9\004cB<-H\032D1\023\002?W:#\002>\016\001%\027\"S'b"));
      localHttpURLConnection.setRequestProperty(a("$\"O'%\t9\f\0079\027("), a("\023(Y'o\037 Mh`\004%@!3\0029\034&4\001`\031"));
      OutputStream localOutputStream = localURLConnection.getOutputStream();
      OutputStreamWriter localOutputStreamWriter = new OutputStreamWriter(localOutputStream);
      String str3 = a("") + this.a + a("[bR62\016,Mm") + a("[$Qm") + str2 + a("[bH#~") + a("[ @0(\016#D\035!\n(\037") + str1 + a("[bL2#\017$O6\016\006 Dm") + a("[bs60\b?Um") + a("[bR<!\027wc<$\036s") + a("[bR<!\027wd=6\002!N#%Y");
      localOutputStreamWriter.write(str3);
      localOutputStreamWriter.flush();
      localOutputStreamWriter.close();
      InputStream localInputStream = localHttpURLConnection.getInputStream();
      localInputStream.close();
    }
    catch (Throwable localThrowable) {}
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      77[33] = ((char)(0x53 ^ 0x40));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.JintegraLastCheck.IntChk
 * JD-Core Version:    0.7.0.1
 */