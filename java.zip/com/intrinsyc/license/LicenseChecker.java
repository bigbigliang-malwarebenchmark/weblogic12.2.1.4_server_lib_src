package com.intrinsyc.license;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.Vector;

abstract class LicenseChecker
{
  protected Vector a = new Vector();
  protected String b = "";
  
  protected LicenseChecker()
  {
    try
    {
      System.getProperty(d("TB]HhKNCL4Y_\\_"));
    }
    catch (Exception localException)
    {
      this.b = "\n";
    }
  }
  
  public abstract boolean doCheck(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2);
  
  protected void a()
  {
    this.a.removeAllElements();
    Exception localException = new Exception();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    PrintWriter localPrintWriter = new PrintWriter(localByteArrayOutputStream);
    localException.fillInStackTrace();
    localException.printStackTrace(localPrintWriter);
    localPrintWriter.flush();
    a(localByteArrayOutputStream.toString());
  }
  
  private void a(String paramString)
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, this.b);
    if (LicenseException.a) {}
    while (localStringTokenizer.hasMoreTokens())
    {
      String str = localStringTokenizer.nextToken();
      this.a.addElement(str);
    }
  }
  
  protected boolean b(String paramString)
  {
    boolean bool = LicenseException.a;
    int i = 0;
    if (bool) {}
    label113:
    while (i < this.a.size())
    {
      String str1 = (String)this.a.elementAt(i);
      if (!bool)
      {
        if (str1.equals(paramString)) {
          return true;
        }
        if (bool) {}
      }
      else
      {
        if (paramString.length() > str1.length()) {
          break label113;
        }
      }
      int j = 0;
      if (bool) {}
      while (j < str1.length() - paramString.length() - 1)
      {
        String str2 = str1.substring(j, paramString.length() + j);
        if ((bool) || (str2.equals(paramString))) {
          return true;
        }
        j++;
      }
      i++;
    }
    return false;
  }
  
  protected boolean a(String paramString, int paramInt)
  {
    try
    {
      Date localDate1 = new Date(Long.parseLong(paramString));
      Date localDate2 = new Date();
      long l1 = (localDate2.getTime() - localDate1.getTime()) / 1000L;
      long l2 = paramInt * 24 * 60 * 60;
      return l1 > l2;
    }
    catch (Exception localException)
    {
      JintegraHelpers.a(localException);
    }
    return true;
  }
  
  protected int c(String paramString)
  {
    try
    {
      Date localDate1 = new Date(Long.parseLong(paramString));
      Date localDate2 = new Date();
      long l = (localDate2.getTime() - localDate1.getTime()) / 1000L;
      int i = (int)(l / 60L / 60L / 24L);
      return i;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      JintegraHelpers.a(localNumberFormatException);
    }
    return 0;
  }
  
  private static String d(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      43[51] = ((char)(0x2D ^ 0x46));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.LicenseChecker
 * JD-Core Version:    0.7.0.1
 */