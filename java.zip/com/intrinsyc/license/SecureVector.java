package com.intrinsyc.license;

import java.util.Enumeration;
import java.util.Vector;

class SecureVector
{
  private Vector a = null;
  
  protected SecureVector()
  {
    this.a = new Vector();
  }
  
  protected SecureVector(int paramInt)
  {
    this.a = new Vector(paramInt);
  }
  
  protected SecureVector(int paramInt1, int paramInt2)
  {
    this.a = new Vector(paramInt1, paramInt2);
  }
  
  protected int a(Object paramObject)
  {
    d(paramObject);
    return this.a.size();
  }
  
  protected boolean b(Object paramObject)
  {
    d(paramObject);
    return this.a.isEmpty();
  }
  
  protected Enumeration c(Object paramObject)
  {
    d(paramObject);
    return this.a.elements();
  }
  
  protected Object a(Object paramObject, int paramInt)
  {
    d(paramObject);
    return this.a.elementAt(paramInt);
  }
  
  protected void a(Object paramObject1, Object paramObject2)
  {
    d(paramObject1);
    this.a.addElement(paramObject2);
  }
  
  private void d(Object paramObject)
  {
    if (!(paramObject instanceof b)) {
      throw new RuntimeException(a("?r(<\025\027rd\030\021\025{7*"));
    }
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      30[68] = ((char)(0x59 ^ 0x72));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.SecureVector
 * JD-Core Version:    0.7.0.1
 */