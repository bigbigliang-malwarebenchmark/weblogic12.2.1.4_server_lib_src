package com.intrinsyc.license;

class JintegraLicenseStruct
{
  protected String a = "";
  protected String b = "";
  protected String c = "";
  protected String d = "";
  protected int e = 0;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.JintegraLicenseStruct
 * JD-Core Version:    0.7.0.1
 */