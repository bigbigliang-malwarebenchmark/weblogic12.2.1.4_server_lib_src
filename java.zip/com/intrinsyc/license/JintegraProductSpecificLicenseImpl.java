package com.intrinsyc.license;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.StringTokenizer;

class JintegraProductSpecificLicenseImpl
{
  protected String a = "";
  protected String b = "";
  protected String c = "";
  protected String d = "";
  protected JintegraLicenseStruct e = new JintegraLicenseStruct();
  protected String f = "";
  protected String g = "";
  protected String h = "";
  protected int i = 0;
  protected int j = 0;
  
  protected void a(String paramString)
  {
    boolean bool = LicenseException.a;
    this.h = paramString;
    StringTokenizer localStringTokenizer = new StringTokenizer(this.h, "$");
    int k = 1;
    if (bool) {}
    label501:
    while (localStringTokenizer.hasMoreTokens())
    {
      Object localObject1 = localStringTokenizer.nextToken();
      Object localObject2;
      switch (k)
      {
      case 1: 
        localObject2 = this.a + "*" + this.b;
        String str1 = JintegraHelpers.g((String)localObject2);
        if (!((String)localObject1).equals(str1)) {
          throw new LicenseException(b("K\024)bNk\036KCq\022"));
        }
        break;
      case 2: 
        if (!bool)
        {
          if (((String)localObject1).charAt(0) == 'T')
          {
            localObject2 = new StringTokenizer((String)localObject1, "*");
            int i1 = 1;
            if (bool) {}
            while (((StringTokenizer)localObject2).hasMoreTokens())
            {
              String str2 = ((StringTokenizer)localObject2).nextToken();
              if (!bool) {
                if (1 == i1) {
                  localObject1 = str2;
                }
              }
              if (2 == i1) {
                try
                {
                  Integer localInteger = new Integer(str2);
                  this.i = localInteger.intValue();
                }
                catch (Exception localException3) {}
              }
              i1++;
            }
          }
          this.e.b = ((String)localObject1);
        }
        if ((bool) || (((String)localObject1).equalsIgnoreCase(b("Q\037-uGp"))))
        {
          Container.put(b("y;n5\0256?\034@\01718j:\0176Ii2\017@K\031G\017:>g;\0247Oh2\022FI\""), new Object());
          if (!bool) {}
        }
        break;
      case 3: 
        this.e.c = ((String)localObject1);
        try
        {
          long l = Long.parseLong((String)localObject1);
        }
        catch (NumberFormatException localNumberFormatException)
        {
          try
          {
            Date localDate = DateFormat.getDateInstance(1, Locale.US).parse((String)localObject1);
            this.e.c = (localDate.getTime() + "");
          }
          catch (Exception localException1)
          {
            if (!bool) {}
          }
        }
      case 4: 
        this.e.d = ((String)localObject1);
        this.j = JintegraHelpers.c(this.e.d);
        if (!bool) {}
        break;
      case 5: 
        int n = 0;
        if (!bool)
        {
          if (!this.e.b.equalsIgnoreCase(b("v\b6bN")))
          {
            if (bool) {
              break label501;
            }
            if (!this.e.b.equalsIgnoreCase(b("f\037)fNm\n:q"))) {}
          }
          else
          {
            Container.put(b("y;n5\0256?\034@\01718j:\0176Ii2\017@K\031G\017:>g;\0247Oh2\022FI\""), new Object());
            Container.put(b("yL\031B\024G<j7\0175Hh@\0176\034<`\017;>\031;\0171N\0315`ANg3\0225H\""), new Integer(2147483647));
          }
        }
        else
        {
          Container.put(b("yHi@\02479g3\017;J\0332\0176L=6\017CB\0331\017G>f4cD<\035:f1O\""), new Object());
          this.e.e = 2147483647;
          if (!bool) {
            break label613;
          }
        }
        try
        {
          if (!bool)
          {
            if (((String)localObject1).equalsIgnoreCase("U"))
            {
              Container.put(b("yHi@\02479g3\017;J\0332\0176L=6\017CB\0331\017G>f4cD<\035:f1O\""), new Object());
              Container.put(b("yL\031B\024G<j7\0175Hh@\0176\034<`\017;>\031;\0171N\0315`ANg3\0225H\""), new Integer(2147483647));
              n = 2147483647;
              if (!bool) {
                break label608;
              }
            }
            n = new Integer((String)localObject1).intValue();
            if (bool) {}
          }
          else
          {
            if (n < 1000) {
              n = 1000;
            }
            this.e.e = n;
          }
          Container.put(b("yL\031B\024G<j7\0175Hh@\0176\034<`\017;>\031;\0171N\0315`ANg3\0225H\""), new Integer(n));
        }
        catch (Exception localException2) {}
      }
      k++;
    }
    label608:
    label613:
    int m = 0;
    m++;
  }
  
  public String toString()
  {
    Date localDate = new Date(Long.parseLong(this.e.c));
    String str = "";
    str = str + b("R\b0gWa\016e") + this.a;
    str = str + b("\"66`Gl\031:f\030") + this.b;
    str = str + b("\">>wGM\034\026pQw\037e") + DateFormat.getDateInstance(1).format(localDate);
    str = str + b("\"66`Gl\t:W[r\037e") + this.e.b;
    if (this.i > 0) {
      str = str + b("\".-jCn>>zQ8") + this.i;
    }
    str = str + b("\",:qQk\0251BVK\t,vG8") + this.e.d;
    if (this.e.b.equals(b("q\037-uGp"))) {
      str = str + b("\"):qTg\b@Cr\033<jV{@") + this.e.e + b("\"\033<wKt\037l@h\037<wQ");
    }
    return str;
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int k = arrayOfChar.length;
    int m = 0;
    while (m < k)
    {
      switch (m % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      122[95] = ((char)(0x3 ^ 0x22));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.JintegraProductSpecificLicenseImpl
 * JD-Core Version:    0.7.0.1
 */