package com.intrinsyc.license;

public class LicenseException
  extends RuntimeException
{
  public static boolean a;
  
  public LicenseException() {}
  
  public LicenseException(String paramString)
  {
    super(paramString);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.LicenseException
 * JD-Core Version:    0.7.0.1
 */