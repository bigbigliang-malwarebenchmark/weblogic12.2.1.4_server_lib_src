package com.intrinsyc.license;

class JintegraConstants
  implements a
{
  private final String a = a("");
  private final String b = a("#cL[\004Q\0236-r+\024");
  private final String c = a("\"kI^k");
  private final String d = a("+`9Yk");
  private final String e = a("'06Xk");
  private final String f = "{";
  private final String g = "}";
  protected static final String h = "";
  protected static final String i = "";
  protected static final String j = "";
  protected static final String k = "";
  protected static final String l = "";
  protected static final String m = "";
  protected static final String n = "";
  protected static final String o = "";
  protected static final String p = "";
  protected static final String q = "";
  protected static final String r = "";
  protected static final String s = "";
  protected static final String t = "";
  protected static final String u = "";
  protected static final String v = "";
  protected static final String w = "";
  protected static final String x = "";
  protected static final String y = "";
  protected static final String z = "";
  protected static final int A = 1;
  public static final String DEFAULT_MESSAGE = "";
  protected static final String B = "";
  protected static final String C = "";
  protected static final String D = "";
  
  public String a(String paramString, Object paramObject)
  {
    if (!(paramObject instanceof b)) {
      throw new RuntimeException(a("Z>c\n!r>/.%p7|\034"));
    }
    int i1 = paramString.charAt(1);
    switch (i1)
    {
    case 65: 
      return a("");
    case 66: 
      return a("#cL[\004Q\0236-r+\024");
    case 67: 
      return a("\"kI^k");
    case 68: 
      return a("+`9Yk");
    case 69: 
      return a("'06Xk");
    case 70: 
      return "{";
    case 71: 
      return "}";
    }
    return "";
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      82[15] = ((char)(0x6F ^ 0x46));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.JintegraConstants
 * JD-Core Version:    0.7.0.1
 */