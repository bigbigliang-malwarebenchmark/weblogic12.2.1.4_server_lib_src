package com.intrinsyc.license;

class JintegraLicenseTool$ProdSnippetInfo
{
  protected String a;
  protected String b;
  protected String c;
  protected String d;
  protected String e;
  protected boolean f;
  private final JintegraLicenseTool g;
  
  JintegraLicenseTool$ProdSnippetInfo(JintegraLicenseTool paramJintegraLicenseTool)
  {
    this.g = paramJintegraLicenseTool;
    this.a = null;
    this.b = null;
    this.c = null;
    this.d = null;
    this.e = null;
    this.f = false;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.JintegraLicenseTool.ProdSnippetInfo
 * JD-Core Version:    0.7.0.1
 */