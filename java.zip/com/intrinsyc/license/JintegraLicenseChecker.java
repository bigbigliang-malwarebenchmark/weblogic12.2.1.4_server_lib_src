package com.intrinsyc.license;

import com.linar.jintegra.Banner;
import com.linar.jintegra.Version;
import java.io.PrintStream;
import java.io.Serializable;

class JintegraLicenseChecker
  extends LicenseChecker
  implements b, Serializable, Runnable
{
  private static boolean c = true;
  
  public boolean doCheck(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2)
  {
    boolean bool = LicenseException.a;
    Object localObject;
    try
    {
      JintegraLicenseManager localJintegraLicenseManager = new JintegraLicenseManager();
      localObject = (SecureVector)Container.getValue(e("}>\016oeG7\001\033p>7r\031p26\006\035p?=\017ip6;\016\031\036B7\003\032l3=J"));
      int i = 0;
      if (bool) {}
      while (i < ((SecureVector)localObject).a(this))
      {
        JintegraProductSpecificLicenseImpl localJintegraProductSpecificLicenseImpl2 = (JintegraProductSpecificLicenseImpl)((SecureVector)localObject).a(this, i);
        paramStringBuffer2.append(localJintegraProductSpecificLicenseImpl2.toString());
        i++;
      }
    }
    catch (Exception localException)
    {
      System.err.println(e("S`VI1c.CD}jaTJ)c.V\013+gb^O}jgTN3uk\031"));
      System.err.println(e("VbRJ.c.EN;c|\027_2&z_N}v|XO(ez\027O2e{ZN3roCB2h.QD/&gYX)t{T_4i`D\0132h._D*&zX"));
      System.err.println(e("o`D_<jb\027J3b.AB8q.V\0131omRE.c =!"));
      System.exit(0);
    }
    JintegraProductSpecificLicenseImpl localJintegraProductSpecificLicenseImpl1 = null;
    localJintegraProductSpecificLicenseImpl1 = b();
    if (!bool) {
      if (localJintegraProductSpecificLicenseImpl1 != null)
      {
        a(localJintegraProductSpecificLicenseImpl1);
        b(localJintegraProductSpecificLicenseImpl1);
        if (!bool)
        {
          if (localJintegraProductSpecificLicenseImpl1.e.b.equals(e("R|^J1"))) {
            if (!bool)
            {
              if (a(localJintegraProductSpecificLicenseImpl1.e.c, localJintegraProductSpecificLicenseImpl1.i))
              {
                localObject = g();
                if (null == localObject) {
                  throw new LicenseException(e("_aBY}r|^J1&~RY4ij\027C<u.RS-o|ROs\013\004gG8g}R\013>i`CJ>r.D^-vaE_}ra\027[(tm_J.c.V\0131omRE.c4\027C)r~\r\004rl#^E)ciEJso`CY4h}NHseaZ\004"));
                }
                if (!bool) {
                  if (((JintegraProductSpecificLicenseImpl)localObject).f.equals(e("uzVH6YzEJ>cQYD)Y~EN.c`C"))) {
                    throw new LicenseException(e("_aB\013<tk\027_/gYL}ra\027^.c.CC8&~ED9smC\0134h.VE}o`AJ1oj\027\\< :!\rjkVX8&|RM8t.CD}aBY}v|XO(ez\027O2e{ZN3roCB2h.XY}eaY_<ez\027X(v~XY)<.__)v4\030\0047+gY_8a|V\0054hzEB3uwT\005>ic\030"));
                  }
                }
                if (bool) {
                  break label352;
                }
                if (((JintegraProductSpecificLicenseImpl)localObject).e.b.equals(e("R|^J1")))
                {
                  if (!bool)
                  {
                    if (a(((JintegraProductSpecificLicenseImpl)localObject).e.c, ((JintegraProductSpecificLicenseImpl)localObject).i)) {
                      throw new LicenseException(e("_aBY}r|^J1&~RY4ij\027C<u.RS-o|ROs\013\004gG8g}R\013>i`CJ>r.D^-vaE_}ra\027[(tm_J.c.V\0131omRE.c4\027C)r~\r\004rl#^E)ciEJso`CY4h}NHseaZ\004"));
                    }
                    d((JintegraProductSpecificLicenseImpl)localObject);
                    h();
                  }
                  return true;
                }
              }
              else
              {
                d(localJintegraProductSpecificLicenseImpl1);
                i();
                h();
              }
            }
            else {
              return true;
            }
          }
          if (bool) {
            break label365;
          }
        }
        if (localJintegraProductSpecificLicenseImpl1.e.b.equals(e("BkAN1i~RY"))) {
          label352:
          c(localJintegraProductSpecificLicenseImpl1);
        }
        i();
        label365:
        return true;
      }
    }
    localJintegraProductSpecificLicenseImpl1 = g();
    if (!bool)
    {
      if (null == localJintegraProductSpecificLicenseImpl1) {
        throw new LicenseException(e("_aB\013<tk\027_/gYL}ra\027^.c.CC8&~ED9smC\0134h.VE}o`AJ1oj\027\\< :!\rjkVX8&|RM8t.CD}aBY}v|XO(ez\027O2e{ZN3roCB2h.XY}eaY_<ez\027X(v~XY)<.__)v4\030\0047+gY_8a|V\0054hzEB3uwT\005>ic\030"));
      }
      a(localJintegraProductSpecificLicenseImpl1);
    }
    if (!bool) {
      if (localJintegraProductSpecificLicenseImpl1.f.equals(e("uzVH6YzEJ>cQYD)Y~EN.c`C"))) {
        throw new LicenseException(e("_aB\013<tk\027_/gYL}ra\027^.c.CC8&~ED9smC\0134h.VE}o`AJ1oj\027\\< :!\rjkVX8&|RM8t.CD}aBY}v|XO(ez\027O2e{ZN3roCB2h.XY}eaY_<ez\027X(v~XY)<.__)v4\030\0047+gY_8a|V\0054hzEB3uwT\005>ic\030"));
      }
    }
    if (!bool)
    {
      if (localJintegraProductSpecificLicenseImpl1.e.b.equals(e("R|^J1")))
      {
        if (!bool) {
          if (a(localJintegraProductSpecificLicenseImpl1.e.c, localJintegraProductSpecificLicenseImpl1.i)) {
            throw new LicenseException(e("_aBY}r|^J1&~RY4ij\027C<u.RS-o|ROs\013\004gG8g}R\013>i`CJ>r.D^-vaE_}ra\027[(tm_J.c.V\0131omRE.c4\027C)r~\r\004rl#^E)ciEJso`CY4h}NHseaZ\004"));
          }
        }
        d(localJintegraProductSpecificLicenseImpl1);
      }
      i();
    }
    return true;
  }
  
  private JintegraProductSpecificLicenseImpl b()
  {
    boolean bool = LicenseException.a;
    SecureVector localSecureVector = (SecureVector)Container.getValue(e("}>\016oeG7\001\033p>7r\031p26\006\035p?=\017ip6;\016\031\036B7\003\032l3=J"));
    int i = 0;
    if (bool) {}
    while (i < localSecureVector.a(this))
    {
      JintegraProductSpecificLicenseImpl localJintegraProductSpecificLicenseImpl = (JintegraProductSpecificLicenseImpl)localSecureVector.a(this, i);
      if ((bool) || (localJintegraProductSpecificLicenseImpl.f.equals(e("akYN/omh^.c")))) {
        return localJintegraProductSpecificLicenseImpl;
      }
      i++;
    }
    return null;
  }
  
  private void a(JintegraProductSpecificLicenseImpl paramJintegraProductSpecificLicenseImpl)
  {
    int i = JintegraHelpers.c(Version.getVersion());
    if (paramJintegraProductSpecificLicenseImpl.j < i)
    {
      String str = e("O`AJ1oj\027}8t}^D3&hX^3b.^E}jgTN3uk\031&W_aBY}jgTN3uk\027H2hzVB3u.AN/ugXEg&") + paramJintegraProductSpecificLicenseImpl.e.d + e("\013\004e^3rgZN}o}\027]8t}^D3<.") + Version.getVersion() + e("\013\004gG8g}R\013>i`CJ>r.~E)tgYX$e.CD}s~PY<bk\027R2s|\027G4ekYX8(\003=") + e("nzC[g)!]\0064hzRL/g ^E)tgYX$e TD0)");
      throw new LicenseException(str);
    }
  }
  
  private void b(JintegraProductSpecificLicenseImpl paramJintegraProductSpecificLicenseImpl)
  {
    if (paramJintegraProductSpecificLicenseImpl.e.b.equalsIgnoreCase(e("eb^N3r")))
    {
      if (c()) {
        throw new LicenseException(e("G.dN/pkE\013\021omRE.c.^X}tkF^4tkS\013)i.SN-jaN\0134h.VE}C`CN/v|^X8&kY]4taYF8hz"));
      }
      if (d()) {
        throw new LicenseException(e("G.dN/pkE\013\021omRE.c.^X}tkF^4tkS\013)i.SN-jaN\0134h.VE}C`CN/v|^X8&kY]4taYF8hz"));
      }
      if (e()) {
        throw new LicenseException(e("G.dN/pkE\013\021omRE.c.^X}tkF^4tkS\013)i.SN-jaN\0134h.VE}C`CN/v|^X8&kY]4taYF8hz"));
      }
    }
  }
  
  private boolean c()
  {
    Class localClass = null;
    try
    {
      localClass = Class.forName(e("loAJ%(k]IsCDud?lkT_"), false, ClassLoader.getSystemClassLoader());
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      return false;
    }
    return true;
  }
  
  private boolean d()
  {
    Class localClass = null;
    try
    {
      localClass = Class.forName(e("loAJ%(dZXsW{R^8"), false, ClassLoader.getSystemClassLoader());
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      return false;
    }
    return true;
  }
  
  private boolean e()
  {
    Class localClass = null;
    try
    {
      localClass = Class.forName(e("loAJ%(}RY+jkC\0055rzG\005\025rzGx8tx[N)"), false, ClassLoader.getSystemClassLoader());
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      return false;
    }
    return true;
  }
  
  private JintegraProductSpecificLicenseImpl f()
  {
    boolean bool = LicenseException.a;
    SecureVector localSecureVector = (SecureVector)Container.getValue(e("}>\016oeG7\001\033p>7r\031p26\006\035p?=\017ip6;\016\031\036B7\003\032l3=J"));
    int i = 0;
    if (bool) {}
    while (i < localSecureVector.a(this))
    {
      JintegraProductSpecificLicenseImpl localJintegraProductSpecificLicenseImpl = (JintegraProductSpecificLicenseImpl)localSecureVector.a(this, i);
      if ((bool) || (localJintegraProductSpecificLicenseImpl.e.b.equals(e("R|^J1")))) {
        return localJintegraProductSpecificLicenseImpl;
      }
      i++;
    }
    return null;
  }
  
  private JintegraProductSpecificLicenseImpl g()
  {
    boolean bool = LicenseException.a;
    a();
    SecureVector localSecureVector = (SecureVector)Container.getValue(e("}>\016oeG7\001\033p>7r\031p26\006\035p?=\017ip6;\016\031\036B7\003\032l3=J"));
    int i = 0;
    if (bool) {}
    while (i < localSecureVector.a(this))
    {
      JintegraProductSpecificLicenseImpl localJintegraProductSpecificLicenseImpl = (JintegraProductSpecificLicenseImpl)localSecureVector.a(this, i);
      if ((bool) || ((localJintegraProductSpecificLicenseImpl.f.equals(e("uzVH6YzEJ>cQYD)Y~EN.c`C"))) || ((bool) || (localJintegraProductSpecificLicenseImpl.f.equals(e("uzVH6YzEJ>cQGY8ukY_"))))))
      {
        String str = localJintegraProductSpecificLicenseImpl.g;
        if (b(str)) {
          return localJintegraProductSpecificLicenseImpl;
        }
      }
      i++;
    }
    return null;
  }
  
  private void c(JintegraProductSpecificLicenseImpl paramJintegraProductSpecificLicenseImpl)
  {
    if (c)
    {
      System.err.println("\n");
      Banner.printBanner();
      System.err.println(e("\f$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$="));
      System.err.println(e("RfVE6&wX^}`aE\013>naXX4hi\027apO`CN:to\031"));
      System.err.println(e("VbRJ.c.AB.oz\027C)r~\r\004rl#^E)ciEJso`CY4h}NHseaZ\004}`aE"));
      System.err.println(e("baT^0c`CJ)oaY\007}u{G[2tz\033\013<hj\027[(tm_J.o`P\0134hhXY0gz^D3(\004"));
      System.err.println(e(",$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,\004="));
      c = false;
    }
  }
  
  private void d(JintegraProductSpecificLicenseImpl paramJintegraProductSpecificLicenseImpl)
  {
    if (c)
    {
      int i = c(paramJintegraProductSpecificLicenseImpl.e.c);
      System.err.println("\n");
      Banner.printBanner();
      System.err.println(e("\f$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$"));
      System.err.println(e("RfVE6&wX^}`aE\013>naXX4hi\027apO`CN:to\031"));
      System.err.println(e("_aB\0135gxR\013?ckY\0138po[^<rgYL}rf^X}v|XO(ez\027M2t.") + i + e("&jVR.("));
      System.err.println(e("VbRJ.c.AB.oz\027C)r~\r\004rl#^E)ciEJso`CY4h}NHseaZ\004}`aE"));
      System.err.println(e("baT^0c`CJ)oaY\007}u{G[2tz\033\013<hj\027[(tm_J.o`P\0134hhXY0gz^D3("));
      System.err.println(e(",$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,\004="));
      c = false;
    }
  }
  
  private void h()
  {
    try
    {
      Thread localThread = new Thread(this);
      localThread.setDaemon(true);
      localThread.start();
    }
    catch (Throwable localThrowable) {}
  }
  
  private void i()
  {
    d locald = new d();
    locald.a(this);
  }
  
  public void run()
  {
    int i = 7200000;
    try
    {
      Thread.sleep(i);
      System.err.println(e("\f$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$"));
      System.err.println(e("R|^J1&XRY.oaY\013\030~gCX}ghCN/&<\027C2s|D\0132`.TD3rgY^2s}\027^.c "));
      System.err.println(e("VbRJ.c.EN.roE_}aBY}ukE]8t.CD}eaY_4h{R\013)c}CB3a "));
      System.err.println(e("\f$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$\035\001w,$"));
      System.exit(0);
    }
    catch (Exception localException) {}
  }
  
  private static String e(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      14[55] = ((char)(0x2B ^ 0x5D));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.JintegraLicenseChecker
 * JD-Core Version:    0.7.0.1
 */