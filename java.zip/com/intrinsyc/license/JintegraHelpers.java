package com.intrinsyc.license;

import com.intrinsyc.license.Acme.Crypto.g;
import com.intrinsyc.license.Acme.Crypto.h;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.PrintStream;
import java.net.URL;
import java.util.Hashtable;
import java.util.StringTokenizer;

class JintegraHelpers
{
  protected static final String a = "";
  protected static final String b = "a;hq\001l gz\bb1ck\027n";
  protected static final String c = "o7dp\003t&td\007n";
  protected static String d = "";
  protected static String e = "";
  protected static byte[] f = null;
  private static boolean g = true;
  private static boolean h = false;
  private static final String i = "PB\025\035um4\037\021i\031Ag\035i\037ACFi\0221`gi\035J\037d\006\030K``uoJ[";
  private static Hashtable j = new Hashtable();
  static Class k;
  static Class l;
  
  protected static void a(String paramString)
  {
    j.put(j("P0\024\024\002n4b\026i\0351\024\027i\037\020\037\022ijBb`inGg\020\001\0220\024\025unC["), paramString);
    Container.put(j("P0\024\024\002n4b\026i\0351\024\027i\037\020\037\022ijBb`inGg\020\001\0220\024\025unC["), paramString);
  }
  
  protected static String b(String paramString)
  {
    return (String)j.get(paramString);
  }
  
  protected static void doCheck(boolean paramBoolean)
  {
    if (!paramBoolean) {
      throw new RuntimeException(j("h\032CF/\0134GL(N\026"));
    }
  }
  
  protected static int c(String paramString)
  {
    boolean bool = LicenseException.a;
    int m = 0;
    if (!bool)
    {
      if (paramString.indexOf(" ") > 0) {
        paramString = paramString.substring(0, paramString.indexOf(" "));
      }
      if (bool) {}
    }
    else if (paramString.indexOf(j("x0")) > 0)
    {
      paramString = paramString.substring(0, paramString.indexOf(j("x0")));
    }
    String str = "";
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ".");
    int n = 0;
    if (bool) {
      if (n > 1) {
        break label132;
      }
    }
    for (;;)
    {
      Object localObject = localStringTokenizer.nextToken();
      str = str + (String)localObject;
      n++;
      if (localStringTokenizer.hasMoreTokens()) {
        break;
      }
      try
      {
        label132:
        localObject = new Integer(str);
        m = ((Integer)localObject).intValue();
        if (bool) {}
      }
      catch (NumberFormatException localNumberFormatException) {}
    }
    return m;
  }
  
  protected static void doCheck(boolean paramBoolean, String paramString)
  {
    if (!paramBoolean) {
      throw new RuntimeException(j("h\032CF/\0134GL(N\026\034\005") + paramString);
    }
  }
  
  protected static String a()
  {
    try
    {
      String str = System.getProperty(j("a;hq\001l gz\bb1ck\027n"));
      if ((null == str) || (str.equals(""))) {
        return null;
      }
      return d(str);
    }
    catch (Exception localException) {}
    return null;
  }
  
  protected static String b()
  {
    URL localURL = (k == null ? (JintegraHelpers.k = i(j("H\035K\013-E\006TL*X\013E\013(B\021CK7N\\lL*_\027AW%c\027JU!Y\001"))) : k).getResource(j(""));
    return localURL.toString();
  }
  
  protected static InputStream c()
  {
    try
    {
      return (k == null ? (JintegraHelpers.k = i(j("H\035K\013-E\006TL*X\013E\013(B\021CK7N\\lL*_\027AW%c\027JU!Y\001"))) : k).getResource(j("")).openStream();
    }
    catch (Exception localException) {}
    return null;
  }
  
  protected static String d(String paramString)
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, d);
    if (LicenseException.a) {}
    while (localStringTokenizer.hasMoreTokens())
    {
      String str1 = localStringTokenizer.nextToken();
      String str2 = h(str1);
      str1 = str2 + e + j("");
      try
      {
        FileInputStream localFileInputStream = new FileInputStream(str1);
        localFileInputStream.close();
        return new String("/" + str1);
      }
      catch (Exception localException) {}
    }
    return null;
  }
  
  protected static String e(String paramString)
  {
    boolean bool = LicenseException.a;
    String str1 = null;
    str1 = System.getProperty(j("^\001CWjO\033T"));
    File localFile = new File(str1 + e + paramString);
    if (!bool)
    {
      if (localFile.exists()) {
        return str1;
      }
      str1 = System.getProperty(j("A\023PDjH\036GV7\005\002GQ,"));
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(str1, d);
    if (bool) {}
    while (localStringTokenizer.hasMoreTokens())
    {
      String str2 = localStringTokenizer.nextToken();
      String str3 = h(str2);
      str2 = str3 + e + paramString;
      try
      {
        FileInputStream localFileInputStream = new FileInputStream(str2);
        localFileInputStream.close();
        return str3;
      }
      catch (Exception localException) {}
    }
    return null;
  }
  
  protected static String f(String paramString)
  {
    boolean bool = LicenseException.a;
    String str1 = null;
    str1 = System.getProperty(j("^\001CWjO\033T")) + e + paramString;
    File localFile = new File(str1);
    if (!bool)
    {
      if (localFile.exists()) {
        return str1;
      }
      System.getProperty(j("A\023PDjH\036GV7\005\002GQ,"));
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(str1, d);
    if (bool) {}
    while (localStringTokenizer.hasMoreTokens())
    {
      String str2 = localStringTokenizer.nextToken();
      String str3 = h(str2);
      str2 = str3 + e + paramString;
      try
      {
        FileInputStream localFileInputStream = new FileInputStream(str2);
        localFileInputStream.close();
        return str2;
      }
      catch (Exception localException) {}
    }
    return null;
  }
  
  protected static String g(String paramString)
  {
    h localh = new h();
    localh.d(paramString);
    return localh.toString();
  }
  
  protected static void a(Object paramObject)
  {
    if (!(paramObject instanceof b)) {
      throw new LicenseException(j(""));
    }
    try
    {
      if (g)
      {
        ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(f);
        ObjectInputStream localObjectInputStream = new ObjectInputStream(localByteArrayInputStream);
        Object localObject = localObjectInputStream.readObject();
        Container.put((l == null ? (JintegraHelpers.l = i(j(""))) : l).getName(), localObject);
        g = false;
        localObjectInputStream.close();
      }
    }
    catch (Throwable localThrowable)
    {
      if ((localThrowable instanceof NoClassDefFoundError)) {
        throw new LicenseException();
      }
    }
  }
  
  protected static void a(Throwable paramThrowable)
  {
    if (h)
    {
      System.err.println(j(""));
      System.err.println(paramThrowable.getMessage());
      paramThrowable.printStackTrace();
      System.err.println(j("\017V\002\001`\017V\002\001`\017V\002\001`\017V\002\001`\017V\002\001`\017V\002\001`\017V\002\001`\017V\002\001`\017V\002\001`\017V\002"));
    }
  }
  
  private static String h(String paramString)
  {
    boolean bool = LicenseException.a;
    if (!bool) {
      if (paramString.length() > 4)
      {
        String str1 = paramString.substring(paramString.length() - 4, paramString.length());
        if (bool) {
          break label146;
        }
        if (str1.equals(j("\005\030GW")))
        {
          String str2 = paramString.substring(0, paramString.length() - 4);
          int m = str2.length();
          int n = m - 1;
          if (bool) {}
          do
          {
            do
            {
              String str3 = "" + str2.charAt(n);
              if (!bool)
              {
                if (str3.equals(e)) {
                  str2 = str2.substring(0, n);
                }
              }
              else {
                return str2;
              }
              n--;
            } while (n > 1);
          } while (bool);
          return str2;
        }
      }
    }
    label146:
    return paramString;
  }
  
  static Class i(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  static
  {
    try
    {
      String str = System.getProperty(j("o7dp\003t&td\007n"));
      if ((str != null) && (str.equals(j("PB\025\035um4\037\021i\031Ag\035i\037ACFi\0221`gi\035J\037d\006\030K``uoJ[")))) {
        h = true;
      }
      d = System.getProperty(j("[\023RMjX\027VD6J\006IW"));
      e = System.getProperty(j("M\033J@jX\027VD6J\006IW"));
    }
    catch (Throwable localThrowable) {}
  }
  
  private static String j(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int m = arrayOfChar.length;
    int n = 0;
    while (n < m)
    {
      switch (n % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      114[38] = ((char)(0x25 ^ 0x44));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.JintegraHelpers
 * JD-Core Version:    0.7.0.1
 */