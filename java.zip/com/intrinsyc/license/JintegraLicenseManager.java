package com.intrinsyc.license;

import com.intrinsyc.license.Acme.Crypto.a;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.ObjectOutputStream;

class JintegraLicenseManager
  implements e
{
  public void a()
  {
    String str = null;
    str = JintegraHelpers.b();
    InputStream localInputStream = JintegraHelpers.c();
    if (null == str) {
      throw new LicenseException(a(""));
    }
    JintegraLicParser localJintegraLicParser = new JintegraLicParser();
    localJintegraLicParser.b(str, localInputStream);
    localJintegraLicParser = null;
  }
  
  public g b()
  {
    g localg = new g();
    h localh = (h)Container.getValue(a(",J\030s+\022Gl\f1aE\027{1c@\037(1\0266\026~1gDk^\022@my*o0R"));
    Object localObject = null;
    try
    {
      localObject = Class.forName(localh.provider).newInstance();
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      ObjectOutputStream localObjectOutputStream = new ObjectOutputStream(localByteArrayOutputStream);
      localObjectOutputStream.writeObject(localObject);
      String str1 = a.c(localByteArrayOutputStream.toByteArray());
      String str2 = JintegraHelpers.g(str1);
    }
    catch (Throwable localThrowable)
    {
      JintegraHelpers.a(localThrowable);
      throw new LicenseException(a("\016\034Z8<\033\032L/r$\026\017\032n8\005F.y%SN:l2\022]9<#\034\017(yw\032A<};\032Kd\021]#C/}$\026\0178y1\026]jh8SV%i%S_8s3\006L><3\034L?q2\035[+h>\034Ajs%SL%r#\022L><$\006_:s%\007\025jt#\007_p3x\031\002#r#\026H8}y\032A>n>\035\\3y\020@'3"));
    }
    localg.a(localObject, localh.a);
    return localg;
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      115[47] = ((char)(0x4A ^ 0x1C));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.JintegraLicenseManager
 * JD-Core Version:    0.7.0.1
 */