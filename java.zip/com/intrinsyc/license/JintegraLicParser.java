package com.intrinsyc.license;

import com.intrinsyc.license.Acme.Crypto.a;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.StringTokenizer;
import net.n3.nanoxml.e;
import net.n3.nanoxml.g;
import net.n3.nanoxml.m;
import net.n3.nanoxml.q;

class JintegraLicParser
  implements b
{
  private JintegraCrypto a = null;
  private String b = "";
  private String c = "";
  private static boolean d = true;
  
  private void a(String paramString, InputStream paramInputStream)
  {
    boolean bool = LicenseException.a;
    try
    {
      g localg = q.a();
      net.n3.nanoxml.h localh = m.a(paramString, paramInputStream);
      localg.a(localh);
      e locale1 = (e)localg.e();
      Enumeration localEnumeration1 = locale1.e();
      if (bool) {}
      label353:
      do
      {
        while (localEnumeration1.hasMoreElements())
        {
          e locale2 = (e)localEnumeration1.nextElement();
          Enumeration localEnumeration2;
          do
          {
            if (!bool) {
              if (locale2.c().equals(b("]9x\002NB5~")))
              {
                this.b = locale2.o();
                a(this.b);
              }
            }
            if (!bool) {
              if (locale2.c().equals(b("B5i\016A]")))
              {
                this.c = locale2.o();
                JintegraHelpers.a(this.c);
              }
            }
            if (!locale2.c().equals(b("{}R\tTT7i\006"))) {
              break label353;
            }
            localEnumeration2 = locale2.e();
            if (!bool) {
              break;
            }
          } while (bool);
          while (localEnumeration2.hasMoreElements())
          {
            e locale3;
            do
            {
              locale3 = (e)localEnumeration2.nextElement();
              String str;
              Object localObject;
              if (!bool)
              {
                if (locale3.c().equals(b("A\"t\021IU5i")))
                {
                  str = locale3.o();
                  localObject = locale3.e(b("G1w"), "");
                  a(str, (String)localObject);
                }
                if (bool) {}
              }
              else if (locale3.c().equals(b("A1i\024EC")))
              {
                str = locale3.o();
                str = this.a.b(str);
                str = a.b(str);
                localObject = a.a(str);
                JintegraHelpers.f = (byte[])localObject;
              }
              if (!locale3.c().equals(b("X>h\023A]<~\003A\"t\003UR$h"))) {
                break;
              }
            } while (bool);
            a(locale3);
          }
        }
      } while (bool);
    }
    catch (Exception localException)
    {
      JintegraHelpers.a(localException);
      throw new LicenseException(b(""));
    }
  }
  
  protected void b(String paramString, InputStream paramInputStream)
  {
    try
    {
      if (d)
      {
        a(paramString, paramInputStream);
        d = false;
      }
    }
    catch (Exception localException)
    {
      JintegraHelpers.a(localException);
      throw new LicenseException(b(""));
    }
  }
  
  private void a(e parame)
  {
    boolean bool = LicenseException.a;
    try
    {
      SecureVector localSecureVector = new SecureVector();
      Enumeration localEnumeration = parame.e();
      if (bool) {}
      do
      {
        while (localEnumeration.hasMoreElements())
        {
          JintegraProductSpecificLicenseImpl localJintegraProductSpecificLicenseImpl;
          do
          {
            e locale = (e)localEnumeration.nextElement();
            if (!locale.c().equals(b("A\"t\003UR$"))) {
              break;
            }
            localJintegraProductSpecificLicenseImpl = new JintegraProductSpecificLicenseImpl();
            localJintegraProductSpecificLicenseImpl.b = this.b;
            localJintegraProductSpecificLicenseImpl.c = this.c;
            a(locale, localJintegraProductSpecificLicenseImpl);
            b(locale, localJintegraProductSpecificLicenseImpl);
            c(locale, localJintegraProductSpecificLicenseImpl);
          } while (bool);
          localSecureVector.a(this, localJintegraProductSpecificLicenseImpl);
        }
        Container.put(b("J`\"#\030pi-W\r\ti^U\r\005h*Q\r\bc#%\r\001e\"Ucui/V\021\004cf"), localSecureVector);
      } while (bool);
    }
    catch (Exception localException)
    {
      JintegraHelpers.a(localException);
      throw new LicenseException(b(""));
    }
  }
  
  private void a(String paramString1, String paramString2)
  {
    boolean bool = LicenseException.a;
    paramString1 = this.a.b(paramString1);
    if ((bool) || (!paramString2.equals(""))) {
      paramString2 = this.a.b(paramString2);
    }
    h localh = new h();
    int i = 1;
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString1, "$");
    if (bool) {}
    do
    {
      do
      {
        String str = localStringTokenizer.nextToken();
        if (!bool) {
          if (1 == i) {
            localh.provider = str;
          }
        }
        if (2 == i) {
          localh.a = str;
        }
        i++;
      } while (localStringTokenizer.hasMoreTokens());
      localh.b = paramString2;
    } while (bool);
    Container.put(b("Ji,^\027tdX!\r\007f#V\r\005c+\005\rp\025\"S\r\001g_RbtcYT\026\t\023f"), localh);
  }
  
  private void a(String paramString)
  {
    JintegraConstants localJintegraConstants = new JintegraConstants();
    String str = localJintegraConstants.a(b("}\026Z2ia"), this) + localJintegraConstants.a(b("f\021Z$vy\032"), this) + localJintegraConstants.a(b("e\023Z6wr\006S"), this) + localJintegraConstants.a(b("{\025Z6ab\024I"), this) + localJintegraConstants.a(b("c\024Z7l|\032"), this) + localJintegraConstants.a(b("u\022Z6ab\024"), this) + localJintegraConstants.a(b("h\027Z7lz\031N>"), this) + b("\033z") + paramString;
    this.a = new JintegraCrypto(str);
  }
  
  private void a(e parame, JintegraProductSpecificLicenseImpl paramJintegraProductSpecificLicenseImpl)
  {
    String str1 = parame.e(b("_1v\002"), "");
    String str2 = parame.e(b("X4"), "");
    paramJintegraProductSpecificLicenseImpl.a = str1;
    paramJintegraProductSpecificLicenseImpl.d = str2;
  }
  
  private void b(e parame, JintegraProductSpecificLicenseImpl paramJintegraProductSpecificLicenseImpl)
  {
    boolean bool = LicenseException.a;
    Enumeration localEnumeration = parame.e();
    if (bool) {}
    while (localEnumeration.hasMoreElements())
    {
      String str;
      do
      {
        e locale = (e)localEnumeration.nextElement();
        if (!locale.c().equals(b("]9x\002NB5"))) {
          break;
        }
        str = locale.o();
      } while (bool);
      paramJintegraProductSpecificLicenseImpl.a(this.a.b(str));
    }
  }
  
  private void c(e parame, JintegraProductSpecificLicenseImpl paramJintegraProductSpecificLicenseImpl)
  {
    boolean bool = LicenseException.a;
    Enumeration localEnumeration = parame.e();
    if (bool) {}
    while (localEnumeration.hasMoreElements())
    {
      e locale = (e)localEnumeration.nextElement();
      String str;
      if (!bool) {
        if (locale.c().equals(b("U1o\006\021"))) {
          str = locale.o();
        }
      }
      do
      {
        paramJintegraProductSpecificLicenseImpl.f = this.a.b(str);
        if (!locale.c().equals(b("U1o\006\022"))) {
          break;
        }
        str = locale.o();
      } while (bool);
      paramJintegraProductSpecificLicenseImpl.g = this.a.b(str);
    }
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      80[27] = ((char)(0x67 ^ 0x20));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.JintegraLicParser
 * JD-Core Version:    0.7.0.1
 */