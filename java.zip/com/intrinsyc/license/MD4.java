package com.intrinsyc.license;

import com.intrinsyc.license.Acme.Crypto.a;

class MD4
{
  int[] a = new int[2];
  int[] b = new int[4];
  byte[] c = new byte[64];
  byte[] d = new byte[8];
  int e = 3;
  int f = 7;
  int g = 11;
  int h = 19;
  int i = 3;
  int j = 5;
  int k = 9;
  int l = 13;
  int m = 3;
  int n = 9;
  int o = 11;
  int p = 15;
  char[] q = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
  byte[] r = new byte[64];
  byte[] s = new byte[8];
  byte[] t = new byte[16];
  
  void a(int[] paramArrayOfInt, byte[] paramArrayOfByte, int paramInt)
  {
    int i1 = 0;
    int i2 = 0;
    if (LicenseException.a) {}
    while (i2 < paramInt)
    {
      paramArrayOfInt[i1] = 0;
      paramArrayOfInt[i1] = (paramArrayOfByte[(i2 + 3)] & 0xFF);
      paramArrayOfInt[i1] <<= 8;
      paramArrayOfInt[i1] |= paramArrayOfByte[(i2 + 2)] & 0xFF;
      paramArrayOfInt[i1] <<= 8;
      paramArrayOfInt[i1] |= paramArrayOfByte[(i2 + 1)] & 0xFF;
      paramArrayOfInt[i1] <<= 8;
      paramArrayOfInt[i1] |= paramArrayOfByte[(i2 + 0)] & 0xFF;
      i1++;
      i2 += 4;
    }
  }
  
  void a(byte[] paramArrayOfByte, int[] paramArrayOfInt, int paramInt)
  {
    int i1 = 0;
    int i2 = 0;
    if (LicenseException.a) {}
    while (i2 < paramInt)
    {
      paramArrayOfByte[i2] = ((byte)(paramArrayOfInt[i1] & 0xFF));
      paramArrayOfByte[(i2 + 1)] = ((byte)(paramArrayOfInt[i1] >> 8 & 0xFF));
      paramArrayOfByte[(i2 + 2)] = ((byte)(paramArrayOfInt[i1] >> 16 & 0xFF));
      paramArrayOfByte[(i2 + 3)] = ((byte)(paramArrayOfInt[i1] >> 24 & 0xFF));
      i1++;
      i2 += 4;
    }
  }
  
  void a()
  {
    this.a[0] = 0;
    this.a[1] = 0;
    this.b[0] = 1732584193;
    this.b[1] = -271733879;
    this.b[2] = -1732584194;
    this.b[3] = 271733878;
    this.r[0] = -128;
  }
  
  void a(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    int i1 = 0;
    if (LicenseException.a) {}
    while (i1 < paramInt2)
    {
      paramArrayOfInt[i1] = paramInt1;
      i1++;
    }
  }
  
  void a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    int i1 = 0;
    if (LicenseException.a) {}
    while (i1 < paramInt)
    {
      paramArrayOfByte1[i1] = paramArrayOfByte2[i1];
      i1++;
    }
  }
  
  void a(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, int paramInt3)
  {
    int i1 = 0;
    if (LicenseException.a) {}
    while (i1 < paramInt3)
    {
      paramArrayOfByte1[(i1 + paramInt1)] = paramArrayOfByte2[(i1 + paramInt2)];
      i1++;
    }
  }
  
  int a(int paramInt1, int paramInt2, int paramInt3)
  {
    return paramInt1 & paramInt2 | (paramInt1 ^ 0xFFFFFFFF) & paramInt3;
  }
  
  int b(int paramInt1, int paramInt2, int paramInt3)
  {
    return paramInt1 & paramInt2 | paramInt1 & paramInt3 | paramInt2 & paramInt3;
  }
  
  int c(int paramInt1, int paramInt2, int paramInt3)
  {
    return paramInt1 ^ paramInt2 ^ paramInt3;
  }
  
  int a(int paramInt1, int paramInt2)
  {
    return paramInt1 << paramInt2 | paramInt1 >>> 32 - paramInt2;
  }
  
  int a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    paramInt1 += a(paramInt2, paramInt3, paramInt4) + paramInt5;
    paramInt1 = a(paramInt1, paramInt6);
    return paramInt1;
  }
  
  int b(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    paramInt1 += b(paramInt2, paramInt3, paramInt4) + paramInt5 + 1518500249;
    paramInt1 = a(paramInt1, paramInt6);
    return paramInt1;
  }
  
  int c(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    paramInt1 += c(paramInt2, paramInt3, paramInt4) + paramInt5 + 1859775393;
    paramInt1 = a(paramInt1, paramInt6);
    return paramInt1;
  }
  
  void a(int[] paramArrayOfInt, byte[] paramArrayOfByte)
  {
    boolean bool = LicenseException.a;
    int i1 = paramArrayOfInt[0];
    int i2 = paramArrayOfInt[1];
    int i3 = paramArrayOfInt[2];
    int i4 = paramArrayOfInt[3];
    int[] arrayOfInt = new int[16];
    a(arrayOfInt, paramArrayOfByte, 64);
    i1 = a(i1, i2, i3, i4, arrayOfInt[0], this.e);
    i4 = a(i4, i1, i2, i3, arrayOfInt[1], this.f);
    i3 = a(i3, i4, i1, i2, arrayOfInt[2], this.g);
    i2 = a(i2, i3, i4, i1, arrayOfInt[3], this.h);
    i1 = a(i1, i2, i3, i4, arrayOfInt[4], this.e);
    i4 = a(i4, i1, i2, i3, arrayOfInt[5], this.f);
    i3 = a(i3, i4, i1, i2, arrayOfInt[6], this.g);
    i2 = a(i2, i3, i4, i1, arrayOfInt[7], this.h);
    i1 = a(i1, i2, i3, i4, arrayOfInt[8], this.e);
    i4 = a(i4, i1, i2, i3, arrayOfInt[9], this.f);
    i3 = a(i3, i4, i1, i2, arrayOfInt[10], this.g);
    i2 = a(i2, i3, i4, i1, arrayOfInt[11], this.h);
    i1 = a(i1, i2, i3, i4, arrayOfInt[12], this.e);
    i4 = a(i4, i1, i2, i3, arrayOfInt[13], this.f);
    i3 = a(i3, i4, i1, i2, arrayOfInt[14], this.g);
    i2 = a(i2, i3, i4, i1, arrayOfInt[15], this.h);
    i1 = b(i1, i2, i3, i4, arrayOfInt[0], this.i);
    i4 = b(i4, i1, i2, i3, arrayOfInt[4], this.j);
    i3 = b(i3, i4, i1, i2, arrayOfInt[8], this.k);
    i2 = b(i2, i3, i4, i1, arrayOfInt[12], this.l);
    i1 = b(i1, i2, i3, i4, arrayOfInt[1], this.i);
    i4 = b(i4, i1, i2, i3, arrayOfInt[5], this.j);
    i3 = b(i3, i4, i1, i2, arrayOfInt[9], this.k);
    i2 = b(i2, i3, i4, i1, arrayOfInt[13], this.l);
    i1 = b(i1, i2, i3, i4, arrayOfInt[2], this.i);
    i4 = b(i4, i1, i2, i3, arrayOfInt[6], this.j);
    i3 = b(i3, i4, i1, i2, arrayOfInt[10], this.k);
    i2 = b(i2, i3, i4, i1, arrayOfInt[14], this.l);
    i1 = b(i1, i2, i3, i4, arrayOfInt[3], this.i);
    i4 = b(i4, i1, i2, i3, arrayOfInt[7], this.j);
    i3 = b(i3, i4, i1, i2, arrayOfInt[11], this.k);
    i2 = b(i2, i3, i4, i1, arrayOfInt[15], this.l);
    i1 = c(i1, i2, i3, i4, arrayOfInt[0], this.m);
    i4 = c(i4, i1, i2, i3, arrayOfInt[8], this.n);
    i3 = c(i3, i4, i1, i2, arrayOfInt[4], this.o);
    i2 = c(i2, i3, i4, i1, arrayOfInt[12], this.p);
    i1 = c(i1, i2, i3, i4, arrayOfInt[2], this.m);
    i4 = c(i4, i1, i2, i3, arrayOfInt[10], this.n);
    i3 = c(i3, i4, i1, i2, arrayOfInt[6], this.o);
    i2 = c(i2, i3, i4, i1, arrayOfInt[14], this.p);
    i1 = c(i1, i2, i3, i4, arrayOfInt[1], this.m);
    i4 = c(i4, i1, i2, i3, arrayOfInt[9], this.n);
    i3 = c(i3, i4, i1, i2, arrayOfInt[5], this.o);
    i2 = c(i2, i3, i4, i1, arrayOfInt[13], this.p);
    i1 = c(i1, i2, i3, i4, arrayOfInt[3], this.m);
    i4 = c(i4, i1, i2, i3, arrayOfInt[11], this.n);
    i3 = c(i3, i4, i1, i2, arrayOfInt[7], this.o);
    i2 = c(i2, i3, i4, i1, arrayOfInt[15], this.p);
    paramArrayOfInt[0] += i1;
    paramArrayOfInt[1] += i2;
    paramArrayOfInt[2] += i3;
    paramArrayOfInt[3] += i4;
    a(arrayOfInt, 0, 16);
    if (bool)
    {
      int i5 = a.a;
      i5++;
      a.a = i5;
    }
  }
  
  void b(int[] paramArrayOfInt, byte[] paramArrayOfByte, int paramInt)
  {
    boolean bool = LicenseException.a;
    byte[] arrayOfByte = new byte[256];
    int i1 = paramInt;
    int i2 = 0;
    if (bool) {}
    do
    {
      do
      {
        arrayOfByte[i2] = paramArrayOfByte[i1];
        i1++;
        i2++;
      } while (i1 < 256);
      a(paramArrayOfInt, arrayOfByte);
    } while (bool);
  }
  
  void a(String paramString, int paramInt)
  {
    byte[] arrayOfByte = new byte[paramString.length()];
    paramString.getBytes(0, paramString.length(), arrayOfByte, 0);
    a(arrayOfByte, paramString.length());
  }
  
  void a(byte[] paramArrayOfByte, int paramInt)
  {
    boolean bool = LicenseException.a;
    int i2 = this.a[0] >> 3 & 0x3F;
    if (!bool)
    {
      if (this.a[0] += (paramInt << 3) < paramInt << 3) {
        this.a[1] += 1;
      }
      this.a[1] += (paramInt >> 29);
    }
    int i3 = 64 - i2;
    if (!bool) {
      if (paramInt >= i3)
      {
        a(this.c, i2, paramArrayOfByte, 0, i3);
        a(this.b, this.c);
        i1 = i3;
        if (bool) {}
        do
        {
          do
          {
            b(this.b, paramArrayOfByte, i1);
            i1 += 64;
          } while (i1 + 63 < paramInt);
          i2 = 0;
        } while (bool);
        if (!bool) {
          break label153;
        }
      }
    }
    int i1 = 0;
    label153:
    a(this.c, i2, paramArrayOfByte, i1, paramInt - i1);
  }
  
  byte[] b()
  {
    boolean bool = LicenseException.a;
    byte[] arrayOfByte = new byte[8];
    a(arrayOfByte, this.a, 8);
    int i1 = this.a[0] >> 3 & 0x3F;
    if (!bool) {}
    int i2 = i1 < 56 ? 56 - i1 : 120 - i1;
    a(this.r, i2);
    a(arrayOfByte, 8);
    a(this.t, this.b, 16);
    int tmp125_124 = (this.b[0] = this.b[1] = this.b[2] = this.b[3] = 0);
    this.a[1] = tmp125_124;
    this.a[0] = tmp125_124;
    i1 = 0;
    if (bool) {}
    do
    {
      do
      {
        this.c[i1] = 0;
        i1++;
      } while (i1 < 64);
    } while (bool);
    return this.t;
  }
  
  void c()
  {
    a();
    a(this.d, 8);
    b();
    this.d[0] = ((byte)(this.t[0] ^ this.t[8]));
    this.d[1] = ((byte)(this.t[1] ^ this.t[9]));
    this.d[2] = ((byte)(this.t[2] ^ this.t[10]));
    this.d[3] = ((byte)(this.t[3] ^ this.t[11]));
    this.d[4] = ((byte)(this.t[4] ^ this.t[12]));
    this.d[5] = ((byte)(this.t[5] ^ this.t[13]));
    this.d[6] = ((byte)(this.t[6] ^ this.t[14]));
    this.d[7] = ((byte)(this.t[7] ^ this.t[15]));
  }
  
  void a(String paramString1, String paramString2)
  {
    boolean bool = LicenseException.a;
    StringBuffer localStringBuffer = new StringBuffer(paramString1);
    byte[] arrayOfByte = new byte[paramString1.length() + paramString2.length()];
    localStringBuffer.append(paramString2);
    String str = localStringBuffer.toString();
    str.getBytes(0, str.length(), arrayOfByte, 0);
    a();
    a(arrayOfByte, arrayOfByte.length);
    b();
    this.d[0] = ((byte)(this.t[0] ^ this.t[8]));
    this.d[1] = ((byte)(this.t[1] ^ this.t[9]));
    this.d[2] = ((byte)(this.t[2] ^ this.t[10]));
    this.d[3] = ((byte)(this.t[3] ^ this.t[11]));
    this.d[4] = ((byte)(this.t[4] ^ this.t[12]));
    this.d[5] = ((byte)(this.t[5] ^ this.t[13]));
    this.d[6] = ((byte)(this.t[6] ^ this.t[14]));
    this.d[7] = ((byte)(this.t[7] ^ this.t[15]));
    if (a.a != 0) {
      LicenseException.a = !bool;
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.MD4
 * JD-Core Version:    0.7.0.1
 */