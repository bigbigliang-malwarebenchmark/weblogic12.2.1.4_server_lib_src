package com.intrinsyc.license;

import com.linar.jintegra.Version;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.text.DateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public class JintegraLicenseTool
  implements b
{
  protected static final String a = "\t-8\001";
  protected static final String b = "\n49\0270\032";
  protected static final String c = "\r!0\0312\032";
  protected static final String d = "\026*.\002%\023(";
  protected static final String e = "\034(8\027*";
  protected static final String f = "\f*4\0064\0320s\016)\023";
  protected static final String g = "\025-3\002!\0306<X<\022(";
  protected static final String h = "\025-3\002!\0306<X.\0366";
  protected static final String i = "\034+0Y-\0210/\037*\f=>Y(\026'8\0307\032k7\037*\013!:\004%Q<0\032";
  protected static final String j = "\025-3\002!\0306<)6\032 (\025!\033\0331\031#\030-3\021j\025%/";
  protected static final String k = "";
  protected static final String l = "";
  protected static final String m = "+,8\004!_-.V*\020d1\037'\032*.\023d\026*}";
  protected static final String n = "6\007\016)\020:\t\r";
  protected static final String o = "_d}Vd_x-\004+\0331>\002d\021%0\023y";
  protected static final String p = "_-9Kf]z";
  protected static final String q = "_d}Vd_xr\0066\020 (\0250A";
  protected static final String r = "_d";
  protected static final String s = "_d}VxP-3\0050\036(1\023  4/\031 \n')\005z";
  protected static final String t = "_d}Vd_x1\037'\032*.\023z";
  protected static final String u = "_d}Vd_x9\0270\036uc";
  protected static final String v = "_d}Vd_x9\0270\036vc";
  protected static final String w = "_d}Vx\01762\0221\0340}\030%\022!`";
  protected static final String x = "_d}VxP4/\031 \n')H";
  protected String y = System.getProperty(h("\n78\004j\033-/"));
  
  protected void a(String[] paramArrayOfString)
  {
    b(paramArrayOfString);
  }
  
  private void b(String[] paramArrayOfString)
  {
    boolean bool = LicenseException.a;
    if (!bool) {
      if (paramArrayOfString.length == 0)
      {
        System.err.println(h(""));
        return;
      }
    }
    if (!bool) {
      if (paramArrayOfString[0].equals(h("\t-8\001")))
      {
        a();
        if (!bool)
        {
          if (paramArrayOfString.length == 2)
          {
            System.err.println(h("<,8\025/\026*:V.\0366}\020-\023!}") + paramArrayOfString[1] + h("Qjs"));
            if (!bool)
            {
              if (d(paramArrayOfString[1])) {
                break label263;
              }
              System.err.println(h("+,8\004!_-.V*\020d1\037'\032*.\023d\026*}") + paramArrayOfString[1] + ".");
              System.err.println(h(""));
            }
          }
          else
          {
            System.err.println(h("<,8\025/\026*:V.\0366}\020-\023!}\034-\02108\0216\036j7\0276Qjs"));
          }
        }
        else
        {
          if (!bool)
          {
            if (!d(h("\025-3\002!\0306<X.\0366")))
            {
              System.err.println(h("+,8\004!_-.V*\020d1\037'\032*.\023d\026*}\034-\02108\0216\036j7\0276Q"));
              System.err.println(h(""));
              return;
            }
            System.err.println(h("<,8\025/\026*:V.\0366}\020-\023!}\034-\02108\0216\036\033/\023 \n'8\022\033\023+:\021-\021#s\034%\rjsX"));
            if (bool) {}
          }
          else
          {
            if (d(h("\025-3\002!\0306<)6\032 (\025!\033\0331\031#\030-3\021j\025%/"))) {
              break label263;
            }
            System.err.println(h("+,8\004!_-.V*\020d1\037'\032*.\023d\026*}\034-\02108\0216\036\033/\023 \n'8\022\033\023+:\021-\021#s\034%\rj"));
            System.err.println(h(""));
          }
          return;
        }
        try
        {
          label263:
          JintegraLicenseManager localJintegraLicenseManager = new JintegraLicenseManager();
          localJintegraLicenseManager.a();
          SecureVector localSecureVector = (SecureVector)Container.getValue(h("\004td2|>}kFiG}\030DiK|l@iFwe4iOqdD\007;}iGuJw "));
          System.err.println();
          System.err.println(h("6*.\002%\023(8\022d\01762\0221\0340.L"));
          System.err.println(h(" \033\002)\033 \033\002)\033 \033\002)\033 \033\002)\033 \033\002)\033 \033\002)\033 \033\002)\033 \033\002)\033 \033\002)"));
          int i1 = 0;
          if (bool) {}
          while (i1 < localSecureVector.a(this))
          {
            JintegraProductSpecificLicenseImpl localJintegraProductSpecificLicenseImpl = (JintegraProductSpecificLicenseImpl)localSecureVector.a(this, i1);
            a(localJintegraProductSpecificLicenseImpl);
            System.err.println(h(" \033\002)\033 \033\002)\033 \033\002)\033 \033\002)\033 \033\002)\033 \033\002)\033 \033\002)\033 \033\002)\033 \033\002)"));
            i1++;
          }
        }
        catch (Exception localException1)
        {
          System.err.println(h("**<\024(\032d)\031d\023+>\0270\032d<V2\036(4\022d\023->\023*\f!s"));
          System.err.println(h(""));
          System.exit(0);
          if (!bool) {
            return;
          }
        }
      }
    }
    if (!bool) {
      if (paramArrayOfString[0].equals(h("\n49\0270\032")))
      {
        System.err.println(h(",+/\004=Sd)\036!_1-\022%\013!}\025+\022)<\030 _,<\005d\035!8\030d\033!-\004!\034%)\023 Q"));
        System.err.println(h("/(8\0277\032d(\005!_05\023d\034(8\027*_%3\022d\026*.\002%\023(}\025+\022)<\030 \fd4\0307\013!<\022j"));
        if (!bool) {
          return;
        }
      }
    }
    if (!bool)
    {
      if (paramArrayOfString[0].equals(h("\r!0\0312\032")))
      {
        System.err.println(h(",+/\004=Sd)\036!_68\033+\t!}\025+\022)<\030 _,<\005d\035!8\030d\033!-\004!\034%)\023 Q"));
        System.err.println(h("/(8\0277\032d(\005!_05\023d\034(8\027*_'2\033)\036*9V-\0217)\023%\033j"));
        if (!bool) {
          return;
        }
      }
      if (bool) {}
    }
    else if (paramArrayOfString[0].equals(h("\026*.\002%\023(")))
    {
      try
      {
        a();
        System.err.println(h("+6$\037*\030d)\031d6*.\002%\023(}:-\034!3\005!_\"4\032!Qjs"));
        if (!bool)
        {
          if (paramArrayOfString.length == 2)
          {
            System.err.println(h("*49\0270\026*:V") + paramArrayOfString[1] + h("QjsX"));
            c(paramArrayOfString[1]);
            if (!bool) {}
          }
          else
          {
            System.err.println(h("*49\0270\026*:V.\026*)\023#\r%s\034%\rjsXj"));
            c(h("\025-3\002!\0306<X.\0366"));
            System.err.println(h("*49\0270\026*:V.\026*)\023#\r%\002\004!\0331>\023  (2\021#\026*:X.\0366sXjQ"));
          }
        }
        else {
          c(h("\025-3\002!\0306<)6\032 (\025!\033\0331\031#\030-3\021j\025%/"));
        }
        d();
        System.err.println(h(""));
      }
      catch (Exception localException2)
      {
        System.err.println(h(">*}36\r+/V,\0367}\031'\0341/\023 Ed") + localException2.getMessage());
        localException2.printStackTrace();
        if (!bool) {
          return;
        }
      }
    }
    if ((bool) || (paramArrayOfString[0].equals(h("\034(8\027*"))))
    {
      try
      {
        a();
        System.err.println(h("+6$\037*\030d)\031d<(8\027*_\b4\025!\02178V\"\026(8XjQ"));
        if (!bool)
        {
          if (paramArrayOfString.length == 2)
          {
            System.err.println(h("<(8\027*\026*:XjQd") + paramArrayOfString[1] + h("QjsX"));
            g(paramArrayOfString[1]);
            if (!bool) {}
          }
          else
          {
            System.err.println(h("*49\0270\026*:V.\026*)\023#\r%s\034%\rjsXj"));
            g(h("\025-3\002!\0306<X.\0366"));
            System.err.println(h("*49\0270\026*:V.\026*)\023#\r%\002\004!\0331>\023  (2\021#\026*:X.\0366sXjQ"));
          }
        }
        else {
          g(h("\025-3\002!\0306<)6\032 (\025!\033\0331\031#\030-3\021j\025%/"));
        }
      }
      catch (Exception localException3)
      {
        System.err.println(h(">*}36\r+/V,\0367}\031'\0341/\023 Ed") + localException3.getMessage());
        localException3.printStackTrace();
        if (!bool) {
          return;
        }
      }
    }
    else
    {
      System.err.println(h("6*+\027(\026 }94\013-2\030~_") + paramArrayOfString[0]);
      System.err.println(h(""));
      return;
    }
  }
  
  private void a(JintegraProductSpecificLicenseImpl paramJintegraProductSpecificLicenseImpl)
  {
    System.err.println(h("/62\0221\0340}Vd_d}Vd_~}V") + paramJintegraProductSpecificLicenseImpl.a);
    System.err.println(h("3->\023*\f!} !\r74\031*_~}V") + paramJintegraProductSpecificLicenseImpl.e.d);
    System.err.println(h("-13\002-\022!} !\r74\031*_~}V") + Version.getVersion());
    System.err.println(h("3->\023*\f!9V0\020d}Vd_~}V") + paramJintegraProductSpecificLicenseImpl.b);
    System.err.println(h(",!/\037%\023d~Vd_d}Vd_~}V") + paramJintegraProductSpecificLicenseImpl.c);
    System.err.println(h("3->\023*\f!}\"=\017!}Vd_~}V") + paramJintegraProductSpecificLicenseImpl.e.b);
    if (paramJintegraProductSpecificLicenseImpl.e.b.equals(h("+64\027(")))
    {
      System.err.println(h("+64\027(_\0248\004-\020 }Vd_~}V") + paramJintegraProductSpecificLicenseImpl.i + h("_ <\0177"));
      if (a(paramJintegraProductSpecificLicenseImpl.e.c, paramJintegraProductSpecificLicenseImpl.i)) {
        System.err.println(h(",0<\0021\fd}Vd_d}Vd_~}V\001'\024\024$\001;dpV\024\023!<\005!_#2\002+_,)\0024Ekr\034i\026*)\023#\r%s\037*\01364\0307\006's\025+\022k}\002+_4(\004'\027%.\023d\036d1\037'\032*.\023"));
      }
    }
    Date localDate = new Date(Long.parseLong(paramJintegraProductSpecificLicenseImpl.e.c));
    System.err.println(h(";%)\023d\020\"}?7\f18Vd_~}V") + DateFormat.getDateInstance(1).format(localDate));
  }
  
  private void a()
  {
    System.err.println(h("5i\024\0300\032#/\027d\t") + Version.getVersion() + h("_l>_d6*)\004-\0217$\025d,+;\0023\03668V\r\02108\004*\03604\031*\036(qV\r\021'sV,\0130-LkP.p\037*\013!:\004%Q-3\0026\026*.\017'Q'2\033k"));
  }
  
  private boolean a(String paramString, int paramInt)
  {
    try
    {
      Date localDate1 = new Date(Long.parseLong(paramString));
      Date localDate2 = new Date();
      long l1 = (localDate2.getTime() - localDate1.getTime()) / 1000L;
      long l2 = paramInt * 24 * 60 * 60;
      return l1 > l2;
    }
    catch (NumberFormatException localNumberFormatException) {}
    return true;
  }
  
  public static void main(String[] paramArrayOfString)
  {
    try
    {
      JintegraLicenseTool localJintegraLicenseTool = new JintegraLicenseTool();
      localJintegraLicenseTool.a(paramArrayOfString);
      localJintegraLicenseTool = null;
    }
    catch (Exception localException)
    {
      System.err.println(h(":<>\0234\013-2\030e_\0241\023%\f!}\025+\0210<\0250_\r3\0026\026*.\017'Sd5\0020\017~rY.R-3\002!\0306<X-\0210/\037*\f=>X'\020)r"));
      System.err.println(h(":<>\0234\013-2\030d2!.\005%\030!gV") + localException.getMessage());
      localException.printStackTrace();
    }
  }
  
  private void a(String paramString)
    throws FileNotFoundException, IOException
  {
    boolean bool = LicenseException.a;
    String str1 = JintegraHelpers.e(h("\025-3\002!\0306<X<\022("));
    if (!bool)
    {
      if (null == str1)
      {
        System.err.println(h(""));
        System.err.println(h(""));
      }
    }
    else {
      System.exit(0);
    }
    String str2 = h("_d}Vd_x-\004+\0331>\002d\021%0\023y]") + paramString + "\"" + h("_-9Kf]z");
    File localFile1 = new File(str1 + JintegraHelpers.e + h("\025-3\002!\0306<X<\022("));
    FileInputStream localFileInputStream = new FileInputStream(localFile1);
    BufferedInputStream localBufferedInputStream = new BufferedInputStream(localFileInputStream);
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localBufferedInputStream));
    File localFile2 = new File(str1 + JintegraHelpers.e + h("6\007\016)\020:\t\r"));
    if (!bool) {
      if (localFile2.exists()) {
        localFile2.delete();
      }
    }
    localFile2.createNewFile();
    FileOutputStream localFileOutputStream = new FileOutputStream(localFile2);
    BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(localFileOutputStream);
    BufferedWriter localBufferedWriter = new BufferedWriter(new OutputStreamWriter(localBufferedOutputStream));
    int i1 = 1;
    int i2 = 0;
    if (bool) {}
    label298:
    do
    {
      String str3 = localBufferedReader.readLine();
      if (null == str3) {
        break;
      }
      if (!bool) {
        if (str3.equals(str2))
        {
          i2 = 1;
          i1 = 0;
        }
      }
      do
      {
        if (!bool) {
          if (i1 != 0)
          {
            str3 = str3 + "\n";
            localBufferedWriter.write(str3, 0, str3.length());
          }
        }
        if (i1 != 0) {
          break;
        }
        if (bool) {
          break label298;
        }
        if (!str3.equals(h("_d}Vd_xr\0066\020 (\0250A"))) {
          break;
        }
        i1 = 1;
      } while (bool);
    } while (!bool);
    localBufferedWriter.flush();
    localBufferedReader.close();
    localBufferedInputStream.close();
    localFileInputStream.close();
    localFileOutputStream.close();
    localBufferedOutputStream.close();
    localBufferedWriter.close();
    localBufferedWriter = null;
    localBufferedReader = null;
    localBufferedInputStream = null;
    localFileInputStream = null;
    localFileOutputStream = null;
    localBufferedOutputStream = null;
    localBufferedWriter = null;
    System.gc();
    localFile1.delete();
    localFile2.renameTo(localFile1);
    if (!bool)
    {
      if (i2 == 0)
      {
        System.err.println(h("/62\0221\0340gV") + paramString + h("_*2\002d9+(\030 Q"));
        System.err.println(h(":<4\002-\021#sXjQ"));
      }
    }
    else
    {
      System.exit(0);
      if (!bool) {
        return;
      }
    }
    System.err.println(h("/62\0221\0340gV") + paramString + h("_68\033+\t!9X"));
  }
  
  private void b()
    throws FileNotFoundException, IOException
  {
    boolean bool = LicenseException.a;
    String str1 = JintegraHelpers.e(h("\025-3\002!\0306<X<\022("));
    if (!bool)
    {
      if (null == str1)
      {
        System.err.println(h(""));
        System.err.println(h(""));
      }
    }
    else {
      System.exit(0);
    }
    Vector localVector = new Vector();
    Object localObject1 = null;
    File localFile1 = new File(str1 + JintegraHelpers.e + h("\f*4\0064\0320s\016)\023"));
    if (!bool)
    {
      if (!localFile1.exists())
      {
        System.err.println(h(""));
        System.err.println(h(":*.\0036\032d)\036%\013d)\036!_73\0374\017!)V\"\026(8V7\021--\006!\013j%\033(_-.V-\021d)\036!_7<\033!"));
        System.err.println(h("\033-/\023'\013+/\017d\0367}\017+\n6}\034%\rd;\037(\032l._~_.4\0300\032#/\027j\025%/V%\021 }\034-\02108\0216\036\033/\023 \n'8\022\033\023+:\021-\021#s\034%\r"));
      }
    }
    else {
      System.exit(0);
    }
    FileInputStream localFileInputStream1 = new FileInputStream(localFile1);
    BufferedInputStream localBufferedInputStream1 = new BufferedInputStream(localFileInputStream1);
    BufferedReader localBufferedReader1 = new BufferedReader(new InputStreamReader(localBufferedInputStream1));
    int i1 = 1;
    int i2 = 1;
    JintegraLicenseTool.ProdSnippetInfo localProdSnippetInfo1 = new JintegraLicenseTool.ProdSnippetInfo(this);
    do
    {
      localObject2 = localBufferedReader1.readLine();
      if (null == localObject2) {
        break;
      }
      if (!bool) {
        if (3 == i1) {
          localObject1 = localObject2;
        }
      }
      if (!bool)
      {
        if (a(h("_d}Vx\01762\0221\0340}\030%\022!`"), (String)localObject2))
        {
          localProdSnippetInfo1.a = (h("_d") + (String)localObject2);
          i2 = 0;
        }
        if (bool) {}
      }
      else if (a(h("_d}Vd_x1\037'\032*.\023z"), (String)localObject2))
      {
        localProdSnippetInfo1.b = (h("_d") + (String)localObject2);
      }
      if (!bool) {
        if (a(h("_d}Vd_x9\0270\036uc"), (String)localObject2)) {
          localProdSnippetInfo1.c = (h("_d") + (String)localObject2);
        }
      }
      if (!bool) {
        if (a(h("_d}Vd_x9\0270\036vc"), (String)localObject2)) {
          localProdSnippetInfo1.d = (h("_d") + (String)localObject2);
        }
      }
      if (((String)localObject2).equals(h("_d}VxP4/\031 \n')H")))
      {
        localProdSnippetInfo1.e = (h("_d") + (String)localObject2);
        localVector.addElement(localProdSnippetInfo1);
        localProdSnippetInfo1 = new JintegraLicenseTool.ProdSnippetInfo(this);
      }
      i1++;
    } while (!bool);
    if (!bool)
    {
      if (i2 != 0)
      {
        System.err.println(h("+,8\004!_%-\006!\0366.V0\020d?\023d\f+0\0230\027-3\021d\b62\030#_34\002,"));
        System.err.println(h("\006+(\004d\f*4\0064\0320}\020-\023!gV7\021--\006!\013j%\033("));
        System.err.println(h("/(8\0277\032d>\031*\013%>\002d6*)\004-\0217$\025d\013+}\021!\013d<V*\0323}\031*\032j"));
      }
    }
    else {
      System.exit(0);
    }
    str1 = JintegraHelpers.e(h("\025-3\002!\0306<X<\022("));
    if (!bool)
    {
      if (null == str1)
      {
        System.err.println(h(""));
        System.err.println(h(""));
      }
    }
    else {
      System.exit(0);
    }
    Object localObject2 = new File(str1 + JintegraHelpers.e + h("\025-3\002!\0306<X<\022("));
    FileInputStream localFileInputStream2 = new FileInputStream((File)localObject2);
    BufferedInputStream localBufferedInputStream2 = new BufferedInputStream(localFileInputStream2);
    BufferedReader localBufferedReader2 = new BufferedReader(new InputStreamReader(localBufferedInputStream2));
    File localFile2 = new File(str1 + JintegraHelpers.e + h("6\007\016)\020:\t\r"));
    if (!bool) {
      if (localFile2.exists()) {
        localFile2.delete();
      }
    }
    localFile2.createNewFile();
    FileOutputStream localFileOutputStream = new FileOutputStream(localFile2);
    BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(localFileOutputStream);
    BufferedWriter localBufferedWriter = new BufferedWriter(new OutputStreamWriter(localBufferedOutputStream));
    int i3 = 1;
    int i4 = 0;
    i1 = 1;
    if (bool) {}
    label927:
    label1535:
    do
    {
      String str2 = localBufferedReader2.readLine();
      if (null == str2) {
        break;
      }
      int i5;
      JintegraLicenseTool.ProdSnippetInfo localProdSnippetInfo2;
      if (!bool)
      {
        if (9 == i1)
        {
          if (bool) {
            break label927;
          }
          if (!str2.equals(localObject1))
          {
            System.err.println(h("3->\023*\f!8V\r\021\"2\004)\03604\031*_\"2\003*\033d4\030d\f*4\0064\0320}\022+\0327}\030+\013"));
            System.err.println(h("2%)\025,_\b4\025!\02178\023d6*;\0316\022%)\037+\021d4\030d3->\023*\f!}0-\023!"));
            System.err.println(h("&+(\004d3->\023*\f!}\001-\023(}\030+\013d*\0316\024e"));
            System.err.println(h("/(8\0277\032d/\023\"\0326}\002+_=2\0036_4/\031 \n')V-\021\"2\004)\03604\031*"));
            System.err.println(h("\0206}\025+\0210<\0250_7(\0064\0206)Ld\0270)\006~Pk7[-\02108\0216\036j4\0300\r-3\005=\034j>\031)P"));
            localBufferedWriter.flush();
            localFileOutputStream.close();
            localBufferedOutputStream.close();
            localBufferedWriter.close();
            localBufferedWriter = null;
            localBufferedOutputStream = null;
            localFileOutputStream = null;
            System.gc();
            localFile2.delete();
            System.exit(0);
          }
        }
        if (bool) {}
      }
      else
      {
        if (a(h("_d}Vd_x-\004+\0331>\002d\021%0\023y"), str2))
        {
          i5 = 0;
          if (bool) {}
          while (i5 < localVector.size())
          {
            localProdSnippetInfo2 = (JintegraLicenseTool.ProdSnippetInfo)localVector.elementAt(i5);
            if (!bool)
            {
              if (localProdSnippetInfo2.a.equals(str2)) {
                i4 = 1;
              }
            }
            else
            {
              i3 = 0;
              localProdSnippetInfo2.a += "\n";
              localProdSnippetInfo2.b += "\n";
              localProdSnippetInfo2.c += "\n";
              localProdSnippetInfo2.d += "\n";
              localProdSnippetInfo2.e += "\n";
              localBufferedWriter.write(localProdSnippetInfo2.a, 0, localProdSnippetInfo2.a.length());
              localBufferedWriter.write(localProdSnippetInfo2.b, 0, localProdSnippetInfo2.b.length());
              localBufferedWriter.write(localProdSnippetInfo2.c, 0, localProdSnippetInfo2.c.length());
              localBufferedWriter.write(localProdSnippetInfo2.d, 0, localProdSnippetInfo2.d.length());
              localBufferedWriter.write(localProdSnippetInfo2.e, 0, localProdSnippetInfo2.e.length());
              localProdSnippetInfo2.f = true;
            }
            i5++;
          }
        }
        if (bool) {
          break label1535;
        }
      }
      if (str2.equals(h("_d}VxP-3\0050\036(1\023  4/\031 \n')\005z")))
      {
        if (bool) {
          break label1535;
        }
        if (i4 == 0)
        {
          i5 = 0;
          if (bool) {}
          while (i5 < localVector.size())
          {
            localProdSnippetInfo2 = (JintegraLicenseTool.ProdSnippetInfo)localVector.elementAt(i5);
            if (!bool)
            {
              if (!localProdSnippetInfo2.f)
              {
                localProdSnippetInfo2.a += "\n";
                localProdSnippetInfo2.b += "\n";
                localProdSnippetInfo2.c += "\n";
                localProdSnippetInfo2.d += "\n";
                localProdSnippetInfo2.e += "\n";
                localBufferedWriter.write(localProdSnippetInfo2.a, 0, localProdSnippetInfo2.a.length());
                localBufferedWriter.write(localProdSnippetInfo2.b, 0, localProdSnippetInfo2.b.length());
                localBufferedWriter.write(localProdSnippetInfo2.c, 0, localProdSnippetInfo2.c.length());
                localBufferedWriter.write(localProdSnippetInfo2.d, 0, localProdSnippetInfo2.d.length());
              }
            }
            else {
              localBufferedWriter.write(localProdSnippetInfo2.e, 0, localProdSnippetInfo2.e.length());
            }
            i5++;
          }
        }
      }
      if (!bool) {
        if (i3 != 0)
        {
          str2 = str2 + "\n";
          localBufferedWriter.write(str2, 0, str2.length());
        }
      }
      if (((bool) || (i3 == 0)) && ((bool) || (str2.equals(h("_d}Vd_xr\0066\020 (\0250A"))))) {
        i3 = 1;
      }
      i1++;
    } while (!bool);
    localBufferedWriter.flush();
    localBufferedReader2.close();
    localBufferedInputStream2.close();
    localFileInputStream2.close();
    localFileOutputStream.close();
    localBufferedOutputStream.close();
    localBufferedWriter.close();
    localBufferedReader1.close();
    localBufferedInputStream1.close();
    localFileInputStream1.close();
    localBufferedWriter = null;
    localBufferedReader2 = null;
    localBufferedInputStream2 = null;
    localFileInputStream2 = null;
    localFileOutputStream = null;
    localBufferedOutputStream = null;
    localBufferedWriter = null;
    localBufferedReader1 = null;
    localBufferedInputStream1 = null;
    localFileInputStream1 = null;
    System.gc();
    ((File)localObject2).delete();
    localFile2.renameTo((File)localObject2);
  }
  
  private boolean a(String paramString1, String paramString2)
  {
    if (paramString1.length() >= paramString2.length()) {
      return false;
    }
    String str = paramString2.substring(0, paramString1.length());
    return paramString2.substring(0, paramString1.length()).equals(paramString1);
  }
  
  private void b(String paramString)
    throws Exception
  {
    try
    {
      String str = JintegraHelpers.f(paramString);
      if (str == null)
      {
        System.err.println(h("5%/V\"\026(8Ld") + paramString + h("_*2\002d9+(\030 ^"));
        System.err.println(h("/(8\0277\032d8\0307\n68V0\027%)V0\027!}\034%\rd;\037(\032d") + paramString + h("_-.V-\021d)\036!_7<\033!_ 4\004!\03402\004=_%.V(\026'8\0307\032d;\037(\032l._"));
        System.err.println(h("/(8\0277\032d/\023\"\0326}\002+_05\023d\033+>\003)\032*)\0270\026+3V+\rd:\0310\020d5\0020\017~rY.R-3\002!\0306<X-\0210/\037*\f=>X'\020)rV\"\0206}\0277\f-.\002%\021'8"));
        System.err.println(h("+,8V0\020+1V-\fd8\016-\013-3\021d\021+*XjQd)\036!\r!}\033%\006d?\023d\023!;\002+\t!/V0\032)-\0316\0366$V\"\026(8\005jQj"));
        System.exit(0);
      }
      File localFile1 = new File(str);
      JarFile localJarFile = new JarFile(localFile1);
      JarEntry localJarEntry = localJarFile.getJarEntry(h("\034+0Y-\0210/\037*\f=>Y(\026'8\0307\032k7\037*\013!:\004%Q<0\032"));
      if (localJarEntry == null)
      {
        System.err.println(h("1+}\032-\034!3\005!_\"2\003*\033d4\030d\025%/V\"\026(8Ld") + paramString);
        System.err.println(h("/!/\036%\0177}\017+\nd*\027*\013d)\031d\026*.\002%\023(}\027d\023->\023*\f!}\020-\023!bI"));
        System.err.println(h(""));
        System.exit(0);
      }
      File localFile2 = new File(this.y + JintegraHelpers.e + h("\025-3\002!\0306<X<\022("));
      FileOutputStream localFileOutputStream = new FileOutputStream(localFile2);
      InputStream localInputStream = localJarFile.getInputStream(localJarEntry);
      byte[] arrayOfByte = new byte[1024];
      int i1;
      while ((i1 = localInputStream.read(arrayOfByte)) != -1) {
        localFileOutputStream.write(arrayOfByte, 0, i1);
      }
      localJarFile.close();
      localJarEntry = null;
      localInputStream.close();
      localInputStream = null;
      localFileOutputStream.flush();
      localFileOutputStream.close();
      localFileOutputStream = null;
    }
    catch (Exception localException)
    {
      throw localException;
    }
  }
  
  private void c()
  {
    String str = JintegraHelpers.f(h("\025-3\002!\0306<X<\022("));
    File localFile;
    if (str != null)
    {
      localFile = new File(str);
      if (localFile.exists()) {
        localFile.delete();
      }
    }
    str = JintegraHelpers.f(h("\f*4\0064\0320s\016)\023"));
    if (str != null)
    {
      localFile = new File(str);
      if (localFile.exists()) {
        localFile.delete();
      }
    }
  }
  
  private void d()
  {
    String str = JintegraHelpers.f(h("\025-3\002!\0306<X<\022("));
    if (str != null)
    {
      File localFile = new File(str);
      if (localFile.exists()) {
        localFile.delete();
      }
    }
  }
  
  private void c(String paramString)
    throws Exception
  {
    try
    {
      if (d(paramString))
      {
        System.err.println(h(">d1\037'\032*.\023d\031-1\023d\0267}\027(\r!<\022=_-3\0050\036(1\023 _-3V") + paramString);
        System.err.println(h("/(8\0277\032d(\005!_05\023d\034(8\027*_'2\033)\036*9V0\020d/\023)\02028V0\027!}\023<\0267)\037*\030d1\037'\032*.\023d\035!;\0316\032d<\0020\032)-\002-\021#}\002+_-3\0050\036(1V0\027!}\030!\bd2\030!Q"));
        System.exit(0);
      }
      e(paramString);
    }
    catch (ZipException localZipException)
    {
      System.err.print(h("u\001/\004+\r~}\",\032d3\027)\032d2\020d5%/V\"\026(8V-\fdz") + paramString + h("Xj"));
      System.err.println(h("_\t<\035!_7(\004!_-)Q7_05\023d\021%0\023d\020\"}\034%\rd;\037(\032d<\030 _05\023d\025%/V\"\026(8V-\fd3\0310_'2\0046\n4)\023 QN"));
      throw localZipException;
    }
    catch (Exception localException)
    {
      throw localException;
    }
  }
  
  private boolean d(String paramString)
  {
    try
    {
      String str = JintegraHelpers.f(paramString);
      if (str == null)
      {
        System.err.println(h("5%/V\"\026(8Ld") + paramString + h("_*2\002d9+(\030 ^"));
        System.err.println(h("/(8\0277\032d8\0307\n68V0\027%)V0\027!}\034%\rd;\037(\032d") + paramString + h("_-.V-\021d)\036!_7<\033!_ 4\004!\03402\004=_%.V0\027!}\034-\02108\0216\036j%\033(_\"4\032!Q"));
        System.exit(0);
      }
      File localFile = new File(str);
      JarFile localJarFile = new JarFile(localFile);
      JarEntry localJarEntry = localJarFile.getJarEntry(h("\034+0Y-\0210/\037*\f=>Y(\026'8\0307\032k7\037*\013!:\004%Q<0\032"));
      return localJarEntry != null;
    }
    catch (Exception localException) {}
    return false;
  }
  
  private void e(String paramString)
    throws Exception
  {
    boolean bool = LicenseException.a;
    try
    {
      System.gc();
      String str1 = JintegraHelpers.f(paramString);
      if (!bool)
      {
        if (str1 == null)
        {
          System.err.println(h("5%/V\"\026(8Ld") + paramString + h("_*2\002d9+(\030 ^"));
          System.err.println(h("/(8\0277\032d8\0307\n68V0\027%)V0\027!}\034%\rd;\037(\032d") + paramString + h("_-.V-\021d)\036!_7<\033!_ 4\004!\03402\004=_%.V0\027!}\034-\02108\0216\036j%\033(_\"4\032!Q"));
        }
      }
      else {
        System.exit(0);
      }
      File localFile1 = new File(str1);
      File localFile2 = new File(str1 + h("Q00\006"));
      String str2 = JintegraHelpers.f(h("\025-3\002!\0306<X<\022("));
      if (!bool)
      {
        if (null == str2)
        {
          System.err.println(h("3->\023*\f!}\020-\023!}\030+\013d;\0311\021 s"));
          System.err.println(h(""));
        }
      }
      else {
        System.exit(0);
      }
      File localFile3 = new File(str2);
      JarFile localJarFile = new JarFile(localFile1);
      Manifest localManifest = localJarFile.getManifest();
      JarOutputStream localJarOutputStream = new JarOutputStream(new FileOutputStream(localFile2));
      byte[] arrayOfByte = new byte[1024];
      FileInputStream localFileInputStream = new FileInputStream(localFile3);
      JarEntry localJarEntry1 = new JarEntry(h("\034+0Y-\0210/\037*\f=>Y(\026'8\0307\032k7\037*\013!:\004%Q<0\032"));
      localJarOutputStream.putNextEntry(localJarEntry1);
      int i1;
      while ((i1 = localFileInputStream.read(arrayOfByte)) != -1) {
        localJarOutputStream.write(arrayOfByte, 0, i1);
      }
      localFileInputStream.close();
      Enumeration localEnumeration = localJarFile.entries();
      if (bool) {}
      do
      {
        while (localEnumeration.hasMoreElements())
        {
          JarEntry localJarEntry2 = (JarEntry)localEnumeration.nextElement();
          while (!localJarEntry2.getName().equals(h("\034+0Y-\0210/\037*\f=>Y(\026'8\0307\032k7\037*\013!:\004%Q<0\032")))
          {
            InputStream localInputStream = localJarFile.getInputStream(localJarEntry2);
            localJarOutputStream.putNextEntry(localJarEntry2);
            if (!bool)
            {
              if (bool) {}
              while ((i1 = localInputStream.read(arrayOfByte)) != -1) {
                localJarOutputStream.write(arrayOfByte, 0, i1);
              }
            }
          }
        }
        localJarOutputStream.close();
      } while (bool);
      localManifest = null;
      localJarOutputStream = null;
      localFileInputStream = null;
      localFile3 = null;
      localJarFile.close();
      localJarFile = null;
      arrayOfByte = null;
      f(paramString);
    }
    catch (Exception localException)
    {
      throw localException;
    }
  }
  
  private void f(String paramString)
    throws Exception
  {
    try
    {
      System.gc();
      String str1 = JintegraHelpers.f(paramString);
      String str2 = JintegraHelpers.f(paramString + h("Q00\006"));
      FileInputStream localFileInputStream = new FileInputStream(str2);
      FileOutputStream localFileOutputStream = new FileOutputStream(str1);
      byte[] arrayOfByte = new byte[1024];
      do
      {
        int i1;
        do
        {
          localFileOutputStream.write(arrayOfByte, 0, i1);
        } while ((i1 = localFileInputStream.read(arrayOfByte)) != -1);
        localFileInputStream.close();
      } while (LicenseException.a);
      localFileOutputStream.close();
      localFileInputStream = null;
      localFileOutputStream = null;
      System.gc();
      new File(str2).delete();
    }
    catch (Exception localException)
    {
      throw localException;
    }
  }
  
  private void g(String paramString)
    throws Exception
  {
    boolean bool = LicenseException.a;
    try
    {
      System.gc();
      String str = JintegraHelpers.f(paramString);
      if (!bool)
      {
        if (str == null)
        {
          System.err.println(h("5%/V\"\026(8Ld") + paramString + h("_*2\002d\031+(\030 Q"));
          System.err.println(h("/(8\0277\032d8\0307\n68V0\027%)V0\027!}\034%\rd;\037(\032d") + paramString + h("_-.V-\021d)\036!_7<\033!_ 4\004!\03402\004=_%.V0\027!}\034-\02108\0216\036j%\033(_\"4\032!Q"));
        }
      }
      else {
        System.exit(0);
      }
      File localFile1 = new File(str);
      JarFile localJarFile = new JarFile(localFile1);
      File localFile2 = new File(str + h("Q00\006"));
      Manifest localManifest = localJarFile.getManifest();
      JarOutputStream localJarOutputStream = new JarOutputStream(new FileOutputStream(localFile2));
      byte[] arrayOfByte = new byte[1024];
      Enumeration localEnumeration = localJarFile.entries();
      if (bool) {}
      do
      {
        while (localEnumeration.hasMoreElements())
        {
          JarEntry localJarEntry = (JarEntry)localEnumeration.nextElement();
          while (!localJarEntry.getName().equals(h("\034+0Y-\0210/\037*\f=>Y(\026'8\0307\032k7\037*\013!:\004%Q<0\032")))
          {
            InputStream localInputStream = localJarFile.getInputStream(localJarEntry);
            localJarOutputStream.putNextEntry(localJarEntry);
            if (!bool)
            {
              int i1;
              while ((i1 = localInputStream.read(arrayOfByte)) != -1) {
                localJarOutputStream.write(arrayOfByte, 0, i1);
              }
            }
          }
        }
        localJarOutputStream.close();
      } while (bool);
      localManifest = null;
      localJarOutputStream = null;
      localJarFile.close();
      localJarFile = null;
      arrayOfByte = null;
      localFile2 = null;
      f(paramString);
    }
    catch (Exception localException)
    {
      throw localException;
    }
  }
  
  private static String h(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      68[93] = ((char)(0x76 ^ 0x44));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.intrinsyc.license.JintegraLicenseTool
 * JD-Core Version:    0.7.0.1
 */