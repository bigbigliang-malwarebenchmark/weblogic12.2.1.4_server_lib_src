/*   1:    */ package com.ning.compress.gzip;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import com.ning.compress.DataHandler;
/*   5:    */ import com.ning.compress.Uncompressor;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.util.zip.CRC32;
/*   8:    */ import java.util.zip.DataFormatException;
/*   9:    */ import java.util.zip.Inflater;
/*  10:    */ 
/*  11:    */ public class GZIPUncompressor
/*  12:    */   extends Uncompressor
/*  13:    */ {
/*  14:    */   protected static final int GZIP_MAGIC = 35615;
/*  15:    */   protected static final byte GZIP_MAGIC_0 = 31;
/*  16:    */   protected static final byte GZIP_MAGIC_1 = -117;
/*  17:    */   protected static final int FHCRC = 2;
/*  18:    */   protected static final int FEXTRA = 4;
/*  19:    */   protected static final int FNAME = 8;
/*  20:    */   protected static final int FCOMMENT = 16;
/*  21:    */   protected static final int DEFAULT_CHUNK_SIZE = 4096;
/*  22:    */   protected static final int DECODE_BUFFER_SIZE = 65535;
/*  23:    */   protected static final int STATE_INITIAL = 0;
/*  24:    */   protected static final int STATE_HEADER_SIG1 = 1;
/*  25:    */   protected static final int STATE_HEADER_COMP_TYPE = 2;
/*  26:    */   protected static final int STATE_HEADER_FLAGS = 3;
/*  27:    */   protected static final int STATE_HEADER_SKIP = 4;
/*  28:    */   protected static final int STATE_HEADER_EXTRA0 = 5;
/*  29:    */   protected static final int STATE_HEADER_EXTRA1 = 6;
/*  30:    */   protected static final int STATE_HEADER_FNAME = 7;
/*  31:    */   protected static final int STATE_HEADER_COMMENT = 8;
/*  32:    */   protected static final int STATE_HEADER_CRC0 = 9;
/*  33:    */   protected static final int STATE_HEADER_CRC1 = 10;
/*  34:    */   protected static final int STATE_TRAILER_INITIAL = 11;
/*  35:    */   protected static final int STATE_TRAILER_CRC1 = 12;
/*  36:    */   protected static final int STATE_TRAILER_CRC2 = 13;
/*  37:    */   protected static final int STATE_TRAILER_CRC3 = 14;
/*  38:    */   protected static final int STATE_TRAILER_LEN0 = 15;
/*  39:    */   protected static final int STATE_TRAILER_LEN1 = 16;
/*  40:    */   protected static final int STATE_TRAILER_LEN2 = 17;
/*  41:    */   protected static final int STATE_TRAILER_LEN3 = 18;
/*  42:    */   protected static final int STATE_BODY = 20;
/*  43:    */   protected final DataHandler _handler;
/*  44:    */   protected final BufferRecycler _recycler;
/*  45:    */   protected final GZIPRecycler _gzipRecycler;
/*  46:    */   protected Inflater _inflater;
/*  47:    */   protected final CRC32 _crc;
/*  48:    */   protected final int _inputChunkLength;
/*  49:    */   protected byte[] _decodeBuffer;
/*  50:132 */   protected int _state = 0;
/*  51:    */   protected boolean _terminated;
/*  52:    */   protected int _flags;
/*  53:    */   protected int _headerCRC;
/*  54:    */   protected int _skippedBytes;
/*  55:    */   protected int _trailerCRC;
/*  56:    */   protected int _trailerCount;
/*  57:    */   
/*  58:    */   public GZIPUncompressor(DataHandler h)
/*  59:    */   {
/*  60:174 */     this(h, 4096, BufferRecycler.instance(), GZIPRecycler.instance());
/*  61:    */   }
/*  62:    */   
/*  63:    */   public GZIPUncompressor(DataHandler h, int inputChunkLength)
/*  64:    */   {
/*  65:179 */     this(h, inputChunkLength, BufferRecycler.instance(), GZIPRecycler.instance());
/*  66:    */   }
/*  67:    */   
/*  68:    */   public GZIPUncompressor(DataHandler h, int inputChunkLength, BufferRecycler bufferRecycler, GZIPRecycler gzipRecycler)
/*  69:    */   {
/*  70:184 */     this._inputChunkLength = inputChunkLength;
/*  71:185 */     this._handler = h;
/*  72:186 */     this._recycler = bufferRecycler;
/*  73:187 */     this._decodeBuffer = bufferRecycler.allocDecodeBuffer(65535);
/*  74:188 */     this._gzipRecycler = gzipRecycler;
/*  75:189 */     this._inflater = gzipRecycler.allocInflater();
/*  76:190 */     this._crc = new CRC32();
/*  77:    */   }
/*  78:    */   
/*  79:    */   public boolean feedCompressedData(byte[] comp, int offset, int len)
/*  80:    */     throws IOException
/*  81:    */   {
/*  82:202 */     if (this._terminated) {
/*  83:203 */       return false;
/*  84:    */     }
/*  85:206 */     int end = offset + len;
/*  86:207 */     if (this._state != 20) {
/*  87:208 */       if (this._state < 11)
/*  88:    */       {
/*  89:209 */         offset = _handleHeader(comp, offset, end);
/*  90:210 */         if (offset >= end) {
/*  91:211 */           return true;
/*  92:    */         }
/*  93:    */       }
/*  94:    */       else
/*  95:    */       {
/*  96:215 */         offset = _handleTrailer(comp, offset, end);
/*  97:216 */         if (offset < end) {
/*  98:217 */           _throwInternal();
/*  99:    */         }
/* 100:220 */         return true;
/* 101:    */       }
/* 102:    */     }
/* 103:    */     do
/* 104:    */     {
/* 105:227 */       if (this._inflater.needsInput())
/* 106:    */       {
/* 107:228 */         int left = end - offset;
/* 108:229 */         if (left < 1) {
/* 109:230 */           return true;
/* 110:    */         }
/* 111:232 */         int amount = Math.min(left, this._inputChunkLength);
/* 112:233 */         this._inflater.setInput(comp, offset, amount);
/* 113:234 */         offset += amount;
/* 114:    */       }
/* 115:    */       for (;;)
/* 116:    */       {
/* 117:    */         int decoded;
/* 118:    */         try
/* 119:    */         {
/* 120:240 */           decoded = this._inflater.inflate(this._decodeBuffer);
/* 121:    */         }
/* 122:    */         catch (DataFormatException e)
/* 123:    */         {
/* 124:242 */           throw new GZIPException("Problems inflating gzip data: " + e.getMessage(), e);
/* 125:    */         }
/* 126:244 */         if (decoded == 0) {
/* 127:    */           break;
/* 128:    */         }
/* 129:247 */         this._crc.update(this._decodeBuffer, 0, decoded);
/* 130:248 */         if (!this._handler.handleData(this._decodeBuffer, 0, decoded))
/* 131:    */         {
/* 132:249 */           this._terminated = true;
/* 133:250 */           return false;
/* 134:    */         }
/* 135:    */       }
/* 136:253 */     } while ((!this._inflater.finished()) && (!this._inflater.needsDictionary()));
/* 137:254 */     this._state = 11;
/* 138:    */     
/* 139:256 */     int remains = this._inflater.getRemaining();
/* 140:257 */     if (remains > 0) {
/* 141:258 */       offset -= remains;
/* 142:    */     }
/* 143:265 */     offset = _handleTrailer(comp, offset, end);
/* 144:266 */     if (offset < end) {
/* 145:267 */       _throwInternal();
/* 146:    */     }
/* 147:269 */     return !this._terminated;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public void complete()
/* 151:    */     throws IOException
/* 152:    */   {
/* 153:275 */     byte[] b = this._decodeBuffer;
/* 154:276 */     if (b != null)
/* 155:    */     {
/* 156:277 */       this._decodeBuffer = null;
/* 157:278 */       this._recycler.releaseDecodeBuffer(b);
/* 158:    */     }
/* 159:280 */     Inflater i = this._inflater;
/* 160:281 */     if (i != null)
/* 161:    */     {
/* 162:282 */       this._inflater = null;
/* 163:283 */       this._gzipRecycler.releaseInflater(i);
/* 164:    */     }
/* 165:286 */     this._handler.allDataHandled();
/* 166:287 */     if ((!this._terminated) && 
/* 167:288 */       (this._state != 0))
/* 168:    */     {
/* 169:289 */       if (this._state >= 11)
/* 170:    */       {
/* 171:290 */         if (this._state == 20) {
/* 172:291 */           throw new GZIPException("Invalid GZIP stream: end-of-input in the middle of compressed data");
/* 173:    */         }
/* 174:293 */         throw new GZIPException("Invalid GZIP stream: end-of-input in the trailer (state: " + this._state + ")");
/* 175:    */       }
/* 176:295 */       throw new GZIPException("Invalid GZIP stream: end-of-input in header (state: " + this._state + ")");
/* 177:    */     }
/* 178:    */   }
/* 179:    */   
/* 180:    */   protected final boolean _hasFlag(int flag)
/* 181:    */   {
/* 182:307 */     return (this._flags & flag) == flag;
/* 183:    */   }
/* 184:    */   
/* 185:    */   private final int _handleHeader(byte[] comp, int offset, int end)
/* 186:    */     throws IOException
/* 187:    */   {
/* 188:    */     label742:
/* 189:314 */     while (offset < end)
/* 190:    */     {
/* 191:315 */       byte b = comp[(offset++)];
/* 192:316 */       this._crc.update(b);
/* 193:318 */       switch (this._state)
/* 194:    */       {
/* 195:    */       case 0: 
/* 196:320 */         if (b != 31) {
/* 197:321 */           _reportBadHeader(comp, offset, end, 0);
/* 198:    */         }
/* 199:323 */         if (offset >= end)
/* 200:    */         {
/* 201:324 */           this._state = 1;
/* 202:    */           break label742;
/* 203:    */         }
/* 204:327 */         b = comp[(offset++)];
/* 205:328 */         this._crc.update(b);
/* 206:    */       case 1: 
/* 207:331 */         if (b != -117) {
/* 208:332 */           _reportBadHeader(comp, offset, end, 1);
/* 209:    */         }
/* 210:334 */         if (offset >= end)
/* 211:    */         {
/* 212:335 */           this._state = 2;
/* 213:    */           break label742;
/* 214:    */         }
/* 215:338 */         b = comp[(offset++)];
/* 216:339 */         this._crc.update(b);
/* 217:    */       case 2: 
/* 218:342 */         if (b != 8) {
/* 219:343 */           _reportBadHeader(comp, offset, end, 1);
/* 220:    */         }
/* 221:345 */         if (offset >= end)
/* 222:    */         {
/* 223:346 */           this._state = 3;
/* 224:    */           break label742;
/* 225:    */         }
/* 226:349 */         b = comp[(offset++)];
/* 227:350 */         this._crc.update(b);
/* 228:    */       case 3: 
/* 229:353 */         this._flags = b;
/* 230:354 */         this._skippedBytes = 0;
/* 231:355 */         this._state = 4;
/* 232:356 */         if (offset >= end) {
/* 233:    */           break label742;
/* 234:    */         }
/* 235:359 */         b = comp[(offset++)];
/* 236:360 */         this._crc.update(b);
/* 237:    */       case 4: 
/* 238:363 */         while (++this._skippedBytes < 6)
/* 239:    */         {
/* 240:364 */           if (offset >= end) {
/* 241:    */             break label745;
/* 242:    */           }
/* 243:367 */           b = comp[(offset++)];
/* 244:368 */           this._crc.update(b);
/* 245:    */         }
/* 246:370 */         if (_hasFlag(4))
/* 247:    */         {
/* 248:371 */           this._state = 5; continue;
/* 249:    */         }
/* 250:372 */         if (_hasFlag(8))
/* 251:    */         {
/* 252:373 */           this._state = 7; continue;
/* 253:    */         }
/* 254:374 */         if (_hasFlag(16))
/* 255:    */         {
/* 256:375 */           this._state = 8; continue;
/* 257:    */         }
/* 258:376 */         if (_hasFlag(2))
/* 259:    */         {
/* 260:377 */           this._state = 9; continue;
/* 261:    */         }
/* 262:379 */         this._state = 20;
/* 263:380 */         break;
/* 264:    */       case 5: 
/* 265:385 */         this._state = 6;
/* 266:386 */         break;
/* 267:    */       case 6: 
/* 268:388 */         if (_hasFlag(8))
/* 269:    */         {
/* 270:389 */           this._state = 7;
/* 271:    */           break label742;
/* 272:    */         }
/* 273:390 */         if (_hasFlag(16))
/* 274:    */         {
/* 275:391 */           this._state = 8;
/* 276:    */           break label742;
/* 277:    */         }
/* 278:392 */         if (_hasFlag(2))
/* 279:    */         {
/* 280:393 */           this._state = 9;
/* 281:    */           break label742;
/* 282:    */         }
/* 283:395 */         this._state = 20;
/* 284:396 */         break;
/* 285:    */       case 7: 
/* 286:400 */         while (b != 0)
/* 287:    */         {
/* 288:401 */           if (offset >= end) {
/* 289:    */             break label745;
/* 290:    */           }
/* 291:404 */           b = comp[(offset++)];
/* 292:405 */           this._crc.update(b);
/* 293:    */         }
/* 294:407 */         if (_hasFlag(16))
/* 295:    */         {
/* 296:408 */           this._state = 8;
/* 297:    */           break label742;
/* 298:    */         }
/* 299:409 */         if (_hasFlag(2))
/* 300:    */         {
/* 301:410 */           this._state = 9;
/* 302:    */           break label742;
/* 303:    */         }
/* 304:412 */         this._state = 20;
/* 305:413 */         break;
/* 306:    */       case 8: 
/* 307:417 */         while (b != 0)
/* 308:    */         {
/* 309:418 */           if (offset >= end) {
/* 310:    */             break label745;
/* 311:    */           }
/* 312:421 */           b = comp[(offset++)];
/* 313:    */         }
/* 314:423 */         if (_hasFlag(2))
/* 315:    */         {
/* 316:424 */           this._state = 9;
/* 317:    */           break label742;
/* 318:    */         }
/* 319:426 */         this._state = 20;
/* 320:427 */         break;
/* 321:    */       case 9: 
/* 322:431 */         this._headerCRC = (b & 0xFF);
/* 323:432 */         if (offset >= end)
/* 324:    */         {
/* 325:433 */           this._state = 10;
/* 326:    */           break label742;
/* 327:    */         }
/* 328:436 */         b = comp[(offset++)];
/* 329:437 */         this._crc.update(b);
/* 330:    */       case 10: 
/* 331:440 */         this._headerCRC += ((b & 0xFF) << 8);
/* 332:441 */         int act = (int)this._crc.getValue() & 0xFFFF;
/* 333:442 */         if (act != this._headerCRC) {
/* 334:443 */           throw new GZIPException("Corrupt GZIP header: header CRC 0x" + Integer.toHexString(act) + ", expected 0x " + Integer.toHexString(this._headerCRC));
/* 335:    */         }
/* 336:447 */         this._state = 20;
/* 337:448 */         break;
/* 338:    */       }
/* 339:450 */       _throwInternal("Unknown header state: " + this._state);
/* 340:    */     }
/* 341:    */     label745:
/* 342:453 */     if (this._state == 20) {
/* 343:454 */       this._crc.reset();
/* 344:    */     }
/* 345:456 */     return offset;
/* 346:    */   }
/* 347:    */   
/* 348:    */   private final int _handleTrailer(byte[] comp, int offset, int end)
/* 349:    */     throws IOException
/* 350:    */   {
/* 351:461 */     while (offset < end)
/* 352:    */     {
/* 353:462 */       byte b = comp[(offset++)];
/* 354:464 */       switch (this._state)
/* 355:    */       {
/* 356:    */       case 11: 
/* 357:466 */         this._trailerCRC = (b & 0xFF);
/* 358:467 */         this._state = 12;
/* 359:468 */         break;
/* 360:    */       case 12: 
/* 361:470 */         this._trailerCRC += ((b & 0xFF) << 8);
/* 362:471 */         this._state = 13;
/* 363:472 */         break;
/* 364:    */       case 13: 
/* 365:474 */         this._trailerCRC += ((b & 0xFF) << 16);
/* 366:475 */         this._state = 14;
/* 367:476 */         break;
/* 368:    */       case 14: 
/* 369:478 */         this._trailerCRC += ((b & 0xFF) << 24);
/* 370:479 */         int actCRC = (int)this._crc.getValue();
/* 371:481 */         if (this._trailerCRC != actCRC) {
/* 372:482 */           throw new GZIPException("Corrupt block or trailer: expected CRC " + Integer.toHexString(this._trailerCRC) + ", computed " + Integer.toHexString(actCRC));
/* 373:    */         }
/* 374:485 */         this._state = 15;
/* 375:486 */         break;
/* 376:    */       case 15: 
/* 377:488 */         this._trailerCount = (b & 0xFF);
/* 378:489 */         this._state = 16;
/* 379:490 */         break;
/* 380:    */       case 16: 
/* 381:492 */         this._trailerCount += ((b & 0xFF) << 8);
/* 382:493 */         this._state = 17;
/* 383:494 */         break;
/* 384:    */       case 17: 
/* 385:496 */         this._trailerCount += ((b & 0xFF) << 16);
/* 386:497 */         this._state = 18;
/* 387:498 */         break;
/* 388:    */       case 18: 
/* 389:500 */         this._trailerCount += ((b & 0xFF) << 24);
/* 390:501 */         this._state = 0;
/* 391:    */         
/* 392:503 */         int actCount32 = (int)this._inflater.getBytesWritten();
/* 393:505 */         if (actCount32 != this._trailerCount) {
/* 394:506 */           throw new GZIPException("Corrupt block or trailed: expected byte count " + this._trailerCount + ", read " + actCount32);
/* 395:    */         }
/* 396:    */         break;
/* 397:    */       default: 
/* 398:510 */         _throwInternal("Unknown trailer state: " + this._state);
/* 399:    */       }
/* 400:    */     }
/* 401:513 */     return offset;
/* 402:    */   }
/* 403:    */   
/* 404:    */   protected void _throwInternal()
/* 405:    */     throws GZIPException
/* 406:    */   {
/* 407:523 */     throw new GZIPException("Internal error");
/* 408:    */   }
/* 409:    */   
/* 410:    */   protected void _throwInternal(String msg)
/* 411:    */     throws GZIPException
/* 412:    */   {
/* 413:527 */     throw new GZIPException("Internal error: " + msg);
/* 414:    */   }
/* 415:    */   
/* 416:    */   protected void _reportBadHeader(byte[] comp, int nextOffset, int end, int relative)
/* 417:    */     throws GZIPException
/* 418:    */   {
/* 419:533 */     String byteStr = "0x" + Integer.toHexString(comp[nextOffset] & 0xFF);
/* 420:534 */     if (relative <= 1)
/* 421:    */     {
/* 422:535 */       int exp = relative == 0 ? 31 : 139;
/* 423:536 */       nextOffset--;
/* 424:537 */       throw new GZIPException("Bad GZIP stream: byte #" + relative + " of header not '" + exp + "' (0x" + Integer.toHexString(exp) + ") but " + byteStr);
/* 425:    */     }
/* 426:540 */     if (relative == 2) {
/* 427:541 */       throw new GZIPException("Bad GZIP stream: byte #2 of header invalid: type " + byteStr + " not supported, 0x" + Integer.toHexString(8) + " expected");
/* 428:    */     }
/* 429:545 */     throw new GZIPException("Bad GZIP stream: byte #" + relative + " of header invalid: " + byteStr);
/* 430:    */   }
/* 431:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.gzip.GZIPUncompressor
 * JD-Core Version:    0.7.0.1
 */