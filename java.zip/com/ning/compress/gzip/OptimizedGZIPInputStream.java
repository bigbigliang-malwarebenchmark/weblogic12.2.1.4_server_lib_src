/*   1:    */ package com.ning.compress.gzip;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.InputStream;
/*   6:    */ import java.util.zip.CRC32;
/*   7:    */ import java.util.zip.DataFormatException;
/*   8:    */ import java.util.zip.Inflater;
/*   9:    */ 
/*  10:    */ public class OptimizedGZIPInputStream
/*  11:    */   extends InputStream
/*  12:    */ {
/*  13:    */   private static final int INPUT_BUFFER_SIZE = 16000;
/*  14:    */   protected Inflater _inflater;
/*  15:    */   protected final CRC32 _crc;
/*  16:    */   protected final BufferRecycler _bufferRecycler;
/*  17:    */   protected final GZIPRecycler _gzipRecycler;
/*  18:    */   protected byte[] _buffer;
/*  19:    */   protected int _bufferPtr;
/*  20:    */   protected int _bufferEnd;
/*  21:    */   protected byte[] _tmpBuffer;
/*  22:    */   protected InputStream _rawInput;
/*  23:    */   protected OptimizedGZIPInputStream.State _state;
/*  24:    */   
/*  25:    */   public OptimizedGZIPInputStream(InputStream in)
/*  26:    */     throws IOException
/*  27:    */   {
/*  28: 81 */     this(in, BufferRecycler.instance(), GZIPRecycler.instance());
/*  29:    */   }
/*  30:    */   
/*  31:    */   public OptimizedGZIPInputStream(InputStream in, BufferRecycler bufferRecycler, GZIPRecycler gzipRecycler)
/*  32:    */     throws IOException
/*  33:    */   {
/*  34: 87 */     this._bufferRecycler = bufferRecycler;
/*  35: 88 */     this._gzipRecycler = gzipRecycler;
/*  36: 89 */     this._rawInput = in;
/*  37: 90 */     this._buffer = bufferRecycler.allocInputBuffer(16000);
/*  38:    */     
/*  39: 92 */     this._bufferPtr = (this._bufferEnd = 0);
/*  40: 93 */     this._inflater = gzipRecycler.allocInflater();
/*  41: 94 */     this._crc = new CRC32();
/*  42:    */     
/*  43:    */ 
/*  44: 97 */     _readHeader();
/*  45: 98 */     this._state = OptimizedGZIPInputStream.State.GZIP_CONTENT;
/*  46: 99 */     this._crc.reset();
/*  47:101 */     if (this._bufferPtr >= this._bufferEnd) {
/*  48:102 */       _loadMore();
/*  49:    */     }
/*  50:104 */     this._inflater.setInput(this._buffer, this._bufferPtr, this._bufferEnd - this._bufferPtr);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public int available()
/*  54:    */   {
/*  55:116 */     if (this._state == OptimizedGZIPInputStream.State.GZIP_COMPLETE) {
/*  56:117 */       return 0;
/*  57:    */     }
/*  58:120 */     return this._inflater.finished() ? 0 : 1;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void close()
/*  62:    */     throws IOException
/*  63:    */   {
/*  64:126 */     this._state = OptimizedGZIPInputStream.State.GZIP_COMPLETE;
/*  65:127 */     if (this._rawInput != null)
/*  66:    */     {
/*  67:128 */       this._rawInput.close();
/*  68:129 */       this._rawInput = null;
/*  69:    */     }
/*  70:131 */     byte[] b = this._buffer;
/*  71:132 */     if (b != null)
/*  72:    */     {
/*  73:133 */       this._buffer = null;
/*  74:134 */       this._bufferRecycler.releaseInputBuffer(b);
/*  75:    */     }
/*  76:136 */     b = this._tmpBuffer;
/*  77:137 */     if (b != null)
/*  78:    */     {
/*  79:138 */       this._tmpBuffer = null;
/*  80:139 */       this._bufferRecycler.releaseDecodeBuffer(b);
/*  81:    */     }
/*  82:141 */     Inflater i = this._inflater;
/*  83:142 */     if (i != null)
/*  84:    */     {
/*  85:143 */       this._inflater = null;
/*  86:144 */       this._gzipRecycler.releaseInflater(i);
/*  87:    */     }
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void mark(int limit) {}
/*  91:    */   
/*  92:    */   public boolean markSupported()
/*  93:    */   {
/*  94:155 */     return false;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public final int read()
/*  98:    */     throws IOException
/*  99:    */   {
/* 100:161 */     byte[] tmp = _getTmpBuffer();
/* 101:162 */     int count = read(tmp, 0, 1);
/* 102:163 */     if (count < 0) {
/* 103:164 */       return -1;
/* 104:    */     }
/* 105:166 */     return tmp[0] & 0xFF;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public final int read(byte[] buf)
/* 109:    */     throws IOException
/* 110:    */   {
/* 111:171 */     return read(buf, 0, buf.length);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public final int read(byte[] buf, int offset, int len)
/* 115:    */     throws IOException
/* 116:    */   {
/* 117:177 */     if (buf == null) {
/* 118:178 */       throw new NullPointerException();
/* 119:    */     }
/* 120:180 */     if ((offset < 0) || (len < 0) || (len > buf.length - offset)) {
/* 121:181 */       throw new IndexOutOfBoundsException();
/* 122:    */     }
/* 123:183 */     if (this._state == OptimizedGZIPInputStream.State.GZIP_COMPLETE) {
/* 124:184 */       return -1;
/* 125:    */     }
/* 126:186 */     if (len == 0) {
/* 127:187 */       return 0;
/* 128:    */     }
/* 129:    */     try
/* 130:    */     {
/* 131:    */       int count;
/* 132:191 */       while ((count = this._inflater.inflate(buf, offset, len)) == 0)
/* 133:    */       {
/* 134:192 */         if ((this._inflater.finished()) || (this._inflater.needsDictionary()))
/* 135:    */         {
/* 136:193 */           _readTrailer();
/* 137:194 */           this._state = OptimizedGZIPInputStream.State.GZIP_COMPLETE;
/* 138:195 */           return -1;
/* 139:    */         }
/* 140:197 */         if (this._inflater.needsInput())
/* 141:    */         {
/* 142:198 */           _loadMore();
/* 143:199 */           this._inflater.setInput(this._buffer, this._bufferPtr, this._bufferEnd - this._bufferPtr);
/* 144:200 */           this._bufferPtr = this._bufferEnd;
/* 145:    */         }
/* 146:    */       }
/* 147:203 */       this._crc.update(buf, offset, count);
/* 148:204 */       return count;
/* 149:    */     }
/* 150:    */     catch (DataFormatException e)
/* 151:    */     {
/* 152:206 */       String s = e.getMessage();
/* 153:207 */       throw new GZIPException(s != null ? s : "Invalid ZLIB data format");
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   public void reset()
/* 158:    */     throws IOException
/* 159:    */   {
/* 160:213 */     throw new IOException("mark/reset not supported");
/* 161:    */   }
/* 162:    */   
/* 163:    */   public long skip(long n)
/* 164:    */     throws IOException
/* 165:    */   {
/* 166:219 */     if (n < 0L) {
/* 167:220 */       throw new IllegalArgumentException("negative skip length");
/* 168:    */     }
/* 169:222 */     byte[] tmp = _getTmpBuffer();
/* 170:223 */     long total = 0L;
/* 171:    */     for (;;)
/* 172:    */     {
/* 173:226 */       int max = (int)(n - total);
/* 174:227 */       if (max == 0) {
/* 175:    */         break;
/* 176:    */       }
/* 177:230 */       int count = read(tmp, 0, Math.min(max, tmp.length));
/* 178:231 */       total += count;
/* 179:    */     }
/* 180:233 */     return total;
/* 181:    */   }
/* 182:    */   
/* 183:    */   protected byte[] _getTmpBuffer()
/* 184:    */   {
/* 185:244 */     if (this._tmpBuffer == null) {
/* 186:245 */       this._tmpBuffer = this._bufferRecycler.allocDecodeBuffer(16000);
/* 187:    */     }
/* 188:247 */     return this._tmpBuffer;
/* 189:    */   }
/* 190:    */   
/* 191:    */   protected final void _readHeader()
/* 192:    */     throws IOException
/* 193:    */   {
/* 194:252 */     this._state = OptimizedGZIPInputStream.State.GZIP_HEADER;
/* 195:    */     
/* 196:    */ 
/* 197:255 */     int sig = _readShort();
/* 198:256 */     if (sig != 35615) {
/* 199:257 */       throw new GZIPException("Not in GZIP format (got 0x" + Integer.toHexString(sig) + ", should be 0x" + Integer.toHexString(35615) + ")");
/* 200:    */     }
/* 201:261 */     if (_readByte() != 8) {
/* 202:262 */       throw new GZIPException("Unsupported compression method (only support Deflate, 8)");
/* 203:    */     }
/* 204:265 */     int flg = _readByte();
/* 205:    */     
/* 206:267 */     _skipBytes(6);
/* 207:269 */     if ((flg & 0x4) != 0) {
/* 208:270 */       _skipBytes(_readShort());
/* 209:    */     }
/* 210:273 */     while (((flg & 0x8) != 0) && 
/* 211:274 */       (_readByte() != 0)) {}
/* 212:277 */     while (((flg & 0x10) != 0) && 
/* 213:278 */       (_readByte() != 0)) {}
/* 214:281 */     if ((flg & 0x2) != 0)
/* 215:    */     {
/* 216:282 */       int act = (int)this._crc.getValue() & 0xFFFF;
/* 217:283 */       int exp = _readShort();
/* 218:284 */       if (act != exp) {
/* 219:285 */         throw new GZIPException("Corrupt GZIP header (header CRC 0x" + Integer.toHexString(act) + ", expected 0x " + Integer.toHexString(exp));
/* 220:    */       }
/* 221:    */     }
/* 222:    */   }
/* 223:    */   
/* 224:    */   protected final void _readTrailer()
/* 225:    */     throws IOException
/* 226:    */   {
/* 227:294 */     int actCrc = (int)this._crc.getValue();
/* 228:    */     
/* 229:296 */     int remains = this._inflater.getRemaining();
/* 230:297 */     if (remains > 0) {
/* 231:299 */       this._bufferPtr = (this._bufferEnd - remains);
/* 232:    */     } else {
/* 233:301 */       _loadMore(8);
/* 234:    */     }
/* 235:303 */     int expCrc = _readInt();
/* 236:304 */     int expCount = _readInt();
/* 237:305 */     int actCount32 = (int)this._inflater.getBytesWritten();
/* 238:307 */     if (actCount32 != expCount) {
/* 239:308 */       throw new GZIPException("Corrupt trailer: expected byte count " + expCount + ", read " + actCount32);
/* 240:    */     }
/* 241:310 */     if (expCrc != actCrc) {
/* 242:311 */       throw new GZIPException("Corrupt trailer: expected CRC " + Integer.toHexString(expCrc) + ", computed " + Integer.toHexString(actCrc));
/* 243:    */     }
/* 244:    */   }
/* 245:    */   
/* 246:    */   private final void _skipBytes(int count)
/* 247:    */     throws IOException
/* 248:    */   {
/* 249:    */     for (;;)
/* 250:    */     {
/* 251:    */       
/* 252:317 */       if (count < 0) {
/* 253:    */         break;
/* 254:    */       }
/* 255:318 */       _readByte();
/* 256:    */     }
/* 257:    */   }
/* 258:    */   
/* 259:    */   private final int _readByte()
/* 260:    */     throws IOException
/* 261:    */   {
/* 262:324 */     if (this._bufferPtr >= this._bufferEnd) {
/* 263:325 */       _loadMore();
/* 264:    */     }
/* 265:327 */     byte b = this._buffer[(this._bufferPtr++)];
/* 266:328 */     if (this._state == OptimizedGZIPInputStream.State.GZIP_HEADER) {
/* 267:329 */       this._crc.update(b);
/* 268:    */     }
/* 269:331 */     return b & 0xFF;
/* 270:    */   }
/* 271:    */   
/* 272:    */   private final int _readShort()
/* 273:    */     throws IOException
/* 274:    */   {
/* 275:337 */     return _readByte() | _readByte() << 8;
/* 276:    */   }
/* 277:    */   
/* 278:    */   private final int _readInt()
/* 279:    */     throws IOException
/* 280:    */   {
/* 281:343 */     return _readByte() | _readByte() << 8 | _readByte() << 16 | _readByte() << 24;
/* 282:    */   }
/* 283:    */   
/* 284:    */   private final void _loadMore()
/* 285:    */     throws IOException
/* 286:    */   {
/* 287:350 */     _loadMore(Math.min(this._buffer.length, 16000));
/* 288:    */   }
/* 289:    */   
/* 290:    */   private final void _loadMore(int max)
/* 291:    */     throws IOException
/* 292:    */   {
/* 293:355 */     int count = this._rawInput.read(this._buffer, 0, max);
/* 294:356 */     if (count < 1)
/* 295:    */     {
/* 296:357 */       String prob = count < 0 ? "Unexpected end of input" : "Strange underlying stream (returned 0 bytes for read)";
/* 297:    */       
/* 298:359 */       throw new GZIPException(prob + " when reading " + this._state);
/* 299:    */     }
/* 300:361 */     this._bufferPtr = 0;
/* 301:362 */     this._bufferEnd = count;
/* 302:    */   }
/* 303:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.gzip.OptimizedGZIPInputStream
 * JD-Core Version:    0.7.0.1
 */