/*   1:    */ package com.ning.compress.gzip;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.OutputStream;
/*   5:    */ import java.util.zip.CRC32;
/*   6:    */ import java.util.zip.Deflater;
/*   7:    */ import java.util.zip.DeflaterOutputStream;
/*   8:    */ 
/*   9:    */ public class OptimizedGZIPOutputStream
/*  10:    */   extends OutputStream
/*  11:    */ {
/*  12:    */   private static final int GZIP_MAGIC = 35615;
/*  13: 25 */   static final byte[] DEFAULT_HEADER = { 31, -117, 8, 0, 0, 0, 0, 0, 0, -1 };
/*  14:    */   protected Deflater _deflater;
/*  15:    */   protected final GZIPRecycler _gzipRecycler;
/*  16: 48 */   protected final byte[] _eightByteBuffer = new byte[8];
/*  17:    */   protected OutputStream _rawOut;
/*  18:    */   protected DeflaterOutputStream _deflaterOut;
/*  19:    */   protected CRC32 _crc;
/*  20:    */   
/*  21:    */   public OptimizedGZIPOutputStream(OutputStream out)
/*  22:    */     throws IOException
/*  23:    */   {
/*  24: 76 */     this._gzipRecycler = GZIPRecycler.instance();
/*  25: 77 */     this._rawOut = out;
/*  26:    */     
/*  27: 79 */     this._rawOut.write(DEFAULT_HEADER);
/*  28: 80 */     this._deflater = this._gzipRecycler.allocDeflater();
/*  29: 81 */     this._deflaterOut = new DeflaterOutputStream(this._rawOut, this._deflater, 4000);
/*  30: 82 */     this._crc = new CRC32();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void close()
/*  34:    */     throws IOException
/*  35:    */   {
/*  36: 94 */     this._deflaterOut.finish();
/*  37: 95 */     this._deflaterOut = null;
/*  38: 96 */     _writeTrailer(this._rawOut);
/*  39: 97 */     this._rawOut.close();
/*  40: 98 */     Deflater d = this._deflater;
/*  41: 99 */     if (d != null)
/*  42:    */     {
/*  43:100 */       this._deflater = null;
/*  44:101 */       this._gzipRecycler.releaseDeflater(d);
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void flush()
/*  49:    */     throws IOException
/*  50:    */   {
/*  51:107 */     this._deflaterOut.flush();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public final void write(byte[] buf)
/*  55:    */     throws IOException
/*  56:    */   {
/*  57:112 */     write(buf, 0, buf.length);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public final void write(int c)
/*  61:    */     throws IOException
/*  62:    */   {
/*  63:117 */     this._eightByteBuffer[0] = ((byte)c);
/*  64:118 */     write(this._eightByteBuffer, 0, 1);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void write(byte[] buf, int off, int len)
/*  68:    */     throws IOException
/*  69:    */   {
/*  70:123 */     this._deflaterOut.write(buf, off, len);
/*  71:124 */     this._crc.update(buf, off, len);
/*  72:    */   }
/*  73:    */   
/*  74:    */   private void _writeTrailer(OutputStream out)
/*  75:    */     throws IOException
/*  76:    */   {
/*  77:135 */     _putInt(this._eightByteBuffer, 0, (int)this._crc.getValue());
/*  78:136 */     _putInt(this._eightByteBuffer, 4, this._deflater.getTotalIn());
/*  79:137 */     out.write(this._eightByteBuffer, 0, 8);
/*  80:    */   }
/*  81:    */   
/*  82:    */   private static final void _putInt(byte[] buf, int offset, int value)
/*  83:    */   {
/*  84:145 */     buf[(offset++)] = ((byte)value);
/*  85:146 */     buf[(offset++)] = ((byte)(value >> 8));
/*  86:147 */     buf[(offset++)] = ((byte)(value >> 16));
/*  87:148 */     buf[offset] = ((byte)(value >> 24));
/*  88:    */   }
/*  89:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.gzip.OptimizedGZIPOutputStream
 * JD-Core Version:    0.7.0.1
 */