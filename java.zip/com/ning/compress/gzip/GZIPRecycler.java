/*  1:   */ package com.ning.compress.gzip;
/*  2:   */ 
/*  3:   */ import java.lang.ref.SoftReference;
/*  4:   */ import java.util.zip.Deflater;
/*  5:   */ import java.util.zip.Inflater;
/*  6:   */ 
/*  7:   */ public final class GZIPRecycler
/*  8:   */ {
/*  9:15 */   protected static final ThreadLocal<SoftReference<GZIPRecycler>> _recyclerRef = new ThreadLocal();
/* 10:   */   protected Inflater _inflater;
/* 11:   */   protected Deflater _deflater;
/* 12:   */   
/* 13:   */   public static GZIPRecycler instance()
/* 14:   */   {
/* 15:27 */     SoftReference<GZIPRecycler> ref = (SoftReference)_recyclerRef.get();
/* 16:28 */     GZIPRecycler br = ref == null ? null : (GZIPRecycler)ref.get();
/* 17:29 */     if (br == null)
/* 18:   */     {
/* 19:30 */       br = new GZIPRecycler();
/* 20:31 */       _recyclerRef.set(new SoftReference(br));
/* 21:   */     }
/* 22:33 */     return br;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Deflater allocDeflater()
/* 26:   */   {
/* 27:44 */     Deflater d = this._deflater;
/* 28:45 */     if (d == null) {
/* 29:46 */       d = new Deflater(-1, true);
/* 30:   */     } else {
/* 31:48 */       this._deflater = null;
/* 32:   */     }
/* 33:50 */     return d;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void releaseDeflater(Deflater d)
/* 37:   */   {
/* 38:55 */     if (d != null)
/* 39:   */     {
/* 40:56 */       d.reset();
/* 41:57 */       this._deflater = d;
/* 42:   */     }
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Inflater allocInflater()
/* 46:   */   {
/* 47:63 */     Inflater i = this._inflater;
/* 48:64 */     if (i == null) {
/* 49:65 */       i = new Inflater(true);
/* 50:   */     } else {
/* 51:67 */       this._inflater = null;
/* 52:   */     }
/* 53:69 */     return i;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void releaseInflater(Inflater i)
/* 57:   */   {
/* 58:74 */     if (i != null)
/* 59:   */     {
/* 60:75 */       i.reset();
/* 61:76 */       this._inflater = i;
/* 62:   */     }
/* 63:   */   }
/* 64:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.gzip.GZIPRecycler
 * JD-Core Version:    0.7.0.1
 */