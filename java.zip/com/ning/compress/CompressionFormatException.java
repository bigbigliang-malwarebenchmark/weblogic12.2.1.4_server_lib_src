/*  1:   */ package com.ning.compress;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ 
/*  5:   */ public class CompressionFormatException
/*  6:   */   extends IOException
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = 1L;
/*  9:   */   
/* 10:   */   protected CompressionFormatException(String message)
/* 11:   */   {
/* 12:14 */     super(message);
/* 13:   */   }
/* 14:   */   
/* 15:   */   protected CompressionFormatException(Throwable t)
/* 16:   */   {
/* 17:19 */     initCause(t);
/* 18:   */   }
/* 19:   */   
/* 20:   */   protected CompressionFormatException(String message, Throwable t)
/* 21:   */   {
/* 22:23 */     super(message);
/* 23:24 */     initCause(t);
/* 24:   */   }
/* 25:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.CompressionFormatException
 * JD-Core Version:    0.7.0.1
 */