/*   1:    */ package com.ning.compress.lzf.util;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import com.ning.compress.lzf.ChunkEncoder;
/*   5:    */ import com.ning.compress.lzf.impl.UnsafeChunkEncoders;
/*   6:    */ import com.ning.compress.lzf.impl.VanillaChunkEncoder;
/*   7:    */ 
/*   8:    */ public class ChunkEncoderFactory
/*   9:    */ {
/*  10:    */   public static ChunkEncoder optimalInstance()
/*  11:    */   {
/*  12: 29 */     return optimalInstance(65535);
/*  13:    */   }
/*  14:    */   
/*  15:    */   public static ChunkEncoder optimalInstance(int totalLength)
/*  16:    */   {
/*  17:    */     try
/*  18:    */     {
/*  19: 47 */       return UnsafeChunkEncoders.createEncoder(totalLength);
/*  20:    */     }
/*  21:    */     catch (Exception e) {}
/*  22: 49 */     return safeInstance(totalLength);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static ChunkEncoder optimalNonAllocatingInstance(int totalLength)
/*  26:    */   {
/*  27:    */     try
/*  28:    */     {
/*  29: 61 */       return UnsafeChunkEncoders.createNonAllocatingEncoder(totalLength);
/*  30:    */     }
/*  31:    */     catch (Exception e) {}
/*  32: 63 */     return safeNonAllocatingInstance(totalLength);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static ChunkEncoder safeInstance()
/*  36:    */   {
/*  37: 74 */     return safeInstance(65535);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static ChunkEncoder safeInstance(int totalLength)
/*  41:    */   {
/*  42: 88 */     return new VanillaChunkEncoder(totalLength);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static ChunkEncoder safeNonAllocatingInstance(int totalLength)
/*  46:    */   {
/*  47: 97 */     return VanillaChunkEncoder.nonAllocatingEncoder(totalLength);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static ChunkEncoder optimalInstance(BufferRecycler bufferRecycler)
/*  51:    */   {
/*  52:107 */     return optimalInstance(65535, bufferRecycler);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static ChunkEncoder optimalInstance(int totalLength, BufferRecycler bufferRecycler)
/*  56:    */   {
/*  57:    */     try
/*  58:    */     {
/*  59:124 */       return UnsafeChunkEncoders.createEncoder(totalLength, bufferRecycler);
/*  60:    */     }
/*  61:    */     catch (Exception e) {}
/*  62:126 */     return safeInstance(totalLength, bufferRecycler);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static ChunkEncoder optimalNonAllocatingInstance(int totalLength, BufferRecycler bufferRecycler)
/*  66:    */   {
/*  67:    */     try
/*  68:    */     {
/*  69:136 */       return UnsafeChunkEncoders.createNonAllocatingEncoder(totalLength, bufferRecycler);
/*  70:    */     }
/*  71:    */     catch (Exception e) {}
/*  72:138 */     return safeNonAllocatingInstance(totalLength, bufferRecycler);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static ChunkEncoder safeInstance(BufferRecycler bufferRecycler)
/*  76:    */   {
/*  77:149 */     return safeInstance(65535, bufferRecycler);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static ChunkEncoder safeInstance(int totalLength, BufferRecycler bufferRecycler)
/*  81:    */   {
/*  82:161 */     return new VanillaChunkEncoder(totalLength, bufferRecycler);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static ChunkEncoder safeNonAllocatingInstance(int totalLength, BufferRecycler bufferRecycler)
/*  86:    */   {
/*  87:169 */     return VanillaChunkEncoder.nonAllocatingEncoder(totalLength, bufferRecycler);
/*  88:    */   }
/*  89:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.util.ChunkEncoderFactory
 * JD-Core Version:    0.7.0.1
 */