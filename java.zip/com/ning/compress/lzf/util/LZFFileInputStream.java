/*   1:    */ package com.ning.compress.lzf.util;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import com.ning.compress.lzf.ChunkDecoder;
/*   5:    */ import java.io.File;
/*   6:    */ import java.io.FileDescriptor;
/*   7:    */ import java.io.FileInputStream;
/*   8:    */ import java.io.FileNotFoundException;
/*   9:    */ import java.io.IOException;
/*  10:    */ import java.io.OutputStream;
/*  11:    */ 
/*  12:    */ public class LZFFileInputStream
/*  13:    */   extends FileInputStream
/*  14:    */ {
/*  15:    */   protected final ChunkDecoder _decompressor;
/*  16:    */   protected final BufferRecycler _recycler;
/*  17:    */   protected boolean _inputStreamClosed;
/*  18: 45 */   protected boolean _cfgFullReads = false;
/*  19:    */   protected byte[] _inputBuffer;
/*  20:    */   protected byte[] _decodedBytes;
/*  21: 60 */   protected int _bufferPosition = 0;
/*  22: 65 */   protected int _bufferLength = 0;
/*  23:    */   protected final LZFFileInputStream.Wrapper _wrapper;
/*  24:    */   
/*  25:    */   public LZFFileInputStream(File file)
/*  26:    */     throws FileNotFoundException
/*  27:    */   {
/*  28: 80 */     this(file, ChunkDecoderFactory.optimalInstance(), BufferRecycler.instance());
/*  29:    */   }
/*  30:    */   
/*  31:    */   public LZFFileInputStream(FileDescriptor fdObj)
/*  32:    */   {
/*  33: 84 */     this(fdObj, ChunkDecoderFactory.optimalInstance(), BufferRecycler.instance());
/*  34:    */   }
/*  35:    */   
/*  36:    */   public LZFFileInputStream(String name)
/*  37:    */     throws FileNotFoundException
/*  38:    */   {
/*  39: 88 */     this(name, ChunkDecoderFactory.optimalInstance(), BufferRecycler.instance());
/*  40:    */   }
/*  41:    */   
/*  42:    */   public LZFFileInputStream(File file, ChunkDecoder decompressor)
/*  43:    */     throws FileNotFoundException
/*  44:    */   {
/*  45: 93 */     this(file, decompressor, BufferRecycler.instance());
/*  46:    */   }
/*  47:    */   
/*  48:    */   public LZFFileInputStream(FileDescriptor fdObj, ChunkDecoder decompressor)
/*  49:    */   {
/*  50: 98 */     this(fdObj, decompressor, BufferRecycler.instance());
/*  51:    */   }
/*  52:    */   
/*  53:    */   public LZFFileInputStream(String name, ChunkDecoder decompressor)
/*  54:    */     throws FileNotFoundException
/*  55:    */   {
/*  56:103 */     this(name, decompressor, BufferRecycler.instance());
/*  57:    */   }
/*  58:    */   
/*  59:    */   public LZFFileInputStream(File file, ChunkDecoder decompressor, BufferRecycler bufferRecycler)
/*  60:    */     throws FileNotFoundException
/*  61:    */   {
/*  62:108 */     super(file);
/*  63:109 */     this._decompressor = decompressor;
/*  64:110 */     this._recycler = bufferRecycler;
/*  65:111 */     this._inputStreamClosed = false;
/*  66:112 */     this._inputBuffer = bufferRecycler.allocInputBuffer(65535);
/*  67:113 */     this._decodedBytes = bufferRecycler.allocDecodeBuffer(65535);
/*  68:114 */     this._wrapper = new LZFFileInputStream.Wrapper(this, null);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public LZFFileInputStream(FileDescriptor fdObj, ChunkDecoder decompressor, BufferRecycler bufferRecycler)
/*  72:    */   {
/*  73:119 */     super(fdObj);
/*  74:120 */     this._decompressor = decompressor;
/*  75:121 */     this._recycler = bufferRecycler;
/*  76:122 */     this._inputStreamClosed = false;
/*  77:123 */     this._inputBuffer = bufferRecycler.allocInputBuffer(65535);
/*  78:124 */     this._decodedBytes = bufferRecycler.allocDecodeBuffer(65535);
/*  79:125 */     this._wrapper = new LZFFileInputStream.Wrapper(this, null);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public LZFFileInputStream(String name, ChunkDecoder decompressor, BufferRecycler bufferRecycler)
/*  83:    */     throws FileNotFoundException
/*  84:    */   {
/*  85:130 */     super(name);
/*  86:131 */     this._decompressor = decompressor;
/*  87:132 */     this._recycler = bufferRecycler;
/*  88:133 */     this._inputStreamClosed = false;
/*  89:134 */     this._inputBuffer = bufferRecycler.allocInputBuffer(65535);
/*  90:135 */     this._decodedBytes = bufferRecycler.allocDecodeBuffer(65535);
/*  91:136 */     this._wrapper = new LZFFileInputStream.Wrapper(this, null);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setUseFullReads(boolean b)
/*  95:    */   {
/*  96:146 */     this._cfgFullReads = b;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public int available()
/* 100:    */   {
/* 101:158 */     if (this._inputStreamClosed) {
/* 102:159 */       return 0;
/* 103:    */     }
/* 104:161 */     int left = this._bufferLength - this._bufferPosition;
/* 105:162 */     return left <= 0 ? 0 : left;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void close()
/* 109:    */     throws IOException
/* 110:    */   {
/* 111:168 */     this._bufferPosition = (this._bufferLength = 0);
/* 112:169 */     byte[] buf = this._inputBuffer;
/* 113:170 */     if (buf != null)
/* 114:    */     {
/* 115:171 */       this._inputBuffer = null;
/* 116:172 */       this._recycler.releaseInputBuffer(buf);
/* 117:    */     }
/* 118:174 */     buf = this._decodedBytes;
/* 119:175 */     if (buf != null)
/* 120:    */     {
/* 121:176 */       this._decodedBytes = null;
/* 122:177 */       this._recycler.releaseDecodeBuffer(buf);
/* 123:    */     }
/* 124:179 */     if (!this._inputStreamClosed)
/* 125:    */     {
/* 126:180 */       this._inputStreamClosed = true;
/* 127:181 */       super.close();
/* 128:    */     }
/* 129:    */   }
/* 130:    */   
/* 131:    */   public int read()
/* 132:    */     throws IOException
/* 133:    */   {
/* 134:194 */     if (!readyBuffer()) {
/* 135:195 */       return -1;
/* 136:    */     }
/* 137:197 */     return this._decodedBytes[(this._bufferPosition++)] & 0xFF;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public int read(byte[] b)
/* 141:    */     throws IOException
/* 142:    */   {
/* 143:203 */     return read(b, 0, b.length);
/* 144:    */   }
/* 145:    */   
/* 146:    */   public int read(byte[] buffer, int offset, int length)
/* 147:    */     throws IOException
/* 148:    */   {
/* 149:209 */     if (!readyBuffer()) {
/* 150:210 */       return -1;
/* 151:    */     }
/* 152:212 */     if (length < 1) {
/* 153:213 */       return 0;
/* 154:    */     }
/* 155:216 */     int chunkLength = Math.min(this._bufferLength - this._bufferPosition, length);
/* 156:217 */     System.arraycopy(this._decodedBytes, this._bufferPosition, buffer, offset, chunkLength);
/* 157:218 */     this._bufferPosition += chunkLength;
/* 158:220 */     if ((chunkLength == length) || (!this._cfgFullReads)) {
/* 159:221 */       return chunkLength;
/* 160:    */     }
/* 161:224 */     int totalRead = chunkLength;
/* 162:    */     do
/* 163:    */     {
/* 164:226 */       offset += chunkLength;
/* 165:227 */       if (!readyBuffer()) {
/* 166:    */         break;
/* 167:    */       }
/* 168:230 */       chunkLength = Math.min(this._bufferLength - this._bufferPosition, length - totalRead);
/* 169:231 */       System.arraycopy(this._decodedBytes, this._bufferPosition, buffer, offset, chunkLength);
/* 170:232 */       this._bufferPosition += chunkLength;
/* 171:233 */       totalRead += chunkLength;
/* 172:234 */     } while (totalRead < length);
/* 173:236 */     return totalRead;
/* 174:    */   }
/* 175:    */   
/* 176:    */   public long skip(long n)
/* 177:    */     throws IOException
/* 178:    */   {
/* 179:266 */     if (this._inputStreamClosed) {
/* 180:267 */       return -1L;
/* 181:    */     }
/* 182:269 */     if (n <= 0L) {
/* 183:270 */       return n;
/* 184:    */     }
/* 185:    */     long skipped;
/* 186:275 */     if (this._bufferPosition < this._bufferLength)
/* 187:    */     {
/* 188:276 */       int left = this._bufferLength - this._bufferPosition;
/* 189:277 */       if (n <= left)
/* 190:    */       {
/* 191:278 */         this._bufferPosition += (int)n;
/* 192:279 */         return n;
/* 193:    */       }
/* 194:281 */       this._bufferPosition = this._bufferLength;
/* 195:282 */       long skipped = left;
/* 196:283 */       n -= left;
/* 197:    */     }
/* 198:    */     else
/* 199:    */     {
/* 200:285 */       skipped = 0L;
/* 201:    */     }
/* 202:    */     int amount;
/* 203:    */     do
/* 204:    */     {
/* 205:289 */       amount = this._decompressor.skipOrDecodeChunk(this._wrapper, this._inputBuffer, this._decodedBytes, n);
/* 206:290 */       if (amount < 0) {
/* 207:    */         break;
/* 208:    */       }
/* 209:291 */       skipped += amount;
/* 210:292 */       n -= amount;
/* 211:293 */     } while (n > 0L);
/* 212:294 */     return skipped;
/* 213:298 */     if (amount == -1)
/* 214:    */     {
/* 215:299 */       close();
/* 216:300 */       return skipped;
/* 217:    */     }
/* 218:303 */     this._bufferLength = (-(amount + 1));
/* 219:304 */     skipped += n;
/* 220:305 */     this._bufferPosition = ((int)n);
/* 221:306 */     return skipped;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public int readAndWrite(OutputStream out)
/* 225:    */     throws IOException
/* 226:    */   {
/* 227:328 */     int total = 0;
/* 228:330 */     while (readyBuffer())
/* 229:    */     {
/* 230:331 */       int avail = this._bufferLength - this._bufferPosition;
/* 231:332 */       out.write(this._decodedBytes, this._bufferPosition, avail);
/* 232:333 */       this._bufferPosition += avail;
/* 233:334 */       total += avail;
/* 234:    */     }
/* 235:336 */     return total;
/* 236:    */   }
/* 237:    */   
/* 238:    */   protected boolean readyBuffer()
/* 239:    */     throws IOException
/* 240:    */   {
/* 241:351 */     if (this._inputStreamClosed) {
/* 242:352 */       throw new IOException("Input stream closed");
/* 243:    */     }
/* 244:354 */     if (this._bufferPosition < this._bufferLength) {
/* 245:355 */       return true;
/* 246:    */     }
/* 247:357 */     this._bufferLength = this._decompressor.decodeChunk(this._wrapper, this._inputBuffer, this._decodedBytes);
/* 248:358 */     if (this._bufferLength < 0)
/* 249:    */     {
/* 250:359 */       close();
/* 251:360 */       return false;
/* 252:    */     }
/* 253:362 */     this._bufferPosition = 0;
/* 254:363 */     return this._bufferPosition < this._bufferLength;
/* 255:    */   }
/* 256:    */   
/* 257:    */   protected final int readRaw(byte[] buffer, int offset, int length)
/* 258:    */     throws IOException
/* 259:    */   {
/* 260:367 */     return super.read(buffer, offset, length);
/* 261:    */   }
/* 262:    */   
/* 263:    */   protected final long skipRaw(long amount)
/* 264:    */     throws IOException
/* 265:    */   {
/* 266:371 */     return super.skip(amount);
/* 267:    */   }
/* 268:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.util.LZFFileInputStream
 * JD-Core Version:    0.7.0.1
 */