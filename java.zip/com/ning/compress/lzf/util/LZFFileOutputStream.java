/*   1:    */ package com.ning.compress.lzf.util;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import com.ning.compress.lzf.ChunkEncoder;
/*   5:    */ import java.io.File;
/*   6:    */ import java.io.FileDescriptor;
/*   7:    */ import java.io.FileNotFoundException;
/*   8:    */ import java.io.FileOutputStream;
/*   9:    */ import java.io.IOException;
/*  10:    */ import java.io.InputStream;
/*  11:    */ import java.nio.ByteBuffer;
/*  12:    */ import java.nio.MappedByteBuffer;
/*  13:    */ import java.nio.channels.FileChannel;
/*  14:    */ import java.nio.channels.FileChannel.MapMode;
/*  15:    */ import java.nio.channels.WritableByteChannel;
/*  16:    */ 
/*  17:    */ public class LZFFileOutputStream
/*  18:    */   extends FileOutputStream
/*  19:    */   implements WritableByteChannel
/*  20:    */ {
/*  21:    */   private static final int OUTPUT_BUFFER_SIZE = 65535;
/*  22:    */   private final ChunkEncoder _encoder;
/*  23:    */   private final BufferRecycler _recycler;
/*  24:    */   protected byte[] _outputBuffer;
/*  25: 40 */   protected int _position = 0;
/*  26: 48 */   protected boolean _cfgFinishBlockOnFlush = true;
/*  27:    */   protected boolean _outputStreamClosed;
/*  28:    */   private final LZFFileOutputStream.Wrapper _wrapper;
/*  29:    */   
/*  30:    */   public LZFFileOutputStream(File file)
/*  31:    */     throws FileNotFoundException
/*  32:    */   {
/*  33: 69 */     this(ChunkEncoderFactory.optimalInstance(65535), file);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public LZFFileOutputStream(File file, boolean append)
/*  37:    */     throws FileNotFoundException
/*  38:    */   {
/*  39: 73 */     this(ChunkEncoderFactory.optimalInstance(65535), file, append);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public LZFFileOutputStream(FileDescriptor fdObj)
/*  43:    */   {
/*  44: 77 */     this(ChunkEncoderFactory.optimalInstance(65535), fdObj);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public LZFFileOutputStream(String name)
/*  48:    */     throws FileNotFoundException
/*  49:    */   {
/*  50: 81 */     this(ChunkEncoderFactory.optimalInstance(65535), name);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public LZFFileOutputStream(String name, boolean append)
/*  54:    */     throws FileNotFoundException
/*  55:    */   {
/*  56: 85 */     this(ChunkEncoderFactory.optimalInstance(65535), name, append);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public LZFFileOutputStream(ChunkEncoder encoder, File file)
/*  60:    */     throws FileNotFoundException
/*  61:    */   {
/*  62: 89 */     this(encoder, file, encoder.getBufferRecycler());
/*  63:    */   }
/*  64:    */   
/*  65:    */   public LZFFileOutputStream(ChunkEncoder encoder, File file, boolean append)
/*  66:    */     throws FileNotFoundException
/*  67:    */   {
/*  68: 93 */     this(encoder, file, append, encoder.getBufferRecycler());
/*  69:    */   }
/*  70:    */   
/*  71:    */   public LZFFileOutputStream(ChunkEncoder encoder, FileDescriptor fdObj)
/*  72:    */   {
/*  73: 97 */     this(encoder, fdObj, encoder.getBufferRecycler());
/*  74:    */   }
/*  75:    */   
/*  76:    */   public LZFFileOutputStream(ChunkEncoder encoder, String name)
/*  77:    */     throws FileNotFoundException
/*  78:    */   {
/*  79:101 */     this(encoder, name, encoder.getBufferRecycler());
/*  80:    */   }
/*  81:    */   
/*  82:    */   public LZFFileOutputStream(ChunkEncoder encoder, String name, boolean append)
/*  83:    */     throws FileNotFoundException
/*  84:    */   {
/*  85:105 */     this(encoder, name, append, encoder.getBufferRecycler());
/*  86:    */   }
/*  87:    */   
/*  88:    */   public LZFFileOutputStream(ChunkEncoder encoder, File file, BufferRecycler bufferRecycler)
/*  89:    */     throws FileNotFoundException
/*  90:    */   {
/*  91:109 */     super(file);
/*  92:110 */     this._encoder = encoder;
/*  93:111 */     if (bufferRecycler == null) {
/*  94:112 */       bufferRecycler = encoder.getBufferRecycler();
/*  95:    */     }
/*  96:114 */     this._recycler = bufferRecycler;
/*  97:115 */     this._outputBuffer = bufferRecycler.allocOutputBuffer(65535);
/*  98:116 */     this._wrapper = new LZFFileOutputStream.Wrapper(this, null);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public LZFFileOutputStream(ChunkEncoder encoder, File file, boolean append, BufferRecycler bufferRecycler)
/* 102:    */     throws FileNotFoundException
/* 103:    */   {
/* 104:120 */     super(file, append);
/* 105:121 */     this._encoder = encoder;
/* 106:122 */     this._recycler = bufferRecycler;
/* 107:123 */     this._outputBuffer = bufferRecycler.allocOutputBuffer(65535);
/* 108:124 */     this._wrapper = new LZFFileOutputStream.Wrapper(this, null);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public LZFFileOutputStream(ChunkEncoder encoder, FileDescriptor fdObj, BufferRecycler bufferRecycler)
/* 112:    */   {
/* 113:128 */     super(fdObj);
/* 114:129 */     this._encoder = encoder;
/* 115:130 */     this._recycler = bufferRecycler;
/* 116:131 */     this._outputBuffer = bufferRecycler.allocOutputBuffer(65535);
/* 117:132 */     this._wrapper = new LZFFileOutputStream.Wrapper(this, null);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public LZFFileOutputStream(ChunkEncoder encoder, String name, BufferRecycler bufferRecycler)
/* 121:    */     throws FileNotFoundException
/* 122:    */   {
/* 123:136 */     super(name);
/* 124:137 */     this._encoder = encoder;
/* 125:138 */     this._recycler = bufferRecycler;
/* 126:139 */     this._outputBuffer = bufferRecycler.allocOutputBuffer(65535);
/* 127:140 */     this._wrapper = new LZFFileOutputStream.Wrapper(this, null);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public LZFFileOutputStream(ChunkEncoder encoder, String name, boolean append, BufferRecycler bufferRecycler)
/* 131:    */     throws FileNotFoundException
/* 132:    */   {
/* 133:144 */     super(name, append);
/* 134:145 */     this._encoder = encoder;
/* 135:146 */     this._recycler = bufferRecycler;
/* 136:147 */     this._outputBuffer = bufferRecycler.allocOutputBuffer(65535);
/* 137:148 */     this._wrapper = new LZFFileOutputStream.Wrapper(this, null);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public LZFFileOutputStream setFinishBlockOnFlush(boolean b)
/* 141:    */   {
/* 142:156 */     this._cfgFinishBlockOnFlush = b;
/* 143:157 */     return this;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public boolean isOpen()
/* 147:    */   {
/* 148:168 */     return !this._outputStreamClosed;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public void close()
/* 152:    */     throws IOException
/* 153:    */   {
/* 154:174 */     if (!this._outputStreamClosed)
/* 155:    */     {
/* 156:175 */       if (this._position > 0) {
/* 157:176 */         writeCompressedBlock();
/* 158:    */       }
/* 159:178 */       super.flush();
/* 160:179 */       super.close();
/* 161:180 */       this._outputStreamClosed = true;
/* 162:181 */       this._encoder.close();
/* 163:182 */       byte[] buf = this._outputBuffer;
/* 164:183 */       if (buf != null)
/* 165:    */       {
/* 166:184 */         this._outputBuffer = null;
/* 167:185 */         this._recycler.releaseOutputBuffer(buf);
/* 168:    */       }
/* 169:    */     }
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void flush()
/* 173:    */     throws IOException
/* 174:    */   {
/* 175:193 */     checkNotClosed();
/* 176:194 */     if ((this._cfgFinishBlockOnFlush) && (this._position > 0)) {
/* 177:195 */       writeCompressedBlock();
/* 178:    */     }
/* 179:197 */     super.flush();
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void write(byte[] b)
/* 183:    */     throws IOException
/* 184:    */   {
/* 185:209 */     write(b, 0, b.length);
/* 186:    */   }
/* 187:    */   
/* 188:    */   public void write(byte[] buffer, int offset, int length)
/* 189:    */     throws IOException
/* 190:    */   {
/* 191:215 */     checkNotClosed();
/* 192:    */     
/* 193:217 */     int BUFFER_LEN = this._outputBuffer.length;
/* 194:220 */     while ((this._position == 0) && (length >= BUFFER_LEN))
/* 195:    */     {
/* 196:221 */       this._encoder.encodeAndWriteChunk(buffer, offset, BUFFER_LEN, this._wrapper);
/* 197:222 */       offset += BUFFER_LEN;
/* 198:223 */       length -= BUFFER_LEN;
/* 199:    */     }
/* 200:227 */     int free = BUFFER_LEN - this._position;
/* 201:228 */     if (free > length)
/* 202:    */     {
/* 203:229 */       System.arraycopy(buffer, offset, this._outputBuffer, this._position, length);
/* 204:230 */       this._position += length;
/* 205:231 */       return;
/* 206:    */     }
/* 207:234 */     System.arraycopy(buffer, offset, this._outputBuffer, this._position, free);
/* 208:235 */     offset += free;
/* 209:236 */     length -= free;
/* 210:237 */     this._position += free;
/* 211:238 */     writeCompressedBlock();
/* 212:241 */     while (length >= BUFFER_LEN)
/* 213:    */     {
/* 214:242 */       this._encoder.encodeAndWriteChunk(buffer, offset, BUFFER_LEN, this._wrapper);
/* 215:243 */       offset += BUFFER_LEN;
/* 216:244 */       length -= BUFFER_LEN;
/* 217:    */     }
/* 218:248 */     if (length > 0) {
/* 219:249 */       System.arraycopy(buffer, offset, this._outputBuffer, 0, length);
/* 220:    */     }
/* 221:251 */     this._position = length;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public void write(int b)
/* 225:    */     throws IOException
/* 226:    */   {
/* 227:257 */     checkNotClosed();
/* 228:258 */     if (this._position >= this._outputBuffer.length) {
/* 229:259 */       writeCompressedBlock();
/* 230:    */     }
/* 231:261 */     this._outputBuffer[(this._position++)] = ((byte)b);
/* 232:    */   }
/* 233:    */   
/* 234:    */   public void write(InputStream in)
/* 235:    */     throws IOException
/* 236:    */   {
/* 237:265 */     writeCompressedBlock();
/* 238:    */     int read;
/* 239:267 */     while ((read = in.read(this._outputBuffer)) >= 0)
/* 240:    */     {
/* 241:268 */       this._position = read;
/* 242:269 */       writeCompressedBlock();
/* 243:    */     }
/* 244:    */   }
/* 245:    */   
/* 246:    */   public synchronized int write(ByteBuffer src)
/* 247:    */     throws IOException
/* 248:    */   {
/* 249:284 */     int r = src.remaining();
/* 250:285 */     if (r <= 0) {
/* 251:286 */       return r;
/* 252:    */     }
/* 253:288 */     writeCompressedBlock();
/* 254:289 */     if (src.hasArray()) {
/* 255:291 */       write(src.array(), src.arrayOffset(), src.limit() - src.arrayOffset());
/* 256:    */     } else {
/* 257:294 */       while (src.hasRemaining())
/* 258:    */       {
/* 259:295 */         int toRead = Math.min(src.remaining(), this._outputBuffer.length);
/* 260:296 */         src.get(this._outputBuffer, 0, toRead);
/* 261:297 */         this._position = toRead;
/* 262:298 */         writeCompressedBlock();
/* 263:    */       }
/* 264:    */     }
/* 265:301 */     return r;
/* 266:    */   }
/* 267:    */   
/* 268:    */   public void write(FileChannel in)
/* 269:    */     throws IOException
/* 270:    */   {
/* 271:305 */     MappedByteBuffer src = in.map(FileChannel.MapMode.READ_ONLY, 0L, in.size());
/* 272:306 */     write(src);
/* 273:    */   }
/* 274:    */   
/* 275:    */   public boolean getFinishBlockOnFlush()
/* 276:    */   {
/* 277:320 */     return this._cfgFinishBlockOnFlush;
/* 278:    */   }
/* 279:    */   
/* 280:    */   public LZFFileOutputStream finishBlock()
/* 281:    */     throws IOException
/* 282:    */   {
/* 283:332 */     checkNotClosed();
/* 284:333 */     if (this._position > 0) {
/* 285:334 */       writeCompressedBlock();
/* 286:    */     }
/* 287:336 */     return this;
/* 288:    */   }
/* 289:    */   
/* 290:    */   protected void writeCompressedBlock()
/* 291:    */     throws IOException
/* 292:    */   {
/* 293:350 */     int left = this._position;
/* 294:351 */     this._position = 0;
/* 295:352 */     int offset = 0;
/* 296:354 */     while (left > 0)
/* 297:    */     {
/* 298:355 */       int chunkLen = Math.min(65535, left);
/* 299:356 */       this._encoder.encodeAndWriteChunk(this._outputBuffer, offset, chunkLen, this._wrapper);
/* 300:357 */       offset += chunkLen;
/* 301:358 */       left -= chunkLen;
/* 302:    */     }
/* 303:    */   }
/* 304:    */   
/* 305:    */   protected void rawWrite(byte[] buffer, int offset, int length)
/* 306:    */     throws IOException
/* 307:    */   {
/* 308:364 */     super.write(buffer, offset, length);
/* 309:    */   }
/* 310:    */   
/* 311:    */   protected void checkNotClosed()
/* 312:    */     throws IOException
/* 313:    */   {
/* 314:369 */     if (this._outputStreamClosed) {
/* 315:370 */       throw new IOException(getClass().getName() + " already closed");
/* 316:    */     }
/* 317:    */   }
/* 318:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.util.LZFFileOutputStream
 * JD-Core Version:    0.7.0.1
 */