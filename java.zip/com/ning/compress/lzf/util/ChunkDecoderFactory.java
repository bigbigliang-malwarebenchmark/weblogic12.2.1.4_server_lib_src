/*  1:   */ package com.ning.compress.lzf.util;
/*  2:   */ 
/*  3:   */ import com.ning.compress.lzf.ChunkDecoder;
/*  4:   */ import com.ning.compress.lzf.impl.UnsafeChunkDecoder;
/*  5:   */ import com.ning.compress.lzf.impl.VanillaChunkDecoder;
/*  6:   */ 
/*  7:   */ public class ChunkDecoderFactory
/*  8:   */ {
/*  9:   */   private static final ChunkDecoderFactory _instance;
/* 10:   */   private final Class<? extends ChunkDecoder> _implClass;
/* 11:   */   
/* 12:   */   static
/* 13:   */   {
/* 14:19 */     Class<?> impl = null;
/* 15:   */     try
/* 16:   */     {
/* 17:22 */       impl = Class.forName(UnsafeChunkDecoder.class.getName());
/* 18:   */     }
/* 19:   */     catch (Throwable t) {}
/* 20:24 */     if (impl == null) {
/* 21:25 */       impl = VanillaChunkDecoder.class;
/* 22:   */     }
/* 23:27 */     _instance = new ChunkDecoderFactory(impl);
/* 24:   */   }
/* 25:   */   
/* 26:   */   private ChunkDecoderFactory(Class<?> imp)
/* 27:   */   {
/* 28:35 */     this._implClass = imp;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public static ChunkDecoder optimalInstance()
/* 32:   */   {
/* 33:   */     try
/* 34:   */     {
/* 35:53 */       return (ChunkDecoder)_instance._implClass.newInstance();
/* 36:   */     }
/* 37:   */     catch (Exception e)
/* 38:   */     {
/* 39:55 */       throw new IllegalStateException("Failed to load a ChunkDecoder instance (" + e.getClass().getName() + "): " + e.getMessage(), e);
/* 40:   */     }
/* 41:   */   }
/* 42:   */   
/* 43:   */   public static ChunkDecoder safeInstance()
/* 44:   */   {
/* 45:66 */     return new VanillaChunkDecoder();
/* 46:   */   }
/* 47:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.util.ChunkDecoderFactory
 * JD-Core Version:    0.7.0.1
 */