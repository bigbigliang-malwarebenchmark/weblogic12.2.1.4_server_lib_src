/*   1:    */ package com.ning.compress.lzf;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import com.ning.compress.DataHandler;
/*   5:    */ import com.ning.compress.Uncompressor;
/*   6:    */ import com.ning.compress.lzf.util.ChunkDecoderFactory;
/*   7:    */ import java.io.IOException;
/*   8:    */ 
/*   9:    */ public class LZFUncompressor
/*  10:    */   extends Uncompressor
/*  11:    */ {
/*  12:    */   protected static final int STATE_INITIAL = 0;
/*  13:    */   protected static final int STATE_HEADER_Z_GOTTEN = 1;
/*  14:    */   protected static final int STATE_HEADER_ZV_GOTTEN = 2;
/*  15:    */   protected static final int STATE_HEADER_COMPRESSED_0 = 3;
/*  16:    */   protected static final int STATE_HEADER_COMPRESSED_1 = 4;
/*  17:    */   protected static final int STATE_HEADER_COMPRESSED_2 = 5;
/*  18:    */   protected static final int STATE_HEADER_COMPRESSED_3 = 6;
/*  19:    */   protected static final int STATE_HEADER_COMPRESSED_BUFFERING = 7;
/*  20:    */   protected static final int STATE_HEADER_UNCOMPRESSED_0 = 8;
/*  21:    */   protected static final int STATE_HEADER_UNCOMPRESSED_1 = 9;
/*  22:    */   protected static final int STATE_HEADER_UNCOMPRESSED_STREAMING = 10;
/*  23:    */   protected final DataHandler _handler;
/*  24:    */   protected final ChunkDecoder _decoder;
/*  25:    */   protected final BufferRecycler _recycler;
/*  26: 69 */   protected int _state = 0;
/*  27:    */   protected boolean _terminated;
/*  28:    */   protected int _compressedLength;
/*  29:    */   protected int _uncompressedLength;
/*  30:    */   protected byte[] _inputBuffer;
/*  31:    */   protected byte[] _decodeBuffer;
/*  32:    */   protected int _bytesReadFromBlock;
/*  33:    */   
/*  34:    */   public LZFUncompressor(DataHandler handler)
/*  35:    */   {
/*  36:112 */     this(handler, ChunkDecoderFactory.optimalInstance(), BufferRecycler.instance());
/*  37:    */   }
/*  38:    */   
/*  39:    */   public LZFUncompressor(DataHandler handler, BufferRecycler bufferRecycler)
/*  40:    */   {
/*  41:116 */     this(handler, ChunkDecoderFactory.optimalInstance(), bufferRecycler);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public LZFUncompressor(DataHandler handler, ChunkDecoder dec)
/*  45:    */   {
/*  46:121 */     this(handler, dec, BufferRecycler.instance());
/*  47:    */   }
/*  48:    */   
/*  49:    */   public LZFUncompressor(DataHandler handler, ChunkDecoder dec, BufferRecycler bufferRecycler)
/*  50:    */   {
/*  51:126 */     this._handler = handler;
/*  52:127 */     this._decoder = dec;
/*  53:128 */     this._recycler = bufferRecycler;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public boolean feedCompressedData(byte[] comp, int offset, int len)
/*  57:    */     throws IOException
/*  58:    */   {
/*  59:140 */     int end = offset + len;
/*  60:142 */     while (offset < end)
/*  61:    */     {
/*  62:143 */       byte b = comp[(offset++)];
/*  63:145 */       switch (this._state)
/*  64:    */       {
/*  65:    */       case 0: 
/*  66:147 */         if (b != 90) {
/*  67:148 */           _reportBadHeader(comp, offset, len, 0);
/*  68:    */         }
/*  69:150 */         if (offset >= end) {
/*  70:151 */           this._state = 1;
/*  71:    */         } else {
/*  72:154 */           b = comp[(offset++)];
/*  73:    */         }
/*  74:    */         break;
/*  75:    */       case 1: 
/*  76:157 */         if (b != 86) {
/*  77:158 */           _reportBadHeader(comp, offset, len, 1);
/*  78:    */         }
/*  79:160 */         if (offset >= end) {
/*  80:161 */           this._state = 2;
/*  81:    */         } else {
/*  82:164 */           b = comp[(offset++)];
/*  83:    */         }
/*  84:    */         break;
/*  85:    */       case 2: 
/*  86:167 */         this._bytesReadFromBlock = 0;
/*  87:    */         
/*  88:169 */         int type = b & 0xFF;
/*  89:170 */         if (type != 1)
/*  90:    */         {
/*  91:171 */           if (type == 0) {
/*  92:172 */             this._state = 8;
/*  93:    */           } else {
/*  94:175 */             _reportBadBlockType(comp, offset, len, type);
/*  95:    */           }
/*  96:    */         }
/*  97:    */         else
/*  98:    */         {
/*  99:178 */           this._state = 3;
/* 100:179 */           if (offset < end) {
/* 101:182 */             b = comp[(offset++)];
/* 102:    */           }
/* 103:    */         }
/* 104:    */         break;
/* 105:    */       case 3: 
/* 106:185 */         this._compressedLength = (b & 0xFF);
/* 107:186 */         if (offset >= end) {
/* 108:187 */           this._state = 4;
/* 109:    */         } else {
/* 110:190 */           b = comp[(offset++)];
/* 111:    */         }
/* 112:    */         break;
/* 113:    */       case 4: 
/* 114:193 */         this._compressedLength = ((this._compressedLength << 8) + (b & 0xFF));
/* 115:194 */         if (offset >= end) {
/* 116:195 */           this._state = 5;
/* 117:    */         } else {
/* 118:198 */           b = comp[(offset++)];
/* 119:    */         }
/* 120:    */         break;
/* 121:    */       case 5: 
/* 122:201 */         this._uncompressedLength = (b & 0xFF);
/* 123:202 */         if (offset >= end) {
/* 124:203 */           this._state = 6;
/* 125:    */         } else {
/* 126:206 */           b = comp[(offset++)];
/* 127:    */         }
/* 128:    */         break;
/* 129:    */       case 6: 
/* 130:209 */         this._uncompressedLength = ((this._uncompressedLength << 8) + (b & 0xFF));
/* 131:210 */         this._state = 7;
/* 132:211 */         if (offset < end) {
/* 133:214 */           b = comp[(offset++)];
/* 134:    */         }
/* 135:    */         break;
/* 136:    */       case 7: 
/* 137:217 */         offset = _handleCompressed(comp, --offset, end);
/* 138:    */         
/* 139:219 */         break;
/* 140:    */       case 8: 
/* 141:222 */         this._uncompressedLength = (b & 0xFF);
/* 142:223 */         if (offset >= end) {
/* 143:224 */           this._state = 9;
/* 144:    */         } else {
/* 145:227 */           b = comp[(offset++)];
/* 146:    */         }
/* 147:    */         break;
/* 148:    */       case 9: 
/* 149:230 */         this._uncompressedLength = ((this._uncompressedLength << 8) + (b & 0xFF));
/* 150:231 */         this._state = 10;
/* 151:232 */         if (offset < end) {
/* 152:235 */           b = comp[(offset++)];
/* 153:    */         }
/* 154:    */         break;
/* 155:    */       case 10: 
/* 156:238 */         offset = _handleUncompressed(comp, --offset, end);
/* 157:239 */         if (!this._terminated) {
/* 158:243 */           if (this._bytesReadFromBlock == this._uncompressedLength) {
/* 159:244 */             this._state = 0;
/* 160:    */           }
/* 161:    */         }
/* 162:    */         break;
/* 163:    */       }
/* 164:    */     }
/* 165:249 */     return !this._terminated;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void complete()
/* 169:    */     throws IOException
/* 170:    */   {
/* 171:255 */     byte[] b = this._inputBuffer;
/* 172:256 */     if (b != null)
/* 173:    */     {
/* 174:257 */       this._inputBuffer = null;
/* 175:258 */       this._recycler.releaseInputBuffer(b);
/* 176:    */     }
/* 177:260 */     b = this._decodeBuffer;
/* 178:261 */     if (b != null)
/* 179:    */     {
/* 180:262 */       this._decodeBuffer = null;
/* 181:263 */       this._recycler.releaseDecodeBuffer(b);
/* 182:    */     }
/* 183:266 */     this._handler.allDataHandled();
/* 184:267 */     if ((!this._terminated) && 
/* 185:268 */       (this._state != 0))
/* 186:    */     {
/* 187:269 */       if (this._state == 7) {
/* 188:270 */         throw new LZFException("Incomplete compressed LZF block; only got " + this._bytesReadFromBlock + " bytes, needed " + this._compressedLength);
/* 189:    */       }
/* 190:273 */       if (this._state == 10) {
/* 191:274 */         throw new LZFException("Incomplete uncompressed LZF block; only got " + this._bytesReadFromBlock + " bytes, needed " + this._uncompressedLength);
/* 192:    */       }
/* 193:277 */       throw new LZFException("Incomplete LZF block; decoding state = " + this._state);
/* 194:    */     }
/* 195:    */   }
/* 196:    */   
/* 197:    */   private final int _handleUncompressed(byte[] comp, int offset, int end)
/* 198:    */     throws IOException
/* 199:    */   {
/* 200:291 */     int amount = Math.min(end - offset, this._uncompressedLength - this._bytesReadFromBlock);
/* 201:292 */     if (!this._handler.handleData(comp, offset, amount)) {
/* 202:293 */       this._terminated = true;
/* 203:    */     }
/* 204:295 */     this._bytesReadFromBlock += amount;
/* 205:296 */     return offset + amount;
/* 206:    */   }
/* 207:    */   
/* 208:    */   private final int _handleCompressed(byte[] comp, int offset, int end)
/* 209:    */     throws IOException
/* 210:    */   {
/* 211:302 */     int available = end - offset;
/* 212:303 */     if ((this._bytesReadFromBlock == 0) && (available >= this._compressedLength))
/* 213:    */     {
/* 214:304 */       _uncompress(comp, offset, this._compressedLength);
/* 215:305 */       offset += this._compressedLength;
/* 216:306 */       this._state = 0;
/* 217:307 */       return offset;
/* 218:    */     }
/* 219:310 */     if (this._inputBuffer == null) {
/* 220:311 */       this._inputBuffer = this._recycler.allocInputBuffer(65535);
/* 221:    */     }
/* 222:313 */     int amount = Math.min(available, this._compressedLength - this._bytesReadFromBlock);
/* 223:314 */     System.arraycopy(comp, offset, this._inputBuffer, this._bytesReadFromBlock, amount);
/* 224:315 */     offset += amount;
/* 225:316 */     this._bytesReadFromBlock += amount;
/* 226:318 */     if (this._bytesReadFromBlock == this._compressedLength)
/* 227:    */     {
/* 228:319 */       _uncompress(this._inputBuffer, 0, this._compressedLength);
/* 229:320 */       this._state = 0;
/* 230:    */     }
/* 231:322 */     return offset;
/* 232:    */   }
/* 233:    */   
/* 234:    */   private final void _uncompress(byte[] src, int srcOffset, int len)
/* 235:    */     throws IOException
/* 236:    */   {
/* 237:327 */     if (this._decodeBuffer == null) {
/* 238:328 */       this._decodeBuffer = this._recycler.allocDecodeBuffer(65535);
/* 239:    */     }
/* 240:330 */     this._decoder.decodeChunk(src, srcOffset, this._decodeBuffer, 0, this._uncompressedLength);
/* 241:331 */     this._handler.handleData(this._decodeBuffer, 0, this._uncompressedLength);
/* 242:    */   }
/* 243:    */   
/* 244:    */   protected void _reportBadHeader(byte[] comp, int nextOffset, int len, int relative)
/* 245:    */     throws IOException
/* 246:    */   {
/* 247:343 */     char exp = relative == 0 ? 'Z' : 'V';
/* 248:344 */     nextOffset--;
/* 249:345 */     throw new LZFException("Bad block: byte #" + relative + " of block header not '" + exp + "' (0x" + Integer.toHexString(exp) + ") but 0x" + Integer.toHexString(comp[nextOffset] & 0xFF) + " (at " + (nextOffset - 1) + "/" + len + ")");
/* 250:    */   }
/* 251:    */   
/* 252:    */   protected void _reportBadBlockType(byte[] comp, int nextOffset, int len, int type)
/* 253:    */     throws IOException
/* 254:    */   {
/* 255:354 */     throw new LZFException("Bad block: unrecognized type 0x" + Integer.toHexString(type & 0xFF) + " (at " + (nextOffset - 1) + "/" + len + ")");
/* 256:    */   }
/* 257:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.LZFUncompressor
 * JD-Core Version:    0.7.0.1
 */