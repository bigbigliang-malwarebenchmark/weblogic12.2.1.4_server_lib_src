/*   1:    */ package com.ning.compress.lzf;
/*   2:    */ 
/*   3:    */ import com.ning.compress.lzf.util.ChunkDecoderFactory;
/*   4:    */ import java.util.concurrent.atomic.AtomicReference;
/*   5:    */ 
/*   6:    */ public class LZFDecoder
/*   7:    */ {
/*   8: 37 */   protected static final AtomicReference<ChunkDecoder> _fastDecoderRef = new AtomicReference();
/*   9: 43 */   protected static final AtomicReference<ChunkDecoder> _safeDecoderRef = new AtomicReference();
/*  10:    */   
/*  11:    */   public static ChunkDecoder fastDecoder()
/*  12:    */   {
/*  13: 58 */     ChunkDecoder dec = (ChunkDecoder)_fastDecoderRef.get();
/*  14: 59 */     if (dec == null)
/*  15:    */     {
/*  16: 60 */       dec = ChunkDecoderFactory.optimalInstance();
/*  17: 61 */       _fastDecoderRef.compareAndSet(null, dec);
/*  18:    */     }
/*  19: 63 */     return dec;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static ChunkDecoder safeDecoder()
/*  23:    */   {
/*  24: 73 */     ChunkDecoder dec = (ChunkDecoder)_safeDecoderRef.get();
/*  25: 74 */     if (dec == null)
/*  26:    */     {
/*  27: 75 */       dec = ChunkDecoderFactory.safeInstance();
/*  28: 76 */       _safeDecoderRef.compareAndSet(null, dec);
/*  29:    */     }
/*  30: 78 */     return dec;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static int calculateUncompressedSize(byte[] data, int offset, int length)
/*  34:    */     throws LZFException
/*  35:    */   {
/*  36: 92 */     return ChunkDecoder.calculateUncompressedSize(data, length, length);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static byte[] decode(byte[] inputBuffer)
/*  40:    */     throws LZFException
/*  41:    */   {
/*  42:102 */     return fastDecoder().decode(inputBuffer, 0, inputBuffer.length);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static byte[] decode(byte[] inputBuffer, int offset, int length)
/*  46:    */     throws LZFException
/*  47:    */   {
/*  48:106 */     return fastDecoder().decode(inputBuffer, offset, length);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static int decode(byte[] inputBuffer, byte[] targetBuffer)
/*  52:    */     throws LZFException
/*  53:    */   {
/*  54:110 */     return fastDecoder().decode(inputBuffer, 0, inputBuffer.length, targetBuffer);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static int decode(byte[] sourceBuffer, int offset, int length, byte[] targetBuffer)
/*  58:    */     throws LZFException
/*  59:    */   {
/*  60:115 */     return fastDecoder().decode(sourceBuffer, offset, length, targetBuffer);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static byte[] safeDecode(byte[] inputBuffer)
/*  64:    */     throws LZFException
/*  65:    */   {
/*  66:125 */     return safeDecoder().decode(inputBuffer, 0, inputBuffer.length);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static byte[] safeDecode(byte[] inputBuffer, int offset, int length)
/*  70:    */     throws LZFException
/*  71:    */   {
/*  72:129 */     return safeDecoder().decode(inputBuffer, offset, length);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static int safeDecode(byte[] inputBuffer, byte[] targetBuffer)
/*  76:    */     throws LZFException
/*  77:    */   {
/*  78:133 */     return safeDecoder().decode(inputBuffer, 0, inputBuffer.length, targetBuffer);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static int safeDecode(byte[] sourceBuffer, int offset, int length, byte[] targetBuffer)
/*  82:    */     throws LZFException
/*  83:    */   {
/*  84:138 */     return safeDecoder().decode(sourceBuffer, offset, length, targetBuffer);
/*  85:    */   }
/*  86:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.LZFDecoder
 * JD-Core Version:    0.7.0.1
 */