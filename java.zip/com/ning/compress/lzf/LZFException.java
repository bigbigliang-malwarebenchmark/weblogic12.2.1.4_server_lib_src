/*  1:   */ package com.ning.compress.lzf;
/*  2:   */ 
/*  3:   */ import com.ning.compress.CompressionFormatException;
/*  4:   */ 
/*  5:   */ public class LZFException
/*  6:   */   extends CompressionFormatException
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = 1L;
/*  9:   */   
/* 10:   */   public LZFException(String message)
/* 11:   */   {
/* 12:10 */     super(message);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public LZFException(Throwable t)
/* 16:   */   {
/* 17:14 */     super(t);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public LZFException(String message, Throwable t)
/* 21:   */   {
/* 22:18 */     super(message, t);
/* 23:   */   }
/* 24:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.LZFException
 * JD-Core Version:    0.7.0.1
 */