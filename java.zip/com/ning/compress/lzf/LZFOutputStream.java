/*   1:    */ package com.ning.compress.lzf;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import com.ning.compress.lzf.util.ChunkEncoderFactory;
/*   5:    */ import java.io.FilterOutputStream;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStream;
/*   8:    */ import java.io.OutputStream;
/*   9:    */ import java.nio.ByteBuffer;
/*  10:    */ import java.nio.MappedByteBuffer;
/*  11:    */ import java.nio.channels.FileChannel;
/*  12:    */ import java.nio.channels.FileChannel.MapMode;
/*  13:    */ import java.nio.channels.WritableByteChannel;
/*  14:    */ 
/*  15:    */ public class LZFOutputStream
/*  16:    */   extends FilterOutputStream
/*  17:    */   implements WritableByteChannel
/*  18:    */ {
/*  19:    */   private static final int DEFAULT_OUTPUT_BUFFER_SIZE = 65535;
/*  20:    */   private final ChunkEncoder _encoder;
/*  21:    */   private final BufferRecycler _recycler;
/*  22:    */   protected byte[] _outputBuffer;
/*  23: 37 */   protected int _position = 0;
/*  24: 45 */   protected boolean _cfgFinishBlockOnFlush = true;
/*  25:    */   protected boolean _outputStreamClosed;
/*  26:    */   
/*  27:    */   public LZFOutputStream(OutputStream outputStream)
/*  28:    */   {
/*  29: 61 */     this(ChunkEncoderFactory.optimalInstance(65535), outputStream);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public LZFOutputStream(ChunkEncoder encoder, OutputStream outputStream)
/*  33:    */   {
/*  34: 66 */     this(encoder, outputStream, 65535, encoder._recycler);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public LZFOutputStream(OutputStream outputStream, BufferRecycler bufferRecycler)
/*  38:    */   {
/*  39: 71 */     this(ChunkEncoderFactory.optimalInstance(bufferRecycler), outputStream, bufferRecycler);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public LZFOutputStream(ChunkEncoder encoder, OutputStream outputStream, BufferRecycler bufferRecycler)
/*  43:    */   {
/*  44: 76 */     this(encoder, outputStream, 65535, bufferRecycler);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public LZFOutputStream(ChunkEncoder encoder, OutputStream outputStream, int bufferSize, BufferRecycler bufferRecycler)
/*  48:    */   {
/*  49: 82 */     super(outputStream);
/*  50: 83 */     this._encoder = encoder;
/*  51: 84 */     if (bufferRecycler == null) {
/*  52: 85 */       bufferRecycler = this._encoder._recycler;
/*  53:    */     }
/*  54: 87 */     this._recycler = bufferRecycler;
/*  55: 88 */     this._outputBuffer = bufferRecycler.allocOutputBuffer(bufferSize);
/*  56: 89 */     this._outputStreamClosed = false;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public LZFOutputStream setFinishBlockOnFlush(boolean b)
/*  60:    */   {
/*  61: 97 */     this._cfgFinishBlockOnFlush = b;
/*  62: 98 */     return this;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void write(int singleByte)
/*  66:    */     throws IOException
/*  67:    */   {
/*  68:110 */     checkNotClosed();
/*  69:111 */     if (this._position >= this._outputBuffer.length) {
/*  70:112 */       writeCompressedBlock();
/*  71:    */     }
/*  72:114 */     this._outputBuffer[(this._position++)] = ((byte)singleByte);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void write(byte[] buffer, int offset, int length)
/*  76:    */     throws IOException
/*  77:    */   {
/*  78:120 */     checkNotClosed();
/*  79:    */     
/*  80:122 */     int BUFFER_LEN = this._outputBuffer.length;
/*  81:125 */     while ((this._position == 0) && (length >= BUFFER_LEN))
/*  82:    */     {
/*  83:126 */       this._encoder.encodeAndWriteChunk(buffer, offset, BUFFER_LEN, this.out);
/*  84:127 */       offset += BUFFER_LEN;
/*  85:128 */       length -= BUFFER_LEN;
/*  86:    */     }
/*  87:132 */     int free = BUFFER_LEN - this._position;
/*  88:133 */     if (free > length)
/*  89:    */     {
/*  90:134 */       System.arraycopy(buffer, offset, this._outputBuffer, this._position, length);
/*  91:135 */       this._position += length;
/*  92:136 */       return;
/*  93:    */     }
/*  94:139 */     System.arraycopy(buffer, offset, this._outputBuffer, this._position, free);
/*  95:140 */     offset += free;
/*  96:141 */     length -= free;
/*  97:142 */     this._position += free;
/*  98:143 */     writeCompressedBlock();
/*  99:146 */     while (length >= BUFFER_LEN)
/* 100:    */     {
/* 101:147 */       this._encoder.encodeAndWriteChunk(buffer, offset, BUFFER_LEN, this.out);
/* 102:148 */       offset += BUFFER_LEN;
/* 103:149 */       length -= BUFFER_LEN;
/* 104:    */     }
/* 105:153 */     if (length > 0) {
/* 106:154 */       System.arraycopy(buffer, offset, this._outputBuffer, 0, length);
/* 107:    */     }
/* 108:156 */     this._position = length;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void write(InputStream in)
/* 112:    */     throws IOException
/* 113:    */   {
/* 114:160 */     writeCompressedBlock();
/* 115:    */     int read;
/* 116:162 */     while ((read = in.read(this._outputBuffer)) >= 0)
/* 117:    */     {
/* 118:163 */       this._position = read;
/* 119:164 */       writeCompressedBlock();
/* 120:    */     }
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void write(FileChannel in)
/* 124:    */     throws IOException
/* 125:    */   {
/* 126:169 */     MappedByteBuffer src = in.map(FileChannel.MapMode.READ_ONLY, 0L, in.size());
/* 127:170 */     write(src);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public synchronized int write(ByteBuffer src)
/* 131:    */     throws IOException
/* 132:    */   {
/* 133:175 */     int r = src.remaining();
/* 134:176 */     if (r <= 0) {
/* 135:177 */       return r;
/* 136:    */     }
/* 137:179 */     writeCompressedBlock();
/* 138:180 */     if (src.hasArray()) {
/* 139:182 */       write(src.array(), src.arrayOffset(), src.limit() - src.arrayOffset());
/* 140:    */     } else {
/* 141:185 */       while (src.hasRemaining())
/* 142:    */       {
/* 143:186 */         int toRead = Math.min(src.remaining(), this._outputBuffer.length);
/* 144:187 */         src.get(this._outputBuffer, 0, toRead);
/* 145:188 */         this._position = toRead;
/* 146:189 */         writeCompressedBlock();
/* 147:    */       }
/* 148:    */     }
/* 149:192 */     return r;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void flush()
/* 153:    */     throws IOException
/* 154:    */   {
/* 155:198 */     checkNotClosed();
/* 156:199 */     if ((this._cfgFinishBlockOnFlush) && (this._position > 0)) {
/* 157:200 */       writeCompressedBlock();
/* 158:    */     }
/* 159:202 */     super.flush();
/* 160:    */   }
/* 161:    */   
/* 162:    */   public boolean isOpen()
/* 163:    */   {
/* 164:207 */     return !this._outputStreamClosed;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void close()
/* 168:    */     throws IOException
/* 169:    */   {
/* 170:213 */     if (!this._outputStreamClosed)
/* 171:    */     {
/* 172:214 */       if (this._position > 0) {
/* 173:215 */         writeCompressedBlock();
/* 174:    */       }
/* 175:217 */       super.close();
/* 176:218 */       this._encoder.close();
/* 177:219 */       this._outputStreamClosed = true;
/* 178:220 */       byte[] buf = this._outputBuffer;
/* 179:221 */       if (buf != null)
/* 180:    */       {
/* 181:222 */         this._outputBuffer = null;
/* 182:223 */         this._recycler.releaseOutputBuffer(buf);
/* 183:    */       }
/* 184:    */     }
/* 185:    */   }
/* 186:    */   
/* 187:    */   public OutputStream getUnderlyingOutputStream()
/* 188:    */   {
/* 189:241 */     return this.out;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public boolean getFinishBlockOnFlush()
/* 193:    */   {
/* 194:249 */     return this._cfgFinishBlockOnFlush;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public LZFOutputStream finishBlock()
/* 198:    */     throws IOException
/* 199:    */   {
/* 200:261 */     checkNotClosed();
/* 201:262 */     if (this._position > 0) {
/* 202:263 */       writeCompressedBlock();
/* 203:    */     }
/* 204:265 */     return this;
/* 205:    */   }
/* 206:    */   
/* 207:    */   protected void writeCompressedBlock()
/* 208:    */     throws IOException
/* 209:    */   {
/* 210:279 */     int left = this._position;
/* 211:280 */     this._position = 0;
/* 212:281 */     int offset = 0;
/* 213:283 */     while (left > 0)
/* 214:    */     {
/* 215:284 */       int chunkLen = Math.min(65535, left);
/* 216:285 */       this._encoder.encodeAndWriteChunk(this._outputBuffer, offset, chunkLen, this.out);
/* 217:286 */       offset += chunkLen;
/* 218:287 */       left -= chunkLen;
/* 219:    */     }
/* 220:    */   }
/* 221:    */   
/* 222:    */   protected void checkNotClosed()
/* 223:    */     throws IOException
/* 224:    */   {
/* 225:293 */     if (this._outputStreamClosed) {
/* 226:294 */       throw new IOException(getClass().getName() + " already closed");
/* 227:    */     }
/* 228:    */   }
/* 229:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.LZFOutputStream
 * JD-Core Version:    0.7.0.1
 */