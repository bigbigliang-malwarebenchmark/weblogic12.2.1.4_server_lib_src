/*   1:    */ package com.ning.compress.lzf;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import com.ning.compress.lzf.util.ChunkDecoderFactory;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ import java.io.OutputStream;
/*   8:    */ 
/*   9:    */ public class LZFInputStream
/*  10:    */   extends InputStream
/*  11:    */ {
/*  12:    */   protected final ChunkDecoder _decoder;
/*  13:    */   protected final BufferRecycler _recycler;
/*  14:    */   protected final InputStream _inputStream;
/*  15:    */   protected boolean _inputStreamClosed;
/*  16: 50 */   protected boolean _cfgFullReads = false;
/*  17:    */   protected byte[] _inputBuffer;
/*  18:    */   protected byte[] _decodedBytes;
/*  19: 65 */   protected int _bufferPosition = 0;
/*  20: 70 */   protected int _bufferLength = 0;
/*  21:    */   
/*  22:    */   public LZFInputStream(InputStream inputStream)
/*  23:    */     throws IOException
/*  24:    */   {
/*  25: 80 */     this(inputStream, false);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public LZFInputStream(ChunkDecoder decoder, InputStream in)
/*  29:    */     throws IOException
/*  30:    */   {
/*  31: 86 */     this(decoder, in, BufferRecycler.instance(), false);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public LZFInputStream(InputStream in, boolean fullReads)
/*  35:    */     throws IOException
/*  36:    */   {
/*  37: 97 */     this(ChunkDecoderFactory.optimalInstance(), in, BufferRecycler.instance(), fullReads);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public LZFInputStream(ChunkDecoder decoder, InputStream in, boolean fullReads)
/*  41:    */     throws IOException
/*  42:    */   {
/*  43:103 */     this(decoder, in, BufferRecycler.instance(), fullReads);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public LZFInputStream(InputStream inputStream, BufferRecycler bufferRecycler)
/*  47:    */     throws IOException
/*  48:    */   {
/*  49:108 */     this(inputStream, bufferRecycler, false);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public LZFInputStream(InputStream in, BufferRecycler bufferRecycler, boolean fullReads)
/*  53:    */     throws IOException
/*  54:    */   {
/*  55:121 */     this(ChunkDecoderFactory.optimalInstance(), in, bufferRecycler, fullReads);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public LZFInputStream(ChunkDecoder decoder, InputStream in, BufferRecycler bufferRecycler, boolean fullReads)
/*  59:    */     throws IOException
/*  60:    */   {
/*  61:128 */     this._decoder = decoder;
/*  62:129 */     this._recycler = bufferRecycler;
/*  63:130 */     this._inputStream = in;
/*  64:131 */     this._inputStreamClosed = false;
/*  65:132 */     this._cfgFullReads = fullReads;
/*  66:    */     
/*  67:134 */     this._inputBuffer = bufferRecycler.allocInputBuffer(65535);
/*  68:135 */     this._decodedBytes = bufferRecycler.allocDecodeBuffer(65535);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setUseFullReads(boolean b)
/*  72:    */   {
/*  73:145 */     this._cfgFullReads = b;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public int available()
/*  77:    */   {
/*  78:165 */     if (this._inputStreamClosed) {
/*  79:166 */       return 0;
/*  80:    */     }
/*  81:168 */     int left = this._bufferLength - this._bufferPosition;
/*  82:169 */     return left <= 0 ? 0 : left;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public int read()
/*  86:    */     throws IOException
/*  87:    */   {
/*  88:175 */     if (!readyBuffer()) {
/*  89:176 */       return -1;
/*  90:    */     }
/*  91:178 */     return this._decodedBytes[(this._bufferPosition++)] & 0xFF;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public int read(byte[] buffer)
/*  95:    */     throws IOException
/*  96:    */   {
/*  97:184 */     return read(buffer, 0, buffer.length);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public int read(byte[] buffer, int offset, int length)
/* 101:    */     throws IOException
/* 102:    */   {
/* 103:190 */     if (length < 1) {
/* 104:191 */       return 0;
/* 105:    */     }
/* 106:193 */     if (!readyBuffer()) {
/* 107:194 */       return -1;
/* 108:    */     }
/* 109:197 */     int chunkLength = Math.min(this._bufferLength - this._bufferPosition, length);
/* 110:198 */     System.arraycopy(this._decodedBytes, this._bufferPosition, buffer, offset, chunkLength);
/* 111:199 */     this._bufferPosition += chunkLength;
/* 112:201 */     if ((chunkLength == length) || (!this._cfgFullReads)) {
/* 113:202 */       return chunkLength;
/* 114:    */     }
/* 115:205 */     int totalRead = chunkLength;
/* 116:    */     do
/* 117:    */     {
/* 118:207 */       offset += chunkLength;
/* 119:208 */       if (!readyBuffer()) {
/* 120:    */         break;
/* 121:    */       }
/* 122:211 */       chunkLength = Math.min(this._bufferLength - this._bufferPosition, length - totalRead);
/* 123:212 */       System.arraycopy(this._decodedBytes, this._bufferPosition, buffer, offset, chunkLength);
/* 124:213 */       this._bufferPosition += chunkLength;
/* 125:214 */       totalRead += chunkLength;
/* 126:215 */     } while (totalRead < length);
/* 127:216 */     return totalRead;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public void close()
/* 131:    */     throws IOException
/* 132:    */   {
/* 133:222 */     this._bufferPosition = (this._bufferLength = 0);
/* 134:223 */     byte[] buf = this._inputBuffer;
/* 135:224 */     if (buf != null)
/* 136:    */     {
/* 137:225 */       this._inputBuffer = null;
/* 138:226 */       this._recycler.releaseInputBuffer(buf);
/* 139:    */     }
/* 140:228 */     buf = this._decodedBytes;
/* 141:229 */     if (buf != null)
/* 142:    */     {
/* 143:230 */       this._decodedBytes = null;
/* 144:231 */       this._recycler.releaseDecodeBuffer(buf);
/* 145:    */     }
/* 146:233 */     if (!this._inputStreamClosed)
/* 147:    */     {
/* 148:234 */       this._inputStreamClosed = true;
/* 149:235 */       this._inputStream.close();
/* 150:    */     }
/* 151:    */   }
/* 152:    */   
/* 153:    */   public long skip(long n)
/* 154:    */     throws IOException
/* 155:    */   {
/* 156:246 */     if (this._inputStreamClosed) {
/* 157:247 */       return -1L;
/* 158:    */     }
/* 159:249 */     if (n <= 0L) {
/* 160:250 */       return n;
/* 161:    */     }
/* 162:    */     long skipped;
/* 163:255 */     if (this._bufferPosition < this._bufferLength)
/* 164:    */     {
/* 165:256 */       int left = this._bufferLength - this._bufferPosition;
/* 166:257 */       if (n <= left)
/* 167:    */       {
/* 168:258 */         this._bufferPosition += (int)n;
/* 169:259 */         return n;
/* 170:    */       }
/* 171:261 */       this._bufferPosition = this._bufferLength;
/* 172:262 */       long skipped = left;
/* 173:263 */       n -= left;
/* 174:    */     }
/* 175:    */     else
/* 176:    */     {
/* 177:265 */       skipped = 0L;
/* 178:    */     }
/* 179:    */     int amount;
/* 180:    */     do
/* 181:    */     {
/* 182:269 */       amount = this._decoder.skipOrDecodeChunk(this._inputStream, this._inputBuffer, this._decodedBytes, n);
/* 183:270 */       if (amount < 0) {
/* 184:    */         break;
/* 185:    */       }
/* 186:271 */       skipped += amount;
/* 187:    */       
/* 188:273 */       n -= amount;
/* 189:274 */     } while (n > 0L);
/* 190:275 */     return skipped;
/* 191:279 */     if (amount == -1)
/* 192:    */     {
/* 193:280 */       close();
/* 194:281 */       return skipped;
/* 195:    */     }
/* 196:284 */     this._bufferLength = (-(amount + 1));
/* 197:285 */     skipped += n;
/* 198:286 */     this._bufferPosition = ((int)n);
/* 199:287 */     return skipped;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public InputStream getUnderlyingInputStream()
/* 203:    */   {
/* 204:304 */     return this._inputStream;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void discardBuffered()
/* 208:    */   {
/* 209:315 */     this._bufferPosition = (this._bufferLength = 0);
/* 210:    */   }
/* 211:    */   
/* 212:    */   public int readAndWrite(OutputStream out)
/* 213:    */     throws IOException
/* 214:    */   {
/* 215:330 */     int total = 0;
/* 216:332 */     while (readyBuffer())
/* 217:    */     {
/* 218:333 */       int avail = this._bufferLength - this._bufferPosition;
/* 219:334 */       out.write(this._decodedBytes, this._bufferPosition, avail);
/* 220:335 */       this._bufferPosition += avail;
/* 221:336 */       total += avail;
/* 222:    */     }
/* 223:338 */     return total;
/* 224:    */   }
/* 225:    */   
/* 226:    */   protected boolean readyBuffer()
/* 227:    */     throws IOException
/* 228:    */   {
/* 229:357 */     if (this._bufferPosition < this._bufferLength) {
/* 230:358 */       return true;
/* 231:    */     }
/* 232:360 */     if (this._inputStreamClosed) {
/* 233:361 */       return false;
/* 234:    */     }
/* 235:363 */     this._bufferLength = this._decoder.decodeChunk(this._inputStream, this._inputBuffer, this._decodedBytes);
/* 236:364 */     if (this._bufferLength < 0)
/* 237:    */     {
/* 238:365 */       close();
/* 239:366 */       return false;
/* 240:    */     }
/* 241:368 */     this._bufferPosition = 0;
/* 242:369 */     return this._bufferPosition < this._bufferLength;
/* 243:    */   }
/* 244:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.LZFInputStream
 * JD-Core Version:    0.7.0.1
 */