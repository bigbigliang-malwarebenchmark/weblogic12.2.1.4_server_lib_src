/*  1:   */ package com.ning.compress.lzf;
/*  2:   */ 
/*  3:   */ import com.ning.compress.lzf.util.LZFFileInputStream;
/*  4:   */ import com.ning.compress.lzf.util.LZFFileOutputStream;
/*  5:   */ import java.io.File;
/*  6:   */ import java.io.FileInputStream;
/*  7:   */ import java.io.FileOutputStream;
/*  8:   */ import java.io.IOException;
/*  9:   */ import java.io.InputStream;
/* 10:   */ import java.io.OutputStream;
/* 11:   */ import java.io.PrintStream;
/* 12:   */ 
/* 13:   */ public class LZF
/* 14:   */ {
/* 15:   */   public static final String SUFFIX = ".lzf";
/* 16:   */   
/* 17:   */   protected void process(String[] args)
/* 18:   */     throws IOException
/* 19:   */   {
/* 20:32 */     if (args.length == 2)
/* 21:   */     {
/* 22:33 */       String oper = args[0];
/* 23:34 */       boolean compress = "-c".equals(oper);
/* 24:35 */       boolean toSystemOutput = (!compress) && ("-o".equals(oper));
/* 25:36 */       if ((compress) || (toSystemOutput) || ("-d".equals(oper)))
/* 26:   */       {
/* 27:37 */         String filename = args[1];
/* 28:38 */         File src = new File(filename);
/* 29:39 */         if (!src.exists())
/* 30:   */         {
/* 31:40 */           System.err.println("File '" + filename + "' does not exist.");
/* 32:41 */           System.exit(1);
/* 33:   */         }
/* 34:43 */         if ((!compress) && (!filename.endsWith(".lzf")))
/* 35:   */         {
/* 36:44 */           System.err.println("File '" + filename + "' does end with expected suffix ('" + ".lzf" + "', won't decompress.");
/* 37:45 */           System.exit(1);
/* 38:   */         }
/* 39:48 */         if (compress)
/* 40:   */         {
/* 41:49 */           int inputLength = 0;
/* 42:50 */           File resultFile = new File(filename + ".lzf");
/* 43:51 */           InputStream in = new FileInputStream(src);
/* 44:52 */           OutputStream out = new LZFFileOutputStream(resultFile);
/* 45:53 */           byte[] buffer = new byte[8192];
/* 46:   */           int bytesRead;
/* 47:55 */           while ((bytesRead = in.read(buffer, 0, buffer.length)) != -1)
/* 48:   */           {
/* 49:56 */             inputLength += bytesRead;
/* 50:57 */             out.write(buffer, 0, bytesRead);
/* 51:   */           }
/* 52:59 */           in.close();
/* 53:60 */           out.flush();
/* 54:61 */           out.close();
/* 55:62 */           System.out.printf("Compressed '%s' into '%s' (%d->%d bytes)\n", new Object[] { src.getPath(), resultFile.getPath(), Integer.valueOf(inputLength), Long.valueOf(resultFile.length()) });
/* 56:   */         }
/* 57:   */         else
/* 58:   */         {
/* 59:67 */           LZFFileInputStream in = new LZFFileInputStream(src);
/* 60:68 */           File resultFile = null;
/* 61:   */           OutputStream out;
/* 62:   */           OutputStream out;
/* 63:69 */           if (toSystemOutput)
/* 64:   */           {
/* 65:70 */             out = System.out;
/* 66:   */           }
/* 67:   */           else
/* 68:   */           {
/* 69:72 */             resultFile = new File(filename.substring(0, filename.length() - ".lzf".length()));
/* 70:73 */             out = new FileOutputStream(resultFile);
/* 71:   */           }
/* 72:75 */           int uncompLen = in.readAndWrite(out);
/* 73:76 */           in.close();
/* 74:77 */           out.flush();
/* 75:78 */           out.close();
/* 76:79 */           if (resultFile != null) {
/* 77:80 */             System.out.printf("Uncompressed '%s' into '%s' (%d->%d bytes)\n", new Object[] { src.getPath(), resultFile.getPath(), Long.valueOf(src.length()), Integer.valueOf(uncompLen) });
/* 78:   */           }
/* 79:   */         }
/* 80:85 */         return;
/* 81:   */       }
/* 82:   */     }
/* 83:88 */     System.err.println("Usage: java " + getClass().getName() + " -c/-d/-o source-file");
/* 84:89 */     System.err.println(" -d parameter: decompress to file");
/* 85:90 */     System.err.println(" -c parameter: compress to file");
/* 86:91 */     System.err.println(" -o parameter: decompress to stdout");
/* 87:92 */     System.exit(1);
/* 88:   */   }
/* 89:   */   
/* 90:   */   public static void main(String[] args)
/* 91:   */     throws IOException
/* 92:   */   {
/* 93:96 */     new LZF().process(args);
/* 94:   */   }
/* 95:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.LZF
 * JD-Core Version:    0.7.0.1
 */