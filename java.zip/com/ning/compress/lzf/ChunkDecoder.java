/*   1:    */ package com.ning.compress.lzf;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.InputStream;
/*   5:    */ 
/*   6:    */ public abstract class ChunkDecoder
/*   7:    */ {
/*   8:    */   protected static final byte BYTE_NULL = 0;
/*   9:    */   protected static final int HEADER_BYTES = 5;
/*  10:    */   
/*  11:    */   public final byte[] decode(byte[] inputBuffer)
/*  12:    */     throws LZFException
/*  13:    */   {
/*  14: 37 */     byte[] result = new byte[calculateUncompressedSize(inputBuffer, 0, inputBuffer.length)];
/*  15: 38 */     decode(inputBuffer, 0, inputBuffer.length, result);
/*  16: 39 */     return result;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public final byte[] decode(byte[] inputBuffer, int inputPtr, int inputLen)
/*  20:    */     throws LZFException
/*  21:    */   {
/*  22: 51 */     byte[] result = new byte[calculateUncompressedSize(inputBuffer, inputPtr, inputLen)];
/*  23: 52 */     decode(inputBuffer, inputPtr, inputLen, result);
/*  24: 53 */     return result;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public final int decode(byte[] inputBuffer, byte[] targetBuffer)
/*  28:    */     throws LZFException
/*  29:    */   {
/*  30: 65 */     return decode(inputBuffer, 0, inputBuffer.length, targetBuffer);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public int decode(byte[] sourceBuffer, int inPtr, int inLength, byte[] targetBuffer)
/*  34:    */     throws LZFException
/*  35:    */   {
/*  36: 78 */     int outPtr = 0;
/*  37: 79 */     int blockNr = 0;
/*  38:    */     
/*  39: 81 */     int end = inPtr + inLength - 1;
/*  40: 83 */     while (inPtr < end)
/*  41:    */     {
/*  42: 85 */       if ((sourceBuffer[inPtr] != 90) || (sourceBuffer[(inPtr + 1)] != 86)) {
/*  43: 86 */         throw new LZFException("Corrupt input data, block #" + blockNr + " (at offset " + inPtr + "): did not start with 'ZV' signature bytes");
/*  44:    */       }
/*  45: 88 */       inPtr += 2;
/*  46: 89 */       int type = sourceBuffer[(inPtr++)];
/*  47: 90 */       int len = uint16(sourceBuffer, inPtr);
/*  48: 91 */       inPtr += 2;
/*  49: 92 */       if (type == 0)
/*  50:    */       {
/*  51: 93 */         if (outPtr + len > targetBuffer.length) {
/*  52: 94 */           _reportArrayOverflow(targetBuffer, outPtr, len);
/*  53:    */         }
/*  54: 96 */         System.arraycopy(sourceBuffer, inPtr, targetBuffer, outPtr, len);
/*  55: 97 */         outPtr += len;
/*  56:    */       }
/*  57:    */       else
/*  58:    */       {
/*  59: 99 */         int uncompLen = uint16(sourceBuffer, inPtr);
/*  60:100 */         if (outPtr + uncompLen > targetBuffer.length) {
/*  61:101 */           _reportArrayOverflow(targetBuffer, outPtr, uncompLen);
/*  62:    */         }
/*  63:103 */         inPtr += 2;
/*  64:104 */         decodeChunk(sourceBuffer, inPtr, targetBuffer, outPtr, outPtr + uncompLen);
/*  65:105 */         outPtr += uncompLen;
/*  66:    */       }
/*  67:107 */       inPtr += len;
/*  68:108 */       blockNr++;
/*  69:    */     }
/*  70:110 */     return outPtr;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public abstract int decodeChunk(InputStream paramInputStream, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
/*  74:    */     throws IOException;
/*  75:    */   
/*  76:    */   public abstract void decodeChunk(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, int paramInt3)
/*  77:    */     throws LZFException;
/*  78:    */   
/*  79:    */   public abstract int skipOrDecodeChunk(InputStream paramInputStream, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong)
/*  80:    */     throws IOException;
/*  81:    */   
/*  82:    */   public static int calculateUncompressedSize(byte[] data, int ptr, int length)
/*  83:    */     throws LZFException
/*  84:    */   {
/*  85:155 */     int uncompressedSize = 0;
/*  86:156 */     int blockNr = 0;
/*  87:157 */     int end = ptr + length;
/*  88:159 */     while (ptr < end)
/*  89:    */     {
/*  90:161 */       if ((ptr == data.length + 1) && (data[ptr] == 0))
/*  91:    */       {
/*  92:162 */         ptr++;
/*  93:163 */         break;
/*  94:    */       }
/*  95:    */       try
/*  96:    */       {
/*  97:167 */         if ((data[ptr] != 90) || (data[(ptr + 1)] != 86)) {
/*  98:168 */           throw new LZFException("Corrupt input data, block #" + blockNr + " (at offset " + ptr + "): did not start with 'ZV' signature bytes");
/*  99:    */         }
/* 100:170 */         int type = data[(ptr + 2)];
/* 101:171 */         int blockLen = uint16(data, ptr + 3);
/* 102:172 */         if (type == 0)
/* 103:    */         {
/* 104:173 */           ptr += 5;
/* 105:174 */           uncompressedSize += blockLen;
/* 106:    */         }
/* 107:175 */         else if (type == 1)
/* 108:    */         {
/* 109:176 */           uncompressedSize += uint16(data, ptr + 5);
/* 110:177 */           ptr += 7;
/* 111:    */         }
/* 112:    */         else
/* 113:    */         {
/* 114:179 */           throw new LZFException("Corrupt input data, block #" + blockNr + " (at offset " + ptr + "): unrecognized block type " + (type & 0xFF));
/* 115:    */         }
/* 116:181 */         ptr += blockLen;
/* 117:    */       }
/* 118:    */       catch (ArrayIndexOutOfBoundsException e)
/* 119:    */       {
/* 120:183 */         throw new LZFException("Corrupt input data, block #" + blockNr + " (at offset " + ptr + "): truncated block header");
/* 121:    */       }
/* 122:185 */       blockNr++;
/* 123:    */     }
/* 124:188 */     if (ptr != end) {
/* 125:189 */       throw new LZFException("Corrupt input data: block #" + blockNr + " extends " + (data.length - ptr) + " beyond end of input");
/* 126:    */     }
/* 127:191 */     return uncompressedSize;
/* 128:    */   }
/* 129:    */   
/* 130:    */   protected static final int uint16(byte[] data, int ptr)
/* 131:    */   {
/* 132:201 */     return ((data[ptr] & 0xFF) << 8) + (data[(ptr + 1)] & 0xFF);
/* 133:    */   }
/* 134:    */   
/* 135:    */   protected static final int readHeader(InputStream is, byte[] inputBuffer)
/* 136:    */     throws IOException
/* 137:    */   {
/* 138:212 */     int needed = 5;
/* 139:213 */     int count = is.read(inputBuffer, 0, needed);
/* 140:215 */     if (count == needed) {
/* 141:216 */       return count;
/* 142:    */     }
/* 143:218 */     if (count <= 0) {
/* 144:219 */       return 0;
/* 145:    */     }
/* 146:223 */     int offset = count;
/* 147:224 */     needed -= count;
/* 148:    */     do
/* 149:    */     {
/* 150:227 */       count = is.read(inputBuffer, offset, needed);
/* 151:228 */       if (count <= 0) {
/* 152:    */         break;
/* 153:    */       }
/* 154:231 */       offset += count;
/* 155:232 */       needed -= count;
/* 156:233 */     } while (needed > 0);
/* 157:234 */     return offset;
/* 158:    */   }
/* 159:    */   
/* 160:    */   protected static final void readFully(InputStream is, boolean compressed, byte[] outputBuffer, int offset, int len)
/* 161:    */     throws IOException
/* 162:    */   {
/* 163:240 */     int left = len;
/* 164:241 */     while (left > 0)
/* 165:    */     {
/* 166:242 */       int count = is.read(outputBuffer, offset, left);
/* 167:243 */       if (count < 0) {
/* 168:244 */         throw new LZFException("EOF in " + len + " byte (" + (compressed ? "" : "un") + "compressed) block: could only read " + (len - left) + " bytes");
/* 169:    */       }
/* 170:248 */       offset += count;
/* 171:249 */       left -= count;
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   protected static final void skipFully(InputStream is, int amount)
/* 176:    */     throws IOException
/* 177:    */   {
/* 178:255 */     int orig = amount;
/* 179:256 */     while (amount > 0)
/* 180:    */     {
/* 181:257 */       long skipped = is.skip(amount);
/* 182:258 */       if (skipped <= 0L) {
/* 183:259 */         throw new LZFException("Input problem: failed to skip " + orig + " bytes in input stream, only skipped " + (orig - amount));
/* 184:    */       }
/* 185:262 */       amount -= (int)skipped;
/* 186:    */     }
/* 187:    */   }
/* 188:    */   
/* 189:    */   protected void _reportCorruptHeader()
/* 190:    */     throws LZFException
/* 191:    */   {
/* 192:267 */     throw new LZFException("Corrupt input data, block did not start with 2 byte signature ('ZV') followed by type byte, 2-byte length)");
/* 193:    */   }
/* 194:    */   
/* 195:    */   protected void _reportArrayOverflow(byte[] targetBuffer, int outPtr, int dataLen)
/* 196:    */     throws LZFException
/* 197:    */   {
/* 198:277 */     throw new LZFException("Target buffer too small (" + targetBuffer.length + "): can not copy/uncompress " + dataLen + " bytes to offset " + outPtr);
/* 199:    */   }
/* 200:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.ChunkDecoder
 * JD-Core Version:    0.7.0.1
 */