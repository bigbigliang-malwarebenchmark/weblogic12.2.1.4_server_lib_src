/*   1:    */ package com.ning.compress.lzf;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import java.io.Closeable;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.OutputStream;
/*   7:    */ 
/*   8:    */ public abstract class ChunkEncoder
/*   9:    */   implements Closeable
/*  10:    */ {
/*  11:    */   protected static final int MIN_BLOCK_TO_COMPRESS = 16;
/*  12:    */   protected static final int MIN_HASH_SIZE = 256;
/*  13:    */   protected static final int MAX_HASH_SIZE = 16384;
/*  14:    */   protected static final int MAX_OFF = 8192;
/*  15:    */   protected static final int MAX_REF = 264;
/*  16:    */   protected static final int TAIL_LENGTH = 4;
/*  17:    */   protected final BufferRecycler _recycler;
/*  18:    */   protected int[] _hashTable;
/*  19:    */   protected final int _hashModulo;
/*  20:    */   protected byte[] _encodeBuffer;
/*  21:    */   protected byte[] _headerBuffer;
/*  22:    */   
/*  23:    */   protected ChunkEncoder(int totalLength)
/*  24:    */   {
/*  25: 85 */     this(totalLength, BufferRecycler.instance());
/*  26:    */   }
/*  27:    */   
/*  28:    */   protected ChunkEncoder(int totalLength, BufferRecycler bufferRecycler)
/*  29:    */   {
/*  30: 97 */     int largestChunkLen = Math.min(totalLength, 65535);
/*  31: 98 */     int suggestedHashLen = calcHashLen(largestChunkLen);
/*  32: 99 */     this._recycler = bufferRecycler;
/*  33:100 */     this._hashTable = bufferRecycler.allocEncodingHash(suggestedHashLen);
/*  34:101 */     this._hashModulo = (this._hashTable.length - 1);
/*  35:    */     
/*  36:    */ 
/*  37:    */ 
/*  38:105 */     int bufferLen = largestChunkLen + (largestChunkLen + 31 >> 5) + 7;
/*  39:106 */     this._encodeBuffer = bufferRecycler.allocEncodingBuffer(bufferLen);
/*  40:    */   }
/*  41:    */   
/*  42:    */   protected ChunkEncoder(int totalLength, boolean bogus)
/*  43:    */   {
/*  44:115 */     this(totalLength, BufferRecycler.instance(), bogus);
/*  45:    */   }
/*  46:    */   
/*  47:    */   protected ChunkEncoder(int totalLength, BufferRecycler bufferRecycler, boolean bogus)
/*  48:    */   {
/*  49:124 */     int largestChunkLen = Math.max(totalLength, 65535);
/*  50:125 */     int suggestedHashLen = calcHashLen(largestChunkLen);
/*  51:126 */     this._recycler = bufferRecycler;
/*  52:127 */     this._hashTable = bufferRecycler.allocEncodingHash(suggestedHashLen);
/*  53:128 */     this._hashModulo = (this._hashTable.length - 1);
/*  54:129 */     this._encodeBuffer = null;
/*  55:    */   }
/*  56:    */   
/*  57:    */   private static int calcHashLen(int chunkSize)
/*  58:    */   {
/*  59:135 */     chunkSize += chunkSize;
/*  60:137 */     if (chunkSize >= 16384) {
/*  61:138 */       return 16384;
/*  62:    */     }
/*  63:141 */     int hashLen = 256;
/*  64:142 */     while (hashLen < chunkSize) {
/*  65:143 */       hashLen += hashLen;
/*  66:    */     }
/*  67:145 */     return hashLen;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public final void close()
/*  71:    */   {
/*  72:161 */     byte[] buf = this._encodeBuffer;
/*  73:162 */     if (buf != null)
/*  74:    */     {
/*  75:163 */       this._encodeBuffer = null;
/*  76:164 */       this._recycler.releaseEncodeBuffer(buf);
/*  77:    */     }
/*  78:166 */     int[] ibuf = this._hashTable;
/*  79:167 */     if (ibuf != null)
/*  80:    */     {
/*  81:168 */       this._hashTable = null;
/*  82:169 */       this._recycler.releaseEncodingHash(ibuf);
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public LZFChunk encodeChunk(byte[] data, int offset, int len)
/*  87:    */   {
/*  88:177 */     if (len >= 16)
/*  89:    */     {
/*  90:181 */       int compLen = tryCompress(data, offset, offset + len, this._encodeBuffer, 0);
/*  91:182 */       if (compLen < len - 2) {
/*  92:183 */         return LZFChunk.createCompressed(len, this._encodeBuffer, 0, compLen);
/*  93:    */       }
/*  94:    */     }
/*  95:187 */     return LZFChunk.createNonCompressed(data, offset, len);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public LZFChunk encodeChunkIfCompresses(byte[] data, int offset, int inputLen, double maxResultRatio)
/*  99:    */   {
/* 100:203 */     if (inputLen >= 16)
/* 101:    */     {
/* 102:204 */       int maxSize = (int)(maxResultRatio * inputLen + 7.0D + 0.5D);
/* 103:205 */       int compLen = tryCompress(data, offset, offset + inputLen, this._encodeBuffer, 0);
/* 104:206 */       if (compLen <= maxSize) {
/* 105:207 */         return LZFChunk.createCompressed(inputLen, this._encodeBuffer, 0, compLen);
/* 106:    */       }
/* 107:    */     }
/* 108:210 */     return null;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public int appendEncodedChunk(byte[] input, int inputPtr, int inputLen, byte[] outputBuffer, int outputPos)
/* 112:    */   {
/* 113:226 */     if (inputLen >= 16)
/* 114:    */     {
/* 115:230 */       int compStart = outputPos + 7;
/* 116:231 */       int end = tryCompress(input, inputPtr, inputPtr + inputLen, outputBuffer, compStart);
/* 117:232 */       int uncompEnd = outputPos + 5 + inputLen;
/* 118:233 */       if (end < uncompEnd)
/* 119:    */       {
/* 120:234 */         int compLen = end - compStart;
/* 121:235 */         LZFChunk.appendCompressedHeader(inputLen, compLen, outputBuffer, outputPos);
/* 122:236 */         return end;
/* 123:    */       }
/* 124:    */     }
/* 125:240 */     return LZFChunk.appendNonCompressed(input, inputPtr, inputLen, outputBuffer, outputPos);
/* 126:    */   }
/* 127:    */   
/* 128:    */   public int appendEncodedIfCompresses(byte[] input, double maxResultRatio, int inputPtr, int inputLen, byte[] outputBuffer, int outputPos)
/* 129:    */   {
/* 130:259 */     if (inputLen >= 16)
/* 131:    */     {
/* 132:260 */       int compStart = outputPos + 7;
/* 133:261 */       int end = tryCompress(input, inputPtr, inputPtr + inputLen, outputBuffer, compStart);
/* 134:262 */       int maxSize = (int)(maxResultRatio * inputLen + 7.0D + 0.5D);
/* 135:264 */       if (end <= outputPos + maxSize)
/* 136:    */       {
/* 137:265 */         int compLen = end - compStart;
/* 138:266 */         LZFChunk.appendCompressedHeader(inputLen, compLen, outputBuffer, outputPos);
/* 139:267 */         return end;
/* 140:    */       }
/* 141:    */     }
/* 142:270 */     return -1;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void encodeAndWriteChunk(byte[] data, int offset, int len, OutputStream out)
/* 146:    */     throws IOException
/* 147:    */   {
/* 148:279 */     if (len >= 16)
/* 149:    */     {
/* 150:282 */       int compEnd = tryCompress(data, offset, offset + len, this._encodeBuffer, 7);
/* 151:283 */       int compLen = compEnd - 7;
/* 152:284 */       if (compLen < len - 2)
/* 153:    */       {
/* 154:285 */         LZFChunk.appendCompressedHeader(len, compLen, this._encodeBuffer, 0);
/* 155:286 */         out.write(this._encodeBuffer, 0, compEnd);
/* 156:287 */         return;
/* 157:    */       }
/* 158:    */     }
/* 159:291 */     byte[] headerBuf = this._headerBuffer;
/* 160:292 */     if (headerBuf == null) {
/* 161:293 */       this._headerBuffer = (headerBuf = new byte[7]);
/* 162:    */     }
/* 163:295 */     LZFChunk.writeNonCompressedHeader(len, out, headerBuf);
/* 164:296 */     out.write(data, offset, len);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public boolean encodeAndWriteChunkIfCompresses(byte[] data, int offset, int inputLen, OutputStream out, double resultRatio)
/* 168:    */     throws IOException
/* 169:    */   {
/* 170:309 */     if (inputLen >= 16)
/* 171:    */     {
/* 172:310 */       int compEnd = tryCompress(data, offset, offset + inputLen, this._encodeBuffer, 7);
/* 173:311 */       int maxSize = (int)(resultRatio * inputLen + 7.0D + 0.5D);
/* 174:312 */       if (compEnd <= maxSize)
/* 175:    */       {
/* 176:313 */         LZFChunk.appendCompressedHeader(inputLen, compEnd - 7, this._encodeBuffer, 0);
/* 177:    */         
/* 178:315 */         out.write(this._encodeBuffer, 0, compEnd);
/* 179:316 */         return true;
/* 180:    */       }
/* 181:    */     }
/* 182:319 */     return false;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public BufferRecycler getBufferRecycler()
/* 186:    */   {
/* 187:323 */     return this._recycler;
/* 188:    */   }
/* 189:    */   
/* 190:    */   protected abstract int tryCompress(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3);
/* 191:    */   
/* 192:    */   protected final int hash(int h)
/* 193:    */   {
/* 194:352 */     return h * 57321 >> 9 & this._hashModulo;
/* 195:    */   }
/* 196:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.ChunkEncoder
 * JD-Core Version:    0.7.0.1
 */