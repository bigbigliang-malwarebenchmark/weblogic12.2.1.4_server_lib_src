/*   1:    */ package com.ning.compress.lzf;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import com.ning.compress.lzf.util.ChunkEncoderFactory;
/*   5:    */ 
/*   6:    */ public class LZFEncoder
/*   7:    */ {
/*   8:    */   public static final int MAX_CHUNK_RESULT_SIZE = 133191;
/*   9:    */   
/*  10:    */   public static int estimateMaxWorkspaceSize(int inputSize)
/*  11:    */   {
/*  12: 54 */     if (inputSize <= 65535) {
/*  13: 55 */       return 7 + inputSize + (inputSize >> 5) + (inputSize >> 6);
/*  14:    */     }
/*  15: 58 */     inputSize -= 65535;
/*  16: 59 */     if (inputSize <= 65535) {
/*  17: 60 */       return 133191 + inputSize + 7;
/*  18:    */     }
/*  19: 63 */     int chunkCount = 1 + (inputSize + 65534) / 65535;
/*  20: 64 */     return 133191 + chunkCount * 65542;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static byte[] encode(byte[] data)
/*  24:    */   {
/*  25: 83 */     return encode(data, 0, data.length);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static byte[] safeEncode(byte[] data)
/*  29:    */   {
/*  30: 92 */     return safeEncode(data, 0, data.length);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static byte[] encode(byte[] data, int offset, int length)
/*  34:    */   {
/*  35:106 */     ChunkEncoder enc = ChunkEncoderFactory.optimalInstance(length);
/*  36:107 */     byte[] result = encode(enc, data, offset, length);
/*  37:108 */     enc.close();
/*  38:109 */     return result;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static byte[] safeEncode(byte[] data, int offset, int length)
/*  42:    */   {
/*  43:119 */     ChunkEncoder enc = ChunkEncoderFactory.safeInstance(length);
/*  44:120 */     byte[] result = encode(enc, data, offset, length);
/*  45:121 */     enc.close();
/*  46:122 */     return result;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static byte[] encode(byte[] data, int offset, int length, BufferRecycler bufferRecycler)
/*  50:    */   {
/*  51:136 */     ChunkEncoder enc = ChunkEncoderFactory.optimalInstance(length, bufferRecycler);
/*  52:137 */     byte[] result = encode(enc, data, offset, length);
/*  53:138 */     enc.close();
/*  54:139 */     return result;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static byte[] safeEncode(byte[] data, int offset, int length, BufferRecycler bufferRecycler)
/*  58:    */   {
/*  59:149 */     ChunkEncoder enc = ChunkEncoderFactory.safeInstance(length, bufferRecycler);
/*  60:150 */     byte[] result = encode(enc, data, offset, length);
/*  61:151 */     enc.close();
/*  62:152 */     return result;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static byte[] encode(ChunkEncoder enc, byte[] data, int length)
/*  66:    */   {
/*  67:160 */     return encode(enc, data, 0, length);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static byte[] encode(ChunkEncoder enc, byte[] data, int offset, int length)
/*  71:    */   {
/*  72:172 */     int left = length;
/*  73:173 */     int chunkLen = Math.min(65535, left);
/*  74:174 */     LZFChunk first = enc.encodeChunk(data, offset, chunkLen);
/*  75:175 */     left -= chunkLen;
/*  76:177 */     if (left < 1) {
/*  77:178 */       return first.getData();
/*  78:    */     }
/*  79:181 */     int resultBytes = first.length();
/*  80:182 */     offset += chunkLen;
/*  81:183 */     LZFChunk last = first;
/*  82:    */     do
/*  83:    */     {
/*  84:186 */       chunkLen = Math.min(left, 65535);
/*  85:187 */       LZFChunk chunk = enc.encodeChunk(data, offset, chunkLen);
/*  86:188 */       offset += chunkLen;
/*  87:189 */       left -= chunkLen;
/*  88:190 */       resultBytes += chunk.length();
/*  89:191 */       last.setNext(chunk);
/*  90:192 */       last = chunk;
/*  91:193 */     } while (left > 0);
/*  92:195 */     byte[] result = new byte[resultBytes];
/*  93:196 */     int ptr = 0;
/*  94:197 */     for (; first != null; first = first.next()) {
/*  95:198 */       ptr = first.copyTo(result, ptr);
/*  96:    */     }
/*  97:200 */     return result;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static int appendEncoded(byte[] input, int inputPtr, int inputLength, byte[] outputBuffer, int outputPtr)
/* 101:    */   {
/* 102:218 */     ChunkEncoder enc = ChunkEncoderFactory.optimalNonAllocatingInstance(inputLength);
/* 103:219 */     int len = appendEncoded(enc, input, inputPtr, inputLength, outputBuffer, outputPtr);
/* 104:220 */     enc.close();
/* 105:221 */     return len;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public static int safeAppendEncoded(byte[] input, int inputPtr, int inputLength, byte[] outputBuffer, int outputPtr)
/* 109:    */   {
/* 110:233 */     ChunkEncoder enc = ChunkEncoderFactory.safeNonAllocatingInstance(inputLength);
/* 111:234 */     int len = appendEncoded(enc, input, inputPtr, inputLength, outputBuffer, outputPtr);
/* 112:235 */     enc.close();
/* 113:236 */     return len;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static int appendEncoded(byte[] input, int inputPtr, int inputLength, byte[] outputBuffer, int outputPtr, BufferRecycler bufferRecycler)
/* 117:    */   {
/* 118:248 */     ChunkEncoder enc = ChunkEncoderFactory.optimalNonAllocatingInstance(inputLength, bufferRecycler);
/* 119:249 */     int len = appendEncoded(enc, input, inputPtr, inputLength, outputBuffer, outputPtr);
/* 120:250 */     enc.close();
/* 121:251 */     return len;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static int safeAppendEncoded(byte[] input, int inputPtr, int inputLength, byte[] outputBuffer, int outputPtr, BufferRecycler bufferRecycler)
/* 125:    */   {
/* 126:263 */     ChunkEncoder enc = ChunkEncoderFactory.safeNonAllocatingInstance(inputLength, bufferRecycler);
/* 127:264 */     int len = appendEncoded(enc, input, inputPtr, inputLength, outputBuffer, outputPtr);
/* 128:265 */     enc.close();
/* 129:266 */     return len;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public static int appendEncoded(ChunkEncoder enc, byte[] input, int inputPtr, int inputLength, byte[] outputBuffer, int outputPtr)
/* 133:    */   {
/* 134:275 */     int left = inputLength;
/* 135:276 */     int chunkLen = Math.min(65535, left);
/* 136:    */     
/* 137:278 */     outputPtr = enc.appendEncodedChunk(input, inputPtr, chunkLen, outputBuffer, outputPtr);
/* 138:279 */     left -= chunkLen;
/* 139:281 */     if (left < 1) {
/* 140:282 */       return outputPtr;
/* 141:    */     }
/* 142:285 */     inputPtr += chunkLen;
/* 143:    */     do
/* 144:    */     {
/* 145:287 */       chunkLen = Math.min(left, 65535);
/* 146:288 */       outputPtr = enc.appendEncodedChunk(input, inputPtr, chunkLen, outputBuffer, outputPtr);
/* 147:289 */       inputPtr += chunkLen;
/* 148:290 */       left -= chunkLen;
/* 149:291 */     } while (left > 0);
/* 150:292 */     return outputPtr;
/* 151:    */   }
/* 152:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.LZFEncoder
 * JD-Core Version:    0.7.0.1
 */