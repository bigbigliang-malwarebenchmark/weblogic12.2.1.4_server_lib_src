/*   1:    */ package com.ning.compress.lzf;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.OutputStream;
/*   5:    */ 
/*   6:    */ public class LZFChunk
/*   7:    */ {
/*   8:    */   public static final int MAX_LITERAL = 32;
/*   9:    */   public static final int MAX_CHUNK_LEN = 65535;
/*  10:    */   public static final int MAX_HEADER_LEN = 7;
/*  11:    */   public static final int HEADER_LEN_COMPRESSED = 7;
/*  12:    */   public static final int HEADER_LEN_NOT_COMPRESSED = 5;
/*  13:    */   public static final byte BYTE_Z = 90;
/*  14:    */   public static final byte BYTE_V = 86;
/*  15:    */   public static final int BLOCK_TYPE_NON_COMPRESSED = 0;
/*  16:    */   public static final int BLOCK_TYPE_COMPRESSED = 1;
/*  17:    */   protected final byte[] _data;
/*  18:    */   protected LZFChunk _next;
/*  19:    */   
/*  20:    */   private LZFChunk(byte[] data)
/*  21:    */   {
/*  22: 53 */     this._data = data;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static LZFChunk createCompressed(int origLen, byte[] encData, int encPtr, int encLen)
/*  26:    */   {
/*  27: 60 */     byte[] result = new byte[encLen + 7];
/*  28: 61 */     result[0] = 90;
/*  29: 62 */     result[1] = 86;
/*  30: 63 */     result[2] = 1;
/*  31: 64 */     result[3] = ((byte)(encLen >> 8));
/*  32: 65 */     result[4] = ((byte)encLen);
/*  33: 66 */     result[5] = ((byte)(origLen >> 8));
/*  34: 67 */     result[6] = ((byte)origLen);
/*  35: 68 */     System.arraycopy(encData, encPtr, result, 7, encLen);
/*  36: 69 */     return new LZFChunk(result);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static int appendCompressedHeader(int origLen, int encLen, byte[] headerBuffer, int offset)
/*  40:    */   {
/*  41: 74 */     headerBuffer[(offset++)] = 90;
/*  42: 75 */     headerBuffer[(offset++)] = 86;
/*  43: 76 */     headerBuffer[(offset++)] = 1;
/*  44: 77 */     headerBuffer[(offset++)] = ((byte)(encLen >> 8));
/*  45: 78 */     headerBuffer[(offset++)] = ((byte)encLen);
/*  46: 79 */     headerBuffer[(offset++)] = ((byte)(origLen >> 8));
/*  47: 80 */     headerBuffer[(offset++)] = ((byte)origLen);
/*  48: 81 */     return offset;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static void writeCompressedHeader(int origLen, int encLen, OutputStream out, byte[] headerBuffer)
/*  52:    */     throws IOException
/*  53:    */   {
/*  54: 87 */     headerBuffer[0] = 90;
/*  55: 88 */     headerBuffer[1] = 86;
/*  56: 89 */     headerBuffer[2] = 1;
/*  57: 90 */     headerBuffer[3] = ((byte)(encLen >> 8));
/*  58: 91 */     headerBuffer[4] = ((byte)encLen);
/*  59: 92 */     headerBuffer[5] = ((byte)(origLen >> 8));
/*  60: 93 */     headerBuffer[6] = ((byte)origLen);
/*  61: 94 */     out.write(headerBuffer, 0, 7);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static LZFChunk createNonCompressed(byte[] plainData, int ptr, int len)
/*  65:    */   {
/*  66:102 */     byte[] result = new byte[len + 5];
/*  67:103 */     result[0] = 90;
/*  68:104 */     result[1] = 86;
/*  69:105 */     result[2] = 0;
/*  70:106 */     result[3] = ((byte)(len >> 8));
/*  71:107 */     result[4] = ((byte)len);
/*  72:108 */     System.arraycopy(plainData, ptr, result, 5, len);
/*  73:109 */     return new LZFChunk(result);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static int appendNonCompressed(byte[] plainData, int ptr, int len, byte[] outputBuffer, int outputPtr)
/*  77:    */   {
/*  78:119 */     outputBuffer[(outputPtr++)] = 90;
/*  79:120 */     outputBuffer[(outputPtr++)] = 86;
/*  80:121 */     outputBuffer[(outputPtr++)] = 0;
/*  81:122 */     outputBuffer[(outputPtr++)] = ((byte)(len >> 8));
/*  82:123 */     outputBuffer[(outputPtr++)] = ((byte)len);
/*  83:124 */     System.arraycopy(plainData, ptr, outputBuffer, outputPtr, len);
/*  84:125 */     return outputPtr + len;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static int appendNonCompressedHeader(int len, byte[] headerBuffer, int offset)
/*  88:    */   {
/*  89:130 */     headerBuffer[(offset++)] = 90;
/*  90:131 */     headerBuffer[(offset++)] = 86;
/*  91:132 */     headerBuffer[(offset++)] = 0;
/*  92:133 */     headerBuffer[(offset++)] = ((byte)(len >> 8));
/*  93:134 */     headerBuffer[(offset++)] = ((byte)len);
/*  94:135 */     return offset;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static void writeNonCompressedHeader(int len, OutputStream out, byte[] headerBuffer)
/*  98:    */     throws IOException
/*  99:    */   {
/* 100:141 */     headerBuffer[0] = 90;
/* 101:142 */     headerBuffer[1] = 86;
/* 102:143 */     headerBuffer[2] = 0;
/* 103:144 */     headerBuffer[3] = ((byte)(len >> 8));
/* 104:145 */     headerBuffer[4] = ((byte)len);
/* 105:146 */     out.write(headerBuffer, 0, 5);
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void setNext(LZFChunk next)
/* 109:    */   {
/* 110:149 */     this._next = next;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public LZFChunk next()
/* 114:    */   {
/* 115:151 */     return this._next;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public int length()
/* 119:    */   {
/* 120:152 */     return this._data.length;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public byte[] getData()
/* 124:    */   {
/* 125:153 */     return this._data;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public int copyTo(byte[] dst, int ptr)
/* 129:    */   {
/* 130:156 */     int len = this._data.length;
/* 131:157 */     System.arraycopy(this._data, 0, dst, ptr, len);
/* 132:158 */     return ptr + len;
/* 133:    */   }
/* 134:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.LZFChunk
 * JD-Core Version:    0.7.0.1
 */