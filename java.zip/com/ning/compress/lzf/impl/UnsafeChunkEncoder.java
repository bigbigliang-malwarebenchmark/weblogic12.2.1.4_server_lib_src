/*   1:    */ package com.ning.compress.lzf.impl;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import com.ning.compress.lzf.ChunkEncoder;
/*   5:    */ import java.lang.reflect.Field;
/*   6:    */ import sun.misc.Unsafe;
/*   7:    */ 
/*   8:    */ public abstract class UnsafeChunkEncoder
/*   9:    */   extends ChunkEncoder
/*  10:    */ {
/*  11:    */   protected static final Unsafe unsafe;
/*  12:    */   
/*  13:    */   static
/*  14:    */   {
/*  15:    */     try
/*  16:    */     {
/*  17: 27 */       Field theUnsafe = Unsafe.class.getDeclaredField("theUnsafe");
/*  18: 28 */       theUnsafe.setAccessible(true);
/*  19: 29 */       unsafe = (Unsafe)theUnsafe.get(null);
/*  20:    */     }
/*  21:    */     catch (Exception e)
/*  22:    */     {
/*  23: 32 */       throw new RuntimeException(e);
/*  24:    */     }
/*  25:    */   }
/*  26:    */   
/*  27: 36 */   protected static final long BYTE_ARRAY_OFFSET = unsafe.arrayBaseOffset([B.class);
/*  28: 38 */   protected static final long BYTE_ARRAY_OFFSET_PLUS2 = BYTE_ARRAY_OFFSET + 2L;
/*  29:    */   
/*  30:    */   public UnsafeChunkEncoder(int totalLength)
/*  31:    */   {
/*  32: 41 */     super(totalLength);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public UnsafeChunkEncoder(int totalLength, boolean bogus)
/*  36:    */   {
/*  37: 45 */     super(totalLength, bogus);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public UnsafeChunkEncoder(int totalLength, BufferRecycler bufferRecycler)
/*  41:    */   {
/*  42: 49 */     super(totalLength, bufferRecycler);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public UnsafeChunkEncoder(int totalLength, BufferRecycler bufferRecycler, boolean bogus)
/*  46:    */   {
/*  47: 53 */     super(totalLength, bufferRecycler, bogus);
/*  48:    */   }
/*  49:    */   
/*  50:    */   protected static final int _copyPartialLiterals(byte[] in, int inPos, byte[] out, int outPos, int literals)
/*  51:    */   {
/*  52: 65 */     out[(outPos++)] = ((byte)(literals - 1));
/*  53:    */     
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57: 70 */     long rawInPtr = BYTE_ARRAY_OFFSET + inPos - literals;
/*  58: 71 */     long rawOutPtr = BYTE_ARRAY_OFFSET + outPos;
/*  59: 73 */     switch (literals >> 3)
/*  60:    */     {
/*  61:    */     case 3: 
/*  62: 75 */       unsafe.putLong(out, rawOutPtr, unsafe.getLong(in, rawInPtr));
/*  63: 76 */       rawInPtr += 8L;
/*  64: 77 */       rawOutPtr += 8L;
/*  65:    */     case 2: 
/*  66: 79 */       unsafe.putLong(out, rawOutPtr, unsafe.getLong(in, rawInPtr));
/*  67: 80 */       rawInPtr += 8L;
/*  68: 81 */       rawOutPtr += 8L;
/*  69:    */     case 1: 
/*  70: 83 */       unsafe.putLong(out, rawOutPtr, unsafe.getLong(in, rawInPtr));
/*  71: 84 */       rawInPtr += 8L;
/*  72: 85 */       rawOutPtr += 8L;
/*  73:    */     }
/*  74: 87 */     int left = literals & 0x7;
/*  75: 88 */     if (left > 4) {
/*  76: 89 */       unsafe.putLong(out, rawOutPtr, unsafe.getLong(in, rawInPtr));
/*  77:    */     } else {
/*  78: 91 */       unsafe.putInt(out, rawOutPtr, unsafe.getInt(in, rawInPtr));
/*  79:    */     }
/*  80: 94 */     return outPos + literals;
/*  81:    */   }
/*  82:    */   
/*  83:    */   protected static final int _copyLongLiterals(byte[] in, int inPos, byte[] out, int outPos, int literals)
/*  84:    */   {
/*  85:100 */     inPos -= literals;
/*  86:    */     
/*  87:102 */     long rawInPtr = BYTE_ARRAY_OFFSET + inPos;
/*  88:103 */     long rawOutPtr = BYTE_ARRAY_OFFSET + outPos;
/*  89:105 */     while (literals >= 32)
/*  90:    */     {
/*  91:106 */       out[(outPos++)] = 31;
/*  92:107 */       rawOutPtr += 1L;
/*  93:    */       
/*  94:109 */       unsafe.putLong(out, rawOutPtr, unsafe.getLong(in, rawInPtr));
/*  95:110 */       rawInPtr += 8L;
/*  96:111 */       rawOutPtr += 8L;
/*  97:112 */       unsafe.putLong(out, rawOutPtr, unsafe.getLong(in, rawInPtr));
/*  98:113 */       rawInPtr += 8L;
/*  99:114 */       rawOutPtr += 8L;
/* 100:115 */       unsafe.putLong(out, rawOutPtr, unsafe.getLong(in, rawInPtr));
/* 101:116 */       rawInPtr += 8L;
/* 102:117 */       rawOutPtr += 8L;
/* 103:118 */       unsafe.putLong(out, rawOutPtr, unsafe.getLong(in, rawInPtr));
/* 104:119 */       rawInPtr += 8L;
/* 105:120 */       rawOutPtr += 8L;
/* 106:    */       
/* 107:122 */       inPos += 32;
/* 108:123 */       outPos += 32;
/* 109:124 */       literals -= 32;
/* 110:    */     }
/* 111:126 */     if (literals > 0) {
/* 112:127 */       return _copyPartialLiterals(in, inPos + literals, out, outPos, literals);
/* 113:    */     }
/* 114:129 */     return outPos;
/* 115:    */   }
/* 116:    */   
/* 117:    */   protected static final int _copyFullLiterals(byte[] in, int inPos, byte[] out, int outPos)
/* 118:    */   {
/* 119:135 */     out[(outPos++)] = 31;
/* 120:    */     
/* 121:137 */     long rawInPtr = BYTE_ARRAY_OFFSET + inPos - 32L;
/* 122:138 */     long rawOutPtr = BYTE_ARRAY_OFFSET + outPos;
/* 123:    */     
/* 124:140 */     unsafe.putLong(out, rawOutPtr, unsafe.getLong(in, rawInPtr));
/* 125:141 */     rawInPtr += 8L;
/* 126:142 */     rawOutPtr += 8L;
/* 127:143 */     unsafe.putLong(out, rawOutPtr, unsafe.getLong(in, rawInPtr));
/* 128:144 */     rawInPtr += 8L;
/* 129:145 */     rawOutPtr += 8L;
/* 130:146 */     unsafe.putLong(out, rawOutPtr, unsafe.getLong(in, rawInPtr));
/* 131:147 */     rawInPtr += 8L;
/* 132:148 */     rawOutPtr += 8L;
/* 133:149 */     unsafe.putLong(out, rawOutPtr, unsafe.getLong(in, rawInPtr));
/* 134:    */     
/* 135:151 */     return outPos + 32;
/* 136:    */   }
/* 137:    */   
/* 138:    */   protected static final int _handleTail(byte[] in, int inPos, int inEnd, byte[] out, int outPos, int literals)
/* 139:    */   {
/* 140:157 */     while (inPos < inEnd)
/* 141:    */     {
/* 142:158 */       inPos++;
/* 143:159 */       literals++;
/* 144:160 */       if (literals == 32)
/* 145:    */       {
/* 146:161 */         out[(outPos++)] = ((byte)(literals - 1));
/* 147:162 */         System.arraycopy(in, inPos - literals, out, outPos, literals);
/* 148:163 */         outPos += literals;
/* 149:164 */         literals = 0;
/* 150:    */       }
/* 151:    */     }
/* 152:167 */     if (literals > 0)
/* 153:    */     {
/* 154:168 */       out[(outPos++)] = ((byte)(literals - 1));
/* 155:169 */       System.arraycopy(in, inPos - literals, out, outPos, literals);
/* 156:170 */       outPos += literals;
/* 157:    */     }
/* 158:172 */     return outPos;
/* 159:    */   }
/* 160:    */   
/* 161:    */   protected static final int _findTailMatchLength(byte[] in, int ptr1, int ptr2, int maxPtr1)
/* 162:    */   {
/* 163:177 */     int start1 = ptr1;
/* 164:178 */     while ((ptr1 < maxPtr1) && (in[ptr1] == in[ptr2]))
/* 165:    */     {
/* 166:179 */       ptr1++;
/* 167:180 */       ptr2++;
/* 168:    */     }
/* 169:182 */     return ptr1 - start1 + 1;
/* 170:    */   }
/* 171:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.impl.UnsafeChunkEncoder
 * JD-Core Version:    0.7.0.1
 */