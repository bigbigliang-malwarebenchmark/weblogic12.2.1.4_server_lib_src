/*   1:    */ package com.ning.compress.lzf.impl;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import sun.misc.Unsafe;
/*   5:    */ 
/*   6:    */ public final class UnsafeChunkEncoderBE
/*   7:    */   extends UnsafeChunkEncoder
/*   8:    */ {
/*   9:    */   public UnsafeChunkEncoderBE(int totalLength)
/*  10:    */   {
/*  11: 14 */     super(totalLength);
/*  12:    */   }
/*  13:    */   
/*  14:    */   public UnsafeChunkEncoderBE(int totalLength, boolean bogus)
/*  15:    */   {
/*  16: 18 */     super(totalLength, bogus);
/*  17:    */   }
/*  18:    */   
/*  19:    */   public UnsafeChunkEncoderBE(int totalLength, BufferRecycler bufferRecycler)
/*  20:    */   {
/*  21: 21 */     super(totalLength, bufferRecycler);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public UnsafeChunkEncoderBE(int totalLength, BufferRecycler bufferRecycler, boolean bogus)
/*  25:    */   {
/*  26: 25 */     super(totalLength, bufferRecycler, bogus);
/*  27:    */   }
/*  28:    */   
/*  29:    */   protected int tryCompress(byte[] in, int inPos, int inEnd, byte[] out, int outPos)
/*  30:    */   {
/*  31: 32 */     int[] hashTable = this._hashTable;
/*  32: 33 */     int literals = 0;
/*  33: 34 */     inEnd -= 4;
/*  34: 35 */     int firstPos = inPos;
/*  35:    */     
/*  36: 37 */     int seen = _getInt(in, inPos) >> 16;
/*  37: 39 */     while (inPos < inEnd)
/*  38:    */     {
/*  39: 40 */       seen = (seen << 8) + (in[(inPos + 2)] & 0xFF);
/*  40:    */       
/*  41: 42 */       int off = hash(seen);
/*  42: 43 */       int ref = hashTable[off];
/*  43: 44 */       hashTable[off] = inPos;
/*  44: 47 */       if ((ref >= inPos) || (ref < firstPos) || ((off = inPos - ref) > 8192) || (seen << 8 != _getInt(in, ref - 1) << 8))
/*  45:    */       {
/*  46: 51 */         inPos++;
/*  47: 52 */         literals++;
/*  48: 53 */         if (literals == 32)
/*  49:    */         {
/*  50: 54 */           outPos = _copyFullLiterals(in, inPos, out, outPos);
/*  51: 55 */           literals = 0;
/*  52:    */         }
/*  53:    */       }
/*  54:    */       else
/*  55:    */       {
/*  56: 60 */         int maxLen = inEnd - inPos + 2;
/*  57: 61 */         if (maxLen > 264) {
/*  58: 62 */           maxLen = 264;
/*  59:    */         }
/*  60: 64 */         if (literals > 0)
/*  61:    */         {
/*  62: 65 */           outPos = _copyPartialLiterals(in, inPos, out, outPos, literals);
/*  63: 66 */           literals = 0;
/*  64:    */         }
/*  65: 68 */         int len = _findMatchLength(in, ref + 3, inPos + 3, ref + maxLen);
/*  66:    */         
/*  67: 70 */         off--;
/*  68: 71 */         if (len < 7)
/*  69:    */         {
/*  70: 72 */           out[(outPos++)] = ((byte)((off >> 8) + (len << 5)));
/*  71:    */         }
/*  72:    */         else
/*  73:    */         {
/*  74: 74 */           out[(outPos++)] = ((byte)((off >> 8) + 224));
/*  75: 75 */           out[(outPos++)] = ((byte)(len - 7));
/*  76:    */         }
/*  77: 77 */         out[(outPos++)] = ((byte)off);
/*  78: 78 */         inPos += len;
/*  79: 79 */         seen = _getInt(in, inPos);
/*  80: 80 */         hashTable[hash(seen >> 8)] = inPos;
/*  81: 81 */         inPos++;
/*  82: 82 */         hashTable[hash(seen)] = inPos;
/*  83: 83 */         inPos++;
/*  84:    */       }
/*  85:    */     }
/*  86: 86 */     return _handleTail(in, inPos, inEnd + 4, out, outPos, literals);
/*  87:    */   }
/*  88:    */   
/*  89:    */   private static final int _getInt(byte[] in, int inPos)
/*  90:    */   {
/*  91: 90 */     return unsafe.getInt(in, BYTE_ARRAY_OFFSET + inPos);
/*  92:    */   }
/*  93:    */   
/*  94:    */   private static final int _findMatchLength(byte[] in, int ptr1, int ptr2, int maxPtr1)
/*  95:    */   {
/*  96:102 */     if (ptr1 + 8 >= maxPtr1) {
/*  97:103 */       return _findTailMatchLength(in, ptr1, ptr2, maxPtr1);
/*  98:    */     }
/*  99:107 */     int i1 = unsafe.getInt(in, BYTE_ARRAY_OFFSET + ptr1);
/* 100:108 */     int i2 = unsafe.getInt(in, BYTE_ARRAY_OFFSET + ptr2);
/* 101:109 */     if (i1 != i2) {
/* 102:110 */       return 1 + _leadingBytes(i1, i2);
/* 103:    */     }
/* 104:112 */     ptr1 += 4;
/* 105:113 */     ptr2 += 4;
/* 106:    */     
/* 107:115 */     i1 = unsafe.getInt(in, BYTE_ARRAY_OFFSET + ptr1);
/* 108:116 */     i2 = unsafe.getInt(in, BYTE_ARRAY_OFFSET + ptr2);
/* 109:117 */     if (i1 != i2) {
/* 110:118 */       return 5 + _leadingBytes(i1, i2);
/* 111:    */     }
/* 112:120 */     return _findLongMatchLength(in, ptr1 + 4, ptr2 + 4, maxPtr1);
/* 113:    */   }
/* 114:    */   
/* 115:    */   private static final int _findLongMatchLength(byte[] in, int ptr1, int ptr2, int maxPtr1)
/* 116:    */   {
/* 117:125 */     int base = ptr1 - 9;
/* 118:    */     
/* 119:127 */     int longEnd = maxPtr1 - 8;
/* 120:128 */     while (ptr1 <= longEnd)
/* 121:    */     {
/* 122:129 */       long l1 = unsafe.getLong(in, BYTE_ARRAY_OFFSET + ptr1);
/* 123:130 */       long l2 = unsafe.getLong(in, BYTE_ARRAY_OFFSET + ptr2);
/* 124:131 */       if (l1 != l2) {
/* 125:132 */         return ptr1 - base + _leadingBytes(l1, l2);
/* 126:    */       }
/* 127:134 */       ptr1 += 8;
/* 128:135 */       ptr2 += 8;
/* 129:    */     }
/* 130:138 */     while ((ptr1 < maxPtr1) && (in[ptr1] == in[ptr2]))
/* 131:    */     {
/* 132:139 */       ptr1++;
/* 133:140 */       ptr2++;
/* 134:    */     }
/* 135:142 */     return ptr1 - base;
/* 136:    */   }
/* 137:    */   
/* 138:    */   private static final int _leadingBytes(int i1, int i2)
/* 139:    */   {
/* 140:150 */     return Integer.numberOfLeadingZeros(i1 ^ i2) >> 3;
/* 141:    */   }
/* 142:    */   
/* 143:    */   private static final int _leadingBytes(long l1, long l2)
/* 144:    */   {
/* 145:154 */     return Long.numberOfLeadingZeros(l1 ^ l2) >> 3;
/* 146:    */   }
/* 147:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.impl.UnsafeChunkEncoderBE
 * JD-Core Version:    0.7.0.1
 */