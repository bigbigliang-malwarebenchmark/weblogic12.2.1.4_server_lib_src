/*   1:    */ package com.ning.compress.lzf.impl;
/*   2:    */ 
/*   3:    */ import com.ning.compress.lzf.ChunkDecoder;
/*   4:    */ import com.ning.compress.lzf.LZFException;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ 
/*   8:    */ public class VanillaChunkDecoder
/*   9:    */   extends ChunkDecoder
/*  10:    */ {
/*  11:    */   public final int decodeChunk(InputStream is, byte[] inputBuffer, byte[] outputBuffer)
/*  12:    */     throws IOException
/*  13:    */   {
/*  14: 23 */     int bytesRead = readHeader(is, inputBuffer);
/*  15: 24 */     if ((bytesRead < 5) || (inputBuffer[0] != 90) || (inputBuffer[1] != 86))
/*  16:    */     {
/*  17: 26 */       if (bytesRead == 0) {
/*  18: 27 */         return -1;
/*  19:    */       }
/*  20: 29 */       _reportCorruptHeader();
/*  21:    */     }
/*  22: 31 */     int type = inputBuffer[2];
/*  23: 32 */     int compLen = uint16(inputBuffer, 3);
/*  24: 33 */     if (type == 0)
/*  25:    */     {
/*  26: 34 */       readFully(is, false, outputBuffer, 0, compLen);
/*  27: 35 */       return compLen;
/*  28:    */     }
/*  29: 38 */     readFully(is, true, inputBuffer, 0, 2 + compLen);
/*  30: 39 */     int uncompLen = uint16(inputBuffer, 0);
/*  31: 40 */     decodeChunk(inputBuffer, 2, outputBuffer, 0, uncompLen);
/*  32: 41 */     return uncompLen;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public final void decodeChunk(byte[] in, int inPos, byte[] out, int outPos, int outEnd)
/*  36:    */     throws LZFException
/*  37:    */   {
/*  38:    */     do
/*  39:    */     {
/*  40: 49 */       int ctrl = in[(inPos++)] & 0xFF;
/*  41: 50 */       if (ctrl < 32)
/*  42:    */       {
/*  43: 51 */         switch (ctrl)
/*  44:    */         {
/*  45:    */         case 31: 
/*  46: 53 */           out[(outPos++)] = in[(inPos++)];
/*  47:    */         case 30: 
/*  48: 55 */           out[(outPos++)] = in[(inPos++)];
/*  49:    */         case 29: 
/*  50: 57 */           out[(outPos++)] = in[(inPos++)];
/*  51:    */         case 28: 
/*  52: 59 */           out[(outPos++)] = in[(inPos++)];
/*  53:    */         case 27: 
/*  54: 61 */           out[(outPos++)] = in[(inPos++)];
/*  55:    */         case 26: 
/*  56: 63 */           out[(outPos++)] = in[(inPos++)];
/*  57:    */         case 25: 
/*  58: 65 */           out[(outPos++)] = in[(inPos++)];
/*  59:    */         case 24: 
/*  60: 67 */           out[(outPos++)] = in[(inPos++)];
/*  61:    */         case 23: 
/*  62: 69 */           out[(outPos++)] = in[(inPos++)];
/*  63:    */         case 22: 
/*  64: 71 */           out[(outPos++)] = in[(inPos++)];
/*  65:    */         case 21: 
/*  66: 73 */           out[(outPos++)] = in[(inPos++)];
/*  67:    */         case 20: 
/*  68: 75 */           out[(outPos++)] = in[(inPos++)];
/*  69:    */         case 19: 
/*  70: 77 */           out[(outPos++)] = in[(inPos++)];
/*  71:    */         case 18: 
/*  72: 79 */           out[(outPos++)] = in[(inPos++)];
/*  73:    */         case 17: 
/*  74: 81 */           out[(outPos++)] = in[(inPos++)];
/*  75:    */         case 16: 
/*  76: 83 */           out[(outPos++)] = in[(inPos++)];
/*  77:    */         case 15: 
/*  78: 85 */           out[(outPos++)] = in[(inPos++)];
/*  79:    */         case 14: 
/*  80: 87 */           out[(outPos++)] = in[(inPos++)];
/*  81:    */         case 13: 
/*  82: 89 */           out[(outPos++)] = in[(inPos++)];
/*  83:    */         case 12: 
/*  84: 91 */           out[(outPos++)] = in[(inPos++)];
/*  85:    */         case 11: 
/*  86: 93 */           out[(outPos++)] = in[(inPos++)];
/*  87:    */         case 10: 
/*  88: 95 */           out[(outPos++)] = in[(inPos++)];
/*  89:    */         case 9: 
/*  90: 97 */           out[(outPos++)] = in[(inPos++)];
/*  91:    */         case 8: 
/*  92: 99 */           out[(outPos++)] = in[(inPos++)];
/*  93:    */         case 7: 
/*  94:101 */           out[(outPos++)] = in[(inPos++)];
/*  95:    */         case 6: 
/*  96:103 */           out[(outPos++)] = in[(inPos++)];
/*  97:    */         case 5: 
/*  98:105 */           out[(outPos++)] = in[(inPos++)];
/*  99:    */         case 4: 
/* 100:107 */           out[(outPos++)] = in[(inPos++)];
/* 101:    */         case 3: 
/* 102:109 */           out[(outPos++)] = in[(inPos++)];
/* 103:    */         case 2: 
/* 104:111 */           out[(outPos++)] = in[(inPos++)];
/* 105:    */         case 1: 
/* 106:113 */           out[(outPos++)] = in[(inPos++)];
/* 107:    */         case 0: 
/* 108:115 */           out[(outPos++)] = in[(inPos++)];
/* 109:    */         }
/* 110:    */       }
/* 111:    */       else
/* 112:    */       {
/* 113:120 */         int len = ctrl >> 5;
/* 114:121 */         ctrl = -((ctrl & 0x1F) << 8) - 1;
/* 115:122 */         if (len < 7)
/* 116:    */         {
/* 117:123 */           ctrl -= (in[(inPos++)] & 0xFF);
/* 118:124 */           out[outPos] = out[(outPos++ + ctrl)];
/* 119:125 */           out[outPos] = out[(outPos++ + ctrl)];
/* 120:126 */           switch (len)
/* 121:    */           {
/* 122:    */           case 6: 
/* 123:128 */             out[outPos] = out[(outPos++ + ctrl)];
/* 124:    */           case 5: 
/* 125:130 */             out[outPos] = out[(outPos++ + ctrl)];
/* 126:    */           case 4: 
/* 127:132 */             out[outPos] = out[(outPos++ + ctrl)];
/* 128:    */           case 3: 
/* 129:134 */             out[outPos] = out[(outPos++ + ctrl)];
/* 130:    */           case 2: 
/* 131:136 */             out[outPos] = out[(outPos++ + ctrl)];
/* 132:    */           case 1: 
/* 133:138 */             out[outPos] = out[(outPos++ + ctrl)];
/* 134:    */           }
/* 135:    */         }
/* 136:    */         else
/* 137:    */         {
/* 138:144 */           len = in[(inPos++)] & 0xFF;
/* 139:145 */           ctrl -= (in[(inPos++)] & 0xFF);
/* 140:148 */           if (ctrl + len < -9)
/* 141:    */           {
/* 142:149 */             len += 9;
/* 143:150 */             if (len <= 32) {
/* 144:151 */               copyUpTo32WithSwitch(out, outPos + ctrl, out, outPos, len - 1);
/* 145:    */             } else {
/* 146:153 */               System.arraycopy(out, outPos + ctrl, out, outPos, len);
/* 147:    */             }
/* 148:155 */             outPos += len;
/* 149:    */           }
/* 150:    */           else
/* 151:    */           {
/* 152:160 */             out[outPos] = out[(outPos++ + ctrl)];
/* 153:161 */             out[outPos] = out[(outPos++ + ctrl)];
/* 154:162 */             out[outPos] = out[(outPos++ + ctrl)];
/* 155:163 */             out[outPos] = out[(outPos++ + ctrl)];
/* 156:164 */             out[outPos] = out[(outPos++ + ctrl)];
/* 157:165 */             out[outPos] = out[(outPos++ + ctrl)];
/* 158:166 */             out[outPos] = out[(outPos++ + ctrl)];
/* 159:167 */             out[outPos] = out[(outPos++ + ctrl)];
/* 160:168 */             out[outPos] = out[(outPos++ + ctrl)];
/* 161:    */             
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:174 */             len += outPos;
/* 167:175 */             int end = len - 3;
/* 168:176 */             while (outPos < end)
/* 169:    */             {
/* 170:177 */               out[outPos] = out[(outPos++ + ctrl)];
/* 171:178 */               out[outPos] = out[(outPos++ + ctrl)];
/* 172:179 */               out[outPos] = out[(outPos++ + ctrl)];
/* 173:180 */               out[outPos] = out[(outPos++ + ctrl)];
/* 174:    */             }
/* 175:182 */             switch (len - outPos)
/* 176:    */             {
/* 177:    */             case 3: 
/* 178:184 */               out[outPos] = out[(outPos++ + ctrl)];
/* 179:    */             case 2: 
/* 180:186 */               out[outPos] = out[(outPos++ + ctrl)];
/* 181:    */             case 1: 
/* 182:188 */               out[outPos] = out[(outPos++ + ctrl)];
/* 183:    */             }
/* 184:    */           }
/* 185:    */         }
/* 186:    */       }
/* 187:190 */     } while (outPos < outEnd);
/* 188:193 */     if (outPos != outEnd) {
/* 189:194 */       throw new LZFException("Corrupt data: overrun in decompress, input offset " + inPos + ", output offset " + outPos);
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   public int skipOrDecodeChunk(InputStream is, byte[] inputBuffer, byte[] outputBuffer, long maxToSkip)
/* 194:    */     throws IOException
/* 195:    */   {
/* 196:203 */     int bytesRead = readHeader(is, inputBuffer);
/* 197:204 */     if ((bytesRead < 5) || (inputBuffer[0] != 90) || (inputBuffer[1] != 86))
/* 198:    */     {
/* 199:206 */       if (bytesRead == 0) {
/* 200:207 */         return -1;
/* 201:    */       }
/* 202:209 */       _reportCorruptHeader();
/* 203:    */     }
/* 204:211 */     int type = inputBuffer[2];
/* 205:212 */     int compLen = uint16(inputBuffer, 3);
/* 206:213 */     if (type == 0)
/* 207:    */     {
/* 208:214 */       if (compLen <= maxToSkip)
/* 209:    */       {
/* 210:215 */         skipFully(is, compLen);
/* 211:216 */         return compLen;
/* 212:    */       }
/* 213:218 */       readFully(is, false, outputBuffer, 0, compLen);
/* 214:219 */       return -(compLen + 1);
/* 215:    */     }
/* 216:222 */     readFully(is, true, inputBuffer, 0, 2);
/* 217:223 */     int uncompLen = uint16(inputBuffer, 0);
/* 218:225 */     if (uncompLen <= maxToSkip)
/* 219:    */     {
/* 220:226 */       skipFully(is, compLen);
/* 221:227 */       return uncompLen;
/* 222:    */     }
/* 223:230 */     readFully(is, true, inputBuffer, 2, compLen);
/* 224:231 */     decodeChunk(inputBuffer, 2, outputBuffer, 0, uncompLen);
/* 225:232 */     return -(uncompLen + 1);
/* 226:    */   }
/* 227:    */   
/* 228:    */   protected static final void copyUpTo32WithSwitch(byte[] in, int inPos, byte[] out, int outPos, int lengthMinusOne)
/* 229:    */   {
/* 230:244 */     switch (lengthMinusOne)
/* 231:    */     {
/* 232:    */     case 31: 
/* 233:246 */       out[(outPos++)] = in[(inPos++)];
/* 234:    */     case 30: 
/* 235:248 */       out[(outPos++)] = in[(inPos++)];
/* 236:    */     case 29: 
/* 237:250 */       out[(outPos++)] = in[(inPos++)];
/* 238:    */     case 28: 
/* 239:252 */       out[(outPos++)] = in[(inPos++)];
/* 240:    */     case 27: 
/* 241:254 */       out[(outPos++)] = in[(inPos++)];
/* 242:    */     case 26: 
/* 243:256 */       out[(outPos++)] = in[(inPos++)];
/* 244:    */     case 25: 
/* 245:258 */       out[(outPos++)] = in[(inPos++)];
/* 246:    */     case 24: 
/* 247:260 */       out[(outPos++)] = in[(inPos++)];
/* 248:    */     case 23: 
/* 249:262 */       out[(outPos++)] = in[(inPos++)];
/* 250:    */     case 22: 
/* 251:264 */       out[(outPos++)] = in[(inPos++)];
/* 252:    */     case 21: 
/* 253:266 */       out[(outPos++)] = in[(inPos++)];
/* 254:    */     case 20: 
/* 255:268 */       out[(outPos++)] = in[(inPos++)];
/* 256:    */     case 19: 
/* 257:270 */       out[(outPos++)] = in[(inPos++)];
/* 258:    */     case 18: 
/* 259:272 */       out[(outPos++)] = in[(inPos++)];
/* 260:    */     case 17: 
/* 261:274 */       out[(outPos++)] = in[(inPos++)];
/* 262:    */     case 16: 
/* 263:276 */       out[(outPos++)] = in[(inPos++)];
/* 264:    */     case 15: 
/* 265:278 */       out[(outPos++)] = in[(inPos++)];
/* 266:    */     case 14: 
/* 267:280 */       out[(outPos++)] = in[(inPos++)];
/* 268:    */     case 13: 
/* 269:282 */       out[(outPos++)] = in[(inPos++)];
/* 270:    */     case 12: 
/* 271:284 */       out[(outPos++)] = in[(inPos++)];
/* 272:    */     case 11: 
/* 273:286 */       out[(outPos++)] = in[(inPos++)];
/* 274:    */     case 10: 
/* 275:288 */       out[(outPos++)] = in[(inPos++)];
/* 276:    */     case 9: 
/* 277:290 */       out[(outPos++)] = in[(inPos++)];
/* 278:    */     case 8: 
/* 279:292 */       out[(outPos++)] = in[(inPos++)];
/* 280:    */     case 7: 
/* 281:294 */       out[(outPos++)] = in[(inPos++)];
/* 282:    */     case 6: 
/* 283:296 */       out[(outPos++)] = in[(inPos++)];
/* 284:    */     case 5: 
/* 285:298 */       out[(outPos++)] = in[(inPos++)];
/* 286:    */     case 4: 
/* 287:300 */       out[(outPos++)] = in[(inPos++)];
/* 288:    */     case 3: 
/* 289:302 */       out[(outPos++)] = in[(inPos++)];
/* 290:    */     case 2: 
/* 291:304 */       out[(outPos++)] = in[(inPos++)];
/* 292:    */     case 1: 
/* 293:306 */       out[(outPos++)] = in[(inPos++)];
/* 294:    */     case 0: 
/* 295:308 */       out[(outPos++)] = in[(inPos++)];
/* 296:    */     }
/* 297:    */   }
/* 298:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.impl.VanillaChunkDecoder
 * JD-Core Version:    0.7.0.1
 */