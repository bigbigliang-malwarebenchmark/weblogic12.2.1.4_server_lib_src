/*   1:    */ package com.ning.compress.lzf.impl;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import sun.misc.Unsafe;
/*   5:    */ 
/*   6:    */ public class UnsafeChunkEncoderLE
/*   7:    */   extends UnsafeChunkEncoder
/*   8:    */ {
/*   9:    */   public UnsafeChunkEncoderLE(int totalLength)
/*  10:    */   {
/*  11: 14 */     super(totalLength);
/*  12:    */   }
/*  13:    */   
/*  14:    */   public UnsafeChunkEncoderLE(int totalLength, boolean bogus)
/*  15:    */   {
/*  16: 18 */     super(totalLength, bogus);
/*  17:    */   }
/*  18:    */   
/*  19:    */   public UnsafeChunkEncoderLE(int totalLength, BufferRecycler bufferRecycler)
/*  20:    */   {
/*  21: 22 */     super(totalLength, bufferRecycler);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public UnsafeChunkEncoderLE(int totalLength, BufferRecycler bufferRecycler, boolean bogus)
/*  25:    */   {
/*  26: 26 */     super(totalLength, bufferRecycler, bogus);
/*  27:    */   }
/*  28:    */   
/*  29:    */   protected int tryCompress(byte[] in, int inPos, int inEnd, byte[] out, int outPos)
/*  30:    */   {
/*  31: 32 */     int[] hashTable = this._hashTable;
/*  32: 33 */     int literals = 0;
/*  33: 34 */     inEnd -= 4;
/*  34: 35 */     int firstPos = inPos;
/*  35:    */     
/*  36: 37 */     int seen = _getInt(in, inPos) >> 16;
/*  37: 39 */     while (inPos < inEnd)
/*  38:    */     {
/*  39: 40 */       seen = (seen << 8) + (in[(inPos + 2)] & 0xFF);
/*  40:    */       
/*  41:    */ 
/*  42: 43 */       int off = hash(seen);
/*  43: 44 */       int ref = hashTable[off];
/*  44: 45 */       hashTable[off] = inPos;
/*  45: 47 */       if ((ref >= inPos) || (ref < firstPos) || ((off = inPos - ref) > 8192) || (seen << 8 != _getInt(in, ref - 1) << 8))
/*  46:    */       {
/*  47: 51 */         inPos++;
/*  48: 52 */         literals++;
/*  49: 53 */         if (literals == 32)
/*  50:    */         {
/*  51: 54 */           outPos = _copyFullLiterals(in, inPos, out, outPos);
/*  52: 55 */           literals = 0;
/*  53:    */         }
/*  54:    */       }
/*  55:    */       else
/*  56:    */       {
/*  57: 59 */         if (literals > 0)
/*  58:    */         {
/*  59: 60 */           outPos = _copyPartialLiterals(in, inPos, out, outPos, literals);
/*  60: 61 */           literals = 0;
/*  61:    */         }
/*  62: 64 */         int maxLen = Math.min(264, inEnd - inPos + 2);
/*  63:    */         
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68: 70 */         int len = _findMatchLength(in, ref + 3, inPos + 3, ref + maxLen);
/*  69:    */         
/*  70: 72 */         off--;
/*  71: 73 */         if (len < 7)
/*  72:    */         {
/*  73: 74 */           out[(outPos++)] = ((byte)((off >> 8) + (len << 5)));
/*  74:    */         }
/*  75:    */         else
/*  76:    */         {
/*  77: 76 */           out[(outPos++)] = ((byte)((off >> 8) + 224));
/*  78: 77 */           out[(outPos++)] = ((byte)(len - 7));
/*  79:    */         }
/*  80: 79 */         out[(outPos++)] = ((byte)off);
/*  81: 80 */         inPos += len;
/*  82: 81 */         seen = _getInt(in, inPos);
/*  83: 82 */         hashTable[hash(seen >> 8)] = inPos;
/*  84: 83 */         inPos++;
/*  85: 84 */         hashTable[hash(seen)] = inPos;
/*  86: 85 */         inPos++;
/*  87:    */       }
/*  88:    */     }
/*  89: 88 */     return _handleTail(in, inPos, inEnd + 4, out, outPos, literals);
/*  90:    */   }
/*  91:    */   
/*  92:    */   private static final int _getInt(byte[] in, int inPos)
/*  93:    */   {
/*  94: 92 */     return Integer.reverseBytes(unsafe.getInt(in, BYTE_ARRAY_OFFSET + inPos));
/*  95:    */   }
/*  96:    */   
/*  97:    */   private static final int _findMatchLength(byte[] in, int ptr1, int ptr2, int maxPtr1)
/*  98:    */   {
/*  99:104 */     if (ptr1 + 8 >= maxPtr1) {
/* 100:105 */       return _findTailMatchLength(in, ptr1, ptr2, maxPtr1);
/* 101:    */     }
/* 102:109 */     int i1 = unsafe.getInt(in, BYTE_ARRAY_OFFSET + ptr1);
/* 103:110 */     int i2 = unsafe.getInt(in, BYTE_ARRAY_OFFSET + ptr2);
/* 104:111 */     if (i1 != i2) {
/* 105:112 */       return 1 + _leadingBytes(i1, i2);
/* 106:    */     }
/* 107:114 */     ptr1 += 4;
/* 108:115 */     ptr2 += 4;
/* 109:    */     
/* 110:117 */     i1 = unsafe.getInt(in, BYTE_ARRAY_OFFSET + ptr1);
/* 111:118 */     i2 = unsafe.getInt(in, BYTE_ARRAY_OFFSET + ptr2);
/* 112:119 */     if (i1 != i2) {
/* 113:120 */       return 5 + _leadingBytes(i1, i2);
/* 114:    */     }
/* 115:122 */     return _findLongMatchLength(in, ptr1 + 4, ptr2 + 4, maxPtr1);
/* 116:    */   }
/* 117:    */   
/* 118:    */   private static final int _findLongMatchLength(byte[] in, int ptr1, int ptr2, int maxPtr1)
/* 119:    */   {
/* 120:127 */     int base = ptr1 - 9;
/* 121:    */     
/* 122:129 */     int longEnd = maxPtr1 - 8;
/* 123:130 */     while (ptr1 <= longEnd)
/* 124:    */     {
/* 125:131 */       long l1 = unsafe.getLong(in, BYTE_ARRAY_OFFSET + ptr1);
/* 126:132 */       long l2 = unsafe.getLong(in, BYTE_ARRAY_OFFSET + ptr2);
/* 127:133 */       if (l1 != l2) {
/* 128:134 */         return ptr1 - base + _leadingBytes(l1, l2);
/* 129:    */       }
/* 130:136 */       ptr1 += 8;
/* 131:137 */       ptr2 += 8;
/* 132:    */     }
/* 133:140 */     while ((ptr1 < maxPtr1) && (in[ptr1] == in[ptr2]))
/* 134:    */     {
/* 135:141 */       ptr1++;
/* 136:142 */       ptr2++;
/* 137:    */     }
/* 138:144 */     return ptr1 - base;
/* 139:    */   }
/* 140:    */   
/* 141:    */   private static final int _leadingBytes(int i1, int i2)
/* 142:    */   {
/* 143:153 */     return Integer.numberOfTrailingZeros(i1 ^ i2) >> 3;
/* 144:    */   }
/* 145:    */   
/* 146:    */   private static final int _leadingBytes(long l1, long l2)
/* 147:    */   {
/* 148:157 */     return Long.numberOfTrailingZeros(l1 ^ l2) >> 3;
/* 149:    */   }
/* 150:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.impl.UnsafeChunkEncoderLE
 * JD-Core Version:    0.7.0.1
 */