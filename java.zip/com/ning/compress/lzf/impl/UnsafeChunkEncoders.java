/*  1:   */ package com.ning.compress.lzf.impl;
/*  2:   */ 
/*  3:   */ import com.ning.compress.BufferRecycler;
/*  4:   */ import java.nio.ByteOrder;
/*  5:   */ 
/*  6:   */ public final class UnsafeChunkEncoders
/*  7:   */ {
/*  8:28 */   private static final boolean LITTLE_ENDIAN = ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN;
/*  9:   */   
/* 10:   */   public static UnsafeChunkEncoder createEncoder(int totalLength)
/* 11:   */   {
/* 12:31 */     if (LITTLE_ENDIAN) {
/* 13:32 */       return new UnsafeChunkEncoderLE(totalLength);
/* 14:   */     }
/* 15:34 */     return new UnsafeChunkEncoderBE(totalLength);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static UnsafeChunkEncoder createNonAllocatingEncoder(int totalLength)
/* 19:   */   {
/* 20:38 */     if (LITTLE_ENDIAN) {
/* 21:39 */       return new UnsafeChunkEncoderLE(totalLength, false);
/* 22:   */     }
/* 23:41 */     return new UnsafeChunkEncoderBE(totalLength, false);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public static UnsafeChunkEncoder createEncoder(int totalLength, BufferRecycler bufferRecycler)
/* 27:   */   {
/* 28:45 */     if (LITTLE_ENDIAN) {
/* 29:46 */       return new UnsafeChunkEncoderLE(totalLength, bufferRecycler);
/* 30:   */     }
/* 31:48 */     return new UnsafeChunkEncoderBE(totalLength, bufferRecycler);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static UnsafeChunkEncoder createNonAllocatingEncoder(int totalLength, BufferRecycler bufferRecycler)
/* 35:   */   {
/* 36:52 */     if (LITTLE_ENDIAN) {
/* 37:53 */       return new UnsafeChunkEncoderLE(totalLength, bufferRecycler, false);
/* 38:   */     }
/* 39:55 */     return new UnsafeChunkEncoderBE(totalLength, bufferRecycler, false);
/* 40:   */   }
/* 41:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.impl.UnsafeChunkEncoders
 * JD-Core Version:    0.7.0.1
 */