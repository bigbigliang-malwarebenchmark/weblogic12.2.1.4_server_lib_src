/*   1:    */ package com.ning.compress.lzf.impl;
/*   2:    */ 
/*   3:    */ import com.ning.compress.BufferRecycler;
/*   4:    */ import com.ning.compress.lzf.ChunkEncoder;
/*   5:    */ 
/*   6:    */ public class VanillaChunkEncoder
/*   7:    */   extends ChunkEncoder
/*   8:    */ {
/*   9:    */   public VanillaChunkEncoder(int totalLength)
/*  10:    */   {
/*  11: 15 */     super(totalLength);
/*  12:    */   }
/*  13:    */   
/*  14:    */   protected VanillaChunkEncoder(int totalLength, boolean bogus)
/*  15:    */   {
/*  16: 23 */     super(totalLength, bogus);
/*  17:    */   }
/*  18:    */   
/*  19:    */   public VanillaChunkEncoder(int totalLength, BufferRecycler bufferRecycler)
/*  20:    */   {
/*  21: 32 */     super(totalLength, bufferRecycler);
/*  22:    */   }
/*  23:    */   
/*  24:    */   protected VanillaChunkEncoder(int totalLength, BufferRecycler bufferRecycler, boolean bogus)
/*  25:    */   {
/*  26: 40 */     super(totalLength, bufferRecycler, bogus);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static VanillaChunkEncoder nonAllocatingEncoder(int totalLength)
/*  30:    */   {
/*  31: 44 */     return new VanillaChunkEncoder(totalLength, true);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static VanillaChunkEncoder nonAllocatingEncoder(int totalLength, BufferRecycler bufferRecycler)
/*  35:    */   {
/*  36: 48 */     return new VanillaChunkEncoder(totalLength, bufferRecycler, true);
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected int tryCompress(byte[] in, int inPos, int inEnd, byte[] out, int outPos)
/*  40:    */   {
/*  41: 67 */     int[] hashTable = this._hashTable;
/*  42: 68 */     outPos++;
/*  43: 69 */     int seen = first(in, inPos);
/*  44: 70 */     int literals = 0;
/*  45: 71 */     inEnd -= 4;
/*  46: 72 */     int firstPos = inPos;
/*  47: 74 */     while (inPos < inEnd)
/*  48:    */     {
/*  49: 75 */       byte p2 = in[(inPos + 2)];
/*  50:    */       
/*  51: 77 */       seen = (seen << 8) + (p2 & 0xFF);
/*  52: 78 */       int off = hash(seen);
/*  53: 79 */       int ref = hashTable[off];
/*  54: 80 */       hashTable[off] = inPos;
/*  55: 83 */       if ((ref >= inPos) || (ref < firstPos) || ((off = inPos - ref) > 8192) || (in[(ref + 2)] != p2) || (in[(ref + 1)] != (byte)(seen >> 8)) || (in[ref] != (byte)(seen >> 16)))
/*  56:    */       {
/*  57: 89 */         out[(outPos++)] = in[(inPos++)];
/*  58: 90 */         literals++;
/*  59: 91 */         if (literals == 32)
/*  60:    */         {
/*  61: 92 */           out[(outPos - 33)] = 31;
/*  62: 93 */           literals = 0;
/*  63: 94 */           outPos++;
/*  64:    */         }
/*  65:    */       }
/*  66:    */       else
/*  67:    */       {
/*  68: 99 */         int maxLen = inEnd - inPos + 2;
/*  69:100 */         if (maxLen > 264) {
/*  70:101 */           maxLen = 264;
/*  71:    */         }
/*  72:103 */         if (literals == 0)
/*  73:    */         {
/*  74:104 */           outPos--;
/*  75:    */         }
/*  76:    */         else
/*  77:    */         {
/*  78:106 */           out[(outPos - literals - 1)] = ((byte)(literals - 1));
/*  79:107 */           literals = 0;
/*  80:    */         }
/*  81:109 */         int len = 3;
/*  82:111 */         while ((len < maxLen) && (in[(ref + len)] == in[(inPos + len)])) {
/*  83:112 */           len++;
/*  84:    */         }
/*  85:114 */         len -= 2;
/*  86:115 */         off--;
/*  87:116 */         if (len < 7)
/*  88:    */         {
/*  89:117 */           out[(outPos++)] = ((byte)((off >> 8) + (len << 5)));
/*  90:    */         }
/*  91:    */         else
/*  92:    */         {
/*  93:119 */           out[(outPos++)] = ((byte)((off >> 8) + 224));
/*  94:120 */           out[(outPos++)] = ((byte)(len - 7));
/*  95:    */         }
/*  96:122 */         out[(outPos++)] = ((byte)off);
/*  97:123 */         outPos++;
/*  98:124 */         inPos += len;
/*  99:125 */         seen = first(in, inPos);
/* 100:126 */         seen = (seen << 8) + (in[(inPos + 2)] & 0xFF);
/* 101:127 */         hashTable[hash(seen)] = inPos;
/* 102:128 */         inPos++;
/* 103:129 */         seen = (seen << 8) + (in[(inPos + 2)] & 0xFF);
/* 104:130 */         hashTable[hash(seen)] = inPos;
/* 105:131 */         inPos++;
/* 106:    */       }
/* 107:    */     }
/* 108:134 */     return _handleTail(in, inPos, inEnd + 4, out, outPos, literals);
/* 109:    */   }
/* 110:    */   
/* 111:    */   private final int _handleTail(byte[] in, int inPos, int inEnd, byte[] out, int outPos, int literals)
/* 112:    */   {
/* 113:140 */     while (inPos < inEnd)
/* 114:    */     {
/* 115:141 */       out[(outPos++)] = in[(inPos++)];
/* 116:142 */       literals++;
/* 117:143 */       if (literals == 32)
/* 118:    */       {
/* 119:144 */         out[(outPos - literals - 1)] = ((byte)(literals - 1));
/* 120:145 */         literals = 0;
/* 121:146 */         outPos++;
/* 122:    */       }
/* 123:    */     }
/* 124:149 */     out[(outPos - literals - 1)] = ((byte)(literals - 1));
/* 125:150 */     if (literals == 0) {
/* 126:151 */       outPos--;
/* 127:    */     }
/* 128:153 */     return outPos;
/* 129:    */   }
/* 130:    */   
/* 131:    */   private final int first(byte[] in, int inPos)
/* 132:    */   {
/* 133:163 */     return (in[inPos] << 8) + (in[(inPos + 1)] & 0xFF);
/* 134:    */   }
/* 135:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.impl.VanillaChunkEncoder
 * JD-Core Version:    0.7.0.1
 */