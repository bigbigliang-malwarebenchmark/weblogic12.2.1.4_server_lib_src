/*   1:    */ package com.ning.compress.lzf.impl;
/*   2:    */ 
/*   3:    */ import com.ning.compress.lzf.ChunkDecoder;
/*   4:    */ import com.ning.compress.lzf.LZFException;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ import java.lang.reflect.Field;
/*   8:    */ import sun.misc.Unsafe;
/*   9:    */ 
/*  10:    */ public class UnsafeChunkDecoder
/*  11:    */   extends ChunkDecoder
/*  12:    */ {
/*  13:    */   private static final Unsafe unsafe;
/*  14:    */   
/*  15:    */   static
/*  16:    */   {
/*  17:    */     try
/*  18:    */     {
/*  19: 27 */       Field theUnsafe = Unsafe.class.getDeclaredField("theUnsafe");
/*  20: 28 */       theUnsafe.setAccessible(true);
/*  21: 29 */       unsafe = (Unsafe)theUnsafe.get(null);
/*  22:    */     }
/*  23:    */     catch (Exception e)
/*  24:    */     {
/*  25: 32 */       throw new RuntimeException(e);
/*  26:    */     }
/*  27:    */   }
/*  28:    */   
/*  29: 36 */   private static final long BYTE_ARRAY_OFFSET = unsafe.arrayBaseOffset([B.class);
/*  30:    */   
/*  31:    */   public final int decodeChunk(InputStream is, byte[] inputBuffer, byte[] outputBuffer)
/*  32:    */     throws IOException
/*  33:    */   {
/*  34: 49 */     int bytesRead = readHeader(is, inputBuffer);
/*  35: 50 */     if ((bytesRead < 5) || (inputBuffer[0] != 90) || (inputBuffer[1] != 86))
/*  36:    */     {
/*  37: 52 */       if (bytesRead == 0) {
/*  38: 53 */         return -1;
/*  39:    */       }
/*  40: 55 */       _reportCorruptHeader();
/*  41:    */     }
/*  42: 57 */     int type = inputBuffer[2];
/*  43: 58 */     int compLen = uint16(inputBuffer, 3);
/*  44: 59 */     if (type == 0)
/*  45:    */     {
/*  46: 60 */       readFully(is, false, outputBuffer, 0, compLen);
/*  47: 61 */       return compLen;
/*  48:    */     }
/*  49: 64 */     readFully(is, true, inputBuffer, 0, 2 + compLen);
/*  50: 65 */     int uncompLen = uint16(inputBuffer, 0);
/*  51: 66 */     decodeChunk(inputBuffer, 2, outputBuffer, 0, uncompLen);
/*  52: 67 */     return uncompLen;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public final void decodeChunk(byte[] in, int inPos, byte[] out, int outPos, int outEnd)
/*  56:    */     throws LZFException
/*  57:    */   {
/*  58: 75 */     int outputEnd8 = outEnd - 8;
/*  59: 76 */     int outputEnd32 = outEnd - 32;
/*  60:    */     do
/*  61:    */     {
/*  62: 80 */       int ctrl = in[(inPos++)] & 0xFF;
/*  63: 81 */       while (ctrl < 32)
/*  64:    */       {
/*  65: 82 */         if (outPos > outputEnd32) {
/*  66: 83 */           System.arraycopy(in, inPos, out, outPos, ctrl + 1);
/*  67:    */         } else {
/*  68: 85 */           copyUpTo32(in, inPos, out, outPos, ctrl);
/*  69:    */         }
/*  70: 87 */         ctrl++;
/*  71: 88 */         inPos += ctrl;
/*  72: 89 */         outPos += ctrl;
/*  73: 90 */         if (outPos >= outEnd) {
/*  74:    */           break label342;
/*  75:    */         }
/*  76: 93 */         ctrl = in[(inPos++)] & 0xFF;
/*  77:    */       }
/*  78: 96 */       int len = ctrl >> 5;
/*  79: 97 */       ctrl = -((ctrl & 0x1F) << 8) - 1;
/*  80: 99 */       if (len < 7)
/*  81:    */       {
/*  82:100 */         ctrl -= (in[(inPos++)] & 0xFF);
/*  83:101 */         if ((ctrl < -7) && (outPos < outputEnd8))
/*  84:    */         {
/*  85:102 */           long rawOffset = BYTE_ARRAY_OFFSET + outPos;
/*  86:103 */           unsafe.putLong(out, rawOffset, unsafe.getLong(out, rawOffset + ctrl));
/*  87:    */           
/*  88:105 */           outPos += len + 2;
/*  89:    */         }
/*  90:    */         else
/*  91:    */         {
/*  92:109 */           outPos = copyOverlappingShort(out, outPos, ctrl, len);
/*  93:    */         }
/*  94:    */       }
/*  95:    */       else
/*  96:    */       {
/*  97:113 */         len = (in[(inPos++)] & 0xFF) + 9;
/*  98:114 */         ctrl -= (in[(inPos++)] & 0xFF);
/*  99:116 */         if ((ctrl > -9) || (outPos > outputEnd32))
/* 100:    */         {
/* 101:117 */           outPos = copyOverlappingLong(out, outPos, ctrl, len - 9);
/* 102:    */         }
/* 103:121 */         else if (len <= 32)
/* 104:    */         {
/* 105:122 */           copyUpTo32(out, outPos + ctrl, outPos, len - 1);
/* 106:123 */           outPos += len;
/* 107:    */         }
/* 108:    */         else
/* 109:    */         {
/* 110:126 */           copyLong(out, outPos + ctrl, outPos, len, outputEnd32);
/* 111:127 */           outPos += len;
/* 112:    */         }
/* 113:    */       }
/* 114:128 */     } while (outPos < outEnd);
/* 115:    */     label342:
/* 116:131 */     if (outPos != outEnd) {
/* 117:132 */       throw new LZFException("Corrupt data: overrun in decompress, input offset " + inPos + ", output offset " + outPos);
/* 118:    */     }
/* 119:    */   }
/* 120:    */   
/* 121:    */   public int skipOrDecodeChunk(InputStream is, byte[] inputBuffer, byte[] outputBuffer, long maxToSkip)
/* 122:    */     throws IOException
/* 123:    */   {
/* 124:141 */     int bytesRead = readHeader(is, inputBuffer);
/* 125:142 */     if ((bytesRead < 5) || (inputBuffer[0] != 90) || (inputBuffer[1] != 86))
/* 126:    */     {
/* 127:144 */       if (bytesRead == 0) {
/* 128:145 */         return -1;
/* 129:    */       }
/* 130:147 */       _reportCorruptHeader();
/* 131:    */     }
/* 132:149 */     int type = inputBuffer[2];
/* 133:150 */     int compLen = uint16(inputBuffer, 3);
/* 134:151 */     if (type == 0)
/* 135:    */     {
/* 136:152 */       if (compLen <= maxToSkip)
/* 137:    */       {
/* 138:153 */         skipFully(is, compLen);
/* 139:154 */         return compLen;
/* 140:    */       }
/* 141:156 */       readFully(is, false, outputBuffer, 0, compLen);
/* 142:157 */       return -(compLen + 1);
/* 143:    */     }
/* 144:160 */     readFully(is, true, inputBuffer, 0, 2);
/* 145:161 */     int uncompLen = uint16(inputBuffer, 0);
/* 146:163 */     if (uncompLen <= maxToSkip)
/* 147:    */     {
/* 148:164 */       skipFully(is, compLen);
/* 149:165 */       return uncompLen;
/* 150:    */     }
/* 151:168 */     readFully(is, true, inputBuffer, 2, compLen);
/* 152:169 */     decodeChunk(inputBuffer, 2, outputBuffer, 0, uncompLen);
/* 153:170 */     return -(uncompLen + 1);
/* 154:    */   }
/* 155:    */   
/* 156:    */   private final int copyOverlappingShort(byte[] out, int outPos, int offset, int len)
/* 157:    */   {
/* 158:181 */     out[outPos] = out[(outPos++ + offset)];
/* 159:182 */     out[outPos] = out[(outPos++ + offset)];
/* 160:183 */     switch (len)
/* 161:    */     {
/* 162:    */     case 6: 
/* 163:185 */       out[outPos] = out[(outPos++ + offset)];
/* 164:    */     case 5: 
/* 165:187 */       out[outPos] = out[(outPos++ + offset)];
/* 166:    */     case 4: 
/* 167:189 */       out[outPos] = out[(outPos++ + offset)];
/* 168:    */     case 3: 
/* 169:191 */       out[outPos] = out[(outPos++ + offset)];
/* 170:    */     case 2: 
/* 171:193 */       out[outPos] = out[(outPos++ + offset)];
/* 172:    */     case 1: 
/* 173:195 */       out[outPos] = out[(outPos++ + offset)];
/* 174:    */     }
/* 175:197 */     return outPos;
/* 176:    */   }
/* 177:    */   
/* 178:    */   private static final int copyOverlappingLong(byte[] out, int outPos, int offset, int len)
/* 179:    */   {
/* 180:203 */     out[outPos] = out[(outPos++ + offset)];
/* 181:204 */     out[outPos] = out[(outPos++ + offset)];
/* 182:205 */     out[outPos] = out[(outPos++ + offset)];
/* 183:206 */     out[outPos] = out[(outPos++ + offset)];
/* 184:207 */     out[outPos] = out[(outPos++ + offset)];
/* 185:208 */     out[outPos] = out[(outPos++ + offset)];
/* 186:209 */     out[outPos] = out[(outPos++ + offset)];
/* 187:210 */     out[outPos] = out[(outPos++ + offset)];
/* 188:211 */     out[outPos] = out[(outPos++ + offset)];
/* 189:    */     
/* 190:    */ 
/* 191:    */ 
/* 192:    */ 
/* 193:    */ 
/* 194:217 */     len += outPos;
/* 195:218 */     int end = len - 3;
/* 196:219 */     while (outPos < end)
/* 197:    */     {
/* 198:220 */       out[outPos] = out[(outPos++ + offset)];
/* 199:221 */       out[outPos] = out[(outPos++ + offset)];
/* 200:222 */       out[outPos] = out[(outPos++ + offset)];
/* 201:223 */       out[outPos] = out[(outPos++ + offset)];
/* 202:    */     }
/* 203:225 */     switch (len - outPos)
/* 204:    */     {
/* 205:    */     case 3: 
/* 206:227 */       out[outPos] = out[(outPos++ + offset)];
/* 207:    */     case 2: 
/* 208:229 */       out[outPos] = out[(outPos++ + offset)];
/* 209:    */     case 1: 
/* 210:231 */       out[outPos] = out[(outPos++ + offset)];
/* 211:    */     }
/* 212:233 */     return outPos;
/* 213:    */   }
/* 214:    */   
/* 215:    */   private static final void copyUpTo32(byte[] buffer, int inputIndex, int outputIndex, int lengthMinusOne)
/* 216:    */   {
/* 217:238 */     long inPtr = BYTE_ARRAY_OFFSET + inputIndex;
/* 218:239 */     long outPtr = BYTE_ARRAY_OFFSET + outputIndex;
/* 219:    */     
/* 220:241 */     unsafe.putLong(buffer, outPtr, unsafe.getLong(buffer, inPtr));
/* 221:242 */     if (lengthMinusOne > 7)
/* 222:    */     {
/* 223:243 */       inPtr += 8L;
/* 224:244 */       outPtr += 8L;
/* 225:245 */       unsafe.putLong(buffer, outPtr, unsafe.getLong(buffer, inPtr));
/* 226:246 */       if (lengthMinusOne > 15)
/* 227:    */       {
/* 228:247 */         inPtr += 8L;
/* 229:248 */         outPtr += 8L;
/* 230:249 */         unsafe.putLong(buffer, outPtr, unsafe.getLong(buffer, inPtr));
/* 231:250 */         if (lengthMinusOne > 23)
/* 232:    */         {
/* 233:251 */           inPtr += 8L;
/* 234:252 */           outPtr += 8L;
/* 235:253 */           unsafe.putLong(buffer, outPtr, unsafe.getLong(buffer, inPtr));
/* 236:    */         }
/* 237:    */       }
/* 238:    */     }
/* 239:    */   }
/* 240:    */   
/* 241:    */   private static final void copyUpTo32(byte[] in, int inputIndex, byte[] out, int outputIndex, int lengthMinusOne)
/* 242:    */   {
/* 243:261 */     long inPtr = BYTE_ARRAY_OFFSET + inputIndex;
/* 244:262 */     long outPtr = BYTE_ARRAY_OFFSET + outputIndex;
/* 245:    */     
/* 246:264 */     unsafe.putLong(out, outPtr, unsafe.getLong(in, inPtr));
/* 247:265 */     if (lengthMinusOne > 7)
/* 248:    */     {
/* 249:266 */       inPtr += 8L;
/* 250:267 */       outPtr += 8L;
/* 251:268 */       unsafe.putLong(out, outPtr, unsafe.getLong(in, inPtr));
/* 252:269 */       if (lengthMinusOne > 15)
/* 253:    */       {
/* 254:270 */         inPtr += 8L;
/* 255:271 */         outPtr += 8L;
/* 256:272 */         unsafe.putLong(out, outPtr, unsafe.getLong(in, inPtr));
/* 257:273 */         if (lengthMinusOne > 23)
/* 258:    */         {
/* 259:274 */           inPtr += 8L;
/* 260:275 */           outPtr += 8L;
/* 261:276 */           unsafe.putLong(out, outPtr, unsafe.getLong(in, inPtr));
/* 262:    */         }
/* 263:    */       }
/* 264:    */     }
/* 265:    */   }
/* 266:    */   
/* 267:    */   private static final void copyLong(byte[] buffer, int inputIndex, int outputIndex, int length, int outputEnd8)
/* 268:    */   {
/* 269:284 */     if (outputIndex + length > outputEnd8)
/* 270:    */     {
/* 271:285 */       copyLongTail(buffer, inputIndex, outputIndex, length);
/* 272:286 */       return;
/* 273:    */     }
/* 274:288 */     long inPtr = BYTE_ARRAY_OFFSET + inputIndex;
/* 275:289 */     long outPtr = BYTE_ARRAY_OFFSET + outputIndex;
/* 276:291 */     while (length >= 8)
/* 277:    */     {
/* 278:292 */       unsafe.putLong(buffer, outPtr, unsafe.getLong(buffer, inPtr));
/* 279:293 */       inPtr += 8L;
/* 280:294 */       outPtr += 8L;
/* 281:295 */       length -= 8;
/* 282:    */     }
/* 283:297 */     if (length > 4) {
/* 284:298 */       unsafe.putLong(buffer, outPtr, unsafe.getLong(buffer, inPtr));
/* 285:299 */     } else if (length > 0) {
/* 286:300 */       unsafe.putInt(buffer, outPtr, unsafe.getInt(buffer, inPtr));
/* 287:    */     }
/* 288:    */   }
/* 289:    */   
/* 290:    */   private static final void copyLongTail(byte[] buffer, int inputIndex, int outputIndex, int length)
/* 291:    */   {
/* 292:306 */     for (int inEnd = inputIndex + length; inputIndex < inEnd;) {
/* 293:307 */       buffer[(outputIndex++)] = buffer[(inputIndex++)];
/* 294:    */     }
/* 295:    */   }
/* 296:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.lzf.impl.UnsafeChunkDecoder
 * JD-Core Version:    0.7.0.1
 */