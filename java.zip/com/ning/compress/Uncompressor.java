package com.ning.compress;

import java.io.IOException;

public abstract class Uncompressor
{
  public abstract boolean feedCompressedData(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;
  
  public abstract void complete()
    throws IOException;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.Uncompressor
 * JD-Core Version:    0.7.0.1
 */