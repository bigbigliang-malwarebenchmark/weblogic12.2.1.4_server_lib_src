/*   1:    */ package com.ning.compress;
/*   2:    */ 
/*   3:    */ import java.lang.ref.SoftReference;
/*   4:    */ 
/*   5:    */ public final class BufferRecycler
/*   6:    */ {
/*   7:    */   private static final int MIN_ENCODING_BUFFER = 4000;
/*   8:    */   private static final int MIN_OUTPUT_BUFFER = 8000;
/*   9: 23 */   protected static final ThreadLocal<SoftReference<BufferRecycler>> _recyclerRef = new ThreadLocal();
/*  10:    */   private byte[] _inputBuffer;
/*  11:    */   private byte[] _outputBuffer;
/*  12:    */   private byte[] _decodingBuffer;
/*  13:    */   private byte[] _encodingBuffer;
/*  14:    */   private int[] _encodingHash;
/*  15:    */   
/*  16:    */   public static BufferRecycler instance()
/*  17:    */   {
/*  18: 40 */     SoftReference<BufferRecycler> ref = (SoftReference)_recyclerRef.get();
/*  19: 41 */     BufferRecycler br = ref == null ? null : (BufferRecycler)ref.get();
/*  20: 42 */     if (br == null)
/*  21:    */     {
/*  22: 43 */       br = new BufferRecycler();
/*  23: 44 */       _recyclerRef.set(new SoftReference(br));
/*  24:    */     }
/*  25: 46 */     return br;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public byte[] allocEncodingBuffer(int minSize)
/*  29:    */   {
/*  30: 57 */     byte[] buf = this._encodingBuffer;
/*  31: 58 */     if ((buf == null) || (buf.length < minSize)) {
/*  32: 59 */       buf = new byte[Math.max(minSize, 4000)];
/*  33:    */     } else {
/*  34: 61 */       this._encodingBuffer = null;
/*  35:    */     }
/*  36: 63 */     return buf;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void releaseEncodeBuffer(byte[] buffer)
/*  40:    */   {
/*  41: 68 */     if ((this._encodingBuffer == null) || ((buffer != null) && (buffer.length > this._encodingBuffer.length))) {
/*  42: 69 */       this._encodingBuffer = buffer;
/*  43:    */     }
/*  44:    */   }
/*  45:    */   
/*  46:    */   public byte[] allocOutputBuffer(int minSize)
/*  47:    */   {
/*  48: 75 */     byte[] buf = this._outputBuffer;
/*  49: 76 */     if ((buf == null) || (buf.length < minSize)) {
/*  50: 77 */       buf = new byte[Math.max(minSize, 8000)];
/*  51:    */     } else {
/*  52: 79 */       this._outputBuffer = null;
/*  53:    */     }
/*  54: 81 */     return buf;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void releaseOutputBuffer(byte[] buffer)
/*  58:    */   {
/*  59: 86 */     if ((this._outputBuffer == null) || ((buffer != null) && (buffer.length > this._outputBuffer.length))) {
/*  60: 87 */       this._outputBuffer = buffer;
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */   public int[] allocEncodingHash(int suggestedSize)
/*  65:    */   {
/*  66: 93 */     int[] buf = this._encodingHash;
/*  67: 94 */     if ((buf == null) || (buf.length < suggestedSize)) {
/*  68: 95 */       buf = new int[suggestedSize];
/*  69:    */     } else {
/*  70: 97 */       this._encodingHash = null;
/*  71:    */     }
/*  72: 99 */     return buf;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void releaseEncodingHash(int[] buffer)
/*  76:    */   {
/*  77:104 */     if ((this._encodingHash == null) || ((buffer != null) && (buffer.length > this._encodingHash.length))) {
/*  78:105 */       this._encodingHash = buffer;
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   public byte[] allocInputBuffer(int minSize)
/*  83:    */   {
/*  84:117 */     byte[] buf = this._inputBuffer;
/*  85:118 */     if ((buf == null) || (buf.length < minSize)) {
/*  86:119 */       buf = new byte[Math.max(minSize, 8000)];
/*  87:    */     } else {
/*  88:121 */       this._inputBuffer = null;
/*  89:    */     }
/*  90:123 */     return buf;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void releaseInputBuffer(byte[] buffer)
/*  94:    */   {
/*  95:128 */     if ((this._inputBuffer == null) || ((buffer != null) && (buffer.length > this._inputBuffer.length))) {
/*  96:129 */       this._inputBuffer = buffer;
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   public byte[] allocDecodeBuffer(int size)
/* 101:    */   {
/* 102:135 */     byte[] buf = this._decodingBuffer;
/* 103:136 */     if ((buf == null) || (buf.length < size)) {
/* 104:137 */       buf = new byte[size];
/* 105:    */     } else {
/* 106:139 */       this._decodingBuffer = null;
/* 107:    */     }
/* 108:141 */     return buf;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void releaseDecodeBuffer(byte[] buffer)
/* 112:    */   {
/* 113:146 */     if ((this._decodingBuffer == null) || ((buffer != null) && (buffer.length > this._decodingBuffer.length))) {
/* 114:147 */       this._decodingBuffer = buffer;
/* 115:    */     }
/* 116:    */   }
/* 117:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.BufferRecycler
 * JD-Core Version:    0.7.0.1
 */