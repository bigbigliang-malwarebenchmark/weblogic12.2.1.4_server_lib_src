/*  1:   */ package com.ning.compress;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.io.OutputStream;
/*  5:   */ 
/*  6:   */ public class UncompressorOutputStream
/*  7:   */   extends OutputStream
/*  8:   */ {
/*  9:   */   protected final Uncompressor _uncompressor;
/* 10:13 */   private byte[] _singleByte = null;
/* 11:   */   
/* 12:   */   public UncompressorOutputStream(Uncompressor uncomp)
/* 13:   */   {
/* 14:17 */     this._uncompressor = uncomp;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void close()
/* 18:   */     throws IOException
/* 19:   */   {
/* 20:27 */     this._uncompressor.complete();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void flush() {}
/* 24:   */   
/* 25:   */   public void write(byte[] b)
/* 26:   */     throws IOException
/* 27:   */   {
/* 28:35 */     this._uncompressor.feedCompressedData(b, 0, b.length);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void write(byte[] b, int off, int len)
/* 32:   */     throws IOException
/* 33:   */   {
/* 34:40 */     this._uncompressor.feedCompressedData(b, off, len);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void write(int b)
/* 38:   */     throws IOException
/* 39:   */   {
/* 40:46 */     if (this._singleByte == null) {
/* 41:47 */       this._singleByte = new byte[1];
/* 42:   */     }
/* 43:49 */     this._singleByte[0] = ((byte)b);
/* 44:50 */     this._uncompressor.feedCompressedData(this._singleByte, 0, 1);
/* 45:   */   }
/* 46:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.UncompressorOutputStream
 * JD-Core Version:    0.7.0.1
 */