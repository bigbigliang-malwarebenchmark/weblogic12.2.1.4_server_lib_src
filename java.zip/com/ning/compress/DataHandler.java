package com.ning.compress;

import java.io.IOException;

public abstract interface DataHandler
{
  public abstract boolean handleData(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;
  
  public abstract void allDataHandled()
    throws IOException;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.ning.compress.DataHandler
 * JD-Core Version:    0.7.0.1
 */