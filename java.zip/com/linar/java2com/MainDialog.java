package com.linar.java2com;

import com.linar.jintegra.Version;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.Rectangle;
import java.awt.TextComponent;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.io.PushbackReader;
import java.net.URL;
import java.util.Enumeration;
import java.util.EventObject;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;

public class MainDialog
  extends JFrame
  implements ActionListener, WindowListener, ItemListener
{
  p a = new p();
  String b = ".";
  String c = a("R\\NL-[RU\003gUQ");
  JTextField d;
  JTextField e;
  Hashtable f = w;
  Hashtable g = new Hashtable();
  Vector h = new Vector();
  TextField i;
  JButton j = new JButton(a("zOWZl]"));
  JButton k = new JButton(q.GENERATE);
  JButton l = new JButton(a("{\\VNzT"));
  JButton m = new JButton(a("yY\\\r1\026\023"));
  JMenuItem n = new JMenuItem(q.ABOUT);
  JMenuItem o = new JMenuItem(a("}EQY"));
  JMenuItem p = new JMenuItem(q.SAVE_SETTINGS);
  JMenuItem q = new JMenuItem(q.LOAD_SETTINGS);
  JMenuItem r = new JMenuItem(q.NAMES);
  JCheckBoxMenuItem s;
  JCheckBoxMenuItem t;
  ClassTreeViewPanel u = null;
  String v = ".";
  private static Hashtable w = new Hashtable();
  
  public static void main(String[] paramArrayOfString)
  {
    try
    {
      UIManager.setLookAndFeel(a("[RU\003lMS\026G~N\\\026^hQS_\003oT\\^\003hQS\\BhK\023oDq\\RO^SWRSlq\\{]Hs"));
    }
    catch (Exception localException) {}
    MainDialog localMainDialog = new MainDialog();
    localMainDialog.setTitle(q.translate(q.MAIN_DIALOG_TITLE, Version.getVersion()));
    localMainDialog.a();
    localMainDialog.setVisible(true);
  }
  
  private void a()
  {
    Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
    Rectangle localRectangle = getBounds();
    setLocation((localDimension.width - localRectangle.width) / 2, (localDimension.height - localRectangle.height) / 2);
  }
  
  public MainDialog()
  {
    w.put(a("[QY^l\030WY[~\026QYCx\026~TLlK"), "");
    w.put(a("[QY^l\030WY[~\026QYCx\026~TLlKqWL{]O"), "");
    w.put(a("[QY^l\030WY[~\026QYCx\026~W@oQQ]_"), "");
    w.put(a("[QY^l\030WY[~\026QYCx\026mJB|]NK"), "");
    w.put(a("[QY^l\030WY[~\026QYCx\026oMCkQP]"), "");
    w.put(a("[QY^l\030WY[~\026QYCx\026n]NjJTLTRYSYJzJ"), "");
    w.put(a("[QY^l\030WY[~\026QYCx\026nL_vVZzXy^XJ"), "");
    w.put(a("[QY^l\030WY[~\026QYCx\026nA^k]P"), "");
    w.put(a("[QY^l\030WY[~\026QYCx\026iP_zYY"), "");
    w.put(a("[QY^l\030WY[~\026QYCx\026iP_zYY_pMM"), "");
    w.put(a("]LMLsK"), "");
    w.put(a("_XLnsYNK"), "");
    w.put(a("P\\KE\\WY]"), "");
    w.put(a("VRLDyA"), "");
    w.put(a("VRLDyA|TA"), "");
    w.put(a("LRkYmQS_"), "");
    w.put(a("O\\QY"), "");
    w.put(a("O\\QY"), "");
    w.put(a("O\\QY"), "");
    w.put(a("\004^TDqQI\006"), "");
    w.put(a("MSQBq"), a("BGgXqQRV"));
    w.put(a("\\XTHk]"), a("BGgIzTXLH"));
    w.put(a("[RV^k"), a("BGgNpVNL"));
    w.put(a("_RLB"), a("BGgJpLR"));
    w.put(a("lomh"), a("BGgyMmx"));
    w.put(a("~|t~Z"), a("BGgk^tn}"));
    setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource(a("RTTBxW\023_Dy"))));
    getContentPane().setLayout(new GridBagLayout());
    GridBagConstraints localGridBagConstraints = new GridBagConstraints();
    JPanel localJPanel1 = new JPanel(new GridBagLayout());
    localJPanel1.setBorder(new CompoundBorder(BorderFactory.createTitledBorder(a("{QY^l]N\027}~[VYJzK\035LB?XVHmYI]\r")), new EmptyBorder(2, 5, 3, 4)));
    this.u = new ClassTreeViewPanel();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 0;
    localGridBagConstraints.fill = 1;
    localGridBagConstraints.weightx = 1.0D;
    localGridBagConstraints.weighty = 1.0D;
    localGridBagConstraints.gridwidth = 3;
    localJPanel1.add(this.u, localGridBagConstraints);
    String str1 = null;
    try
    {
      String str2 = new Object().getClass().getResource("").getFile();
      str1 = str2.substring(6, str2.indexOf('!'));
    }
    catch (Exception localException1)
    {
      try
      {
        File localFile = new File(System.getProperty(a("R\\NL1PRUH")) + a("\027QQO0JI\026G~J"));
        str1 = localFile.getAbsolutePath();
      }
      catch (Exception localException2)
      {
        localException2.printStackTrace();
        str1 = null;
      }
    }
    if (str1 != null) {
      this.u.addJar(str1, str1 + a("\030\025\030g[s\035pBr]\035\021"));
    }
    String str3 = new File(".").getAbsolutePath();
    str3 = str3.substring(0, str3.length() - 1);
    this.u.addPath(str3, str3 + a("\030\025\030njJO]Ck\030yQ_z[IW_f\030\024"));
    JPanel localJPanel2 = new JPanel(new GridBagLayout());
    this.m.addActionListener(this);
    localJPanel2.add(this.m, new GridBagConstraints(0, 0, 1, 1, 1.0D, 0.0D, 11, 2, new Insets(0, 5, 2, 0), 0, 0));
    localJPanel2.add(Box.createVerticalGlue(), new GridBagConstraints(0, 2, 1, 1, 1.0D, 1.0D, 15, 1, new Insets(0, 0, 0, 0), 0, 0));
    localGridBagConstraints.gridx = 3;
    localGridBagConstraints.gridy = 0;
    localGridBagConstraints.weightx = 0.0D;
    localGridBagConstraints.weighty = 0.0D;
    localGridBagConstraints.fill = 3;
    localGridBagConstraints.gridwidth = 1;
    localJPanel1.add(localJPanel2, localGridBagConstraints);
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.fill = 0;
    localGridBagConstraints.weightx = 0.0D;
    localGridBagConstraints.weighty = 0.0D;
    localGridBagConstraints.anchor = 18;
    localGridBagConstraints.insets = new Insets(10, 0, 1, 0);
    localJPanel1.add(new Label(q.OUTPUT_DIRECTORY), localGridBagConstraints);
    this.e = new JTextField(str3, 48);
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.fill = 2;
    localGridBagConstraints.weightx = 1.0D;
    localGridBagConstraints.insets = new Insets(0, 0, 0, 0);
    localGridBagConstraints.anchor = 10;
    localJPanel1.add(this.e, localGridBagConstraints);
    this.j.addActionListener(this);
    localGridBagConstraints.gridx = 2;
    localGridBagConstraints.fill = 0;
    localGridBagConstraints.weightx = 0.0D;
    localGridBagConstraints.insets = new Insets(0, 2, 0, 0);
    localJPanel1.add(this.j, localGridBagConstraints);
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.insets = new Insets(0, 0, 0, 0);
    localJPanel1.add(new Label(q.NAME_OF_GENERATED_IDL_FILE), localGridBagConstraints);
    this.d = new JTextField(5);
    this.d.setText(a("R\\NL-[RU"));
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.gridwidth = 2;
    localGridBagConstraints.fill = 2;
    localGridBagConstraints.weightx = 1.0D;
    localJPanel1.add(this.d, localGridBagConstraints);
    localGridBagConstraints = new GridBagConstraints();
    JPanel localJPanel3 = new JPanel(new FlowLayout(2));
    this.l.addActionListener(this);
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.fill = 2;
    localGridBagConstraints.gridwidth = 1;
    localJPanel3.add(this.l);
    this.k.addActionListener(this);
    localGridBagConstraints.gridx = 1;
    localJPanel3.add(this.k);
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.weighty = 1.0D;
    localGridBagConstraints.weightx = 1.0D;
    localGridBagConstraints.fill = 1;
    localGridBagConstraints.insets = new Insets(1, 1, 1, 1);
    getContentPane().add(localJPanel1, localGridBagConstraints);
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.fill = 2;
    localGridBagConstraints.anchor = 15;
    localGridBagConstraints.weighty = 0.0D;
    localGridBagConstraints.weightx = 0.0D;
    getContentPane().add(localJPanel3, localGridBagConstraints);
    this.i = new TextField("", 20);
    this.i.setEditable(false);
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 3;
    localGridBagConstraints.insets = new Insets(0, 0, 0, 0);
    localGridBagConstraints.anchor = 15;
    getContentPane().add(this.i, localGridBagConstraints);
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu1 = new JMenu(a("~TTH"));
    JMenu localJMenu2 = new JMenu(a("kXLYvVZK"));
    JMenu localJMenu3 = new JMenu(a("pXT]"));
    localJMenuBar.add(localJMenu1);
    localJMenuBar.add(localJMenu2);
    localJMenuBar.add(localJMenu3);
    setJMenuBar(localJMenuBar);
    localJMenu1.add(this.p);
    localJMenu1.add(this.q);
    localJMenu1.addSeparator();
    localJMenu1.add(this.o);
    this.o.addActionListener(this);
    this.p.addActionListener(this);
    this.q.addActionListener(this);
    this.s = new JCheckBoxMenuItem(a("|HU]?ySYAfKTK"));
    this.s.addItemListener(this);
    localJMenu2.add(this.s);
    this.t = new JCheckBoxMenuItem(a("yHLB2k\\NH?kXLYvVZK\rpV\035}UvL"));
    this.t.addItemListener(this);
    this.t.setEnabled(false);
    localJMenu2.add(this.t);
    localJMenu2.add(this.r);
    this.r.addActionListener(this);
    localJMenu3.add(this.n);
    this.n.addActionListener(this);
    setSize(500, 400);
    addWindowListener(this);
    b(true);
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    if (paramActionEvent.getSource() == this.k)
    {
      if (!g()) {
        return;
      }
      try
      {
        GenNetClassLoader.createClassLoader(this.u.getSaneClasspath());
        String str1 = this.d.getText();
        if (str1.indexOf('.') != -1) {
          str1 = str1.substring(0, str1.indexOf('.'));
        }
        Main.a(this.e.getText(), this.u.getSelectedClassesCommaSeparatedList(), str1, this.i, this.f);
      }
      catch (Exception localException)
      {
        this.i.setText(localException + "");
      }
    }
    if (paramActionEvent.getSource() == this.l) {
      System.exit(0);
    }
    if (paramActionEvent.getSource() == this.o)
    {
      if ((this.t.isEnabled()) && (this.t.isSelected())) {
        a(false);
      }
      System.exit(0);
    }
    JFileChooser localJFileChooser;
    if (paramActionEvent.getSource() == this.j)
    {
      localJFileChooser = new JFileChooser(q.OUTPUT_DIRECTORY_DIALOG_TITLE);
      localJFileChooser.setCurrentDirectory(new File(this.e.getText()));
      localJFileChooser.setFileSelectionMode(1);
      if (localJFileChooser.showDialog(this, a("wv")) == 0) {
        this.e.setText(localJFileChooser.getSelectedFile().getAbsolutePath());
      }
      return;
    }
    if (paramActionEvent.getSource() == this.p)
    {
      d();
      return;
    }
    if (paramActionEvent.getSource() == this.q)
    {
      f();
      return;
    }
    if (paramActionEvent.getSource() == this.r)
    {
      GenNetClassLoader.createClassLoader(this.u.getSaneClasspath());
      b();
      return;
    }
    if (paramActionEvent.getSource() == this.m)
    {
      localJFileChooser = new JFileChooser(new File(this.v).getAbsolutePath());
      localJFileChooser.setFileFilter(new t(a("R\\J"), a("r|j\rYQQ]^?yS\\\r[QO]NkWOQHl")));
      localJFileChooser.setFileSelectionMode(2);
      if (localJFileChooser.showOpenDialog(this) == 0)
      {
        String str2 = localJFileChooser.getSelectedFile().getAbsolutePath();
        String str3 = str2.length() >= 4 ? str2.substring(str2.length() - 4, str2.length()) : "";
        if (str3.equalsIgnoreCase(a("\026WY_")))
        {
          this.u.addJar(str2, str2);
          if (GenNetClassLoader.c == 0) {}
        }
        else
        {
          this.u.addPath(str2, str2);
        }
      }
      this.v = localJFileChooser.getCurrentDirectory().getAbsolutePath();
      return;
    }
    if (paramActionEvent.getSource() == this.n)
    {
      c();
      return;
    }
  }
  
  private void b()
  {
    try
    {
      Hashtable localHashtable = Main.a(this.u.getSelectedClassesCommaSeparatedList(), this.i, "", new Hashtable());
      new d(this, localHashtable, this.f).setVisible(true);
      this.i.setText("");
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      this.i.setText(localException + "");
    }
  }
  
  private void c()
  {
    new a(this).setVisible(true);
  }
  
  private void d()
  {
    a(true);
  }
  
  private void a(boolean paramBoolean)
  {
    if (paramBoolean) {
      try
      {
        Main.a(this.u.getSelectedClassesCommaSeparatedList(), this.i, "", new Hashtable());
      }
      catch (Throwable localThrowable) {}
    }
    this.a = new p();
    this.a.a = this.u.getSelectedClassesCommaSeparatedList();
    this.a.b = this.d.getText();
    this.a.c = this.e.getText();
    this.a.d = this.f;
    this.a.e = k.a();
    this.a.e.put("", Main.typelibUuid);
    if (paramBoolean)
    {
      JFileChooser localJFileChooser = new JFileChooser(q.SAVE_SETTINGS_DIALOG_TITLE);
      localJFileChooser.setCurrentDirectory(new File(this.b));
      localJFileChooser.setSelectedFile(new File(this.c));
      localJFileChooser.setFileFilter(new t(a("@PT"), a("`pt\rYQQ]^")));
      if (localJFileChooser.showDialog(this, a("k\\NH")) == 0)
      {
        this.b = localJFileChooser.getCurrentDirectory().getAbsolutePath();
        this.c = localJFileChooser.getSelectedFile().getName();
        e();
        if (GenNetClassLoader.c == 0) {}
      }
    }
    else
    {
      e();
    }
  }
  
  private void e()
  {
    int i1 = GenNetClassLoader.c;
    try
    {
      File localFile = new File(this.b, this.c);
      FileOutputStream localFileOutputStream = new FileOutputStream(localFile);
      PrintWriter localPrintWriter = new PrintWriter(localFileOutputStream);
      localPrintWriter.println(a("\004\002@@s\030K]_lQRV\020=\t\023\b\017?KIYC{YQWCz\005\037AHl\032\002\006"));
      localPrintWriter.println(a("\004WY[~\n^W@L]ILDq_N\030[zJNQBq\005\037\t\003/\032\003"));
      localPrintWriter.println(a("\030\035\004G~N\\{A~KNvLr]N\006") + this.a.a + a("\004\022RLiY~TLlKsY@zK\003"));
      localPrintWriter.println(a("\030\035\004YfHXtD}\030SY@z\005\037") + this.a.b + a("\032\035MXv\\\035\005\r=") + Main.typelibUuid + a("\032\035WXkHHLivJX[YpJD\030\020?\032") + this.a.c + a("\032\022\006"));
      localPrintWriter.println(a("\030\035\004^~NXkHkLTVJlwS}UvL\003") + ((this.t.isEnabled()) && (this.t.isSelected())) + a("\004\022KLi]n]YkQS_^PVx@Dk\006"));
      localPrintWriter.println(a("\030\035\004C~UXK`~H\003"));
      if (this.a.d == null) {
        this.a.d = new Hashtable();
      }
      Enumeration localEnumeration = this.a.d.keys();
      if (i1 != 0) {}
      String str;
      while (localEnumeration.hasMoreElements())
      {
        localObject1 = localEnumeration.nextElement() + "";
        str = this.a.d.get(localObject1) + "";
        if (((String)localObject1).startsWith("<")) {
          localObject1 = a("\036QL\026") + ((String)localObject1).substring(1);
        }
        localPrintWriter.println(a("") + (String)localObject1 + a("\032\035LB?\005\035\032") + str + a("\032\022\006"));
      }
      localPrintWriter.println(a("\030\035\004\002qYP]^RYM\006"));
      localPrintWriter.println(a("\030\035\004C~UXKypmHQIlu\\H\023"));
      if (this.a.e == null) {
        this.a.e = new Hashtable();
      }
      Object localObject1 = this.a.e.keys();
      if (i1 != 0) {}
      do
      {
        while (((Enumeration)localObject1).hasMoreElements())
        {
          str = ((Enumeration)localObject1).nextElement() + "";
          Object localObject2 = this.a.e.get(str);
          while ((localObject2 instanceof String[]))
          {
            String[] arrayOfString = (String[])localObject2;
            if (i1 == 0) {
              localPrintWriter.println(a("\030\035\004@~HhMD{\030[JBr\005\037") + str + a("\032\035[AlQY\030\020?\032") + arrayOfString[0] + a("") + arrayOfString[1] + a("\032\035\\DlHT\\\r\"\030\037") + arrayOfString[2] + a("\032\035\027\023"));
            }
          }
        }
        localPrintWriter.println(a("\030\035\004\002qYP]^KWhMD{KpY]!"));
        localPrintWriter.println(a("\004^TLlKMYYw\006") + this.u.getSaneClasspathString() + a("\004\022[A~KNHLkP\003"));
        localPrintWriter.println(a("\004\022RLiY\017[BrkXLYvVZK\023"));
        localPrintWriter.close();
        localFileOutputStream.close();
        this.i.setText(q.translate(q.SETTINGS_SAVED_TO, localFile.getCanonicalPath()));
        this.t.setEnabled(true);
      } while (i1 != 0);
    }
    catch (IOException localIOException)
    {
      this.i.setText(localIOException + "");
    }
  }
  
  void f()
  {
    JFileChooser localJFileChooser = new JFileChooser(q.LOAD_SETTINGS_DIALOG_TITLE);
    localJFileChooser.setCurrentDirectory(new File(this.b));
    localJFileChooser.setSelectedFile(new File(this.c));
    localJFileChooser.setFileFilter(new t(a("@PT"), a("`pt\rYQQ]^")));
    if (localJFileChooser.showDialog(this, a("wM]C")) == 0)
    {
      this.b = localJFileChooser.getCurrentDirectory().getAbsolutePath();
      this.c = localJFileChooser.getSelectedFile().getName();
      b(false);
      if (GenNetClassLoader.c == 0) {}
    }
    else {}
  }
  
  private void a(r paramr)
  {
    s locals = new s(paramr);
    if (locals.f != null) {
      this.u.setClasspath(locals.f.b);
    }
    this.u.setClassesSelected(locals.a.b);
    this.d.setText(locals.b.c.get(a("V\\UH")) + "");
    this.e.setText(locals.b.c.get(a("WHL]jLyQ_z[IW_f")) + "");
    Main.typelibUuid = locals.b.c.get(a("MHQI")) + "";
    this.f = locals.g;
    this.g = locals.h;
    k.b(this.g);
    this.t.setEnabled(true);
    this.t.setSelected(locals.c.b.equals(a("LOMH")));
  }
  
  void b(boolean paramBoolean)
  {
    p localp = new p();
    String str = "";
    try
    {
      File localFile = new File(this.b, this.c);
      str = localFile.getPath();
      FileInputStream localFileInputStream = new FileInputStream(localFile);
      Object localObject1;
      Object localObject2;
      if (str.toLowerCase().endsWith(a("@PT")))
      {
        localObject1 = new PushbackReader(new InputStreamReader(localFileInputStream), 2);
        localObject2 = new r((PushbackReader)localObject1);
        ((PushbackReader)localObject1).close();
        a((r)localObject2);
        if (GenNetClassLoader.c == 0) {}
      }
      else
      {
        localObject1 = new ObjectInputStream(localFileInputStream);
        localp = (p)((ObjectInputStream)localObject1).readObject();
        ((ObjectInputStream)localObject1).close();
        this.u.setClassesSelected(localp.a);
        this.d.setText(localp.b);
        this.e.setText(localp.c);
        this.f = localp.d;
        this.g = localp.e;
        this.h = localp.f;
        if (localp.e != null)
        {
          k.b(localp.e);
          localObject2 = localp.e.get("");
          if (localObject2 != null) {
            Main.typelibUuid = (String)localObject2;
          }
        }
        localFileInputStream.close();
      }
    }
    catch (Exception localException)
    {
      if (!paramBoolean) {
        this.i.setText(localException + "");
      }
      return;
    }
    this.i.setText(q.translate(q.SETTINGS_LOADED_FROM, str));
  }
  
  public void windowOpened(WindowEvent paramWindowEvent) {}
  
  public void windowClosing(WindowEvent paramWindowEvent)
  {
    if ((this.t.isEnabled()) && (this.t.isSelected())) {
      a(false);
    }
    System.exit(0);
  }
  
  public void windowClosed(WindowEvent paramWindowEvent) {}
  
  public void windowIconified(WindowEvent paramWindowEvent) {}
  
  public void windowDeiconified(WindowEvent paramWindowEvent) {}
  
  public void windowActivated(WindowEvent paramWindowEvent) {}
  
  public void windowDeactivated(WindowEvent paramWindowEvent) {}
  
  private boolean g()
  {
    String str1 = this.u.getSelectedClassesCommaSeparatedList();
    String str2 = this.d.getText().trim();
    if (str2.indexOf('.') != -1) {
      str2 = str2.substring(0, str2.indexOf('.'));
    }
    if (str1.length() == 0)
    {
      this.i.setText(a("hQ]Ll]\035K]z[T^T?Y\035rLiY\035[A~KN"));
      return false;
    }
    if (str2.trim().length() == 0)
    {
      this.i.setText(q.TYPE_LIBRARY_NAME_NOT_SPECIFIED);
      return false;
    }
    if ((str2.indexOf(' ') != -1) || (str2.indexOf('\t') != -1))
    {
      this.i.setText(q.TYPE_LIBRARY_NAME_NO_WHITESPACE);
      return false;
    }
    return true;
  }
  
  public void itemStateChanged(ItemEvent paramItemEvent)
  {
    k.d = this.s.getState();
    k.e = true;
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      61[56] = ((char)(0x2D ^ 0x1F));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.java2com.MainDialog
 * JD-Core Version:    0.7.0.1
 */