package com.linar.java2com;

import com.linar.jintegra.Log;
import com.linar.jintegra.Version;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextComponent;
import java.awt.TextField;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.io.PushbackReader;
import java.util.Enumeration;
import java.util.EventObject;
import java.util.Hashtable;
import java.util.Vector;

public class ClassicMainDialog
  extends Frame
  implements ActionListener, WindowListener, ItemListener
{
  p a = new p();
  String b = ".";
  String c = a("/cP/G&mK`\r(n");
  TextField d;
  TextField e;
  TextField f;
  Hashtable g = u;
  Hashtable h = new Hashtable();
  Vector i = new Vector();
  Checkbox j;
  Checkbox k;
  TextField l;
  Button m = new Button(a("k,\b"));
  Button n = new Button(q.GENERATE);
  Button o = new Button(q.ABOUT);
  Button p = new Button(q.CLOSE);
  Button q = new Button(q.SAVE_SETTINGS);
  Button r = new Button(q.LOAD_SETTINGS);
  Button s = new Button(q.NAMES);
  Button t = new Button(a("k,\b"));
  private static Hashtable u = new Hashtable();
  
  public static void main(String[] paramArrayOfString)
  {
    ClassicMainDialog localClassicMainDialog = new ClassicMainDialog();
    localClassicMainDialog.setTitle(q.translate(q.MAIN_DIALOG_TITLE, Version.getVersion()));
    localClassicMainDialog.setVisible(true);
  }
  
  public ClassicMainDialog()
  {
    u.put(a("&nG=\006ehG8\024knG \022kAJ/\0066"), "");
    u.put(a("&nG=\006ehG8\024knG \022kAJ/\0066NI/\021 p"), "");
    u.put(a("&nG=\006ehG8\024knG \022kAI#\005,nC<"), "");
    u.put(a("&nG=\006ehG8\024knG \022kRT!\026 qU"), "");
    u.put(a("&nG=\006ehG8\024knG \022kPS \001,oC"), "");
    u.put(a(""), "");
    u.put(a("&nG=\006ehG8\024knG \022kQR<\034+ed;\023#gT"), "");
    u.put(a("&nG=\006ehG8\024knG \022kQ_=\001 o"), "");
    u.put(a("&nG=\006ehG8\024knG \022kVN<\020$f"), "");
    u.put(a("&nG=\006ehG8\024knG \022kVN<\020$fa<\0320r"), "");
    u.put(a(" sS/\0316"), "");
    u.put(a("\"gR\r\031$qU"), "");
    u.put(a("-cU&6*fC"), "");
    u.put(a("+mR'\023<"), "");
    u.put(a("+mR'\023<CJ\""), "");
    u.put(a("1mu:\007,lA"), "");
    u.put(a("2cO:"), "");
    u.put(a("2cO:"), "");
    u.put(a("2cO:"), "");
    u.put(a("yaJ'\033,v\030"), "");
    u.put(a("0lO!\033"), a("?xy;\033,mH"));
    u.put(a("!gJ+\001 "), a("?xy*\020)gR+"));
    u.put(a("&mH=\001"), a("?xy-\032+qR"));
    u.put(a("\"mR!"), a("?xy)\0321m"));
    u.put(a("\021Ps\013"), a("?xy\032'\020G"));
    u.put(a("\003Cj\0350"), a("?xy\b4\tQc"));
    GridBagLayout localGridBagLayout = new GridBagLayout();
    GridBagConstraints localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.fill = 1;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.weightx = 1.0D;
    Panel localPanel1 = new Panel(localGridBagLayout);
    Panel localPanel2 = new Panel(new BorderLayout());
    localPanel2.add(new Label(q.JAVA_CLASSES_AND_INTERFACES), a("\022gU:"));
    this.d = new TextField(10);
    localPanel2.add(this.d);
    localPanel2.add(this.t, a(""));
    this.t.addActionListener(this);
    localGridBagLayout.setConstraints(localPanel2, localGridBagConstraints);
    localPanel1.add(localPanel2);
    localPanel2 = new Panel(new BorderLayout());
    localPanel2.add(new Label(q.NAME_OF_GENERATED_IDL_FILE), a("\022gU:"));
    this.e = new TextField(5);
    localPanel2.add(this.e);
    localGridBagLayout.setConstraints(localPanel2, localGridBagConstraints);
    localPanel1.add(localPanel2);
    localPanel2 = new Panel(new BorderLayout());
    localPanel2.add(new Label(q.OUTPUT_DIRECTORY), a("\022gU:"));
    this.f = new TextField(".", 48);
    localPanel2.add(this.f);
    localPanel2.add(this.m, a(""));
    this.m.addActionListener(this);
    localGridBagLayout.setConstraints(localPanel2, localGridBagConstraints);
    localPanel1.add(localPanel2);
    localPanel2 = new Panel(new BorderLayout());
    this.j = new Checkbox(q.DUMP_ANALYSIS);
    localPanel2.add(this.j, a("\022gU:"));
    this.j.addItemListener(this);
    this.k = new Checkbox(q.AUTO_SAVE_SETTINGS_ON_EXIT);
    localPanel2.add(this.k);
    this.k.addItemListener(this);
    this.k.setEnabled(false);
    localGridBagLayout.setConstraints(localPanel2, localGridBagConstraints);
    localPanel1.add(localPanel2);
    localPanel2 = new Panel();
    this.n.addActionListener(this);
    localPanel2.add(this.n);
    this.o.addActionListener(this);
    localPanel2.add(this.o);
    this.p.addActionListener(this);
    localPanel2.add(this.p);
    localPanel2.add(this.q);
    this.q.addActionListener(this);
    this.r.addActionListener(this);
    localPanel2.add(this.r);
    localPanel2.add(this.s);
    this.s.addActionListener(this);
    localGridBagLayout = new GridBagLayout();
    Panel localPanel3 = new Panel(localGridBagLayout);
    localGridBagLayout.setConstraints(localPanel2, localGridBagConstraints);
    localPanel3.add(localPanel2);
    localPanel2 = new Panel(new GridLayout(1, 1));
    this.l = new TextField("", 20);
    this.l.setEditable(false);
    localPanel2.add(this.l);
    localGridBagLayout.setConstraints(localPanel2, localGridBagConstraints);
    localPanel3.add(localPanel2);
    localGridBagLayout = new GridBagLayout();
    setLayout(localGridBagLayout);
    localGridBagLayout.setConstraints(localPanel1, localGridBagConstraints);
    localGridBagLayout.setConstraints(localPanel3, localGridBagConstraints);
    add(localPanel1);
    add(localPanel3);
    pack();
    addWindowListener(this);
    b(true);
    if (Log.r)
    {
      i1++;
      GenNetClassLoader.c = i1;
    }
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    if (paramActionEvent.getSource() == this.n)
    {
      if (!g()) {
        return;
      }
      try
      {
        Main.a(this.f.getText(), this.d.getText(), this.e.getText(), this.l, this.g);
      }
      catch (Exception localException)
      {
        this.l.setText(localException + "");
        localException.printStackTrace();
      }
    }
    if (paramActionEvent.getSource() == this.p)
    {
      if ((this.k.isEnabled()) && (this.k.getState())) {
        a(false);
      }
      System.exit(0);
    }
    if (paramActionEvent.getSource() == this.m)
    {
      FileDialog localFileDialog = new FileDialog(this, q.OUTPUT_DIRECTORY_DIALOG_TITLE, 1);
      localFileDialog.setDirectory(this.f.getText());
      localFileDialog.setFile(a("1jO=[!kT+\0261mT7"));
      localFileDialog.show();
      this.f.setText(localFileDialog.getDirectory());
      return;
    }
    if (paramActionEvent.getSource() == this.q)
    {
      d();
      return;
    }
    if (paramActionEvent.getSource() == this.r)
    {
      f();
      return;
    }
    if (paramActionEvent.getSource() == this.s)
    {
      a();
      return;
    }
    if (paramActionEvent.getSource() == this.t)
    {
      b();
      return;
    }
    if (paramActionEvent.getSource() == this.o)
    {
      c();
      return;
    }
  }
  
  private void a()
  {
    try
    {
      Hashtable localHashtable = Main.a(this.d.getText(), this.l, "", new Hashtable());
      new c(this, localHashtable, this.g).setVisible(true);
      this.l.setText("");
    }
    catch (Exception localException)
    {
      this.l.setText(localException + "");
    }
  }
  
  private void b()
  {
    try
    {
      StringBuffer localStringBuffer = new StringBuffer(this.d.getText());
      new b(this, localStringBuffer).setVisible(true);
      this.d.setText(localStringBuffer + "");
      this.l.setText("");
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      this.l.setText(localException + "");
    }
  }
  
  private void c()
  {
    new a(this).setVisible(true);
  }
  
  private void d()
  {
    a(true);
  }
  
  private void a(boolean paramBoolean)
  {
    if (paramBoolean) {
      try
      {
        Main.a(this.d.getText(), this.l, "", new Hashtable());
      }
      catch (Throwable localThrowable) {}
    }
    this.a = new p();
    this.a.a = this.d.getText();
    this.a.b = this.e.getText();
    this.a.c = this.f.getText();
    this.a.d = this.g;
    this.a.e = k.a();
    this.a.e.put("", Main.typelibUuid);
    if (paramBoolean)
    {
      FileDialog localFileDialog = new FileDialog(this, q.SAVE_SETTINGS_DIALOG_TITLE, 1);
      localFileDialog.setDirectory(this.b);
      localFileDialog.setFile(this.c);
      localFileDialog.show();
      if (localFileDialog.getFile() != null)
      {
        this.b = localFileDialog.getDirectory();
        this.c = localFileDialog.getFile();
        e();
        if (GenNetClassLoader.c == 0) {}
      }
    }
    else
    {
      e();
    }
  }
  
  private void e()
  {
    int i1 = GenNetClassLoader.c;
    try
    {
      File localFile = new File(this.b, this.c);
      FileOutputStream localFileOutputStream = new FileOutputStream(localFile);
      PrintWriter localPrintWriter = new PrintWriter(localFileOutputStream);
      localPrintWriter.println(a("y=^#\031etC<\006,mHsWt,\026lU6vG \021$nI \020x _+\006g=\030"));
      localPrintWriter.println(a("yhG8\024waI#& vR'\033\"q\0068\0207qO!\033x \027`Eg<"));
      localPrintWriter.println(a("e\"\032$\0243ce\"\0246qh/\030 q\030") + this.a.a + a("y-L/\003$AJ/\0066LG#\0206<"));
      localPrintWriter.println(a("e\"\032:\f5gj'\027elG#\020x ") + this.a.b + a("g\"S;\034!\"\033nW") + Main.typelibUuid + a("g\"I;\0015wR\n\0347gE:\0327{\006sUg") + this.a.c + a("g-\030"));
      localPrintWriter.println(a("e\"\032=\0243gu+\0011kH)\006\nlc6\0341<") + ((this.k.isEnabled()) && (this.k.getState())) + a("y-U/\003 QC:\001,lA=:+G^'\001{"));
      localPrintWriter.println(a("e\"\032 \024(gU\003\0245<"));
      if (this.a.d == null) {
        this.a.d = new Hashtable();
      }
      Enumeration localEnumeration = this.a.d.keys();
      if (i1 != 0) {}
      String str;
      while (localEnumeration.hasMoreElements())
      {
        localObject1 = localEnumeration.nextElement() + "";
        str = this.a.d.get(localObject1) + "";
        if (((String)localObject1).startsWith("<")) {
          localObject1 = a("cnRu") + ((String)localObject1).substring(1);
        }
        localPrintWriter.println(a("e\"\032#\0245\"@<\032(?\004") + (String)localObject1 + a("g\"R!Ux\"\004") + str + a("g-\030"));
      }
      localPrintWriter.println(a("e\"\032a\033$oC=8$r\030"));
      localPrintWriter.println(a("e\"\032 \024(gU\032\032\020wO*\006\bcVp"));
      if (this.a.e == null) {
        this.a.e = new Hashtable();
      }
      Object localObject1 = this.a.e.keys();
      if (i1 != 0) {}
      do
      {
        while (((Enumeration)localObject1).hasMoreElements())
        {
          str = ((Enumeration)localObject1).nextElement() + "";
          Object localObject2 = this.a.e.get(str);
          while ((localObject2 instanceof String[]))
          {
            String[] arrayOfString = (String[])localObject2;
            if (i1 == 0) {
              localPrintWriter.println(a("e\"\032#\0245WS'\021edT!\030x ") + str + a("g\"E\"\006,f\006sUg") + arrayOfString[0] + a("g\"O'\021e?\006l") + arrayOfString[1] + a("g\"B'\0065kBnHe ") + arrayOfString[2] + a("g\"\tp"));
            }
          }
        }
        localPrintWriter.println(a("e\"\032a\033$oC=!*WS'\0216OG>K"));
        localPrintWriter.println(a("y-L/\003$0E!\030\026gR:\034+eUp"));
        localPrintWriter.close();
        localFileOutputStream.close();
        this.l.setText(q.translate(q.SETTINGS_SAVED_TO, localFile.getCanonicalPath()));
        this.k.setEnabled(true);
      } while (i1 != 0);
    }
    catch (IOException localIOException)
    {
      this.l.setText(localIOException + "");
    }
  }
  
  void f()
  {
    FileDialog localFileDialog = new FileDialog(this, q.LOAD_SETTINGS_DIALOG_TITLE, 0);
    localFileDialog.setDirectory(this.b);
    localFileDialog.setFile(this.c);
    localFileDialog.show();
    if (localFileDialog.getFile() == null) {
      return;
    }
    this.b = localFileDialog.getDirectory();
    this.c = localFileDialog.getFile();
    b(false);
  }
  
  private void a(r paramr)
  {
    s locals = new s(paramr);
    this.d.setText(locals.a.b);
    this.e.setText(locals.b.c.get(a("+cK+")) + "");
    this.f.setText(locals.b.c.get(a("")) + "");
    Main.typelibUuid = locals.b.c.get(a("0wO*")) + "";
    this.g = locals.g;
    this.h = locals.h;
    k.b(this.h);
    this.k.setEnabled(true);
    this.k.setState(locals.c.b.equals(a("1pS+")));
  }
  
  void b(boolean paramBoolean)
  {
    p localp = new p();
    String str = "";
    try
    {
      File localFile = new File(this.b, this.c);
      str = localFile.getPath();
      FileInputStream localFileInputStream = new FileInputStream(localFile);
      Object localObject1;
      Object localObject2;
      if (str.toLowerCase().endsWith(a("=oJ")))
      {
        localObject1 = new PushbackReader(new InputStreamReader(localFileInputStream), 2);
        localObject2 = new r((PushbackReader)localObject1);
        ((PushbackReader)localObject1).close();
        a((r)localObject2);
        if (GenNetClassLoader.c == 0) {}
      }
      else
      {
        localObject1 = new ObjectInputStream(localFileInputStream);
        localp = (p)((ObjectInputStream)localObject1).readObject();
        ((ObjectInputStream)localObject1).close();
        this.d.setText(localp.a);
        this.e.setText(localp.b);
        this.f.setText(localp.c);
        this.g = localp.d;
        this.h = localp.e;
        this.i = localp.f;
        if (localp.e != null)
        {
          k.b(localp.e);
          localObject2 = localp.e.get("");
          if (localObject2 != null) {
            Main.typelibUuid = (String)localObject2;
          }
        }
        localFileInputStream.close();
      }
    }
    catch (Exception localException)
    {
      if (!paramBoolean) {
        this.l.setText(localException + "");
      }
      return;
    }
    this.l.setText(q.translate(q.SETTINGS_LOADED_FROM, str));
  }
  
  public void windowOpened(WindowEvent paramWindowEvent) {}
  
  public void windowClosing(WindowEvent paramWindowEvent)
  {
    if ((this.k.isEnabled()) && (this.k.getState())) {
      a(false);
    }
    System.exit(0);
  }
  
  public void windowClosed(WindowEvent paramWindowEvent) {}
  
  public void windowIconified(WindowEvent paramWindowEvent) {}
  
  public void windowDeiconified(WindowEvent paramWindowEvent) {}
  
  public void windowActivated(WindowEvent paramWindowEvent) {}
  
  public void windowDeactivated(WindowEvent paramWindowEvent) {}
  
  private boolean g()
  {
    String str1 = this.d.getText().trim();
    String str2 = this.e.getText().trim();
    if (str1.length() == 0)
    {
      this.l.setText(a("\025nC/\006 \"U>\020&k@7U$\"l/\003$\"E\"\0246q"));
      return false;
    }
    if (str2.trim().length() == 0)
    {
      this.l.setText(q.TYPE_LIBRARY_NAME_NOT_SPECIFIED);
      return false;
    }
    if ((str2.indexOf(' ') != -1) || (str2.indexOf('\t') != -1))
    {
      this.l.setText(q.TYPE_LIBRARY_NAME_NO_WHITESPACE);
      return false;
    }
    return true;
  }
  
  public void itemStateChanged(ItemEvent paramItemEvent)
  {
    k.d = this.j.getState();
    k.e = true;
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      2[38] = ((char)(0x4E ^ 0x75));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.java2com.ClassicMainDialog
 * JD-Core Version:    0.7.0.1
 */