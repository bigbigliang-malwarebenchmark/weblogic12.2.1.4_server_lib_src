package com.linar.java2com;

public class GenNetClassLoader
{
  private static GenNetStreamClassLoader a = null;
  private static String[] b = null;
  public static int c;
  
  public static synchronized void createClassLoader(String[] paramArrayOfString)
  {
    if (a != null)
    {
      a = null;
      b = null;
    }
    b = paramArrayOfString;
    a = new GenNetStreamClassLoader(paramArrayOfString);
  }
  
  public static synchronized Class getClassForName(String paramString)
    throws ClassNotFoundException
  {
    Class localClass = null;
    try
    {
      localClass = Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      localClass = a.loadClass(paramString);
    }
    return localClass;
  }
  
  public static synchronized String[] getLoadedPaths()
  {
    if (a != null) {
      return a.getLoadedPaths();
    }
    String[] arrayOfString = new String[1];
    arrayOfString[0] = "";
    return arrayOfString;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.java2com.GenNetClassLoader
 * JD-Core Version:    0.7.0.1
 */