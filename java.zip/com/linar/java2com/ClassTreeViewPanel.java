package com.linar.java2com;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeModel;

public class ClassTreeViewPanel
  extends JPanel
{
  private JTree a = null;
  private Vector b = new Vector();
  private Vector c = new Vector();
  
  public ClassTreeViewPanel()
  {
    ba localba = new ba(c("N\031l-`}\024y6`7"));
    localba.b = false;
    this.a = new JTree(localba);
    this.a.putClientProperty(c("G!;v#\031d0v^\001t2v"), c("L\033j2vi"));
    this.a.setCellRenderer(new v());
    setLayout(new BorderLayout());
    add(new JScrollPane(this.a), c("N\020c*v"));
    this.a.addMouseListener(new e(this));
  }
  
  public String[] getSelectedClasses()
  {
    Vector localVector = new Vector();
    a((ba)this.a.getModel().getRoot(), localVector, "");
    return (String[])localVector.toArray(new String[0]);
  }
  
  public String getSelectedClassesCommaSeparatedList()
  {
    int j = GenNetClassLoader.c;
    String[] arrayOfString = getSelectedClasses();
    String str = "";
    int i = 0;
    if (j != 0) {}
    do
    {
      do
      {
        str = str + arrayOfString[i];
        if (i != arrayOfString.length - 1) {
          str = str + ",";
        }
        i++;
      } while (i < arrayOfString.length);
    } while (j != 0);
    return str;
  }
  
  public void setClassesSelected(String paramString)
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ",");
    long l = new Date().getTime();
    if (GenNetClassLoader.c != 0) {}
    while (localStringTokenizer.hasMoreTokens()) {
      setClassSelected(localStringTokenizer.nextToken());
    }
  }
  
  public void setClassSelected(String paramString)
  {
    int k = GenNetClassLoader.c;
    String str1 = null;
    String str2 = null;
    if (paramString.lastIndexOf('.') == -1)
    {
      str1 = "";
      str2 = paramString;
    }
    else
    {
      str1 = paramString.substring(0, paramString.lastIndexOf('.'));
      str2 = paramString.substring(paramString.lastIndexOf('.') + 1, paramString.length());
    }
    ba localba1 = null;
    int i = 0;
    if (k != 0) {}
    while (i < this.c.size())
    {
      Hashtable localHashtable = (Hashtable)this.c.get(i);
      ba localba2 = (ba)localHashtable.get(str1);
      if (localba2 != null)
      {
        int j = 0;
        if (k != 0) {}
        while (j < localba2.getChildCount())
        {
          if (localba2.getChildAt(j).toString().equals(str2))
          {
            localba1 = (ba)localba2.getChildAt(j);
            break;
          }
          j++;
        }
      }
      i++;
    }
    if (localba1 != null) {
      localba1.setSelected(true);
    }
  }
  
  private void a(ba paramba, Vector paramVector, String paramString)
  {
    int j = GenNetClassLoader.c;
    if ((paramba.getChildCount() == 0) && (paramba.isSelected()))
    {
      paramVector.add(paramString + paramba.toString());
      if (j == 0) {}
    }
    else
    {
      int i = 0;
      if (j != 0) {}
      while (i < paramba.getChildCount())
      {
        if (paramba.b) {
          paramString = paramString + paramba.toString() + ".";
        }
        a((ba)paramba.getChildAt(i), paramVector, paramString);
        if (paramba.b) {
          paramString = paramString.substring(0, paramString.length() - paramba.toString().length() - 1);
        }
        i++;
      }
    }
  }
  
  public String[] getClasspath()
  {
    return (String[])this.b.toArray(new String[0]);
  }
  
  public String[] getSaneClasspath()
  {
    int j = GenNetClassLoader.c;
    Vector localVector = new Vector();
    int i = 0;
    if (j != 0) {}
    do
    {
      do
      {
        String str1 = getClasspath()[i];
        String str2 = "";
        if (str1.length() >= 6) {
          str2 = str1.substring(str1.length() - 6, str1.length());
        }
        if (!str2.equalsIgnoreCase(c("\001#4r"))) {
          localVector.add(str1);
        }
        i++;
      } while (i < getClasspath().length);
    } while (j != 0);
    return (String[])localVector.toArray(new String[0]);
  }
  
  public String getClasspathString()
  {
    int j = GenNetClassLoader.c;
    String str = "";
    int i = 0;
    if (j != 0) {}
    do
    {
      do
      {
        str = str + this.b.get(i) + ";";
        i++;
      } while (i < this.b.size());
    } while (j != 0);
    return str;
  }
  
  public String getSaneClasspathString()
  {
    int j = GenNetClassLoader.c;
    String str = "";
    int i = 0;
    if (j != 0) {}
    do
    {
      do
      {
        str = str + getSaneClasspath()[i] + ";";
        i++;
      } while (i < getSaneClasspath().length);
    } while (j != 0);
    return str;
  }
  
  private boolean a(String paramString)
  {
    int j = GenNetClassLoader.c;
    try
    {
      File localFile1 = new File(paramString);
      if (j != 0) {}
      while ((localFile1 = localFile1.getParentFile()) != null)
      {
        int i = 0;
        if (j != 0) {}
        while (i < this.b.size())
        {
          File localFile2 = new File((String)this.b.get(i));
          if (localFile2.getCanonicalPath().equals(localFile1.getCanonicalPath())) {
            return true;
          }
          i++;
        }
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return false;
  }
  
  private boolean b(String paramString)
  {
    int j = GenNetClassLoader.c;
    File localFile = new File(paramString);
    try
    {
      int i = 0;
      if (j != 0) {}
      do
      {
        do
        {
          if (localFile.getCanonicalPath().equals(new File((String)this.b.get(i)).getCanonicalPath())) {
            return true;
          }
          i++;
        } while (i < this.b.size());
      } while (j != 0);
    }
    catch (Exception localException) {}
    return false;
  }
  
  public void addJar(String paramString1, String paramString2)
  {
    if (b(paramString1)) {
      return;
    }
    try
    {
      ba localba = new ba(paramString2);
      localba.b = false;
      Hashtable localHashtable = new Hashtable();
      this.c.add(localHashtable);
      localHashtable.put("", localba);
      a(paramString1, localba, localHashtable);
      DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.a.getModel().getRoot();
      ((DefaultTreeModel)this.a.getModel()).insertNodeInto(localba, localDefaultMutableTreeNode, localDefaultMutableTreeNode.getChildCount());
      this.b.add(paramString1);
      this.a.expandRow(0);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  public void addPath(String paramString1, String paramString2)
  {
    if (b(paramString1)) {
      return;
    }
    ba localba = new ba(paramString2);
    localba.b = false;
    Hashtable localHashtable = new Hashtable();
    this.c.add(localHashtable);
    localHashtable.put("", localba);
    a(new File(paramString1), localba, null, localHashtable);
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.a.getModel().getRoot();
    ((DefaultTreeModel)this.a.getModel()).insertNodeInto(localba, localDefaultMutableTreeNode, localDefaultMutableTreeNode.getChildCount());
    this.b.add(paramString1);
    this.a.expandRow(0);
  }
  
  public void setClasspath(String paramString)
  {
    int i = GenNetClassLoader.c;
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ";");
    if (i != 0) {}
    while (localStringTokenizer.hasMoreTokens())
    {
      String str = localStringTokenizer.nextToken();
      if (str.toLowerCase().endsWith(c("#\037l,")))
      {
        addJar(str, str);
        if (i == 0) {}
      }
      else
      {
        addPath(str, str);
      }
    }
  }
  
  private void a(File paramFile, DefaultMutableTreeNode paramDefaultMutableTreeNode, String paramString, Hashtable paramHashtable)
  {
    int j = GenNetClassLoader.c;
    File[] arrayOfFile = paramFile.listFiles();
    Arrays.sort(arrayOfFile);
    int i = 0;
    if (j != 0) {}
    while (i < arrayOfFile.length)
    {
      Object localObject;
      if (arrayOfFile[i].isDirectory())
      {
        localObject = new ba(arrayOfFile[i].getName());
        String str = "";
        if (paramString == null)
        {
          str = ((DefaultMutableTreeNode)localObject).toString();
          if (j == 0) {}
        }
        else
        {
          str = paramString + "." + ((DefaultMutableTreeNode)localObject).toString();
        }
        a(arrayOfFile[i], (DefaultMutableTreeNode)localObject, str, paramHashtable);
        if (((DefaultMutableTreeNode)localObject).getChildCount() > 0)
        {
          paramDefaultMutableTreeNode.add((MutableTreeNode)localObject);
          if (paramHashtable.get(str) == null)
          {
            paramHashtable.put(str, localObject);
            if (j == 0) {}
          }
        }
      }
      else if ((arrayOfFile[i].getName().indexOf("$") == -1) && (arrayOfFile[i].getName().indexOf(c("#\026a?`~")) > -1))
      {
        localObject = arrayOfFile[i].getName().substring(0, arrayOfFile[i].getName().length() - new String(c("#\026a?`~")).length());
        paramDefaultMutableTreeNode.add(new ba(localObject));
      }
      i++;
    }
  }
  
  private void a(String paramString, DefaultMutableTreeNode paramDefaultMutableTreeNode, Hashtable paramHashtable)
    throws Exception
  {
    int j = GenNetClassLoader.c;
    JarFile localJarFile = new JarFile(paramString);
    Vector localVector = new Vector();
    Enumeration localEnumeration = localJarFile.entries();
    if (j != 0) {}
    do
    {
      do
      {
        localVector.add(localEnumeration.nextElement());
      } while (localEnumeration.hasMoreElements());
      Collections.sort(localVector, new i(this));
    } while (j != 0);
    int i = 0;
    if (j != 0) {}
    while (i < localVector.size())
    {
      JarEntry localJarEntry = (JarEntry)localVector.get(i);
      if ((!localJarEntry.isDirectory()) && (localJarEntry.getName().endsWith(c("#\026a?`~"))) && (localJarEntry.getName().indexOf("$") == -1))
      {
        Object localObject = (ba)paramDefaultMutableTreeNode;
        StringTokenizer localStringTokenizer = new StringTokenizer(localJarEntry.getName(), "/");
        String str1 = null;
        String str2 = null;
        while (localStringTokenizer.hasMoreElements())
        {
          str1 = localStringTokenizer.nextToken();
          while (str1.indexOf('.') == -1) {
            if (j == 0)
            {
              str2 = str2 + "." + str1;
              ba localba1 = null;
              localba1 = (ba)paramHashtable.get(str2);
              if (localba1 == null)
              {
                ba localba2 = new ba(str1);
                ((DefaultMutableTreeNode)localObject).add(localba2);
                localObject = localba2;
                paramHashtable.put(str2, localba2);
                if (j == 0) {
                  break;
                }
              }
              else
              {
                localObject = localba1;
              }
            }
          }
        }
        ((DefaultMutableTreeNode)localObject).add(new ba(str1.substring(0, str1.indexOf('.'))));
      }
      i++;
    }
  }
  
  static JTree a(ClassTreeViewPanel paramClassTreeViewPanel)
  {
    return paramClassTreeViewPanel.a;
  }
  
  private static String c(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      117[13] = ((char)(0x5E ^ 0x13));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.java2com.ClassTreeViewPanel
 * JD-Core Version:    0.7.0.1
 */