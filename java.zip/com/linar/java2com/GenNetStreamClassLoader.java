package com.linar.java2com;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class GenNetStreamClassLoader
  extends ClassLoader
{
  private String[] a;
  private static final int b = 8192;
  private Vector c = new Vector();
  private boolean d = true;
  private Vector e = new Vector();
  private Vector f = new Vector();
  private boolean g = false;
  private ClassLoader h = null;
  private Hashtable i = new Hashtable();
  private ClassLoader j = null;
  private boolean k = false;
  private static Method l = null;
  private static Method m = null;
  static Class n;
  static Class o;
  static Class p;
  static Class q;
  static Class r;
  
  public String[] getLoadedPaths()
  {
    int i2 = GenNetClassLoader.c;
    String[] arrayOfString = new String[this.a.length];
    int i1 = 0;
    if (i2 != 0) {}
    do
    {
      do
      {
        arrayOfString[i1] = this.a[i1];
        i1++;
      } while (i1 < this.a.length);
    } while (i2 != 0);
    return arrayOfString;
  }
  
  public GenNetStreamClassLoader(String[] paramArrayOfString)
  {
    this.a = paramArrayOfString;
    this.h = (r == null ? (GenNetStreamClassLoader.r = g(h("a\037Jk,k\036F7nh\021Q$ra\037Jk\007g\036i 4Q\004U !o3K$3q<H$$g\002"))) : r).getClassLoader();
    if (paramArrayOfString != null)
    {
      int i1 = 0;
      if (GenNetClassLoader.c != 0) {}
      while (i1 < paramArrayOfString.length)
      {
        try
        {
          addPathElement(paramArrayOfString[i1]);
        }
        catch (Exception localException) {}
        i1++;
      }
    }
  }
  
  public void setThreadContextLoader()
  {
    if (this.k) {
      throw new RuntimeException(h("A\037I1%z\004\007)/c\024B7`j\021Te.m\004\007'%g\036\0077%q\025S"));
    }
    if (m.isContextLoaderAvailable())
    {
      this.j = m.getContextClassLoader();
      GenNetStreamClassLoader localGenNetStreamClassLoader = this;
      m.setContextClassLoader(localGenNetStreamClassLoader);
      this.k = true;
    }
  }
  
  public void resetThreadContextLoader()
  {
    if ((m.isContextLoaderAvailable()) && (this.k))
    {
      m.setContextClassLoader(this.j);
      this.j = null;
      this.k = false;
    }
  }
  
  public void addPathElement(String paramString)
  {
    this.c.addElement(new File(paramString));
  }
  
  public String getClasspath()
  {
    int i2 = GenNetClassLoader.c;
    StringBuffer localStringBuffer = new StringBuffer();
    int i1 = 1;
    Enumeration localEnumeration = this.c.elements();
    if (i2 != 0) {}
    do
    {
      do
      {
        if (i1 == 0)
        {
          localStringBuffer.append(System.getProperty(h("r\021S-nq\025W$2c\004H7")));
          if (i2 == 0) {}
        }
        else
        {
          i1 = 0;
        }
        localStringBuffer.append(((File)localEnumeration.nextElement()).getAbsolutePath());
      } while (localEnumeration.hasMoreElements());
    } while (i2 != 0);
    return localStringBuffer.toString();
  }
  
  public void setIsolated(boolean paramBoolean)
  {
    this.g = paramBoolean;
  }
  
  public static void initializeClass(Class paramClass)
  {
    Constructor[] arrayOfConstructor = paramClass.getDeclaredConstructors();
    if ((arrayOfConstructor != null) && (arrayOfConstructor.length > 0) && (arrayOfConstructor[0] != null))
    {
      String[] arrayOfString = new String[256];
      try
      {
        arrayOfConstructor[0].newInstance(arrayOfString);
      }
      catch (Throwable localThrowable) {}
    }
  }
  
  public void addSystemPackageRoot(String paramString)
  {
    this.e.addElement(paramString + (paramString.endsWith(".") ? "" : "."));
  }
  
  public void addLoaderPackageRoot(String paramString)
  {
    this.f.addElement(paramString + (paramString.endsWith(".") ? "" : "."));
  }
  
  public Class forceLoadClass(String paramString)
    throws ClassNotFoundException
  {
    Class localClass = findLoadedClass(paramString);
    if (localClass == null) {
      localClass = findClass(paramString);
    }
    return localClass;
  }
  
  public Class forceLoadSystemClass(String paramString)
    throws ClassNotFoundException
  {
    Class localClass = findLoadedClass(paramString);
    if (localClass == null) {
      localClass = f(paramString);
    }
    return localClass;
  }
  
  public InputStream getResourceAsStream(String paramString)
  {
    InputStream localInputStream = null;
    if (c(paramString))
    {
      localInputStream = b(paramString);
      if (localInputStream == null)
      {
        localInputStream = a(paramString);
        if (localInputStream == null) {}
      }
    }
    else
    {
      localInputStream = a(paramString);
      if (localInputStream == null)
      {
        localInputStream = b(paramString);
        if (localInputStream == null) {}
      }
    }
    if (localInputStream == null) {}
    return localInputStream;
  }
  
  private InputStream a(String paramString)
  {
    InputStream localInputStream = null;
    Enumeration localEnumeration = this.c.elements();
    while ((localEnumeration.hasMoreElements()) && ((GenNetClassLoader.c == 0) && (localInputStream == null)))
    {
      File localFile = (File)localEnumeration.nextElement();
      localInputStream = a(localFile, paramString);
    }
    return localInputStream;
  }
  
  private InputStream b(String paramString)
  {
    if (this.h == null) {
      return ClassLoader.getSystemResourceAsStream(paramString);
    }
    return this.h.getResourceAsStream(paramString);
  }
  
  private InputStream a(File paramFile, String paramString)
  {
    try
    {
      if (!paramFile.exists()) {
        return null;
      }
      Object localObject;
      if (paramFile.isDirectory())
      {
        localObject = new File(paramFile, paramString);
        if (((File)localObject).exists()) {
          return new FileInputStream((File)localObject);
        }
      }
      else
      {
        localObject = (ZipFile)this.i.get(paramFile);
        if (localObject == null)
        {
          localObject = new ZipFile(paramFile);
          this.i.put(paramFile, localObject);
        }
        ZipEntry localZipEntry = ((ZipFile)localObject).getEntry(paramString);
        if (localZipEntry != null) {
          return ((ZipFile)localObject).getInputStream(localZipEntry);
        }
      }
    }
    catch (Exception localException) {}
    return null;
  }
  
  private boolean c(String paramString)
  {
    int i1 = GenNetClassLoader.c;
    boolean bool = this.d;
    Enumeration localEnumeration = this.e.elements();
    if (i1 != 0) {}
    while (localEnumeration.hasMoreElements())
    {
      localObject = (String)localEnumeration.nextElement();
      while (paramString.startsWith((String)localObject))
      {
        bool = true;
        if (i1 == 0) {
          if (i1 == 0) {
            break label64;
          }
        }
      }
    }
    label64:
    Object localObject = this.f.elements();
    if (i1 != 0) {}
    while (((Enumeration)localObject).hasMoreElements())
    {
      String str = (String)((Enumeration)localObject).nextElement();
      while (paramString.startsWith(str))
      {
        bool = false;
        if (i1 == 0) {
          if (i1 == 0) {
            return bool;
          }
        }
      }
    }
    return bool;
  }
  
  public URL getResource(String paramString)
  {
    int i1 = GenNetClassLoader.c;
    URL localURL = null;
    if (c(paramString)) {
      localURL = this.h == null ? super.getResource(paramString) : this.h.getResource(paramString);
    }
    if (localURL == null)
    {
      Enumeration localEnumeration = this.c.elements();
      if (i1 != 0) {}
      while ((localEnumeration.hasMoreElements()) && ((i1 == 0) && (localURL == null)))
      {
        File localFile = (File)localEnumeration.nextElement();
        localURL = b(localFile, paramString);
        if (localURL == null) {}
      }
    }
    if (localURL == null) {
      if (!c(paramString))
      {
        localURL = this.h == null ? super.getResource(paramString) : this.h.getResource(paramString);
        if (localURL == null) {}
      }
    }
    if (localURL == null) {}
    return localURL;
  }
  
  protected Enumeration findResources(String paramString)
    throws IOException
  {
    return new j(this, paramString);
  }
  
  private URL b(File paramFile, String paramString)
  {
    try
    {
      if (!paramFile.exists()) {
        return null;
      }
      if (paramFile.isDirectory())
      {
        localObject = new File(paramFile, paramString);
        if (!((File)localObject).exists()) {
          break label167;
        }
        try
        {
          return new URL(h("d\031K z") + ((File)localObject).toString());
        }
        catch (MalformedURLException localMalformedURLException1)
        {
          return null;
        }
      }
      Object localObject = (ZipFile)this.i.get(paramFile);
      if (localObject == null)
      {
        localObject = new ZipFile(paramFile);
        this.i.put(paramFile, localObject);
      }
      ZipEntry localZipEntry = ((ZipFile)localObject).getEntry(paramString);
      if (localZipEntry != null) {
        try
        {
          return new URL(h("h\021U&k\034B") + paramFile.toString() + h("#_") + localZipEntry);
        }
        catch (MalformedURLException localMalformedURLException2)
        {
          return null;
        }
      }
    }
    catch (Exception localException)
    {
      label167:
      localException.printStackTrace();
    }
    return null;
  }
  
  protected synchronized Class loadClass(String paramString, boolean paramBoolean)
    throws ClassNotFoundException
  {
    Class localClass = findLoadedClass(paramString);
    if (localClass != null) {
      return localClass;
    }
    if (c(paramString)) {
      try
      {
        localClass = f(paramString);
      }
      catch (ClassNotFoundException localClassNotFoundException1)
      {
        localClass = findClass(paramString);
        if (GenNetClassLoader.c == 0) {
          break label70;
        }
      }
    } else {
      try
      {
        localClass = findClass(paramString);
      }
      catch (ClassNotFoundException localClassNotFoundException2)
      {
        if (this.g) {
          throw localClassNotFoundException2;
        }
        localClass = f(paramString);
      }
    }
    label70:
    if (paramBoolean) {
      resolveClass(localClass);
    }
    return localClass;
  }
  
  private String d(String paramString)
  {
    return paramString.replace('.', '/') + h(",\023K$3q");
  }
  
  private Class a(InputStream paramInputStream, String paramString)
    throws IOException, SecurityException
  {
    int i2 = GenNetClassLoader.c;
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i1 = -1;
    byte[] arrayOfByte1 = new byte[8192];
    if (i2 != 0) {}
    do
    {
      do
      {
        localByteArrayOutputStream.write(arrayOfByte1, 0, i1);
      } while ((i1 = paramInputStream.read(arrayOfByte1, 0, 8192)) != -1);
    } while (i2 != 0);
    byte[] arrayOfByte2 = localByteArrayOutputStream.toByteArray();
    if (m != null) {
      try
      {
        Object localObject1 = l.invoke(getClass(), new Object[0]);
        localObject2 = new Object[] { paramString, arrayOfByte2, new Integer(0), new Integer(arrayOfByte2.length), localObject1 };
        return (Class)m.invoke(this, (Object[])localObject2);
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        Object localObject2 = localInvocationTargetException.getTargetException();
        if ((localObject2 instanceof ClassFormatError)) {
          throw ((ClassFormatError)localObject2);
        }
        if ((localObject2 instanceof NoClassDefFoundError)) {
          throw ((NoClassDefFoundError)localObject2);
        }
        if ((localObject2 instanceof SecurityException)) {
          throw ((SecurityException)localObject2);
        }
        throw new IOException(((Throwable)localObject2).toString());
      }
      catch (Exception localException)
      {
        throw new IOException(localException.toString());
      }
    }
    return defineClass(paramString, arrayOfByte2, 0, arrayOfByte2.length);
  }
  
  public Class findClass(String paramString)
    throws ClassNotFoundException
  {
    return e(paramString);
  }
  
  private Class e(String paramString)
    throws ClassNotFoundException
  {
    int i1 = GenNetClassLoader.c;
    InputStream localInputStream = null;
    String str = d(paramString);
    try
    {
      Enumeration localEnumeration = this.c.elements();
      do
      {
        do
        {
          File localFile = (File)localEnumeration.nextElement();
          try
          {
            localInputStream = a(localFile, str);
            if (localInputStream != null)
            {
              Class localClass = a(localInputStream, paramString);
              return localClass;
            }
          }
          catch (SecurityException localSecurityException)
          {
            throw localSecurityException;
          }
          catch (IOException localIOException1) {}
        } while (localEnumeration.hasMoreElements());
      } while ((i1 != 0) || (i1 != 0));
      throw new ClassNotFoundException(paramString);
    }
    finally
    {
      try
      {
        if (localInputStream != null) {
          localInputStream.close();
        }
      }
      catch (IOException localIOException2) {}
    }
  }
  
  private Class f(String paramString)
    throws ClassNotFoundException
  {
    if (this.h == null) {
      return findSystemClass(paramString);
    }
    return this.h.loadClass(paramString);
  }
  
  public synchronized void cleanup()
  {
    int i1 = GenNetClassLoader.c;
    Enumeration localEnumeration = this.i.elements();
    if (i1 != 0) {}
    do
    {
      do
      {
        do
        {
          ZipFile localZipFile = (ZipFile)localEnumeration.nextElement();
          try
          {
            localZipFile.close();
          }
          catch (IOException localIOException) {}
        } while (localEnumeration.hasMoreElements());
      } while (i1 != 0);
      this.i = new Hashtable();
    } while (i1 != 0);
  }
  
  static Vector a(GenNetStreamClassLoader paramGenNetStreamClassLoader)
  {
    return paramGenNetStreamClassLoader.c;
  }
  
  static URL a(GenNetStreamClassLoader paramGenNetStreamClassLoader, File paramFile, String paramString)
  {
    return paramGenNetStreamClassLoader.b(paramFile, paramString);
  }
  
  static Class g(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  static
  {
    try
    {
      l = (n == null ? (GenNetStreamClassLoader.n = g(h("h\021Q$nn\021I\"nA\034F63"))) : n).getMethod(h("e\025S\0252m\004B&4k\037I\001/o\021N+"), new Class[0]);
      Class localClass = Class.forName(h("h\021Q$nq\025D02k\004^k\020p\037S #v\031H+\004m\035F,."));
      Class[] arrayOfClass = { o == null ? (GenNetStreamClassLoader.o = g(h("h\021Q$nn\021I\"nQ\004U,.e"))) : o, p == null ? (GenNetStreamClassLoader.p = g(h("Y2"))) : p, Integer.TYPE, Integer.TYPE, localClass };
      m = (q == null ? (GenNetStreamClassLoader.q = g(h("h\021Q$nn\021I\"nA\034F63N\037F!%p"))) : q).getDeclaredMethod(h("f\025A,.g3K$3q"), arrayOfClass);
    }
    catch (Exception localException) {}
  }
  
  private static String h(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      112[39] = ((char)(0x45 ^ 0x40));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.java2com.GenNetStreamClassLoader
 * JD-Core Version:    0.7.0.1
 */