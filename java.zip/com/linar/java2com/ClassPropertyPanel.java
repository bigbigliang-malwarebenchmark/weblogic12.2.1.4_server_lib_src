package com.linar.java2com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

public class ClassPropertyPanel
  extends JPanel
  implements MouseListener, TreeCellRenderer
{
  JTree a = null;
  DefaultTreeModel b = null;
  w c;
  Hashtable d;
  JLabel e = null;
  Icon f = new ImageIcon(getClass().getResource(a("")));
  Icon g = new ImageIcon(getClass().getResource(a("")));
  DefaultTreeCellRenderer h = new DefaultTreeCellRenderer();
  
  public ClassPropertyPanel(Hashtable paramHashtable, JLabel paramJLabel)
  {
    this.e = paramJLabel;
    this.d = new Hashtable(paramHashtable);
    setLayout(new BorderLayout());
    this.a = new JTree(new z(3, a(")\\\022"), null));
    this.a.setCellRenderer(this);
    this.a.setShowsRootHandles(true);
    this.b = ((DefaultTreeModel)this.a.getModel());
    this.a.setRootVisible(true);
    this.a.setRootVisible(false);
    this.a.addMouseListener(this);
    this.a.putClientProperty(a("\021gb\003Vu_y\bV\bGi\nV"), a("\032]w\nV?"));
    this.c = new w(this.d, paramJLabel);
    JScrollPane localJScrollPane = new JScrollPane(this.a);
    localJScrollPane.setBackground(Color.white);
    localJScrollPane.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
    JSplitPane localJSplitPane = new JSplitPane(1, localJScrollPane, this.c);
    localJSplitPane.setBorder(null);
    add(localJSplitPane, a("\030V~\022V)"));
    localJSplitPane.setDividerLocation(localJSplitPane.getPreferredSize().width * 2 / 5);
    Enumeration localEnumeration = this.d.keys();
    Vector localVector = new Vector();
    if (i != 0) {}
    do
    {
      while (localEnumeration.hasMoreElements())
      {
        localObject = (String)localEnumeration.nextElement();
        do
        {
          do
          {
            if (((String)localObject).startsWith(a("8_q\025@{"))) {
              break;
            }
          } while (i != 0);
          if (((String)localObject).indexOf('.') != -1) {
            break;
          }
        } while (i != 0);
        localVector.add(localObject);
      }
      Object localObject = new z(2, a("\034_\004R7\023^\007^>\023]\007C+Z~\001@"), localVector);
      this.b.insertNodeInto((MutableTreeNode)localObject, (MutableTreeNode)this.b.getRoot(), 0);
      this.a.setSelectionPath(new TreePath(((DefaultMutableTreeNode)localObject).getPath()));
      this.c.setCurrentClassNode((z)localObject);
    } while (i != 0);
  }
  
  public void addClass(k paramk)
  {
    int j = GenNetClassLoader.c;
    Object localObject = null;
    z localz1 = (z)this.a.getModel().getRoot();
    String str1 = paramk.M.getName();
    if (str1.indexOf('.') == -1)
    {
      str2 = "";
      if (j == 0) {}
    }
    else
    {
      str2 = str1.substring(0, str1.lastIndexOf('.'));
      str1 = str1.substring(str1.lastIndexOf('.') + 1, str1.length());
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(str2, ".");
    break label212;
    localObject = localz1;
    String str2 = localStringTokenizer.nextToken();
    label212:
    do
    {
      int i = 0;
      if (j != 0) {}
      do
      {
        do
        {
          do
          {
            if (localObject.getChildAt(i).toString().equals(str2))
            {
              localObject = localz1;
              localz1 = (z)localz1.getChildAt(i);
              if (j == 0) {
                break;
              }
            }
            i++;
          } while (i < localObject.getChildCount());
        } while (j != 0);
        if (localz1 != localObject) {
          break;
        }
        localObject = localz1;
        localz1 = new z(0, str2, null);
      } while (j != 0);
      this.b.insertNodeInto(localz1, localObject, localObject.getChildCount());
      if (localStringTokenizer.hasMoreTokens()) {
        break;
      }
      z localz2 = new z(paramk);
      this.b.insertNodeInto(localz2, localz1, localz1.getChildCount());
      this.a.setRootVisible(true);
      this.a.setRootVisible(false);
      this.a.setShowsRootHandles(true);
    } while (j != 0);
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    TreePath localTreePath = this.a.getPathForLocation(paramMouseEvent.getX(), paramMouseEvent.getY());
    if (localTreePath != null)
    {
      z localz = (z)localTreePath.getLastPathComponent();
      if ((localz.isClass()) || (localz.isGlobalMapping())) {
        this.c.setCurrentClassNode((z)localTreePath.getLastPathComponent());
      }
    }
  }
  
  public Hashtable getNameMappings()
  {
    return this.d;
  }
  
  public void mousePressed(MouseEvent paramMouseEvent) {}
  
  public void mouseReleased(MouseEvent paramMouseEvent) {}
  
  public void mouseEntered(MouseEvent paramMouseEvent) {}
  
  public void mouseExited(MouseEvent paramMouseEvent) {}
  
  public Component getTreeCellRendererComponent(JTree paramJTree, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt, boolean paramBoolean4)
  {
    int i = GenNetClassLoader.c;
    Component localComponent = this.h.getTreeCellRendererComponent(paramJTree, paramObject, paramBoolean1, paramBoolean2, paramBoolean3, paramInt, paramBoolean4);
    z localz = (z)paramObject;
    if (localz.isGlobalMapping())
    {
      this.h.setIcon(this.f);
      if (i == 0) {}
    }
    else if (localz.isClass())
    {
      this.h.setIcon(this.g);
      if (i == 0) {}
    }
    else if (paramBoolean3)
    {
      this.h.setIcon(this.g);
      if (i == 0) {}
    }
    else if (paramBoolean2)
    {
      this.h.setIcon(UIManager.getIcon(a("\017Au\003\0354Cu\bz8\\~")));
      if (i == 0) {}
    }
    else
    {
      this.h.setIcon(UIManager.getIcon(a("\017Au\003\0358_\025V?zs\t]")));
    }
    return localComponent;
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      51[16] = ((char)(0x66 ^ 0x33));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.java2com.ClassPropertyPanel
 * JD-Core Version:    0.7.0.1
 */