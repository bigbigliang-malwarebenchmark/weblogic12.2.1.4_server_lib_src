package com.linar.jintegra;

public abstract interface ObjectExportChecker
{
  public abstract boolean exportAllowed(Object paramObject);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.ObjectExportChecker
 * JD-Core Version:    0.7.0.1
 */