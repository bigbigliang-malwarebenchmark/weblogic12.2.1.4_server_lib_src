package com.linar.jintegra;

import com.linar.spi.Executor;
import com.linar.spi.License;
import com.linar.spi.Manager;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.AccessController;
import java.util.Hashtable;

public class Dispatch
  implements Externalizable
{
  public static final int DISPATCH_METHOD = 1;
  public static final int DISPATCH_PROPERTYGET = 2;
  public static final int DISPATCH_PROPERTYPUT = 4;
  public static final int DISPATCH_PROPERTYPUTREF = 8;
  private static final boolean a = false;
  private static final int b = 32;
  private static final String c = "m|\006e}r~\037z";
  private static final String d = "0!R*!4!B?";
  static volatile int e;
  private StdObjRef f = null;
  private i g;
  private Hashtable h = new Hashtable();
  private boolean i = false;
  private Uuid j;
  private InterfaceDesc k;
  private Param[][] l = new Param[32][];
  static boolean m = true;
  static String n = b("");
  static boolean o = false;
  static boolean p = false;
  static Object q = new Object();
  private static boolean r = false;
  private static boolean s = true;
  private static Executor t;
  private AuthInfo u;
  private String v = null;
  private String w = null;
  private String x = null;
  private boolean y = false;
  private byte[] z;
  private byte[] A;
  Hashtable B = new Hashtable();
  private static long C = 0L;
  static Class D;
  static Class E;
  static Class F;
  static Class G;
  public static int H;
  
  public StdObjRef getObjRef()
  {
    return this.f;
  }
  
  Uuid a()
  {
    return this.j;
  }
  
  public String toString()
  {
    return cj.translate(cj.WRAPPER_AROUND, getClass().getName(), this.f);
  }
  
  protected Dispatch() {}
  
  private void b()
    throws IOException
  {
    if (!this.f.i().equals(this.j))
    {
      StdObjRef localStdObjRef = this.f;
      this.f = this.f.a(this.j, this.u);
      if (this.f == null) {
        throw new ClassCastException(cj.translate(cj.COM_INTERFACE_NOT_SUPPORTED, localStdObjRef, this.j));
      }
    }
  }
  
  static boolean c()
  {
    isNativeMode();
    return NativeInitInproc.a;
  }
  
  public static void setNativeMode()
  {
    a(true);
  }
  
  public static boolean isNativeMode()
  {
    return a(false);
  }
  
  static boolean a(boolean paramBoolean)
  {
    if (p)
    {
      if ((paramBoolean) && (!o)) {
        throw new RuntimeException(cj.ATTEMPT_TO_SET_NATIVE_MODE);
      }
      return o;
    }
    synchronized (q)
    {
      if (p)
      {
        boolean bool = o;
        return bool;
      }
      if (NativeInitInproc.a)
      {
        o = true;
        Log.log(3, b("\022/E\";9n\\$)9nT%,>\"T/mt'_;?3-\030"));
        if (H == 0) {}
      }
      else
      {
        try
        {
          if ((paramBoolean) || (bi.A()))
          {
            NativeObjRef.q();
            o = true;
            Log.log(3, b("\022/E\";9n\\$)9nT%,>\"T/"));
          }
        }
        catch (Exception localException) {}
      }
      p = true;
    }
    return o;
  }
  
  static void d()
  {
    if (!m) {
      return;
    }
    License localLicense = (License)Manager.get(D == null ? (Dispatch.D = a(b("?!\\e!5 P9c6'_?(;<Pe\t5=A*9?&"))) : D, E == null ? (Dispatch.E = a(b("?!\\e!5 P9c/>Xe\0015-T%>9"))) : E);
    if (localLicense == null) {
      throw new RuntimeException(cj.NO_SPI_LICENSE);
    }
    try
    {
      StringBuffer localStringBuffer1 = new StringBuffer();
      StringBuffer localStringBuffer2 = new StringBuffer();
      localLicense.check(true, localStringBuffer1, localStringBuffer2);
      m = false;
      n = localStringBuffer2.toString();
    }
    catch (Exception localException)
    {
      if ((localException instanceof RuntimeException)) {
        throw new RuntimeException(localException.getMessage());
      }
    }
  }
  
  static boolean e()
  {
    if (r) {
      return s;
    }
    s = !bi.o();
    if (!s)
    {
      Log.log(3, b(""));
      if (H == 0) {}
    }
    else
    {
      s = t.isThreadingAvailable();
      if (!s) {
        Log.log(3, b(""));
      }
    }
    r = true;
    return s;
  }
  
  static Executor f()
  {
    return t;
  }
  
  private static void g()
  {
    if (!bi.D()) {
      return;
    }
    try
    {
      Class[] arrayOfClass = { F == null ? (Dispatch.F = a(b("6/G*c0/_,c\b&C.,8"))) : F };
      Method localMethod = (G == null ? (Dispatch.G = a(b("6/G*c0/_,c\016;_?$1+"))) : G).getMethod(b("=*U\030%):U$:2\006^$&"), arrayOfClass);
      cm localcm = new cm();
      localcm.setName(b("\026cx%99)C*m.+].,/+p'!|=Y>98!F%m4!^ m(&C.,8"));
      localMethod.invoke(Runtime.getRuntime(), new Object[] { localcm });
      Log.b(b("\026cx%99)C*m\016+].,/+p'!|=Y>98!F%m4!^ m5 B?,0\"T/"));
    }
    catch (Throwable localThrowable)
    {
      localThrowable.printStackTrace();
    }
  }
  
  protected Dispatch(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
    throws UnknownHostException, IOException
  {
    this.y = paramBoolean;
    if (paramBoolean)
    {
      this.w = paramString1;
      this.x = paramString2;
      this.v = paramString3;
      if (H == 0) {}
    }
    else
    {
      createDispatch(paramString1, paramString2, paramString3, this.u);
    }
  }
  
  public Dispatch(String paramString1, String paramString2)
    throws UnknownHostException, IOException
  {
    createDispatch(paramString1, k.IID_IDISPATCH.toString(), paramString2, null);
  }
  
  public Dispatch(String paramString1, String paramString2, String paramString3, AuthInfo paramAuthInfo)
    throws UnknownHostException, IOException
  {
    createDispatch(paramString1, paramString2, paramString3, paramAuthInfo);
  }
  
  protected void createDispatch(String paramString1, String paramString2, String paramString3, AuthInfo paramAuthInfo)
    throws UnknownHostException, IOException
  {
    this.u = paramAuthInfo;
    this.j = new Uuid(paramString2);
    Uuid localUuid = new Uuid(paramString1);
    this.k = InterfaceDesc.a(this.j);
    if (this.k == null) {
      if (((!this.j.equals(k.IID_IDISPATCH) ? 1 : 0) & (!this.j.equals(k.IID_IUNKNOWN) ? 1 : 0)) != 0) {
        throw new RuntimeException(cj.translate(cj.UNKNOWN_COM_INTERFACE, this.j, getClass()));
      }
    }
    if (isNativeMode())
    {
      Log.log(3, b("\037<T*95 Vk,|\r~\006m3,[..(nD8$2)\021%,('G.m?!U.c|nR'>5*\021vm") + paramString1 + b("pnX\")|s\021") + paramString2);
      localObject = InetAddress.getByName(paramString3);
      InetAddress localInetAddress = InetAddress.getLocalHost();
      if ((paramString3.equals(b("m|\006e}r~\037z"))) || (((InetAddress)localObject).equals(localInetAddress))) {
        paramString3 = b("0!R*!4!B?");
      }
      this.f = new NativeObjRef(paramString1, paramString2, paramString3, paramAuthInfo);
      return;
    }
    Object localObject = bm.a(paramString3);
    try
    {
      this.f = ((bm)localObject).a(localUuid, this.j, paramAuthInfo);
    }
    catch (AutomationException localAutomationException1)
    {
      if (localAutomationException1.getCode() == 2147500034L)
      {
        Log.a(cj.translate(cj.INTERFACE_NOT_SUPPORTED, paramString1, paramString2));
        this.j = k.IID_IDISPATCH;
        try
        {
          this.f = ((bm)localObject).a(localUuid, this.j, paramAuthInfo);
          this.i = true;
        }
        catch (AutomationException localAutomationException2)
        {
          Object[] arrayOfObject2 = { paramString1, paramString2, localAutomationException2 };
          Log.a(cj.translate(cj.ERROR_ACTIVATING, arrayOfObject2));
          throw localAutomationException2;
        }
      }
      else
      {
        Object[] arrayOfObject1 = { paramString1, paramString2, localAutomationException1 };
        Log.a(cj.translate(cj.ERROR_ACTIVATING, arrayOfObject1));
        throw localAutomationException1;
      }
    }
  }
  
  public void writeExternal(ObjectOutput paramObjectOutput)
    throws IOException
  {
    Log.log(3, this + b("|,T\"#;nT399<_*!54T/"));
    paramObjectOutput.writeObject(f.k);
    paramObjectOutput.writeBoolean(this.y);
    if (this.y)
    {
      paramObjectOutput.writeObject(this.v);
      paramObjectOutput.writeObject(this.w);
      paramObjectOutput.writeObject(this.x);
      if (H == 0) {}
    }
    else
    {
      paramObjectOutput.writeObject(this.f);
    }
  }
  
  public void readExternal(ObjectInput paramObjectInput)
    throws IOException, ClassNotFoundException
  {
    String str = (String)paramObjectInput.readObject();
    if (!str.equals(f.k)) {
      throw new IOException(cj.translate(cj.INCOMPATIBLE_VERSIONS_FOR_DISPATCH, f.k, str));
    }
    this.y = paramObjectInput.readBoolean();
    if (this.y)
    {
      this.v = ((String)paramObjectInput.readObject());
      this.w = ((String)paramObjectInput.readObject());
      this.x = ((String)paramObjectInput.readObject());
      try
      {
        createDispatch(this.w, this.x, this.v, null);
      }
      catch (UnknownHostException localUnknownHostException)
      {
        Log.a(cj.translate(cj.HOST_UNRECOGNIZED, this.v));
        if (H == 0) {
          return;
        }
      }
    }
    else
    {
      this.f = ((StdObjRef)paramObjectInput.readObject());
      this.j = this.f.i();
    }
  }
  
  public Dispatch(Object paramObject)
    throws IOException
  {
    this(paramObject, k.IID_IDISPATCH.toString());
  }
  
  public Dispatch(Object paramObject, String paramString)
    throws IOException
  {
    if (paramObject == null) {
      throw new IllegalArgumentException(cj.translate(cj.ARGUMENT_NOT_COM_OBJECT, paramObject));
    }
    this.j = new Uuid(paramString);
    if ((paramObject instanceof StdObjRef))
    {
      this.f = ((StdObjRef)paramObject);
      if (i1 == 0) {}
    }
    else if ((paramObject instanceof Dispatch))
    {
      this.f = ((Dispatch)paramObject).f;
      if (i1 == 0) {}
    }
    else if ((paramObject instanceof RemoteObjRef))
    {
      this.f = ((RemoteObjRef)paramObject).getJintegraDispatch().f;
      if (i1 == 0) {}
    }
    else
    {
      throw new IllegalArgumentException(cj.translate(cj.ARGUMENT_NOT_REMOTE_OBJECT, paramObject));
    }
    this.k = InterfaceDesc.a(this.j);
    if (bi.L()) {
      b();
    }
  }
  
  public static boolean isObjRef(Object paramObject)
  {
    if ((paramObject instanceof StdObjRef)) {
      return true;
    }
    if ((paramObject instanceof Dispatch)) {
      return true;
    }
    return (paramObject instanceof RemoteObjRef);
  }
  
  public void queryInterface()
    throws AutomationException, IOException
  {
    b();
  }
  
  public Object getDefaultProperty()
    throws NoSuchFieldException, IOException, AutomationException
  {
    Variant[] arrayOfVariant = new Variant[0];
    return invoke(b("8+W*80:a9\",+C?4"), 0, 2L, arrayOfVariant).getVARIANT();
  }
  
  protected Variant invoke(String paramString, int paramInt, long paramLong, Variant[] paramArrayOfVariant)
    throws AutomationException, IOException
  {
    b();
    Invoke localInvoke = new Invoke(paramInt, paramLong, paramArrayOfVariant);
    this.f.a(localInvoke, this.j, this.u);
    C = localInvoke.sCode;
    localInvoke.g();
    return localInvoke.getResult();
  }
  
  public void addListener(String paramString, Object paramObject1, Object paramObject2)
    throws IOException
  {
    if (HttpTunnel.a() != null) {
      throw new RuntimeException(cj.CANNOT_SUBSCRIBE_TO_EVENTS);
    }
    synchronized (this)
    {
      if (this.g == null) {
        this.g = new i(this.f, this.u);
      }
    }
    Uuid localUuid = new Uuid(paramString);
    Log.log(3, b("\020!^ $2)\021-\".nR$#2+R?$3 \021;\"5 Ek+3<\021") + localUuid);
    h localh = this.g.a(localUuid, this.u);
    Long localLong = localh.a(paramObject1, paramObject2, this.u);
    this.h.put(paramObject1, localLong);
  }
  
  public long cookieForListener(Object paramObject)
  {
    Long localLong = (Long)this.h.get(paramObject);
    return localLong == null ? 0L : localLong.longValue();
  }
  
  public void removeListener(String paramString, Object paramObject)
    throws IOException
  {
    if (HttpTunnel.a() != null) {
      throw new RuntimeException(cj.CANNOT_SUBSCRIBE_TO_EVENTS);
    }
    if (this.g == null) {
      throw new IOException(cj.CONNECTION_POINT_CONTAINER_NOT_DEFINED);
    }
    Uuid localUuid = new Uuid(paramString);
    h localh = this.g.a(localUuid, this.u);
    Long localLong = (Long)this.h.remove(paramObject);
    if (localLong == null) {
      throw new IOException(cj.COOKIE_NOT_DEFINED);
    }
    localh.a(localLong, paramObject, this.u);
  }
  
  void h()
  {
    if ((this.f != null) && (this.f.i().equals(this.j))) {
      this.f.release(this.u);
    }
    if (this.g != null)
    {
      this.g.release(this.u);
      this.g = null;
    }
  }
  
  protected int getDispatchIdOfName(String paramString)
    throws NoSuchFieldException, AutomationException, IOException
  {
    Object localObject = this.B.get(paramString);
    if (localObject != null)
    {
      Log.log(3, b("\033!Ek\004\030'B;,(-Yk#=#Tk93nx\017m:<^&m?/R#(fn") + paramString + "=" + localObject);
      return ((Integer)localObject).intValue();
    }
    b();
    GetIdsOfNames localGetIdsOfNames = new GetIdsOfNames(paramString);
    this.f.a(localGetIdsOfNames, this.j, this.u);
    if (localGetIdsOfNames.g()) {
      throw new NoSuchFieldException(cj.translate(cj.NO_SUCH_PROPERTY, paramString));
    }
    this.B.put(paramString, new Integer(localGetIdsOfNames.h()));
    return localGetIdsOfNames.h();
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == null) {
      return false;
    }
    if ((paramObject instanceof RemoteObjRef)) {
      paramObject = ((RemoteObjRef)paramObject).getJintegraDispatch();
    }
    if ((paramObject instanceof Dispatch))
    {
      Dispatch localDispatch = (Dispatch)paramObject;
      return this.f.equals(localDispatch.f);
    }
    if ((paramObject instanceof StdObjRef)) {
      return this.f.equals(paramObject);
    }
    return false;
  }
  
  public int hashCode()
  {
    return this.f.hashCode();
  }
  
  public static String createObjrefMonikerDisplayName(Object paramObject)
    throws IOException
  {
    StdObjRef localStdObjRef = z.a(paramObject, k.IID_IUNKNOWN, null);
    if (isNativeMode())
    {
      localObject = (NativeObjRef)localStdObjRef;
      return ((NativeObjRef)localObject).nativeGetObjrefMonikerDisplayName();
    }
    Object localObject = new y(true, null);
    localStdObjRef.b((y)localObject, k.IID_IUNKNOWN);
    byte[] arrayOfByte = ((y)localObject).e();
    return b("3,[9(:t") + d.encode(arrayOfByte) + ":";
  }
  
  public void convertToNative()
    throws IOException
  {
    if (isNativeMode()) {
      return;
    }
    b();
    StdObjRef localStdObjRef = z.a(this, this.j, null);
    y localy = new y(true, null);
    localStdObjRef.b(localy, this.j);
    byte[] arrayOfByte = localy.e();
    String str = b("3,[9(:t") + d.encode(arrayOfByte) + ":";
    this.f = new NativeObjRef(str, this.j, null, false);
  }
  
  public static Object getActiveObject(String paramString)
    throws IOException
  {
    NativeObjRef.q();
    return new NativeObjRef(null, k.IID_IUNKNOWN, paramString, true);
  }
  
  public static Object getActiveObject(String paramString1, String paramString2)
    throws IOException
  {
    NativeObjRef.q();
    return new NativeObjRef(null, new Uuid(paramString2), paramString1, true);
  }
  
  public static Object bindUsingMoniker(String paramString)
    throws IOException
  {
    if (isNativeMode()) {
      return new NativeObjRef(paramString, k.IID_IUNKNOWN, null, false);
    }
    return StdObjRef.a(paramString);
  }
  
  public static int getLastErrorCode()
  {
    return (int)C;
  }
  
  public void vtblInvoke(String paramString, int paramInt, Object[] paramArrayOfObject)
    throws IOException, AutomationException
  {
    int i1 = H;
    if (isNativeMode())
    {
      if (paramInt < 32)
      {
        if (this.l[paramInt] != null)
        {
          localObject1 = this.l[paramInt];
          if (i1 == 0) {}
        }
        else
        {
          localObject1 = this.k.a(paramInt).c;
          this.l[paramInt] = localObject1;
          if (i1 == 0) {}
        }
      }
      else {
        localObject1 = this.k.a(paramInt).c;
      }
      localObject2 = new Request(paramString, paramInt, (Param[])localObject1, paramArrayOfObject);
      this.f.a((Rpc)localObject2, this.j, this.u);
      return;
    }
    b();
    if (this.i) {
      throw new RuntimeException(cj.NON_DISPATCH_METHOD_INVOKED);
    }
    Object localObject1 = new Marshaller(this.j, paramInt, paramArrayOfObject);
    ((Marshaller)localObject1).a(this.f.a(), this.f.b());
    Object localObject2 = e.a(this.f.l(), ((Marshaller)localObject1).a());
    ((Marshaller)localObject1).a((Uuid)localObject2);
    y localy = ((Marshaller)localObject1).b();
    Request localRequest = new Request(paramInt, localy.e(), ((Marshaller)localObject1).a(), (Uuid)localObject2);
    this.f.a(localRequest, this.j, this.u);
    x localx = localRequest.g();
    ((Marshaller)localObject1).b(localx);
    long l1 = localx.e(b("\024\034t\030\030\020\032"), b(")\021X%9o|"));
    C = l1;
    if ((int)l1 < 0)
    {
      AutomationException localAutomationException = localRequest.c();
      if (localAutomationException == null) {
        throw new AutomationException(l1);
      }
      localAutomationException.a(l1);
      throw localAutomationException;
    }
  }
  
  public static Object getMtsObjectContext()
  {
    if (!isNativeMode()) {
      throw new RuntimeException(cj.METHOD_CANNOT_USE_IN_DCOM_MODE);
    }
    return NativeObjRef.nativeGetMTSObjectContext();
  }
  
  public Object getPropertyByName(String paramString)
    throws NoSuchFieldException, IOException, AutomationException
  {
    Variant[] arrayOfVariant = new Variant[0];
    return invoke(paramString, getDispatchIdOfName(paramString), 2L, arrayOfVariant).getVARIANT();
  }
  
  public Object getPropertyByName(String paramString, Object paramObject)
    throws NoSuchFieldException, IOException, AutomationException
  {
    Variant[] arrayOfVariant = { paramObject == null ? new Variant(b(".&B"), 10, 2147614724L) : new Variant(b(".&B"), 12, paramObject) };
    return invoke(paramString, getDispatchIdOfName(paramString), 2L, arrayOfVariant).getVARIANT();
  }
  
  public void setPropertyByName(String paramString, Object paramObject)
    throws NoSuchMethodException, IOException, AutomationException
  {
    Variant[] arrayOfVariant = { new Variant(b("*/]>("), 12, paramObject) };
    try
    {
      invoke(paramString, getDispatchIdOfName(paramString), 4L, arrayOfVariant);
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      throw new NoSuchMethodException(cj.translate(cj.NO_SUCH_PROPERTY, paramString));
    }
  }
  
  public Object invokeMethodByName(String paramString, Object[] paramArrayOfObject)
    throws NoSuchMethodException, IOException, AutomationException
  {
    int i2 = H;
    Variant[] arrayOfVariant = new Variant[paramArrayOfObject.length];
    int i1 = 0;
    if (i2 != 0) {
      arrayOfVariant[i1] = (paramArrayOfObject[i1] == null ? new Variant("p" + i1, 10, 2147614724L) : new Variant("p" + i1, 12, paramArrayOfObject[i1]));
    }
    for (;;)
    {
      i1++;
      if (i1 < paramArrayOfObject.length) {
        break;
      }
      try
      {
        if (i2 != 0) {
          continue;
        }
        return invoke(paramString, getDispatchIdOfName(paramString), 1L, arrayOfVariant).getVARIANT();
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        throw new NoSuchMethodException(cj.translate(cj.NO_SUCH_METHOD, paramString));
      }
    }
  }
  
  public Object invokeMethodByName(String paramString, Variant[] paramArrayOfVariant)
    throws NoSuchMethodException, IOException, AutomationException
  {
    try
    {
      return invoke(paramString, getDispatchIdOfName(paramString), 1L, paramArrayOfVariant).getVARIANT();
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      throw new NoSuchMethodException(cj.translate(cj.NO_SUCH_METHOD, paramString));
    }
  }
  
  public Object invokePropertyGetByName(String paramString, Variant[] paramArrayOfVariant)
    throws NoSuchMethodException, IOException, AutomationException
  {
    try
    {
      return invoke(paramString, getDispatchIdOfName(paramString), 2L, paramArrayOfVariant).getVARIANT();
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      throw new NoSuchMethodException(cj.translate(cj.NO_SUCH_METHOD, paramString));
    }
  }
  
  public void invokePropertyPutByName(String paramString, Variant[] paramArrayOfVariant)
    throws NoSuchMethodException, IOException, AutomationException
  {
    try
    {
      invoke(paramString, getDispatchIdOfName(paramString), 4L, paramArrayOfVariant).getVARIANT();
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      throw new NoSuchMethodException(cj.translate(cj.NO_SUCH_METHOD, paramString));
    }
  }
  
  public void invokePropertyPutByRefByName(String paramString, Variant[] paramArrayOfVariant)
    throws NoSuchMethodException, IOException, AutomationException
  {
    try
    {
      invoke(paramString, getDispatchIdOfName(paramString), 8L, paramArrayOfVariant).getVARIANT();
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      throw new NoSuchMethodException(cj.translate(cj.NO_SUCH_METHOD, paramString));
    }
  }
  
  public Object invokeMethodByName(String paramString, Object[] paramArrayOfObject, boolean[] paramArrayOfBoolean)
    throws NoSuchMethodException, IOException, AutomationException
  {
    int i2 = H;
    Variant[] arrayOfVariant = new Variant[paramArrayOfObject.length];
    int i1 = 0;
    if (i2 != 0) {
      arrayOfVariant[i1] = (paramArrayOfObject[i1] == null ? new Variant("p" + i1, 10, 2147614724L) : new Variant("p" + i1, 12, paramArrayOfObject[i1]));
    }
    for (;;)
    {
      if ((paramArrayOfBoolean[i1] != 0) && (paramArrayOfObject[i1] != null)) {
        arrayOfVariant[i1].b();
      }
      i1++;
      if (i1 < paramArrayOfObject.length) {
        break;
      }
      try
      {
        if (i2 != 0) {
          continue;
        }
        return invoke(paramString, getDispatchIdOfName(paramString), 1L, arrayOfVariant).getVARIANT();
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        throw new NoSuchMethodException(cj.translate(cj.NO_SUCH_METHOD, paramString));
      }
    }
  }
  
  static Class a(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  static Executor a(Executor paramExecutor)
  {
    t = paramExecutor;
    return paramExecutor;
  }
  
  static Executor i()
  {
    return t;
  }
  
  static void j() {}
  
  static
  {
    AccessController.doPrivileged(new m());
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      78[49] = ((char)(0x4B ^ 0x4D));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Dispatch
 * JD-Core Version:    0.7.0.1
 */