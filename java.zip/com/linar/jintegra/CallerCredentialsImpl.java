package com.linar.jintegra;

import com.linar.spi.CallerCredentials;

public class CallerCredentialsImpl
  implements CallerCredentials
{
  private String a;
  private String b;
  private boolean c;
  
  CallerCredentialsImpl(String paramString1, String paramString2, boolean paramBoolean)
  {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramBoolean;
  }
  
  public String getCallerDomain()
  {
    return this.a;
  }
  
  public String getCallerUser()
  {
    return this.b;
  }
  
  public boolean isCallerAuthenticated()
  {
    return this.c;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.CallerCredentialsImpl
 * JD-Core Version:    0.7.0.1
 */