package com.linar.jintegra;

import java.io.IOException;

public final class NativeAuth
  extends c
{
  private byte[] a;
  public long context;
  private static boolean b;
  private static boolean c;
  
  public String toString()
  {
    return a("oVbS_g[b_[cGcEHt8\036xlRq@s$");
  }
  
  public int hashCode()
  {
    return a("HyB{C{YrhGmB~").hashCode();
  }
  
  public boolean equals(Object paramObject)
  {
    return paramObject instanceof NativeAuth;
  }
  
  void a(y paramy)
    throws IOException
  {
    paramy.a(a("h}QynOyBs-A}XsGlSr-@jY{-HyB{C8UyiC"));
    byte[] arrayOfByte = getNegociateMessage();
    if (arrayOfByte == null) {
      throw new RuntimeException(cj.ERROR_INITIALISING_NATIVE_AUTH_SERVICES);
    }
    paramy.a(arrayOfByte, 0, arrayOfByte.length, a("h}QynOyBs-k}EelA}"));
    paramy.c();
  }
  
  void a(x paramx)
    throws IOException
  {
    this.a = new byte[paramx.f()];
    paramx.a(this.a, a("EpWzaCvQsIGlW"));
  }
  
  void b(y paramy)
    throws IOException
  {
    paramy.a(a("gmB~hHl_ulR}\026qhH}DwyC|\026pIu\026xlRq@s-EwRs"));
    byte[] arrayOfByte = getAuthenticateMessage(this.a);
    if (arrayOfByte == null) {
      throw new RuntimeException(cj.ERROR_INITIALISING_NATIVE_AUTH_SERVICES);
    }
    paramy.a(arrayOfByte, 0, arrayOfByte.length, a("gmB~hHl_ulR}\026[hUkWqh"));
    paramy.c();
  }
  
  native void release();
  
  native byte[] getNegociateMessage();
  
  native byte[] getAuthenticateMessage(byte[] paramArrayOfByte);
  
  static synchronized boolean c()
  {
    if (!b)
    {
      b = true;
      try
      {
        System.loadLibrary(a("Hl@wxRp"));
        Log.log(3, a("umUs~U~Cza_8ZylB}R6cGl_`h\006{Yrh\006yCbeCvBnGl_yc\006t_tGjO"));
        c = true;
      }
      catch (Throwable localThrowable)
      {
        Log.log(1, cj.translate(cj.FAILED_TO_LOAD_NATIVE_AUTH_LIBRARY, localThrowable));
      }
    }
    return c;
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      24[54] = ((char)(0x16 ^ 0xD));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.NativeAuth
 * JD-Core Version:    0.7.0.1
 */