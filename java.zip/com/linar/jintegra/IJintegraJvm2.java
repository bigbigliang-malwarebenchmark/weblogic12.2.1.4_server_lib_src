package com.linar.jintegra;

import java.io.IOException;

public abstract interface IJintegraJvm2
{
  public static final int IID652f3880_2c14_11d4_b75f_204c4f4f5020 = 1;
  public static final int xxDummy = 0;
  public static final String IID = "652f3880-2c14-11d4-b75f-204c4f4f5020";
  public static final String DISPID_1_NAME = "newInstance";
  public static final String DISPID_2_NAME = "getRef";
  
  public abstract Object newInstance(String paramString1, String paramString2)
    throws IOException, AutomationException;
  
  public abstract IJintegraJvm2 getRef(String paramString1, String paramString2, String paramString3, int paramInt)
    throws IOException, AutomationException;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.IJintegraJvm2
 * JD-Core Version:    0.7.0.1
 */