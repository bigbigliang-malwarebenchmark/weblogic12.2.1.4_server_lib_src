package com.linar.jintegra;

import java.io.IOException;

public final class NullAuth
  extends c
{
  public String toString()
  {
    return cj.NO_AUTHENTICATION;
  }
  
  public int hashCode()
  {
    return a("6nE/&0").hashCode();
  }
  
  public boolean equals(Object paramObject)
  {
    return paramObject instanceof NullAuth;
  }
  
  void a(y paramy)
    throws IOException
  {
    throw new RuntimeException(cj.INVALID_USE_OF_NULL_AUTH);
  }
  
  void a(x paramx)
    throws IOException
  {
    throw new RuntimeException(cj.INVALID_USE_OF_NULL_AUTH);
  }
  
  void b(y paramy)
    throws IOException
  {
    throw new RuntimeException(cj.INVALID_USE_OF_NULL_AUTH);
  }
  
  void release()
  {
    throw new RuntimeException(cj.INVALID_USE_OF_NULL_AUTH);
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      1[36] = ((char)(0x5A ^ 0x52));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.NullAuth
 * JD-Core Version:    0.7.0.1
 */