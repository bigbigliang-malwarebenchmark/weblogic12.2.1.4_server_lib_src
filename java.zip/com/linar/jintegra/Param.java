package com.linar.jintegra;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

public class Param
{
  private static final int a = 1;
  private static final int b = 2;
  private static final int c = 4;
  private static final int d = 8;
  private static final int e = 16;
  private static final int f = 32;
  static final int g = 0;
  static final int h = 1;
  static final int i = 2;
  static final int j = 3;
  static final int k = 4;
  static final int l = 5;
  static final int m = 6;
  static final int n = 7;
  public String name;
  public int vt;
  public int flags;
  public int assocKind;
  public Uuid assocUuid;
  public String assocUuidStr;
  public Class assocClass;
  public Class assocInterface;
  public int[] fixedArrayDimensions;
  public Field field;
  private Constructor o;
  public int arraySizeParamIndex = -1;
  public StructDesc structDesc;
  static Class p;
  static Class q;
  
  public Param(String paramString, int paramInt1, int paramInt2)
  {
    this.name = paramString;
    this.vt = paramInt1;
    this.flags = paramInt2;
  }
  
  public Param(String paramString, int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    this.name = paramString;
    this.vt = paramInt1;
    this.flags = paramInt2;
    this.fixedArrayDimensions = paramArrayOfInt;
  }
  
  public Param(String paramString, int paramInt1, int paramInt2, Class paramClass, int paramInt3)
  {
    this.name = paramString;
    this.vt = paramInt1;
    this.flags = paramInt2;
    this.assocClass = paramClass;
    this.arraySizeParamIndex = paramInt3;
    try
    {
      if (this.assocClass != null)
      {
        this.structDesc = StructDesc.b(this.assocClass);
        if (Dispatch.H == 0) {}
      }
      else
      {
        this.structDesc = null;
      }
    }
    catch (Exception localException)
    {
      this.structDesc = null;
    }
  }
  
  public Param(String paramString1, int paramInt1, int paramInt2, int paramInt3, String paramString2, Class paramClass)
  {
    this(paramString1, paramInt1, paramInt2, paramInt3, paramString2, paramClass, null);
  }
  
  public Param(String paramString1, int paramInt1, int paramInt2, int paramInt3, String paramString2, Class paramClass, int[] paramArrayOfInt)
  {
    this.name = paramString1;
    this.vt = paramInt1;
    this.flags = paramInt2;
    this.assocKind = paramInt3;
    this.assocUuidStr = paramString2;
    this.assocUuid = (paramString2 == null ? null : new Uuid(paramString2));
    this.assocClass = paramClass;
    this.fixedArrayDimensions = paramArrayOfInt;
    try
    {
      if (paramClass != null)
      {
        this.structDesc = StructDesc.b(paramClass);
        if (Dispatch.H == 0) {}
      }
      else
      {
        this.structDesc = null;
      }
    }
    catch (Exception localException)
    {
      this.structDesc = null;
    }
  }
  
  void a(Class paramClass)
  {
    try
    {
      this.field = paramClass.getField(this.name);
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      throw new RuntimeException(cj.translate(cj.FIELD_NOT_FOUND_IN_STRUCT_CLASS, this.name, paramClass));
    }
  }
  
  public String toString()
  {
    String str = b("H,A\034");
    if (this.fixedArrayDimensions != null)
    {
      str = "";
      int i1 = 0;
      if (Dispatch.H != 0) {}
      while (i1 < this.fixedArrayDimensions.length)
      {
        str = str + "[" + this.fixedArrayDimensions[i1] + "]";
        i1++;
      }
    }
    return b("v8_\021\003\006\"\r\036\017K<\rMN") + this.name + b("\ny[\004N\033y") + this.vt + b("\nyK\034\017A*\rMN") + this.flags + b("") + this.assocKind + b("\nyL\003\035I:x\005\007By\020P") + this.assocUuid + b("\nyL\003\035I:n\034\017U*\rMN") + this.assocClass + b("\nyK\031\026C=l\002\034G i\031\003C7^\031\001H*\rMN") + str + b("\006$");
  }
  
  public Object wrap(StdObjRef paramStdObjRef)
  {
    if (this.o == null) {
      try
      {
        this.o = this.assocClass.getConstructor(new Class[] { p == null ? (Param.p = a(b("L8[\021@J8C\027@i;G\025\rR"))) : p });
      }
      catch (Exception localException1)
      {
        Log.a(cj.translate(cj.UNEXPECTED_USING, localException1, this.assocClass));
        throw new RuntimeException(cj.translate(cj.UNEXPECTED_USING_AND_CHECK_IF_COMPILED, localException1, this.assocClass));
      }
    }
    try
    {
      return this.o.newInstance(new Object[] { paramStdObjRef });
    }
    catch (Exception localException2)
    {
      Log.a(cj.translate(cj.UNEXPECTED_USING, localException2, this.assocClass));
      throw new RuntimeException(cj.translate(cj.UNEXPECTED_USING_AND_CHECK_IF_COMPILED, localException2, this.assocClass));
    }
  }
  
  public Object createOutVal(Object paramObject)
  {
    try
    {
      if (this.assocInterface == null) {
        if ((q == null ? (Param.q = a(b("E6@^\002O7L\002@L0C\004\013A+L^*O*]\021\032E1"))) : q).isAssignableFrom(this.assocClass)) {
          this.assocInterface = ((Class)this.assocClass.getField(b("R8_\027\013R\032A\021\035U")).get(null));
        }
      }
      Class localClass = this.assocInterface != null ? this.assocInterface : this.assocClass;
      Object localObject = Array.newInstance(localClass, 1);
      Array.set(localObject, 0, paramObject);
      return localObject;
    }
    catch (Exception localException)
    {
      Log.a(b("s7H\b\036C:Y\025\n\034y") + localException + b("") + this.assocClass);
      throw new RuntimeException(b("s7H\b\036C:Y\025\n\006") + localException + b("") + this.assocClass + b("\by}\034\013G*HP\rN<N\033NQ1H\004\006C+\r\t\001SyE\021\030CyN\037\003V0A\025\n\006-E\025N@0A\025\035\006,^\025\n\006;TP\032N8YP\rJ8^\003@"));
    }
  }
  
  boolean a()
  {
    return (this.flags & 0x2) != 0;
  }
  
  boolean b()
  {
    return (this.flags & 0x4) != 0;
  }
  
  public boolean isArray()
  {
    return (this.flags & 0x1) != 0;
  }
  
  boolean c()
  {
    return (this.flags & 0x8) != 0;
  }
  
  boolean d()
  {
    return (this.flags & 0x10) != 0;
  }
  
  boolean e()
  {
    return (this.flags & 0x20) != 0;
  }
  
  static Class a(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      89[45] = ((char)(0x70 ^ 0x6E));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Param
 * JD-Core Version:    0.7.0.1
 */