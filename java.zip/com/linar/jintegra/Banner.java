package com.linar.jintegra;

import java.io.PrintStream;

public class Banner
{
  public static void printBanner()
  {
    System.err.println(f.l);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Banner
 * JD-Core Version:    0.7.0.1
 */