package com.linar.jintegra;

import java.util.Enumeration;

public class EnumerationWrapper
  implements Enumeration
{
  private Enumeration a;
  public static final Class targetClass = b == null ? (EnumerationWrapper.b = a(b("J\nZ\031m@\013VE/C\fYCdN\027V\031DG\020ZRsH\021^Xo~\027VGqL\027"))) : b;
  public static final String DISPID_3_NAME = "";
  static Class b;
  static Class c;
  static Class d;
  static Class e;
  static Class f;
  
  EnumerationWrapper(Enumeration paramEnumeration)
  {
    this.a = paramEnumeration;
  }
  
  public Object nextElement()
  {
    return this.a.nextElement();
  }
  
  public boolean hasMoreElements()
  {
    return this.a.hasMoreElements();
  }
  
  Object a(int paramInt)
  {
    try
    {
      return this.a.nextElement();
    }
    catch (Throwable localThrowable) {}
    return null;
  }
  
  public void next(int paramInt, Object[] paramArrayOfObject, int[] paramArrayOfInt)
    throws AutomationException
  {
    Log.log(3, b("") + this.a);
    if (paramArrayOfInt != null) {
      paramArrayOfInt[0] = 0;
    }
    paramArrayOfObject[0] = null;
    if ((paramInt != 1) || (!this.a.hasMoreElements()))
    {
      if (paramInt != 1)
      {
        Log.log(3, b("") + paramInt);
        if (Dispatch.H == 0) {}
      }
      else
      {
        Log.log(3, b(""));
      }
      throw new AutomationException(1L);
    }
    try
    {
      paramArrayOfObject[0] = this.a.nextElement();
      Log.log(3, b("") + paramArrayOfObject[0]);
      if (paramArrayOfInt != null) {
        paramArrayOfInt[0] = 1;
      }
    }
    catch (Throwable localThrowable)
    {
      Log.log(3, b("") + localThrowable);
      throw new AutomationException(1L);
    }
  }
  
  public void skip(int paramInt)
    throws AutomationException
  {
    throw new AutomationException(1L);
  }
  
  public void reset()
    throws AutomationException
  {
    throw new AutomationException(1L);
  }
  
  public void zz_clone(EnumerationWrapper[] paramArrayOfEnumerationWrapper)
    throws AutomationException
  {
    throw new AutomationException(1L);
  }
  
  static Class a(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  static
  {
    InterfaceDesc.add(b("\031U\007\0051\035U\003\0321\031U\007\0321\031U\007\032b\031U\007\0321\031U\007\0071\031U\007\0075\037"), b == null ? (EnumerationWrapper.b = a(b("J\nZ\031m@\013VE/C\fYCdN\027V\031DG\020ZRsH\021^Xo~\027VGqL\027"))) : b, b("\031U\007\0071\031U\007\0321\031U\007\0321\031U\007\032b\031U\007\0321\031U\007\0071\031U\007\0075\037"), 3, new MemberDesc[] { new MemberDesc(b(""), new Class[] { Integer.TYPE, c == null ? (EnumerationWrapper.c = a(b("r)]VwHK[VoNKxUkL\006C\f"))) : c, d == null ? (EnumerationWrapper.d = a(b("r,"))) : d }, new Param[] { new Param(b(""), 19, 2, 8, null, null), new Param(b("[\002AVs"), 16396, 4, e == null ? (EnumerationWrapper.e = a(b("C\004AV/E\004YP/f\007]Rb]"))) : e, 2), new Param(b(""), 16403, 4, 8, null, null), new Param("", 24, 8, -842150451, null, null) }), new MemberDesc(b("Z\016^G"), new Class[] { Integer.TYPE }, new Param[] { new Param(b(""), 19, 2, 8, null, null), new Param("", 24, 8, -842150451, null, null) }), new MemberDesc(b(""), new Class[0], new Param[] { new Param("", 24, 8, -842150451, null, null) }), new MemberDesc(b("S\037hTmF\013R"), new Class[] { f == null ? (EnumerationWrapper.f = a(b(""))) : f }, new Param[] { new Param(b("Y\025RYtD"), 16413, 4, 3, k.IID_IENUM_VARIANT + "", b == null ? (EnumerationWrapper.b = a(b("J\nZ\031m@\013VE/C\fYCdN\027V\031DG\020ZRsH\021^Xo~\027VGqL\027"))) : b), new Param("", 24, 8, -842150451, null, null) }) });
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      101[55] = ((char)(0x37 ^ 0x1));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.EnumerationWrapper
 * JD-Core Version:    0.7.0.1
 */