package com.linar.jintegra;

import java.lang.reflect.Array;
import java.util.Enumeration;
import java.util.Vector;

public class JavaUtilVectorCollector
  implements Collectionable
{
  Vector a;
  
  public Object item(Object paramObject)
    throws AutomationException
  {
    if ((paramObject != null) && (paramObject.getClass().isArray())) {
      paramObject = Array.get(paramObject, 0);
    }
    if ((paramObject == null) || (!(paramObject instanceof Number))) {
      throw new AutomationException(2147614725L);
    }
    int i = ((Number)paramObject).intValue() - 1;
    Object localObject = this.a.elementAt(i);
    if (localObject == null) {
      throw new AutomationException(2147614725L);
    }
    return localObject;
  }
  
  public void add(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
    throws AutomationException
  {
    int j = Dispatch.H;
    Log.log(3, a("\001\036R\037I9[") + paramObject2);
    if (paramObject2 != null) {
      throw new AutomationException(2147614725L, cj.KEY_CANNOT_BE_SPECIFIED);
    }
    int i;
    if (paramObject3 != null)
    {
      if (paramObject4 != null) {
        throw new AutomationException(2147614725L, cj.BEFORE_AND_AFTER_OBJECT_CANNOT_BE_SPECIFIED);
      }
      i = -1;
      if ((paramObject3 instanceof Number))
      {
        i = ((Number)paramObject3).intValue() - 1;
        if (j == 0) {}
      }
      else
      {
        i = this.a.indexOf(paramObject3);
        if (i == -1) {
          throw new AutomationException(2147614725L, cj.BEFORE_OBJECT_NOT_FOUND);
        }
      }
      this.a.insertElementAt(paramObject1, i);
      return;
    }
    if (paramObject4 != null)
    {
      if (paramObject3 != null) {
        throw new AutomationException(2147614725L, cj.BEFORE_AND_AFTER_OBJECT_CANNOT_BE_SPECIFIED);
      }
      i = -1;
      if ((paramObject3 instanceof Number))
      {
        i = ((Number)paramObject4).intValue() - 1;
        if (j == 0) {}
      }
      else
      {
        i = this.a.indexOf(paramObject4);
        if (i == -1) {
          throw new AutomationException(2147614725L, cj.AFTER_OBJECT_NOT_FOUND);
        }
      }
      this.a.insertElementAt(paramObject1, i + 1);
      return;
    }
    this.a.addElement(paramObject1);
  }
  
  public int count()
    throws AutomationException
  {
    return this.a.size();
  }
  
  public Enumeration _NewEnum()
    throws AutomationException
  {
    return new EnumerationWrapper(this.a.elements());
  }
  
  public void remove(Object paramObject)
    throws AutomationException
  {
    if (paramObject == null) {
      throw new AutomationException(2147614725L);
    }
    int i = -1;
    if ((paramObject instanceof Number))
    {
      i = ((Number)paramObject).intValue() - 1;
      this.a.removeElementAt(i);
      if (Dispatch.H == 0) {}
    }
    else if (!this.a.removeElement(paramObject))
    {
      throw new AutomationException(2147614725L, cj.OBJECT_NOT_FOUND);
    }
  }
  
  public boolean canHandle(Object paramObject)
  {
    if ((paramObject instanceof Vector))
    {
      this.a = ((Vector)paramObject);
      return true;
    }
    return false;
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      123[43] = ((char)(0x3F ^ 0x20));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.JavaUtilVectorCollector
 * JD-Core Version:    0.7.0.1
 */