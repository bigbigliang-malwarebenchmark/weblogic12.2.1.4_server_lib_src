package com.linar.jintegra;

import java.io.IOException;

class FindConnectionPoint
  extends Rpc
{
  Uuid k;
  StdObjRef l;
  
  public String getRIIDString()
  {
    return this.k + "";
  }
  
  StdObjRef g()
  {
    return this.l;
  }
  
  public void setConnectionPoint(StdObjRef paramStdObjRef)
  {
    this.l = paramStdObjRef;
  }
  
  FindConnectionPoint(Uuid paramUuid)
  {
    this.k = paramUuid;
  }
  
  String b()
  {
    return b(")3\006$\033\005\023\035#\032\016 \006#\033\0243\006$\001\001\031\007/\007ZJ/#\033\0043\006$\033\005\023\035#\032\016 \006#\033\024");
  }
  
  void b(y paramy)
    throws IOException
  {
    paramy.a(b(""));
    a(paramy);
    Log.log(3, b(")\003\032?\034\016\027I,\034\016\024*%\033\016\025\n>\034\017\0369%\034\016\004I%\033@") + this.k);
    paramy.a(this.k, b(""));
    paramy.c();
  }
  
  void b(x paramx)
    throws IOException
  {
    paramx.a(b(")3\006$\033\005\023\035#\032\016 \006#\033\0243\006$\001\001\031\007/\007ZJ/#\033\0043\006$\033\005\023\035#\032\016 \006#\033\024P\006?\001"));
    a(paramx);
    paramx.a(b(")3\006$\033\005\023\035#\032\016 \006#\033\024ZCj\005\02039"));
    long l1 = paramx.e(b(""), b(""));
    if (l1 == 0L)
    {
      long l2 = 0L;
      try
      {
        l2 = paramx.e(b(""), b(""));
      }
      catch (IOException localIOException) {}
      Log.a(cj.translate(cj.NO_PPCP_IN_RESPONSE_TO_FIND_CONNECTION_POINT, Long.toString(l2)));
      throw new RuntimeException(cj.NO_PPCP_IN_RESPONSE_TO_FIND_CONNECTION_POINT_TEXT);
    }
    this.l = new StdObjRef(false, paramx);
    paramx.c();
    paramx.c();
  }
  
  int a()
  {
    return 4;
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      112[105] = ((char)(0x4A ^ 0x75));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.FindConnectionPoint
 * JD-Core Version:    0.7.0.1
 */