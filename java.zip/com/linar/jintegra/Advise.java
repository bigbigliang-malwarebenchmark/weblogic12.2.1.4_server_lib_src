package com.linar.jintegra;

import java.io.IOException;

class Advise
  extends Rpc
{
  StdObjRef k;
  long l = 0L;
  long m;
  
  public StdObjRef getObjRef()
  {
    return this.k;
  }
  
  long g()
  {
    return this.m;
  }
  
  public void setCookie(long paramLong)
  {
    this.m = paramLong;
  }
  
  Advise(Object paramObject)
    throws IOException
  {
    this.k = z.a(paramObject, k.IID_IUNKNOWN, null);
  }
  
  String b()
  {
    return b("U4F\0318y\024]\0369r'F\0368hM\02362j\036Z\022");
  }
  
  void b(y paramy)
    throws IOException
  {
    paramy.a(b("U4F\0318y\024]\0369r'F\0368hM\02362j\036Z\022vn\022X\0023o\003"));
    a(paramy);
    paramy.a(paramy.f(), b("i\036G\003\t/E"), b(" \007]\005vu\023\027"));
    this.k.a(paramy, k.IID_IUNKNOWN, false);
    paramy.c();
  }
  
  void b(x paramx)
    throws IOException
  {
    paramx.a(b("U4F\0318y\024]\0369r'F\0368hM\02362j\036Z\022vn\022Z\0079r\004L"));
    a(paramx);
    this.m = paramx.e(b("i(@\031\"/E"), b("\030F\034?y"));
    this.l = paramx.e(b("i(@\031\"/E"), b("o\003H\003#o"));
    if (this.l != 0L) {
      throw new AutomationException(this.l);
    }
    paramx.c();
  }
  
  int a()
  {
    return 5;
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      119[41] = ((char)(0x77 ^ 0x56));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Advise
 * JD-Core Version:    0.7.0.1
 */