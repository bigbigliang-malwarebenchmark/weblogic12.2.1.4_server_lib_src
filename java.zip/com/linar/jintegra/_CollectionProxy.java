package com.linar.jintegra;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;

public class _CollectionProxy
  extends Dispatch
{
  private static final String[] I = { d(""), d("") };
  public static final Class targetClass = K == null ? (_CollectionProxy.K = c(d(""))) : K;
  static InterfaceDesc J = new InterfaceDesc(new Uuid(d("")), L == null ? (_CollectionProxy.L = c(d(""))) : L, null, 7, new MemberDesc[] { new MemberDesc(d("w\017_C"), new Class[] { M == null ? (_CollectionProxy.M = c(d("t\032LOLr\032TILQ\031PK\001j"))) : M }, new Param[] { new Param(d("w\025^K\032"), 16396, 2, 8, null, null), new Param(d("n\r[\\0{\017"), 12, 20, 8, null, null) }), new MemberDesc(d("\037^"), new Class[] { M == null ? (_CollectionProxy.M = c(d("t\032LOLr\032TILQ\031PK\001j"))) : M, M == null ? (_CollectionProxy.M = c(d("t\032LOLr\032TILQ\031PK\001j"))) : M, M == null ? (_CollectionProxy.M = c(d("t\032LOLr\032TILQ\031PK\001j"))) : M, M == null ? (_CollectionProxy.M = c(d("t\032LOLr\032TILQ\031PK\001j"))) : M }, new Param[] { new Param(d("w\017_C"), 16396, 2, 8, null, null), new Param(d("u\036C"), 16396, 10, 8, null, null), new Param(d("|\036\\A\020{"), 16396, 10, 8, null, null), new Param(d("\035NK\020"), 16396, 10, 8, null, null), new Param("", 24, 8, -842150451, null, null) }), new MemberDesc(d("}\024O@\026"), new Class[0], new Param[] { new Param(d("n\022\016"), 3, 20, 8, null, null) }), new MemberDesc(d("l\036WA\024{"), new Class[] { M == null ? (_CollectionProxy.M = c(d("t\032LOLr\032TILQ\031PK\001j"))) : M }, new Param[] { new Param(d("w\025^K\032"), 16396, 2, 8, null, null), new Param("", 24, 8, -842150451, null, null) }), new MemberDesc(d("A5_Y'p\016W"), new Class[0], new Param[] { new Param(d("n\013O@\t"), 13, 20, 8, null, null) }) });
  static Class K;
  static Class L;
  static Class M;
  
  static Collectionable a(Object paramObject)
  {
    int i = 0;
    if (Dispatch.H != 0) {}
    while (i < I.length)
    {
      try
      {
        Collectionable localCollectionable = (Collectionable)Class.forName(I[i]).newInstance();
        if (localCollectionable.canHandle(paramObject)) {
          return localCollectionable;
        }
      }
      catch (Throwable localThrowable) {}
      i++;
    }
    return null;
  }
  
  static Variant b(Object paramObject)
    throws IOException
  {
    Collectionable localCollectionable = a(paramObject);
    if (localCollectionable != null)
    {
      Enumeration localEnumeration = localCollectionable._NewEnum();
      Log.log(3, d("M\016YK\021m\035OB\016>$tK\025[\025OCBq\025\032") + paramObject + d("0[\032|\007j\016H@\013p\034\032") + localEnumeration);
      return new Variant(d("L\036Nx\003r"), 9, new EnumerationWrapper(localEnumeration));
    }
    return null;
  }
  
  protected String getJintegraVersion()
  {
    return cj.CONFIG_VERSION;
  }
  
  static Class c(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  static
  {
    InterfaceDesc.k.put(J.a, J);
    InterfaceDesc.a(J.a);
  }
  
  private static String d(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      123[58] = ((char)(0x2E ^ 0x62));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra._CollectionProxy
 * JD-Core Version:    0.7.0.1
 */