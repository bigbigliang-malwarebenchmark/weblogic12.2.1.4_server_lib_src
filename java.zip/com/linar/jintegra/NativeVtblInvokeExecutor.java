package com.linar.jintegra;

import com.linar.spi.Executable;

public class NativeVtblInvokeExecutor
  implements Executable
{
  NativeObjectProxy a;
  private long b;
  private int c;
  private Object[] d;
  Object e;
  AutomationException f = null;
  Object g = new Object();
  boolean h = false;
  
  public NativeVtblInvokeExecutor(NativeObjectProxy paramNativeObjectProxy, long paramLong, int paramInt, Object[] paramArrayOfObject)
  {
    this.a = paramNativeObjectProxy;
    this.b = paramLong;
    this.c = paramInt;
    this.d = paramArrayOfObject;
  }
  
  public void execute()
  {
    try
    {
      this.e = this.a.invoke(this.b, this.c, this.d);
    }
    catch (AutomationException localAutomationException)
    {
      this.f = localAutomationException;
    }
    finally
    {
      c();
    }
  }
  
  Object a()
  {
    return this.e;
  }
  
  void b()
    throws AutomationException
  {
    if (this.f != null) {
      throw this.f;
    }
  }
  
  void c()
  {
    synchronized (this.g)
    {
      this.h = true;
      this.g.notifyAll();
    }
  }
  
  void d()
  {
    int i = Dispatch.H;
    try
    {
      synchronized (this.g)
      {
        if (i != 0) {}
        do
        {
          do
          {
            this.g.wait();
          } while (!this.h);
        } while (i != 0);
      }
    }
    catch (InterruptedException localInterruptedException) {}
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.NativeVtblInvokeExecutor
 * JD-Core Version:    0.7.0.1
 */