package com.linar.jintegra;

import java.util.Enumeration;

public abstract interface Collectionable
{
  public abstract Object item(Object paramObject)
    throws AutomationException;
  
  public abstract void add(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
    throws AutomationException;
  
  public abstract int count()
    throws AutomationException;
  
  public abstract Enumeration _NewEnum()
    throws AutomationException;
  
  public abstract void remove(Object paramObject)
    throws AutomationException;
  
  public abstract boolean canHandle(Object paramObject);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Collectionable
 * JD-Core Version:    0.7.0.1
 */