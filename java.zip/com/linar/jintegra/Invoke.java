package com.linar.jintegra;

import java.io.IOException;

class Invoke
  extends Rpc
{
  static final int k = 1;
  static final int l = 2;
  static final int m = 4;
  static final int n = 8;
  static final int o = -1;
  static final int p = -3;
  public int dispId;
  public long dwFlags;
  public Variant[] parameters;
  public int byRefParameterCount;
  public long returnStatus = 0L;
  public long sCode = 0L;
  public String bstrSource = "";
  public String bstrDescription = "";
  private Variant q = new Variant(b("\016TW\030K\b"));
  long r = 1033L;
  
  void g()
    throws AutomationException
  {
    if ((this.sCode != 0L) || ((this.bstrDescription != null) && (this.bstrDescription.length() != 0))) {
      throw new AutomationException(this.bstrSource, this.bstrDescription, this.sCode);
    }
    if (this.returnStatus != 0L) {
      throw new AutomationException(this.returnStatus, b("5uM\036W\035EG\005\035FXJ\033H\027T"));
    }
  }
  
  public Variant getResult()
  {
    return this.q;
  }
  
  Invoke(int paramInt, long paramLong, Variant[] paramArrayOfVariant)
  {
    this.dispId = paramInt;
    this.dwFlags = paramLong;
    this.parameters = paramArrayOfVariant;
  }
  
  String b()
  {
    return b("");
  }
  
  void b(y paramy)
    throws IOException
  {
    paramy.a(b(""));
    a(paramy);
    paramy.a(this.dispId, b("\025_P^\025"), b(""));
    paramy.a(k.NULL_UUID, b("\016XM\t"));
    paramy.a(this.r, b("\tnM\003SO\003"), b("\020RM\t"));
    paramy.a(this.dwFlags, b("\tnM\003SO\003"), b("\032]E\nT"));
    c(paramy);
    d(paramy);
    paramy.c();
  }
  
  void c(y paramy)
    throws IOException
  {
    int i1 = Dispatch.H;
    Log.log(3, b("+CM\031N\022V\004)N\017A\004=F\016PI\036"));
    paramy.a(b("8xw=w=ce t\\\033\004\035c\025BT=F\016PI\036"));
    long l1 = this.parameters.length == 0 ? 0L : paramy.f();
    paramy.a(l1, b("\tnM\003SO\003"), b("@CC\033F\016V\004\035S\016\021M\t\031"));
    Log.log(3, b("+CM\031N\022V\004\037@\\AP\037\007\025U"));
    l1 = this.dwFlags == 4L ? paramy.f() : 0L;
    paramy.a(l1, b("\tnM\003SO\003"), b("@CC\tN\017AM\ti\035\\A\tf\016VWMW\bC\004\004CB"));
    Log.log(3, b("+CM\031N\022V\004\016F\016VW"));
    paramy.a(this.parameters.length, b("\tnM\003SO\003"), b("\037pV\nT"));
    long l2 = this.dwFlags == 4L ? 1L : 0L;
    paramy.a(l2, b("\tnM\003SO\003"), b(""));
    paramy.a(this.parameters.length, b("\tnM\003SO\003"), b("\037pV\nT"));
    Log.log(3, b("+CM\031N\022V\004\030T\031CW"));
    int i = 0;
    if (i1 != 0) {}
    int j;
    do
    {
      do
      {
        paramy.a(b(")BA\037"), b("\fXG\006K\031U\004\002I\025^J\036\007\030CM\003L\025_CMK\tRE\027F\030T"));
        i++;
      } while (i < this.parameters.length);
      Log.log(3, b("+CM\031N\022V\004\017^.TB=F\016PI.H\t_P\036"));
      this.byRefParameterCount = 0;
      j = this.parameters.length - 1;
    } while (i1 != 0);
    if (i1 != 0) {}
    do
    {
      do
      {
        if (this.parameters[j].isByRef())
        {
          paramy.d(8);
          Variant.a(paramy);
          this.byRefParameterCount += 1;
          if (i1 == 0) {}
        }
        else
        {
          paramy.d(8);
          this.parameters[j].c(paramy);
        }
        j--;
      } while (j >= 0);
    } while (i1 != 0);
    if (paramy.b(8) >= 4)
    {
      paramy.d(4);
      if (i1 == 0) {}
    }
    else
    {
      paramy.d(8);
    }
    if (this.dwFlags == 4L)
    {
      paramy.a(1L, b("\tnM\003SO\003"), b("@PV\037F\005\021H\bI\033ELS"));
      paramy.a(-3, b("\025_P^\025"), b("\030XW\035N\030"));
    }
    paramy.c();
  }
  
  void d(y paramy)
    throws IOException
  {
    int i1 = Dispatch.H;
    Log.log(3, b(""));
    paramy.a(this.byRefParameterCount, b("\tnM\003SO\003"), b("\037s]?B\032"));
    paramy.a(this.byRefParameterCount, b("\tnM\003SO\003"), b("\037s]?B\032"));
    paramy.a(b(")xj9\007V\021V\nq\035Cv\bA5U\\"));
    int i = 0;
    if (i1 != 0) {}
    do
    {
      do
      {
        if (this.parameters[(this.parameters.length - i - 1)].isByRef()) {
          paramy.a(i, b("\tnM\003SO\003"), b("\nPV/^.TB$C\004"));
        }
        i++;
      } while (i < this.parameters.length);
      paramy.c();
      paramy.a(this.byRefParameterCount, b("\tnM\003SO\003"), b("\037s]?B\032"));
      i = 0;
    } while (i1 != 0);
    if (i1 != 0) {}
    int j;
    do
    {
      do
      {
        paramy.a(b(")BA\037"), b("\fXG\006K\031U\004\002I\025^J\036\007\030CM\003L\025_CMK\tRE\027F\030T"));
        i++;
      } while (i < this.byRefParameterCount);
      j = this.parameters.length - 1;
      if (i1 == 0) {
        break;
      }
    } while (i1 != 0);
    while (j >= 0)
    {
      if (this.parameters[j].isByRef())
      {
        paramy.d(8);
        this.parameters[j].c(paramy);
      }
      j--;
    }
  }
  
  void c(x paramx)
    throws IOException
  {
    paramx.a(b("\\t|.b,xj+h\\\033\004\035b\004RA\035n\022WK"));
    int i = paramx.c(b("+~v)"), b("\013rK\tB"));
    paramx.c(b("+~v)"), b("\013cA\036B\016GA\t"));
    paramx.e(b(")}k#`"), b("C\016\033"));
    paramx.e(b(")}k#`"), b("C\016\033"));
    this.sCode = paramx.e(b(")}k#`"), b("\017rk)b"));
    this.bstrSource = paramx.d(b("\036BP\037t\023DV\016B"));
    this.bstrDescription = paramx.d(b("\036BP\037c\031BG\037N\fEM\002I"));
    String str = paramx.d(b("\036BP\037o\031]T+N\020T"));
    paramx.c();
  }
  
  void b(x paramx)
    throws IOException
  {
    int i1 = Dispatch.H;
    paramx.a(b(""));
    a(paramx);
    paramx.a(4, b(",P@\tN\022V"));
    paramx.e(b("\tnM\003SO\003"), b("\fP@"));
    this.q.a(paramx);
    paramx.d(4);
    long l1 = paramx.e(b("\tnM\003SO\003"), b("@AE\tC\025_CS"));
    if (l1 != 1919251285L)
    {
      paramx.a(12, b(",P@\tN\022V"));
      if (i1 == 0) {}
    }
    else
    {
      paramx.a(8, b(",P@\tN\022V"));
    }
    c(paramx);
    long l2 = paramx.e(b("\tnM\003SO\003"), b("\fpV\nb\016C"));
    int i = paramx.b(b("\025_P^\025"), b("\037^Q\003S"));
    paramx.a(4 * i, b(",P@\tN\022V"));
    int j = this.parameters.length - 1;
    if (i1 != 0) {}
    do
    {
      do
      {
        if (this.parameters[j].isByRef())
        {
          paramx.d(8);
          this.parameters[j].a(paramx);
        }
        j--;
      } while (j >= 0);
      this.returnStatus = paramx.e(b("\tnM\003SO\003"), b("\017EE\031R\017"));
    } while (i1 != 0);
    if (this.returnStatus != 0L)
    {
      AutomationException localAutomationException = new AutomationException(this.returnStatus);
      Log.a(cj.translate(cj.IDISPATCH_INVOKE_ERROR_IN_RESPONSE, localAutomationException));
    }
    paramx.c();
  }
  
  int a()
  {
    return 6;
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      49[36] = ((char)(0x6D ^ 0x27));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Invoke
 * JD-Core Version:    0.7.0.1
 */