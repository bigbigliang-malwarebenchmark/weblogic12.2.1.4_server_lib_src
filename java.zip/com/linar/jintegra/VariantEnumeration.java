package com.linar.jintegra;

import java.io.IOException;
import java.util.Enumeration;
import java.util.NoSuchElementException;

public class VariantEnumeration
  extends Dispatch
  implements Enumeration
{
  private boolean I = true;
  private Object J = null;
  static boolean K = bi.b();
  
  protected String getJintegraVersion()
  {
    return cj.INTERNAL_VERSION;
  }
  
  public VariantEnumeration(Object paramObject)
    throws IOException
  {
    super(paramObject, c("B.5[TF.1DTB.5DTB.5D\007B.5DTB.5YTB.5YPD"));
    if (K)
    {
      this.J = k();
      this.I = (this.J != null);
    }
  }
  
  public boolean hasMoreElements()
  {
    return this.I;
  }
  
  public Object nextElement()
    throws NoSuchElementException
  {
    if (!this.I) {
      throw new NoSuchElementException();
    }
    Object localObject1 = k();
    if (K)
    {
      Object localObject2 = this.J;
      this.J = localObject1;
      if (localObject1 == null) {
        this.I = false;
      }
      return localObject2;
    }
    if (localObject1 == null)
    {
      this.I = false;
      throw new NoSuchElementException();
    }
    return localObject1;
  }
  
  private Object k()
  {
    Object[] arrayOfObject1 = { null };
    Object[] arrayOfObject2 = { null };
    int[] arrayOfInt = { 0 };
    Object[] arrayOfObject3 = { new Integer(1), arrayOfObject2, arrayOfInt, arrayOfObject1 };
    try
    {
      vtblInvoke(c("\034{}\035"), 3, arrayOfObject3);
      if (arrayOfInt[0] == 0) {
        return null;
      }
      if ((arrayOfObject2[0] instanceof Object[])) {
        return ((Object[])arrayOfObject2[0])[0];
      }
      return arrayOfObject2[0];
    }
    catch (IOException localIOException) {}
    return null;
  }
  
  static
  {
    try
    {
      Class.forName(c("\021qhG\b\033pd\033J\030wk\035\001\025ldG!\034kh\f\026\023jl\006\n%ld\031\024\027l"));
    }
    catch (Throwable localThrowable) {}
  }
  
  private static String c(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      30[5] = ((char)(0x69 ^ 0x64));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.VariantEnumeration
 * JD-Core Version:    0.7.0.1
 */