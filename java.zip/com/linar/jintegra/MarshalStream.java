package com.linar.jintegra;

import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.Date;

public class MarshalStream
{
  x a;
  y b;
  AutomationException c;
  Uuid d = null;
  static Class e;
  static Class f;
  static Class g;
  static Class h;
  
  Uuid a()
  {
    return this.d;
  }
  
  void a(Uuid paramUuid)
  {
    this.d = paramUuid;
  }
  
  void a(AutomationException paramAutomationException)
  {
    this.c = paramAutomationException;
  }
  
  void a(long paramLong)
    throws AutomationException
  {
    if (this.c == null) {
      throw new AutomationException(paramLong);
    }
    this.c.a(paramLong);
    throw this.c;
  }
  
  byte[] b()
    throws IOException
  {
    this.b.c();
    return this.b.e();
  }
  
  MarshalStream(y paramy)
  {
    this.b = paramy;
  }
  
  MarshalStream(x paramx)
  {
    this.a = paramx;
  }
  
  public void writeDECIMAL(BigDecimal paramBigDecimal, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramBigDecimal + b("a`A\036&!\004\f?&+!\005s\013\003\003 \021\016\ni"));
    this.b.a(paramBigDecimal, paramString);
  }
  
  public void writeUI1(byte paramByte, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramByte + b("a`A\t\006wo\013%;#i"));
    this.b.e(paramByte, paramString, b(""));
  }
  
  public void writeUI1Array(byte[] paramArrayOfByte, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfByte + b(""));
    Variant localVariant = new Variant(paramString, 8209, paramArrayOfByte);
    localVariant.a(this.b, paramString);
  }
  
  public void writeUI1Array(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    if (paramArrayOfInt.length == 1)
    {
      byte[] arrayOfByte = (byte[])paramObject;
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        this.b.e(i < arrayOfByte.length ? arrayOfByte[i] : 0, paramString + "[" + i + "]", b("/.\035d"));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
  }
  
  public void writeI1(byte paramByte, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramByte + b("a`A\025~i\"\020(*o"));
    this.b.e(paramByte, paramString, b(""));
  }
  
  public void writeI1Array(byte[] paramArrayOfByte, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfByte + b(""));
    Variant localVariant = new Variant(paramString, 8208, paramArrayOfByte);
    localVariant.a(this.b, paramString);
  }
  
  public void writeI1Array(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    writeUI1Array(paramObject, paramString, paramArrayOfInt);
  }
  
  public void writeI2(short paramShort, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramShort + b("a`A\025}i3\0013=2i"));
    this.b.b(paramShort, paramString, b("/.\035my"));
  }
  
  public void writeI2Array(short[] paramArrayOfShort, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfShort + b(""));
    Variant localVariant = new Variant(paramString, 8194, paramArrayOfShort);
    localVariant.a(this.b, paramString);
  }
  
  public void writeI2Array(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    if (paramArrayOfInt.length == 1)
    {
      short[] arrayOfShort = (short[])paramObject;
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        this.b.b(i < arrayOfShort.length ? arrayOfShort[i] : 0, paramString + "[" + i + "]", b("/.\035my"));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
  }
  
  public void writeUI2(short paramShort, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramShort + b("a`A\t\006to\0324 44@"));
    this.b.b(paramShort, paramString, b("/.\035my"));
  }
  
  public void writeUI2Array(short[] paramArrayOfShort, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfShort + b(""));
    Variant localVariant = new Variant(paramString, 8210, paramArrayOfShort);
    localVariant.a(this.b, paramString);
  }
  
  public void writeUI2Array(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    writeI2Array(paramObject, paramString, paramArrayOfInt);
  }
  
  public void writeI2AsChar(char paramChar, String paramString)
    throws IOException
  {
    writeI2((short)paramChar, paramString);
  }
  
  public void writeI2AsCharArray(char[] paramArrayOfChar, String paramString)
    throws IOException
  {
    int j = Dispatch.H;
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfChar + b(""));
    short[] arrayOfShort = new short[paramArrayOfChar.length];
    int i = 0;
    if (j != 0) {}
    do
    {
      do
      {
        arrayOfShort[i] = ((short)paramArrayOfChar[i]);
        i++;
      } while (i < paramArrayOfChar.length);
      writeI2Array(arrayOfShort, paramString);
    } while (j != 0);
  }
  
  public void writeI4(int paramInt, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramInt + b("a`A\025{i)\007(f"));
    this.b.a(paramInt, paramString, b("/.\035o}"));
  }
  
  public void writeI4Array(int[] paramArrayOfInt, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfInt + b(""));
    Variant localVariant = new Variant(paramString, 8195, paramArrayOfInt);
    localVariant.a(this.b, paramString);
  }
  
  public void writeI4Array(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    if (paramArrayOfInt.length == 1)
    {
      int[] arrayOfInt = (int[])paramObject;
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        this.b.a(i < arrayOfInt.length ? arrayOfInt[i] : 0, paramString + "[" + i + "]", b("/.\035o}"));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
  }
  
  public void writeUI4(int paramInt, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramInt + b(""));
    this.b.a(paramInt, paramString, b("/.\035o}"));
  }
  
  public void writeUI4Array(int[] paramArrayOfInt, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfInt + b(""));
    Variant localVariant = new Variant(paramString, 8211, paramArrayOfInt);
    localVariant.a(this.b, paramString);
  }
  
  public void writeUI4Array(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    writeI4Array(paramObject, paramString, paramArrayOfInt);
  }
  
  public void writeINT(int paramInt, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramInt + b(""));
    this.b.a(paramInt, paramString, b("/.\035o}"));
  }
  
  public void writeINTArray(int[] paramArrayOfInt, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfInt + b(""));
    Variant localVariant = new Variant(paramString, 8214, paramArrayOfInt);
    localVariant.a(this.b, paramString);
  }
  
  public void writeINTArray(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    writeI4Array(paramObject, paramString, paramArrayOfInt);
  }
  
  public void writeUINT(int paramInt, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramInt + b("a`A\t\006\b\024F5!2i"));
    this.b.a(paramInt, paramString, b("/.\035o}"));
  }
  
  public void writeUINTArray(int[] paramArrayOfInt, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfInt + b(""));
    Variant localVariant = new Variant(paramString, 8215, paramArrayOfInt);
    localVariant.a(this.b, paramString);
  }
  
  public void writeUINTArray(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    writeI4Array(paramObject, paramString, paramArrayOfInt);
  }
  
  public void writeERROR(long paramLong, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramLong + b("a`A\031\035\024\017;s#).\016u"));
    this.b.a(paramLong, paramString, b(""));
  }
  
  public void writeERRORArray(long[] paramArrayOfLong, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfLong + b(""));
    Variant localVariant = new Variant(paramString, 8202, paramArrayOfLong);
    localVariant.a(this.b, paramString);
  }
  
  public void writeCY(long paramLong, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramLong + b("a`A\037\026i,\0062(o"));
    this.b.c(paramLong, paramString, b("/.\035j{"));
  }
  
  public void writeCYArray(long[] paramArrayOfLong, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfLong + b(""));
    Variant localVariant = new Variant(paramString, 8198, paramArrayOfLong);
    localVariant.a(this.b, paramString);
  }
  
  public void writeCYArray(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    if (paramArrayOfInt.length == 1)
    {
      long[] arrayOfLong = (long[])paramObject;
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        this.b.c(i < arrayOfLong.length ? arrayOfLong[i] : 0L, paramString + "[" + i + "]", b("/.\035j{"));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
  }
  
  public void writeI8(long paramLong, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramLong + b("a`A\025wi,\0062(o"));
    this.b.c(paramLong, paramString, b("/.\035j{"));
  }
  
  public void writeI8Array(long[] paramArrayOfLong, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfLong + b(""));
    Variant localVariant = new Variant(paramString, 8212, paramArrayOfLong);
    localVariant.a(this.b, paramString);
  }
  
  public void writeI8Array(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    writeCYArray(paramObject, paramString, paramArrayOfInt);
  }
  
  public void writeUI8(long paramLong, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramLong + b("a`A\t\006~o\0053!!i"));
    this.b.c(paramLong, paramString, b("/.\035j{"));
  }
  
  public void writeUI8Array(long[] paramArrayOfLong, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfLong + b(""));
    Variant localVariant = new Variant(paramString, 8213, paramArrayOfLong);
    localVariant.a(this.b, paramString);
  }
  
  public void writeUI8Array(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    writeCYArray(paramObject, paramString, paramArrayOfInt);
  }
  
  public void writeR4(float paramFloat, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramFloat + b("a`A\016{i&\0053.2i"));
    this.b.a(paramFloat, paramString, b("5)\007;##"));
  }
  
  public void writeR4Array(float[] paramArrayOfFloat, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfFloat + b(""));
    Variant localVariant = new Variant(paramString, 8196, paramArrayOfFloat);
    localVariant.a(this.b, paramString);
  }
  
  public void writeR4Array(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    if (paramArrayOfInt.length == 1)
    {
      float[] arrayOfFloat = (float[])paramObject;
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        this.b.a(i < arrayOfFloat.length ? arrayOfFloat[i] : 0.0F, paramString + "[" + i + "]", b("5)\007;##"));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
  }
  
  public void writeR8(double paramDouble, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramDouble + b("a`A\016wi$\006)-*%@"));
    this.b.a(paramDouble, paramString, b("\"/\034>##"));
  }
  
  public void writeR8Array(Object paramObject, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramObject + b(""));
    Variant localVariant = new Variant(paramString, 8197, paramObject);
    localVariant.a(this.b, paramString);
  }
  
  public void writeR8Array(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    if (paramArrayOfInt.length == 1)
    {
      double[] arrayOfDouble = (double[])paramObject;
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        this.b.a(i < arrayOfDouble.length ? arrayOfDouble[i] : 0.0D, paramString + "[" + i + "]", b("\"/\034>##"));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
  }
  
  public void writeBOOL(boolean paramBoolean, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramBoolean + b(""));
    this.b.b(paramBoolean ? -1 : 0, paramString, b("/.\035myfh\0133 *%\b2f"));
  }
  
  public void writeBOOLArray(boolean[] paramArrayOfBoolean, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfBoolean + b(""));
    Variant localVariant = new Variant(paramString, 8203, paramArrayOfBoolean);
    localVariant.a(this.b, paramString);
  }
  
  public void writeBOOLArray(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    if (paramArrayOfInt.length == 1)
    {
      boolean[] arrayOfBoolean = (boolean[])paramObject;
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        this.b.b(i < arrayOfBoolean.length ? 0 : arrayOfBoolean[i] != 0 ? -1 : 0, paramString + "[" + i + "]", b("/.\035myfh\0133 *%\b2f"));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
  }
  
  public void writeDATE(Date paramDate, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramDate + b("a`A\030\016\022\005F6.0!G);/,G\030.2%@"));
    this.b.a(paramDate, paramString);
  }
  
  public void writeDATEArray(Date[] paramArrayOfDate, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfDate + b(""));
    Variant localVariant = new Variant(paramString, 8199, paramArrayOfDate);
    localVariant.a(this.b, paramString);
  }
  
  public void writeDATEArray(Object paramObject, String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    if (paramArrayOfInt.length == 1)
    {
      Date[] arrayOfDate = (Date[])paramObject;
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        this.b.a(i < arrayOfDate.length ? arrayOfDate[i] : null, paramString + "[" + i + "]");
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
  }
  
  public void writeLPSTR(String paramString1, String paramString2)
    throws IOException
  {
    if (paramString1 == null) {
      paramString1 = "";
    }
    if ((paramString1.length() == 0) || (paramString1.charAt(paramString1.length() - 1) != 0)) {
      paramString1 = paramString1 + "";
    }
    this.b.a(paramString1.length(), b(""), b("*%\007"));
    this.b.a(0L, b("64\033|&\""), b(")&\017/*2"));
    this.b.a(paramString1.length(), b(""), b("*%\007"));
    this.b.a(paramString1, paramString2);
  }
  
  public void writeLPLPSTR(String paramString1, String paramString2)
    throws IOException
  {
    if (paramString1 == null)
    {
      this.b.a(0L, b("64\033|&\""), b("z0\035.q"));
      if (Dispatch.H == 0) {}
    }
    else
    {
      this.b.a(this.b.f(), b("64\033|&\""), b(""));
      writeLPSTR(paramString1, paramString2);
    }
  }
  
  public void writeLPWSTR(String paramString1, String paramString2)
    throws IOException
  {
    if (paramString1 == null) {
      paramString1 = "";
    }
    if ((paramString1.length() == 0) || (paramString1.charAt(paramString1.length() - 1) != 0)) {
      paramString1 = paramString1 + "";
    }
    this.b.a(paramString1.length(), b(""), b("*%\007"));
    this.b.a(0L, b("64\033|&\""), b(")&\017/*2"));
    this.b.a(paramString1.length(), b(""), b("*%\007"));
    this.b.b(paramString1, paramString2);
  }
  
  public void writeLPLPWSTR(String paramString1, String paramString2)
    throws IOException
  {
    if (paramString1 == null)
    {
      this.b.a(0L, b("64\033|&\""), b("z0\035.q"));
      if (Dispatch.H == 0) {}
    }
    else
    {
      this.b.a(this.b.f(), b("64\033|&\""), b(""));
      writeLPWSTR(paramString1, paramString2);
    }
  }
  
  public void writePtrID(Object paramObject, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramObject + b("a`A\036\034\022\022F\017;4)\007;f"));
    long l = paramObject == null ? 0L : this.b.f();
    this.b.a(l, b("64\033|&\"`\0173=f") + paramString, b(""));
  }
  
  public void writeBSTR(String paramString1, String paramString2)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString2 + b("f}I{") + paramString1 + b("a`A\036\034\022\022F\017;4)\007;f"));
    this.b.d(4);
    this.b.a(b("\0233\f."), b("64\033|&\""));
    this.b.c(paramString1, paramString2);
  }
  
  public void writeBSTRNoPtr(String paramString1, String paramString2)
    throws IOException
  {
    if (paramString1 == null) {
      return;
    }
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString2 + b("f}I{") + paramString1 + b("a`A\036\034\022\022F\017;4)\007;f"));
    this.b.c(paramString1, paramString2);
  }
  
  public void writeConformantVaryingString(String paramString1, String paramString2)
    throws IOException
  {
    paramString1 = paramString1 + "";
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString2 + b("f}I{") + paramString1 + b("a`A\036\034\022\022F\017;4)\007;f"));
    this.b.a(paramString1.length(), b(""), b("*%\007;;."));
    this.b.a(0L, b(""), b(")&\017/*2"));
    this.b.a(paramString1.length(), b(""), b("*%\007;;."));
    if (paramString1 == null) {
      throw new IllegalArgumentException(cj.translate(cj.PARAMETER_IS_NULL, paramString2));
    }
    this.b.a(paramString1, paramString2);
  }
  
  public void writeBSTRArray(String[] paramArrayOfString, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfString + b(""));
    Variant localVariant = new Variant(paramString, 8200, paramArrayOfString);
    localVariant.a(this.b, paramString);
  }
  
  public void writeVARIANT(Object paramObject, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramObject + b("a`A\n\016\024\t(\022\033i\017\0136*%4@"));
    this.b.a(b("\0233\f."), b("64\033|&\""));
    Variant localVariant = paramObject == null ? new Variant(paramString, 10, 2147614724L) : new Variant(paramString, 12, paramObject);
    this.b.d(8);
    localVariant.c(this.b);
  }
  
  public void writeVARIANTNoPtr(Object paramObject, String paramString)
    throws IOException
  {
    if (paramObject == null) {
      return;
    }
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramObject + b("a`A\n\016\024\t(\022\033i\017\0136*%4@"));
    Variant localVariant = paramObject == null ? new Variant(paramString, 10, 2147614724L) : new Variant(paramString, 12, paramObject);
    this.b.d(8);
    localVariant.c(this.b);
  }
  
  public void writeVARIANTArray(Object[] paramArrayOfObject, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfObject + b(""));
    Variant localVariant = new Variant(paramString, 8204, paramArrayOfObject);
    localVariant.a(this.b, paramString);
  }
  
  public void writeVARIANTArrayNoPtr(Object[] paramArrayOfObject, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfObject + b(""));
    Variant localVariant = new Variant(paramString, 8204, paramArrayOfObject);
    localVariant.b(this.b, paramString);
  }
  
  public void writeDISPATCH(Object paramObject, String paramString)
    throws IOException
  {
    writeDISPATCH(paramObject, paramString, null);
  }
  
  public void writeDISPATCHNoPtr(Object paramObject, String paramString)
    throws IOException
  {
    writeDISPATCHNoPtr(paramObject, paramString, null);
  }
  
  public void writeDISPATCHArray(Object[] paramArrayOfObject, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfObject + b(""));
    Variant localVariant = new Variant(paramString, 8201, paramArrayOfObject);
    localVariant.a(this.b, paramString);
  }
  
  public void writeDISPATCH(Object paramObject, String paramString1, String paramString2)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString1 + b("f}I{") + paramObject + b("a`A\030\006\025\020(\b\f\016o&>%##\035u"));
    this.b.d(4);
    if (paramObject == null)
    {
      this.b.a(0L, b("64\033|&\""), b(""));
      if (Dispatch.H == 0) {}
    }
    else
    {
      Uuid localUuid = k.IID_IDISPATCH;
      if (paramString2 != null) {
        localUuid = new Uuid(paramString2);
      }
      StdObjRef localStdObjRef = z.a(paramObject, localUuid, null);
      this.b.a(this.b.f(), b("64\033|&\""), b(""));
      localStdObjRef.a(this.b, localUuid, false);
    }
  }
  
  public void writeDISPATCHNoPtr(Object paramObject, String paramString1, String paramString2)
    throws IOException
  {
    if (paramObject == null) {
      return;
    }
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString1 + b("f}I{") + paramObject + b("a`A\030\006\025\020(\b\f\016o&>%##\035u"));
    this.b.d(4);
    Uuid localUuid = k.IID_IDISPATCH;
    if (paramString2 != null) {
      localUuid = new Uuid(paramString2);
    }
    StdObjRef localStdObjRef = z.a(paramObject, localUuid, null);
    localStdObjRef.a(this.b, localUuid, false);
  }
  
  public void writeUNKNOWN(Object paramObject, String paramString)
    throws IOException
  {
    writeUNKNOWN(paramObject, paramString, null);
  }
  
  public void writeUNKNOWN(Object paramObject, String paramString1, String paramString2)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString1 + b("f}I{") + paramObject + b("a`A\t\001\r\016&\013\001i\017\0136*%4@"));
    this.b.d(4);
    if (paramObject == null)
    {
      this.b.a(0L, b("64\033|&\""), b(""));
      if (Dispatch.H == 0) {}
    }
    else
    {
      Uuid localUuid = k.IID_IUNKNOWN;
      if (paramString2 != null) {
        localUuid = new Uuid(paramString2);
      }
      StdObjRef localStdObjRef = z.a(paramObject, null, null);
      this.b.a(this.b.f(), b("64\033|&\""), b(""));
      localStdObjRef.a(this.b, localUuid, false);
    }
  }
  
  public void writeUNKNOWNNoPtr(Object paramObject, String paramString)
    throws IOException
  {
    if (paramObject == null) {
      return;
    }
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramObject + b("a`A\t\001\r\016&\013\001i\017\0136*%4@"));
    StdObjRef localStdObjRef = z.a(paramObject, null, null);
    localStdObjRef.a(this.b, k.IID_IUNKNOWN, false);
  }
  
  public void writeUNKNOWNNoPtr(Object paramObject, String paramString1, String paramString2)
    throws IOException
  {
    if (paramObject == null) {
      return;
    }
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString1 + b("f}I{") + paramObject + b("a`A\t\001\r\016&\013\001i\017\0136*%4@"));
    this.b.d(4);
    Uuid localUuid = k.IID_IUNKNOWN;
    if (paramString2 != null) {
      localUuid = new Uuid(paramString2);
    }
    StdObjRef localStdObjRef = z.a(paramObject, localUuid, null);
    localStdObjRef.a(this.b, localUuid, false);
  }
  
  public void writeUNKNOWNArray(Object[] paramArrayOfObject, String paramString)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramArrayOfObject + b(""));
    Variant localVariant = new Variant(paramString, 8205, paramArrayOfObject);
    localVariant.a(this.b, paramString);
  }
  
  public void writeArray(Object paramObject, String paramString, int paramInt)
    throws IOException
  {
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + paramObject + b(""));
    Variant localVariant = new Variant(paramString, paramInt | 0x2000, paramObject);
    localVariant.a(this.b, paramString);
  }
  
  public Object[] readUNKNOWNArray(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    Object[] arrayOfObject = (Object[])localVariant.a(this.a, 13);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfObject + b(""));
    return arrayOfObject;
  }
  
  public Object readArray(String paramString, int paramInt)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    Object localObject = localVariant.a(this.a, paramInt);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + localObject + b(""));
    return localObject;
  }
  
  public byte readUI1(String paramString)
    throws IOException
  {
    byte b1 = (byte)this.a.g(paramString, b(""));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + b1 + b(""));
    return b1;
  }
  
  public byte[] readUI1Array(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    byte[] arrayOfByte = (byte[])localVariant.a(this.a, 17);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfByte + b(""));
    return arrayOfByte;
  }
  
  public Object readUI1Array(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    Object localObject = Array.newInstance(Byte.TYPE, paramArrayOfInt);
    if (paramArrayOfInt.length == 1)
    {
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        Array.setByte(localObject, i, (byte)this.a.d(paramString + "[" + i + "]", b("/.\035d")));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
    return localObject;
  }
  
  public byte readI1(String paramString)
    throws IOException
  {
    byte b1 = (byte)this.a.g(paramString, b("/.\035d"));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + b1 + b("a`A\025~i)\007(f"));
    return b1;
  }
  
  public byte[] readI1Array(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    byte[] arrayOfByte = (byte[])localVariant.a(this.a, 16);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfByte + b(""));
    return arrayOfByte;
  }
  
  public Object readI1Array(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    return readUI1Array(paramString, paramArrayOfInt);
  }
  
  public short readI2(String paramString)
    throws IOException
  {
    short s = this.a.c(paramString, b("/.\035my"));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + s + b("a`A\025}i3\0013=2i"));
    return s;
  }
  
  public short[] readI2Array(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    short[] arrayOfShort = (short[])localVariant.a(this.a, 2);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfShort + b(""));
    return arrayOfShort;
  }
  
  public Object readI2Array(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    Object localObject = Array.newInstance(Short.TYPE, paramArrayOfInt);
    if (paramArrayOfInt.length == 1)
    {
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        Array.setShort(localObject, i, this.a.c(paramString + "[" + i + "]", b("/.\035my")));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
    return localObject;
  }
  
  public short readUI2(String paramString)
    throws IOException
  {
    short s = this.a.c(paramString, b("/.\035my"));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + s + b("a`A\t\006to\0324 44@"));
    return s;
  }
  
  public short[] readUI2Array(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    short[] arrayOfShort = (short[])localVariant.a(this.a, 18);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfShort + b(""));
    return arrayOfShort;
  }
  
  public Object readUI2Array(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    return readI2Array(paramString, paramArrayOfInt);
  }
  
  public char readI2AsChar(String paramString)
    throws IOException
  {
    return (char)this.a.c(paramString, b("/.\035my"));
  }
  
  public char[] readI2AsCharArray(String paramString)
    throws IOException
  {
    int j = Dispatch.H;
    short[] arrayOfShort = readI2Array(paramString);
    char[] arrayOfChar = new char[arrayOfShort.length];
    int i = 0;
    if (j != 0) {}
    do
    {
      do
      {
        arrayOfChar[i] = ((char)arrayOfShort[i]);
        i++;
      } while (i < arrayOfShort.length);
    } while (j != 0);
    return arrayOfChar;
  }
  
  public int readI4(String paramString)
    throws IOException
  {
    int i = this.a.b(paramString, b("/.\035o}"));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + i + b("a`A\025{i)\007(f"));
    return i;
  }
  
  public int[] readI4Array(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    int[] arrayOfInt = (int[])localVariant.a(this.a, 3);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfInt + b(""));
    return arrayOfInt;
  }
  
  public Object readI4Array(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    Object localObject = Array.newInstance(Integer.TYPE, paramArrayOfInt);
    if (paramArrayOfInt.length == 1)
    {
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        Array.setInt(localObject, i, this.a.b(paramString + "[" + i + "]", b("/.\035o}")));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
    return localObject;
  }
  
  public int readUI4(String paramString)
    throws IOException
  {
    int i = this.a.b(paramString, b("/.\035o}"));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + i + b(""));
    return i;
  }
  
  public int[] readUI4Array(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    int[] arrayOfInt = (int[])localVariant.a(this.a, 19);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfInt + b(""));
    return arrayOfInt;
  }
  
  public Object readUI4Array(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    return readI4Array(paramString, paramArrayOfInt);
  }
  
  public int readINT(String paramString)
    throws IOException
  {
    int i = this.a.b(paramString, b("/.\035o}"));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + i + b(""));
    return i;
  }
  
  public int[] readINTArray(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    int[] arrayOfInt = (int[])localVariant.a(this.a, 22);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfInt + b(""));
    return arrayOfInt;
  }
  
  public Object readINTArray(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    return readI4Array(paramString, paramArrayOfInt);
  }
  
  public int readUINT(String paramString)
    throws IOException
  {
    int i = this.a.b(paramString, b("/.\035o}"));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + i + b("a`A\t\006\b\024F5!2i"));
    return i;
  }
  
  public int[] readUINTArray(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    int[] arrayOfInt = (int[])localVariant.a(this.a, 23);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfInt + b(""));
    return arrayOfInt;
  }
  
  public Object readUINTArray(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    return readI4Array(paramString, paramArrayOfInt);
  }
  
  public long readERROR(String paramString)
    throws IOException
  {
    long l = this.a.e(paramString, b(""));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + l + b("a`A\031\035\024\017;s#).\016u"));
    return l;
  }
  
  public long[] readERRORArray(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    long[] arrayOfLong = (long[])localVariant.a(this.a, 10);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfLong + b(""));
    return arrayOfLong;
  }
  
  public long readCY(String paramString)
    throws IOException
  {
    long l = this.a.i(paramString, b("/.\035j{"));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + l + b("a`A\037\026i,\0062(o"));
    return l;
  }
  
  public long[] readCYArray(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    long[] arrayOfLong = (long[])localVariant.a(this.a, 6);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfLong + b(""));
    return arrayOfLong;
  }
  
  public Object readCYArray(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    Object localObject = Array.newInstance(Long.TYPE, paramArrayOfInt);
    if (paramArrayOfInt.length == 1)
    {
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        Array.setLong(localObject, i, this.a.i(paramString + "[" + i + "]", b("/.\035j{")));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
    return localObject;
  }
  
  public long readI8(String paramString)
    throws IOException
  {
    long l = this.a.i(paramString, b("/.\035j{"));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + l + b("a`A\025wi,\0062(o"));
    return l;
  }
  
  public long[] readI8Array(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    long[] arrayOfLong = (long[])localVariant.a(this.a, 20);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfLong + b(""));
    return arrayOfLong;
  }
  
  public Object readI8Array(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    return readCYArray(paramString, paramArrayOfInt);
  }
  
  public long readUI8(String paramString)
    throws IOException
  {
    long l = this.a.i(paramString, b("/.\035j{"));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + l + b("a`A\t\006~o\0053!!i"));
    return l;
  }
  
  public long[] readUI8Array(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    long[] arrayOfLong = (long[])localVariant.a(this.a, 21);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfLong + b(""));
    return arrayOfLong;
  }
  
  public Object readUI8Array(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    return readCYArray(paramString, paramArrayOfInt);
  }
  
  public float readR4(String paramString)
    throws IOException
  {
    float f1 = this.a.j(paramString, b("5)\007;##"));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + f1 + b("a`A\016{i&\0053.2i"));
    return f1;
  }
  
  public float[] readR4Array(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    float[] arrayOfFloat = (float[])localVariant.a(this.a, 4);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfFloat + b(""));
    return arrayOfFloat;
  }
  
  public Object readR4Array(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    Object localObject = Array.newInstance(Float.TYPE, paramArrayOfInt);
    if (paramArrayOfInt.length == 1)
    {
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        Array.setFloat(localObject, i, this.a.j(paramString + "[" + i + "]", b(" ,\006=;")));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
    return localObject;
  }
  
  public double readR8(String paramString)
    throws IOException
  {
    double d1 = this.a.k(paramString, b("\"/\034>##"));
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + d1 + b("a`A\016wi$\006)-*%@"));
    return d1;
  }
  
  public double[] readR8Array(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    double[] arrayOfDouble = (double[])localVariant.a(this.a, 5);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfDouble + b(""));
    return arrayOfDouble;
  }
  
  public Object readR8Array(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    Object localObject = Array.newInstance(Double.TYPE, paramArrayOfInt);
    if (paramArrayOfInt.length == 1)
    {
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        Array.setDouble(localObject, i, this.a.k(paramString + "[" + i + "]", b("\"/\034>##")));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
    return localObject;
  }
  
  public boolean readBOOL(String paramString)
    throws IOException
  {
    int i = this.a.c(paramString, b("/.\035myfh\0133 *%\b2f"));
    boolean bool = i != 0;
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + bool + b(""));
    return bool;
  }
  
  public boolean[] readBOOLArray(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    boolean[] arrayOfBoolean = (boolean[])localVariant.a(this.a, 11);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfBoolean + b(""));
    return arrayOfBoolean;
  }
  
  public Object readBOOLArray(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    Object localObject = Array.newInstance(Boolean.TYPE, paramArrayOfInt);
    if (paramArrayOfInt.length == 1)
    {
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        Array.setBoolean(localObject, i, this.a.c(paramString + "[" + i + "]", b("/.\035myfh\0133 *%\b2f")) != 0);
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
    return localObject;
  }
  
  public Date readDATE(String paramString)
    throws IOException
  {
    Date localDate = this.a.g(paramString);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + localDate + b("a`A\030\016\022\005F6.0!G);/,G\030.2%@"));
    return localDate;
  }
  
  public BigDecimal readDECIMAL(String paramString)
    throws IOException
  {
    BigDecimal localBigDecimal = this.a.c(paramString);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + localBigDecimal + b(""));
    return localBigDecimal;
  }
  
  public Date[] readDATEArray(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    Date[] arrayOfDate = (Date[])localVariant.a(this.a, 7);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfDate + b(""));
    return arrayOfDate;
  }
  
  public Object readDateArray(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    Object localObject = Array.newInstance(e == null ? (MarshalStream.e = a(b(""))) : e, paramArrayOfInt);
    if (paramArrayOfInt.length == 1)
    {
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        Array.set(localObject, i, this.a.g(paramString + "[" + i + "]"));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
    return localObject;
  }
  
  public String readBSTR(String paramString)
    throws IOException
  {
    this.a.d(4);
    this.a.a(4, b("64\033|&\""));
    String str = this.a.d(paramString);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + str + b("a`A\036\034\022\022F\017;4)\007;f"));
    return str;
  }
  
  public String readBSTRNoPtr(long paramLong, String paramString)
    throws IOException
  {
    if (paramLong == 0L) {
      return null;
    }
    String str = this.a.d(paramString);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + str + b("a`A\036\034\022\022F\017;4)\007;f"));
    return str;
  }
  
  public String readLPSTR(String paramString)
    throws IOException
  {
    int i = (int)this.a.e(b("*%\007"), b(""));
    this.a.e(b(")&\017/*2"), b(""));
    this.a.e(b("*%\007"), b(""));
    String str = this.a.a(i, paramString);
    if ((i != 0) && (str.charAt(i - 1) == 0)) {
      str = str.substring(0, i - 1);
    }
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + str + b("a`A\036\034\022\022F\017;4)\007;f"));
    return str;
  }
  
  public String readLPLPSTR(String paramString)
    throws IOException
  {
    long l = this.a.e(b("a0\035.o/$N"), b(""));
    if (l == 0L) {
      return null;
    }
    return readLPSTR(paramString);
  }
  
  public String readLPWSTR(String paramString)
    throws IOException
  {
    int i = (int)this.a.e(b("*%\007"), b(""));
    this.a.e(b(")&\017/*2"), b(""));
    this.a.e(b("*%\007"), b(""));
    String str = this.a.a(paramString, i);
    if ((i != 0) && (str.charAt(i - 1) == 0)) {
      str = str.substring(0, i - 1);
    }
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + str + b("a`A\036\034\022\022F\017;4)\007;f"));
    return str;
  }
  
  public String readLPLPWSTR(String paramString)
    throws IOException
  {
    long l = this.a.e(b("a0\035.o/$N"), b(""));
    if (l == 0L) {
      return null;
    }
    return readLPWSTR(paramString);
  }
  
  public String[] readBSTRArray(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    String[] arrayOfString = (String[])localVariant.a(this.a, 8);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfString + b(""));
    return arrayOfString;
  }
  
  public Object readBSTRArray(String paramString, int[] paramArrayOfInt)
    throws IOException
  {
    Object localObject = Array.newInstance(f == null ? (MarshalStream.f = a(b(",!\037=a*!\007;a\0254\0335!!"))) : f, paramArrayOfInt);
    if (paramArrayOfInt.length == 1)
    {
      int i = 0;
      if (Dispatch.H != 0) {}
      while (i < paramArrayOfInt[0])
      {
        Array.set(localObject, i, this.a.d(paramString + "[" + i + "]"));
        i++;
      }
    }
    else
    {
      throw new RuntimeException(cj.translate(cj.TOO_MANY_DIMENSIONS, paramString));
    }
    return localObject;
  }
  
  public Object readVARIANT(String paramString)
    throws IOException
  {
    this.a.d(4);
    this.a.a(4, b("64\033|&\""));
    Variant localVariant = new Variant(paramString);
    this.a.d(8);
    localVariant.a(this.a);
    Object localObject = localVariant.getVARIANT();
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + localObject + b("a`A\n\016\024\t(\022\033i\017\0136*%4@"));
    return localObject;
  }
  
  public Object readVARIANTByRefValue(String paramString)
    throws IOException
  {
    this.a.d(4);
    this.a.a(4, b("64\033|&\""));
    Variant localVariant = new Variant(paramString);
    this.a.d(8);
    localVariant.a(this.a);
    Object localObject = localVariant.isByRef() ? localVariant.b(g == null ? (MarshalStream.g = a(b(",!\037=a*!\007;a\t\"\0039,2"))) : g) : localVariant.getVARIANT();
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + localObject + b("a`A\n\016\024\t(\022\033i\017\0136*%4@"));
    return localObject;
  }
  
  public Object readVARIANTNoPtr(long paramLong, String paramString)
    throws IOException
  {
    if (paramLong == 0L) {
      return null;
    }
    Variant localVariant = new Variant(paramString);
    this.a.d(8);
    localVariant.a(this.a);
    Object localObject = localVariant.getVARIANT();
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + localObject + b("a`A\n\016\024\t(\022\033i\017\0136*%4@"));
    return localObject;
  }
  
  public Object[] readVARIANTArray(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    Object[] arrayOfObject = (Object[])localVariant.a(this.a, 12);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfObject + b(""));
    return arrayOfObject;
  }
  
  public Object[] readVARIANTArrayNoPtr(long paramLong, String paramString)
    throws IOException
  {
    if (paramLong == 0L) {
      return null;
    }
    Variant localVariant = new Variant(paramString);
    Object[] arrayOfObject = (Object[])localVariant.b(this.a, 12);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfObject + b(""));
    return arrayOfObject;
  }
  
  public Object readDISPATCH(String paramString)
    throws IOException
  {
    Object localObject1 = null;
    if (this.a.e(b("a0\035.o/$N"), b("")) != 0L)
    {
      StdObjRef localStdObjRef = new StdObjRef(false, this.a);
      Object localObject2 = z.a(localStdObjRef);
      localObject1 = localObject2 == null ? localStdObjRef : localObject2;
    }
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + localObject1 + b("a`A\030\006\025\020(\b\f\016o&>%##\035u"));
    return localObject1;
  }
  
  public Object readDISPATCHNoPtr(long paramLong, String paramString)
    throws IOException
  {
    if (paramLong == 0L) {
      return null;
    }
    Object localObject1 = null;
    StdObjRef localStdObjRef = new StdObjRef(false, this.a);
    Object localObject2 = z.a(localStdObjRef);
    localObject1 = localObject2 == null ? localStdObjRef : localObject2;
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + localObject1 + b("a`A\030\006\025\020(\b\f\016o&>%##\035u"));
    return localObject1;
  }
  
  public Object readDISPATCH(String paramString1, String paramString2)
    throws IOException
  {
    Object localObject = readDISPATCH(paramString1);
    if ((localObject == null) || (!(localObject instanceof StdObjRef))) {
      return localObject;
    }
    return a(localObject, paramString2);
  }
  
  public Object readDISPATCHNoPtr(long paramLong, String paramString1, String paramString2)
    throws IOException
  {
    Object localObject = readDISPATCHNoPtr(paramLong, paramString1);
    if ((localObject == null) || (!(localObject instanceof StdObjRef))) {
      return localObject;
    }
    return a(localObject, paramString2);
  }
  
  Object a(Object paramObject, String paramString)
  {
    try
    {
      Class localClass = Class.forName(paramString);
      Class[] arrayOfClass = { g == null ? (MarshalStream.g = a(b(",!\037=a*!\007;a\t\"\0039,2"))) : g };
      Constructor localConstructor = localClass.getConstructor(arrayOfClass);
      Object[] arrayOfObject = { paramObject };
      return localConstructor.newInstance(arrayOfObject);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      Log.log(3, b("\0032\0333=f!\035(*+0\0355!!`\0353o%/\007/;45\n(o62\006$6f&\006.o") + paramObject + b("|`") + localInvocationTargetException.getTargetException());
    }
    catch (Exception localException)
    {
      Log.log(3, b("\0032\0333=f!\035(*+0\0355!!`\0353o%/\007/;45\n(o62\006$6f&\006.o") + paramObject + b("|`") + localException);
    }
    return null;
  }
  
  Object a(Object paramObject, Class paramClass)
  {
    try
    {
      Class[] arrayOfClass = { g == null ? (MarshalStream.g = a(b(",!\037=a*!\007;a\t\"\0039,2"))) : g };
      Constructor localConstructor = paramClass.getConstructor(arrayOfClass);
      Object[] arrayOfObject = { paramObject };
      return localConstructor.newInstance(arrayOfObject);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      Log.log(3, b("\0032\0333=f!\035(*+0\0355!!`\0353o%/\007/;45\n(o62\006$6f&\006.o") + paramObject + b("|`") + localInvocationTargetException.getTargetException());
    }
    catch (Exception localException)
    {
      Log.log(3, b("\0032\0333=f!\035(*+0\0355!!`\0353o%/\007/;45\n(o62\006$6f&\006.o") + paramObject + b("|`") + localException);
    }
    return null;
  }
  
  public Object readDISPATCH(String paramString, Class paramClass)
    throws IOException
  {
    Object localObject = readDISPATCH(paramString);
    if ((localObject == null) || (!(localObject instanceof StdObjRef)) || (paramClass == null)) {
      return localObject;
    }
    return a(localObject, paramClass);
  }
  
  public Object readDISPATCHNoPtr(long paramLong, String paramString, Class paramClass)
    throws IOException
  {
    Object localObject = readDISPATCHNoPtr(paramLong, paramString);
    if ((localObject == null) || (!(localObject instanceof StdObjRef)) || (paramClass == null)) {
      return localObject;
    }
    return a(localObject, paramClass);
  }
  
  public Object[] readDISPATCHArray(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    Object[] arrayOfObject = (Object[])localVariant.a(this.a, 9);
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + arrayOfObject + b(""));
    return arrayOfObject;
  }
  
  public Object readDISPATCHArray(String paramString1, String paramString2)
    throws IOException
  {
    int j = Dispatch.H;
    Object[] arrayOfObject = readDISPATCHArray(paramString1);
    if (paramString2.endsWith(b("\035\035"))) {
      paramString2 = paramString2.substring(0, paramString2.length() - 2);
    }
    Class localClass = null;
    try
    {
      localClass = Class.forName(paramString2);
    }
    catch (Exception localException)
    {
      Log.a(cj.translate(cj.CANNOT_FIND_CLASS_TO_BUILD_RETURNED_ARRAY, paramString2, localException));
      return null;
    }
    Object localObject = Array.newInstance(localClass, arrayOfObject.length);
    int i = 0;
    if (j != 0) {}
    do
    {
      do
      {
        Array.set(localObject, i, arrayOfObject[i]);
        i++;
      } while (i < arrayOfObject.length);
    } while (j != 0);
    return localObject;
  }
  
  public Object readStructArray(String paramString)
    throws IOException
  {
    Variant localVariant = new Variant(paramString);
    return localVariant.a(this.a, 36);
  }
  
  public void writeStructArray(Object paramObject, String paramString)
    throws IOException
  {
    throw new RuntimeException(cj.UNIMPLEMENTED);
  }
  
  public Object readDISPATCHArray(String paramString, Class paramClass)
    throws IOException
  {
    int j = Dispatch.H;
    Object[] arrayOfObject = readDISPATCHArray(paramString);
    if (paramClass == null) {
      return arrayOfObject;
    }
    Object localObject = Array.newInstance(paramClass, arrayOfObject.length);
    int i = 0;
    if (j != 0) {}
    do
    {
      do
      {
        Array.set(localObject, i, arrayOfObject[i]);
        i++;
      } while (i < arrayOfObject.length);
    } while (j != 0);
    return localObject;
  }
  
  public Object readUNKNOWN(String paramString)
    throws IOException
  {
    Object localObject1 = null;
    if (this.a.e(b("a0\035.o/$N"), b("")) != 0L)
    {
      StdObjRef localStdObjRef = new StdObjRef(false, this.a);
      Object localObject2 = z.a(localStdObjRef);
      localObject1 = localObject2 == null ? localStdObjRef : localObject2;
    }
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + localObject1 + b("a`A\t\001\r\016&\013\001i\017\0136*%4@"));
    return localObject1;
  }
  
  public Object readUNKNOWN(String paramString1, String paramString2)
    throws IOException
  {
    Object localObject = readUNKNOWN(paramString1);
    if ((localObject == null) || (!(localObject instanceof StdObjRef)) || (paramString2 == null)) {
      return localObject;
    }
    return a(localObject, paramString2);
  }
  
  public Object readUNKNOWNNoPtr(long paramLong, String paramString)
    throws IOException
  {
    if (paramLong == 0L) {
      return null;
    }
    Object localObject1 = null;
    StdObjRef localStdObjRef = new StdObjRef(false, this.a);
    Object localObject2 = z.a(localStdObjRef);
    localObject1 = localObject2 == null ? localStdObjRef : localObject2;
    Log.log(3, b("\026!\033=\"#4\f.o") + paramString + b("f}I{") + localObject1 + b("a`A\t\001\r\016&\013\001i\017\0136*%4@"));
    return localObject1;
  }
  
  public Object readUNKNOWNNoPtr(long paramLong, String paramString1, String paramString2)
    throws IOException
  {
    Object localObject = readUNKNOWNNoPtr(paramLong, paramString1);
    if ((localObject == null) || (!(localObject instanceof StdObjRef))) {
      return localObject;
    }
    return a(localObject, paramString2);
  }
  
  public static Object coerceArray(Object paramObject, String paramString)
  {
    if (paramObject == null) {
      return paramObject;
    }
    if (paramString.endsWith(b("\035\035"))) {
      paramString = paramString.substring(0, paramString.length() - 2);
    }
    Class localClass = null;
    try
    {
      localClass = Class.forName(paramString);
    }
    catch (Exception localException)
    {
      Log.a(cj.translate(cj.CANNOT_FIND_CLASS_TO_BUILD_RETURNED_ARRAY, paramString, localException));
      return null;
    }
    return coerceArray(paramObject, localClass);
  }
  
  public static Object coerceArray(Object paramObject, Class paramClass)
  {
    int j = Dispatch.H;
    if (paramObject == null) {
      return paramObject;
    }
    if (paramObject.getClass() != (h == null ? (MarshalStream.h = a(b(""))) : h)) {
      if (paramClass.isAssignableFrom(paramObject.getClass().getComponentType())) {
        return paramObject;
      }
    }
    Object localObject1 = Array.newInstance(paramClass, Array.getLength(paramObject));
    int i = 0;
    if (j != 0) {}
    do
    {
      do
      {
        Object localObject2 = Array.get(paramObject, i);
        if ((localObject2 instanceof Variant)) {
          localObject2 = ((Variant)localObject2).getVARIANT();
        }
        Array.set(localObject1, i, localObject2);
        i++;
      } while (i < Array.getLength(paramObject));
    } while (j != 0);
    return localObject1;
  }
  
  static Class a(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      64[105] = ((char)(0x5C ^ 0x4F));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.MarshalStream
 * JD-Core Version:    0.7.0.1
 */