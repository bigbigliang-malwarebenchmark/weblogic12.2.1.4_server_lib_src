package com.linar.jintegra;

import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.lang.reflect.Method;

public class MemberDesc
{
  String a;
  Class[] b;
  Param[] c;
  Member d;
  boolean e;
  int f;
  Method g;
  Constructor h;
  static Class i;
  
  public MemberDesc(String paramString, Class[] paramArrayOfClass, Param[] paramArrayOfParam)
  {
    this(paramString, 0, paramArrayOfClass, paramArrayOfParam, false);
  }
  
  public MemberDesc(String paramString, Class[] paramArrayOfClass, Param[] paramArrayOfParam, boolean paramBoolean)
  {
    this(paramString, 0, paramArrayOfClass, paramArrayOfParam, paramBoolean);
  }
  
  public MemberDesc(String paramString, int paramInt, Class[] paramArrayOfClass, Param[] paramArrayOfParam)
  {
    this(paramString, paramInt, paramArrayOfClass, paramArrayOfParam, false);
  }
  
  public MemberDesc(String paramString, int paramInt, Class[] paramArrayOfClass, Param[] paramArrayOfParam, boolean paramBoolean)
  {
    this.a = paramString;
    this.b = paramArrayOfClass;
    this.c = paramArrayOfParam;
    this.e = paramBoolean;
    this.f = paramInt;
  }
  
  public synchronized void resolve(Class paramClass, boolean paramBoolean)
    throws NoSuchMethodException, NoSuchFieldException
  {
    int k = Dispatch.H;
    if (!this.e)
    {
      this.d = paramClass.getMethod(this.a, this.b);
      if ((paramBoolean) && (this.b.length == 1) && (!this.b[0].isPrimitive())) {
        try
        {
          Class localClass = this.b[0];
          Class[] arrayOfClass = { i == null ? (MemberDesc.i = a(b("$\005oey$\035ieZ'\031k(a"))) : i };
          this.h = localClass.getConstructor(arrayOfClass);
          Method[] arrayOfMethod = this.b[0].getMethods();
          int j = 0;
          if (k != 0) {}
          do
          {
            do
            {
              if (arrayOfMethod[j].getName().equals(b("|+\032z")))
              {
                this.g = arrayOfMethod[j];
                return;
              }
              j++;
            } while (j < arrayOfMethod.length);
          } while (k != 0);
        }
        catch (NoSuchMethodException localNoSuchMethodException)
        {
          if (k == 0) {
            return;
          }
        }
      }
    }
    else
    {
      this.d = paramClass.getField(this.a);
    }
  }
  
  public String toString()
  {
    int k = Dispatch.H;
    if (this.b == null) {
      return this.a + "";
    }
    String str = this.a + "(";
    int j = 0;
    if (k != 0) {
      if (j != 0) {
        str = str + b("9e");
      }
    }
    do
    {
      str = str + this.b[j];
      j++;
      if (j < this.b.length) {
        break;
      }
    } while (k != 0);
    return str + ")";
  }
  
  static Class a(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int j = arrayOfChar.length;
    int k = 0;
    while (k < j)
    {
      switch (k % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      69[115] = ((char)(0xE ^ 0x4B));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.MemberDesc
 * JD-Core Version:    0.7.0.1
 */