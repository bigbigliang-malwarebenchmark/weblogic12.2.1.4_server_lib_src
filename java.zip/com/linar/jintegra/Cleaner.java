package com.linar.jintegra;

import java.io.PrintStream;

public abstract class Cleaner
{
  public static void releaseAll()
  {
    if (Dispatch.isNativeMode())
    {
      NativeObjRef.p();
      if (Dispatch.H == 0) {}
    }
    else
    {
      bm.d();
    }
    ch.a();
    Log.flush();
  }
  
  public static void trackObjectsInCurrentThread() {}
  
  public static void releaseAllInCurrentThread() {}
  
  public static void flushLog() {}
  
  public static int getActiveObjectCount()
  {
    return b.getCurrenyActiveObjects();
  }
  
  public static void reset() {}
  
  public static void release(Object paramObject)
  {
    int i = Dispatch.H;
    if ((paramObject instanceof Dispatch))
    {
      ((Dispatch)paramObject).h();
      if (i == 0) {}
    }
    else if ((paramObject instanceof StdObjRef))
    {
      ((StdObjRef)paramObject).release(null);
      if (i == 0) {}
    }
    else if ((paramObject instanceof RemoteObjRef))
    {
      ((RemoteObjRef)paramObject).release();
      if (i == 0) {}
    }
    else
    {
      throw new IllegalArgumentException(cj.translate(cj.OBJECT_TO_RELEASE_IS_NOT_REMOTE_OBJECT, paramObject));
    }
  }
  
  public static String getReleaseStackTraceFor(Object paramObject)
  {
    int i = Dispatch.H;
    StdObjRef localStdObjRef;
    if ((paramObject instanceof Dispatch))
    {
      localStdObjRef = ((Dispatch)paramObject).getObjRef();
      if (i == 0) {}
    }
    else if ((paramObject instanceof StdObjRef))
    {
      localStdObjRef = (StdObjRef)paramObject;
      if (i == 0) {}
    }
    else if ((paramObject instanceof RemoteObjRef))
    {
      localStdObjRef = ((RemoteObjRef)paramObject).getJintegraDispatch().getObjRef();
      if (i == 0) {}
    }
    else
    {
      throw new IllegalArgumentException(cj.translate(cj.OBJECT_IS_NOT_REMOTE_OBJECT, paramObject));
    }
    return localStdObjRef.e();
  }
  
  public static void addUnreferencedListener(Unreferenced paramUnreferenced)
  {
    ck.a(paramUnreferenced);
  }
  
  public static void removeUnreferencedListener(Unreferenced paramUnreferenced)
  {
    ck.b(paramUnreferenced);
  }
  
  public static void setObjectExportListener(ObjectExportChecker paramObjectExportChecker)
    throws SecurityException
  {
    if (paramObjectExportChecker != null) {
      Log.b(a("Ga!=Aaj/JpB&6Jgy\001$_k0\020Fwy!2Jv-'=Chh |Xmy,|") + paramObjectExportChecker + a("$%") + paramObjectExportChecker.getClass() + ")");
    }
    z.a(paramObjectExportChecker);
  }
  
  public static void clearCreatorThreadContextFor(Object paramObject)
  {
    if (paramObject == null) {
      return;
    }
    ObjectProxy localObjectProxy = z.b(paramObject);
    if (localObjectProxy == null)
    {
      Log.log(3, a("Jbd,]ku=|Ikd") + paramObject + a("$z,9A$n(9Nvd*;\017pe69N`-'3Aph<("));
      return;
    }
    localObjectProxy.b();
    Log.log(3, a("Ga!=]aid(Gvh%8\017gb*(J|yd:@v-") + paramObject);
  }
  
  public static void addConnectionListener(ConnectionListener paramConnectionListener)
  {
    bd.a(paramConnectionListener);
  }
  
  public static void removeConnectionListener(ConnectionListener paramConnectionListener)
  {
    bd.b(paramConnectionListener);
  }
  
  public static String sizes()
  {
    return z.a();
  }
  
  static void a(PrintStream paramPrintStream)
  {
    AuthInfo.a(paramPrintStream);
    e.a(paramPrintStream);
    ObjectProxy.a(paramPrintStream);
    Jvm.a(paramPrintStream);
    NativeObjectProxy.b(paramPrintStream);
    NativeObjRef.b(paramPrintStream);
    z.a(paramPrintStream);
    ObjectProxy.a(paramPrintStream);
    bc.a(paramPrintStream);
    bm.a(paramPrintStream);
    ch.a(paramPrintStream);
    StdObjRef.a(paramPrintStream);
    bd.a(paramPrintStream);
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      13[68] = ((char)(0x5C ^ 0x2F));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Cleaner
 * JD-Core Version:    0.7.0.1
 */