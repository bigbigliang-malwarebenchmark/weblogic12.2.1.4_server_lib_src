package com.linar.jintegra;

import java.io.Serializable;

public class IRpcCommonHeaderImpl
  implements IRpcCommonHeader, Serializable
{
  private int REQUEST = 0;
  private int RESPONSE = 0;
  private int FAULT = 0;
  private int BIND = 0;
  private int BIND_ACK = 0;
  private int BIND_NAK = 0;
  private int ALTER_CONTEXT = 0;
  private int ALTER_CONTEXT_RESP = 0;
  private int SECRET = 0;
  private int SHUTDOWN = 0;
  private int CO_CANCEL = 0;
  private int ORPHANED = 0;
  private int DREP_INTCHAR_FORMAT_BYTE = 0;
  private int DREP_FLOAT_FORMAT_BYTE = 0;
  private int DREP_CHAR_MASK = 0;
  private int DREP_ENDIAN_MASK = 0;
  private int DREP_ASCII = 0;
  private int DREP_EBCIDIC = 0;
  private int DREP_LITTLE_ENDIAN = 0;
  private int DREP_BIG_ENDIAN = 0;
  private int DREP_IEEE_FLOATS = 0;
  private int LENGTH = 0;
  private int RPC_VERSION_MAJOR = 0;
  private int RPC_VERSION_MINOR = 0;
  private int FLAG_FIRST_FRAG = 0;
  private int FLAG_LAST_FRAG = 0;
  private int FLAG_FIRST_AND_LAST_FRAG = 0;
  private int FLAG_NON_NULL_OID = 0;
  
  public int getValue(int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
      return this.REQUEST;
    case 1: 
      return this.RESPONSE;
    case 2: 
      return this.FAULT;
    case 3: 
      return this.BIND;
    case 4: 
      return this.BIND_ACK;
    case 5: 
      return this.BIND_NAK;
    case 6: 
      return this.ALTER_CONTEXT;
    case 7: 
      return this.ALTER_CONTEXT_RESP;
    case 8: 
      return this.SECRET;
    case 9: 
      return this.SHUTDOWN;
    case 10: 
      return this.CO_CANCEL;
    case 11: 
      return this.ORPHANED;
    case 12: 
      return this.DREP_INTCHAR_FORMAT_BYTE;
    case 13: 
      return this.DREP_FLOAT_FORMAT_BYTE;
    case 14: 
      return this.DREP_CHAR_MASK;
    case 15: 
      return this.DREP_ENDIAN_MASK;
    case 16: 
      return this.DREP_ASCII;
    case 17: 
      return this.DREP_EBCIDIC;
    case 18: 
      return this.DREP_LITTLE_ENDIAN;
    case 19: 
      return this.DREP_BIG_ENDIAN;
    case 20: 
      return this.DREP_IEEE_FLOATS;
    case 21: 
      return this.LENGTH;
    case 22: 
      return this.RPC_VERSION_MAJOR;
    case 23: 
      return this.RPC_VERSION_MINOR;
    case 24: 
      return this.FLAG_FIRST_FRAG;
    case 25: 
      return this.FLAG_LAST_FRAG;
    case 26: 
      return this.FLAG_FIRST_AND_LAST_FRAG;
    case 27: 
      return this.FLAG_NON_NULL_OID;
    }
    throw new RuntimeException("AAAA Shouldn't see this!!!");
  }
  
  public void setValue(int paramInt1, int paramInt2)
  {
    switch (paramInt1)
    {
    case 0: 
      this.REQUEST = paramInt2;
      return;
    case 1: 
      this.RESPONSE = paramInt2;
      return;
    case 2: 
      this.FAULT = paramInt2;
      return;
    case 3: 
      this.BIND = paramInt2;
      return;
    case 4: 
      this.BIND_ACK = paramInt2;
      return;
    case 5: 
      this.BIND_NAK = paramInt2;
      return;
    case 6: 
      this.ALTER_CONTEXT = paramInt2;
      return;
    case 7: 
      this.ALTER_CONTEXT_RESP = paramInt2;
      return;
    case 8: 
      this.SECRET = paramInt2;
      return;
    case 9: 
      this.SHUTDOWN = paramInt2;
      return;
    case 10: 
      this.CO_CANCEL = paramInt2;
      return;
    case 11: 
      this.ORPHANED = paramInt2;
      return;
    case 12: 
      this.DREP_INTCHAR_FORMAT_BYTE = paramInt2;
      return;
    case 13: 
      this.DREP_FLOAT_FORMAT_BYTE = paramInt2;
      return;
    case 14: 
      this.DREP_CHAR_MASK = paramInt2;
      return;
    case 15: 
      this.DREP_ENDIAN_MASK = paramInt2;
      return;
    case 16: 
      this.DREP_ASCII = paramInt2;
      return;
    case 17: 
      this.DREP_EBCIDIC = paramInt2;
      return;
    case 18: 
      this.DREP_LITTLE_ENDIAN = paramInt2;
      return;
    case 19: 
      this.DREP_BIG_ENDIAN = paramInt2;
      return;
    case 20: 
      this.DREP_IEEE_FLOATS = paramInt2;
      return;
    case 21: 
      this.LENGTH = paramInt2;
      return;
    case 22: 
      this.RPC_VERSION_MAJOR = paramInt2;
      return;
    case 23: 
      this.RPC_VERSION_MINOR = paramInt2;
      return;
    case 24: 
      this.FLAG_FIRST_FRAG = paramInt2;
      return;
    case 25: 
      this.FLAG_LAST_FRAG = paramInt2;
      return;
    case 26: 
      this.FLAG_FIRST_AND_LAST_FRAG = paramInt2;
      return;
    case 27: 
      this.FLAG_NON_NULL_OID = paramInt2;
      return;
    }
    throw new RuntimeException("AAAA Shouldn't see this!!!");
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.IRpcCommonHeaderImpl
 * JD-Core Version:    0.7.0.1
 */