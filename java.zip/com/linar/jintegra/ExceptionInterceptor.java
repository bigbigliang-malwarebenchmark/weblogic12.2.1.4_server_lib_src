package com.linar.jintegra;

public abstract interface ExceptionInterceptor
{
  public abstract AutomationException handleException(Throwable paramThrowable);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.ExceptionInterceptor
 * JD-Core Version:    0.7.0.1
 */