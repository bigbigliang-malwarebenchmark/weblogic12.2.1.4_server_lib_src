package com.linar.jintegra;

import com.linar.spi.CallerCredentials;
import java.io.PrintStream;
import java.net.InetAddress;
import java.util.Hashtable;

public class AuthInfo
{
  static final int a = 0;
  static final int b = 1;
  static final int c = 2;
  static final int d = 3;
  static final int e = 4;
  static final int f = 5;
  static final int g = 6;
  static final int h = 1;
  public static final int IMP_LEVEL_IDENTIFY = 2;
  public static final int IMP_LEVEL_IMPERSONATE = 3;
  public static final int IMP_LEVEL_DELEGATE = 4;
  private String i;
  private String j;
  private byte[] k;
  private byte[] l;
  private int m;
  private int n = 2;
  private boolean o = false;
  private static String p = ;
  private static int q = 2;
  private static AuthInfo r = null;
  private static Hashtable s = new Hashtable();
  private static Hashtable t = new Hashtable();
  
  public String toString()
  {
    return this.i + "/" + this.j;
  }
  
  public void disableLmResponse()
  {
    this.l = null;
  }
  
  String a()
  {
    return this.i;
  }
  
  String b()
  {
    return this.j;
  }
  
  boolean c()
  {
    return this.o;
  }
  
  static String d()
  {
    return p;
  }
  
  byte[] e()
  {
    return this.k;
  }
  
  byte[] f()
  {
    return this.l;
  }
  
  int g()
  {
    return this.m;
  }
  
  int h()
  {
    return this.n;
  }
  
  public AuthInfo(String paramString1, String paramString2, String paramString3)
  {
    this(paramString1, paramString2, paramString3, 2);
  }
  
  public AuthInfo(String paramString1, String paramString2, String paramString3, int paramInt)
    throws RuntimeException
  {
    if (Dispatch.isNativeMode()) {
      throw new RuntimeException(c("!!\007c`\024'nLs\017oH@\005,S\002v\001!IMa@-B\002v\022*FVp\004oNL5..SKc\005ojMq\005"));
    }
    this.i = paramString1;
    this.j = paramString2;
    this.k = a(paramString3);
    this.l = b(paramString3);
    this.m = paramInt;
  }
  
  AuthInfo(String paramString1, String paramString2, boolean paramBoolean)
  {
    this.i = paramString1;
    this.j = paramString2;
    this.o = paramBoolean;
  }
  
  static AuthInfo i()
  {
    AuthInfo localAuthInfo = (AuthInfo)s.get(Thread.currentThread());
    return localAuthInfo != null ? localAuthInfo : r;
  }
  
  static int j()
  {
    return q;
  }
  
  public static void setDefault(AuthInfo paramAuthInfo)
  {
    r = paramAuthInfo;
  }
  
  static void a(PrintStream paramPrintStream)
  {
    paramPrintStream.println(c("\024'UGt\004<sMT\025;Ok{\006 T\002f\t5B\002|\023o") + s.size());
    paramPrintStream.println(c("\024'UGt\004<sMV\001#KGg#=BFp\016;NCy\023oTKo\005oNQ5") + t.size());
  }
  
  public static void setThreadDefault(AuthInfo paramAuthInfo)
  {
    s.remove(Thread.currentThread());
    if (paramAuthInfo != null) {
      s.put(Thread.currentThread(), paramAuthInfo);
    }
  }
  
  static void a(CallerCredentials paramCallerCredentials)
  {
    t.remove(Thread.currentThread());
    if (paramCallerCredentials != null) {
      t.put(Thread.currentThread(), paramCallerCredentials);
    }
  }
  
  public static String getCallerDomain()
  {
    CallerCredentials localCallerCredentials = (CallerCredentials)t.get(Thread.currentThread());
    return localCallerCredentials == null ? null : localCallerCredentials.getCallerDomain();
  }
  
  public static String getCallerUser()
  {
    CallerCredentials localCallerCredentials = (CallerCredentials)t.get(Thread.currentThread());
    return localCallerCredentials == null ? null : localCallerCredentials.getCallerUser();
  }
  
  public static boolean isCallerAuthenticated()
  {
    CallerCredentials localCallerCredentials = (CallerCredentials)t.get(Thread.currentThread());
    return localCallerCredentials == null ? false : localCallerCredentials.isCallerAuthenticated();
  }
  
  public static void setDefaultImpLevel(int paramInt)
  {
    q = paramInt;
  }
  
  public static void setDefault(String paramString1, String paramString2, String paramString3)
  {
    if (Dispatch.isNativeMode())
    {
      NativeObjRef.nativeIntializeCOMSecurity(paramString1, paramString2, paramString3, q);
      if (Dispatch.H == 0) {}
    }
    else
    {
      setDefault(new AuthInfo(paramString1, paramString2, paramString3));
    }
  }
  
  public static void setThreadDefault(String paramString1, String paramString2, String paramString3)
  {
    setThreadDefault(new AuthInfo(paramString1, paramString2, paramString3));
  }
  
  private byte[] a(String paramString)
  {
    int i2 = Dispatch.H;
    byte[] arrayOfByte = new byte[paramString.length() * 2];
    int i1 = 0;
    if (i2 != 0) {
      arrayOfByte[(i1 * 2)] = ((byte)paramString.charAt(i1));
    }
    w localw;
    do
    {
      arrayOfByte[(i1 * 2 + 1)] = 0;
      i1++;
      if (i1 < paramString.length()) {
        break;
      }
      localw = new w();
      localw.a();
      localw.a(arrayOfByte, arrayOfByte.length);
    } while (i2 != 0);
    return localw.b();
  }
  
  private byte[] b(String paramString)
  {
    byte[] arrayOfByte1 = new byte[14];
    int i1 = paramString.length() < 14 ? paramString.length() : 14;
    System.arraycopy(paramString.toUpperCase().getBytes(), 0, arrayOfByte1, 0, i1);
    byte[] arrayOfByte2 = c("+\bt\003UCk\002").getBytes();
    byte[] arrayOfByte3 = new byte[16];
    System.arraycopy(PureAuth.a(arrayOfByte2, arrayOfByte1, 0), 0, arrayOfByte3, 0, 8);
    System.arraycopy(PureAuth.a(arrayOfByte2, arrayOfByte1, 7), 0, arrayOfByte3, 8, 8);
    return arrayOfByte3;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof AuthInfo)) {
      return false;
    }
    AuthInfo localAuthInfo = (AuthInfo)paramObject;
    return (this.i.equals(localAuthInfo.i)) && (this.j.equals(localAuthInfo.j));
  }
  
  public int hashCode()
  {
    return (this.i + this.j).hashCode();
  }
  
  static
  {
    if ((p == null) || (p.length() == 0))
    {
      p = c("\025!LLz\027!\007\n_\t!SGr\022.\016");
      try
      {
        p = InetAddress.getLocalHost().getHostName() + c("H\005\nk{\024*@PtI");
      }
      catch (Throwable localThrowable)
      {
        Log.a(cj.translate(cj.CANNOT_GET_LOCAL_HOST, localThrowable));
      }
    }
  }
  
  private static String c(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      79[39] = ((char)(0x22 ^ 0x15));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.AuthInfo
 * JD-Core Version:    0.7.0.1
 */