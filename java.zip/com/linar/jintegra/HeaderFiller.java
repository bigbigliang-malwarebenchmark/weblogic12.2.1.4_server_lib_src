package com.linar.jintegra;

public class HeaderFiller
{
  public IRpcCommonHeader getHeader()
  {
    IRpcCommonHeaderImpl localIRpcCommonHeaderImpl = new IRpcCommonHeaderImpl();
    localIRpcCommonHeaderImpl.setValue(0, 0);
    localIRpcCommonHeaderImpl.setValue(1, 2);
    localIRpcCommonHeaderImpl.setValue(2, 3);
    localIRpcCommonHeaderImpl.setValue(3, 11);
    localIRpcCommonHeaderImpl.setValue(4, 12);
    localIRpcCommonHeaderImpl.setValue(5, 13);
    localIRpcCommonHeaderImpl.setValue(6, 14);
    localIRpcCommonHeaderImpl.setValue(7, 15);
    localIRpcCommonHeaderImpl.setValue(8, 16);
    localIRpcCommonHeaderImpl.setValue(9, 17);
    localIRpcCommonHeaderImpl.setValue(10, 18);
    localIRpcCommonHeaderImpl.setValue(11, 19);
    localIRpcCommonHeaderImpl.setValue(12, 0);
    localIRpcCommonHeaderImpl.setValue(13, 0);
    localIRpcCommonHeaderImpl.setValue(14, 15);
    localIRpcCommonHeaderImpl.setValue(15, 240);
    localIRpcCommonHeaderImpl.setValue(16, 0);
    localIRpcCommonHeaderImpl.setValue(17, 1);
    localIRpcCommonHeaderImpl.setValue(18, 0);
    localIRpcCommonHeaderImpl.setValue(19, 16);
    localIRpcCommonHeaderImpl.setValue(20, 0);
    localIRpcCommonHeaderImpl.setValue(21, 16);
    localIRpcCommonHeaderImpl.setValue(22, 5);
    localIRpcCommonHeaderImpl.setValue(23, 0);
    localIRpcCommonHeaderImpl.setValue(24, 1);
    localIRpcCommonHeaderImpl.setValue(25, 2);
    localIRpcCommonHeaderImpl.setValue(26, 3);
    localIRpcCommonHeaderImpl.setValue(27, 128);
    return localIRpcCommonHeaderImpl;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.HeaderFiller
 * JD-Core Version:    0.7.0.1
 */