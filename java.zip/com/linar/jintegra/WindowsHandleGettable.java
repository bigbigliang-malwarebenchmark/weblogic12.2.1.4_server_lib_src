package com.linar.jintegra;

import java.awt.Canvas;

public abstract interface WindowsHandleGettable
{
  public abstract long getHandleForCanvas(Canvas paramCanvas);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.WindowsHandleGettable
 * JD-Core Version:    0.7.0.1
 */