package com.linar.jintegra;

public abstract interface D5F73474_B4DE_4f02_BDEB_ADAB1ABB5A7D {}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.D5F73474_B4DE_4f02_BDEB_ADAB1ABB5A7D
 * JD-Core Version:    0.7.0.1
 */