package com.linar.jintegra;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;

abstract class Rpc
  implements D5F73474_B4DE_4f02_BDEB_ADAB1ABB5A7D
{
  private static int a = 0;
  private static int b = 16;
  ch c;
  long d;
  AutomationException e;
  Uuid f = null;
  int g = 0;
  int h = 0;
  private byte[] i;
  private byte[] j;
  
  abstract int a();
  
  abstract String b();
  
  AutomationException c()
  {
    return this.e;
  }
  
  void a(Uuid paramUuid)
  {
    this.f = paramUuid;
  }
  
  void a(int paramInt1, int paramInt2)
  {
    this.g = paramInt1;
    this.h = paramInt2;
  }
  
  final void a(y paramy)
    throws IOException
  {
    if (this.g == 0) {
      throw new RuntimeException(cj.COM_VERSION_NOT_INITIALIZED_IN_RPC);
    }
    paramy.a(a("7l%\016^0w&m 7l%\016~\020W\006"));
    paramy.a(a(";q8\033O*m<\002DXH\020?y\021Q\033"));
    paramy.d(this.g, a("\ra\034#~I\b"), a("\025_\037\"x"));
    paramy.d(this.h, a("\ra\034#~I\b"), a("\025W\033\"x"));
    paramy.c();
    paramy.a(0L, a("\ra\034#~K\f"), a("\036R\024*y"));
    paramy.a(0L, a("\ra\034#~K\f"), a("\n[\006(x\016[\021|"));
    this.f = e.a(this.d, b());
    paramy.a(this.f, a("\033W\021"));
    paramy.a(0L, a("\ra\034#~K\f"), a("\035F\001(d\f\036\024?x\031GU=~\n\036\034)"));
    paramy.c();
  }
  
  private final void a(ch paramch, y paramy)
    throws IOException
  {
    c localc = paramch.c();
    if ((localc instanceof NullAuth)) {
      return;
    }
    paramy.b(true);
    paramy.a(a(""));
    long l = paramch.e();
    int k = paramy.b();
    paramy.d(b);
    k = paramy.b() - k;
    paramy.e(10, a("\ra\034#~@"), a("\031K\001%U\fG\005("));
    paramy.e(2, a("\ra\034#~@"), a("\031K\001%U\024[\003(f"));
    paramy.e(k, a("\ra\034#~@"), a("\031K\001%U\b_\021\022f\035P\0229b"));
    paramy.e(0, a("\ra\034#~@"), a("\031K\001%U\n[\006(x\016[\021"));
    paramy.a(l, a("\ra\034#~K\f"), a(""));
    byte[] arrayOfByte = new byte[16];
    arrayOfByte[0] = 1;
    paramy.a(arrayOfByte, 0, 16, a("9K\001%*.[\007$l\021[\007"));
    paramy.c();
  }
  
  void a(x paramx)
    throws IOException
  {
    int m = Dispatch.H;
    paramx.a(a("7l%\016^0!m 7l%\016~\020_\001"));
    long l1 = paramx.e(a("\ra\034#~K\f"), a("\036R\024*y"));
    long l2 = paramx.e(a("DN\001?*\021ZK"), a("\035F\001(d\013W\032#y"));
    if (l2 != 0L)
    {
      paramx.a(a(""));
      long l3 = paramx.e(a("\rP\006$m\026[\021mf\027P\022"), a("\013W\017("));
      paramx.e(a("\rP\006$m\026[\021mf\027P\022"), a("\n[\006(x\016[\021"));
      int k = 0;
      if (m != 0) {
        paramx.a(a("7l%\016U=f!\bD,"));
      }
      do
      {
        paramx.d(8);
        Uuid localUuid1 = k == 0 ? paramx.a(a("?k<\t"), a("\021Z")) : k.NULL_UUID;
        long l4 = paramx.e(a("\rP\006$m\026[\021mf\027P\022"), a("\013W\017("));
        Uuid localUuid2 = paramx.a(a("?k<\t"), a("\031P\0329b\035LU\004NG"));
        Log.log(3, a("") + localUuid1 + a("T\036\034)8B\036") + localUuid2);
        byte[] arrayOfByte;
        if (((localUuid1.equals(k.ERR_UUID1)) || (localUuid1.equals(k.ERR_UUID2)) || (localUuid1.equals(k.NULL_UUID))) && (localUuid2.equals(k.ERR_UUID3)))
        {
          arrayOfByte = new byte[(int)l4];
          paramx.a(arrayOfByte, null);
          a(paramx, arrayOfByte);
          if (m == 0) {}
        }
        else
        {
          paramx.e(a("\rP\006$m\026[\021mf\027P\022"), a("\013W\017("));
          arrayOfByte = new byte[(int)l4];
          paramx.a(arrayOfByte, a("\035F\001(d\013W\032#*\034_\001,"));
        }
        paramx.c();
        k++;
        if (k < l3) {
          break;
        }
        paramx.d(8);
      } while (m != 0);
      paramx.c();
    }
    paramx.c();
  }
  
  void a(x paramx, byte[] paramArrayOfByte)
    throws IOException
  {
    x localx = paramx.b(paramArrayOfByte);
    localx.b(true);
    StdObjRef localStdObjRef = new StdObjRef(false, false, localx);
    byte[] arrayOfByte = new byte[paramArrayOfByte.length - localx.b()];
    localx.a(arrayOfByte, a("\n[\0069*\027XU(r\f[\033>c\027PU)k\f_"));
    this.e = localStdObjRef.n();
  }
  
  boolean d()
  {
    return false;
  }
  
  byte[] e()
  {
    return this.i;
  }
  
  byte[] f()
  {
    return this.j;
  }
  
  void a(ch paramch, Uuid paramUuid1, long paramLong, Uuid paramUuid2)
    throws IOException
  {
    int i12 = Dispatch.H;
    if (!paramch.k) {
      throw new RuntimeException(cj.ATTEMPT_TO_USE_CONNECTION_HANDLER_NOT_IN_USE);
    }
    try
    {
      this.c = paramch;
      this.d = paramLong;
      paramch.c(paramUuid2);
      y localy = paramch.j();
      localy.b(true);
      localy.a(paramUuid1 == null ? 24 : 40);
      b(localy);
      this.i = localy.e();
      Vector localVector1 = new Vector();
      int k = paramch.f();
      int m = 1;
      int n = a + (paramUuid1 == null ? 0 : 16);
      int i1 = (paramch.c() instanceof NullAuth) ? 0 : 24;
      int i2 = k - n - i1;
      if (i1 != 0)
      {
        int i3 = b - (i2 + n) % b;
        i2 -= (i3 == b ? 0 : i3);
      }
      long l = paramch.h();
      Log.log(2, a("+[\033)c\026YU") + b() + a("XL\020<\035M\001a*\017W\001%**n6mi\031R\031mc\034\036") + l + a("XQ\033mc\bW\021m") + paramUuid1);
      int i4 = 0;
      if (i12 != 0) {}
      Object localObject1;
      do
      {
        do
        {
          int i5 = this.i.length - i4;
          int i6 = i5 > i2 ? i2 : i5;
          int i7 = i6 + n + i1;
          if (i1 != 0)
          {
            i8 = b - (i6 + n) % b;
            i7 += (i8 == b ? 0 : i8);
          }
          int i8 = i5 <= i2 ? 1 : 0;
          if ((m == 0) || (i8 == 0)) {
            if (m != 0)
            {
              Log.log(3, a("+[\033)c\026YU+c\nM\001ml\n_\022 o\026JU$dX") + b() + a("XL\020<\035M\001a*\017W\001%**n6mi\031R\031mc\034\036") + l);
              if (i12 == 0) {}
            }
            else if (i8 != 0)
            {
              Log.log(3, a("+[\033)c\026YU!k\013JU+x\031Y\030(d\f\036\034#*") + b() + a("XL\020<\035M\001a*\017W\001%**n6mi\031R\031mc\034\036") + l);
              if (i12 == 0) {}
            }
            else
            {
              Log.log(3, a("+[\033)c\026YU,*\036L\024*g\035P\001mc\026\036") + b() + a("XL\020<\035M\001a*\017W\001%**n6mi\031R\031mc\034\036") + l);
            }
          }
          int i9 = 0;
          localIRpcCommonHeader = (IRpcCommonHeader)InternalInstanciator.getObj(this);
          i9 |= (m != 0 ? localIRpcCommonHeader.getValue(24) : 0);
          i9 |= (i8 != 0 ? localIRpcCommonHeader.getValue(25) : 0);
          i9 |= (paramUuid1 != null ? localIRpcCommonHeader.getValue(27) : 0);
          m = 0;
          localObject1 = new ce(localIRpcCommonHeader.getValue(0), i9, l, i7, (paramch.c() instanceof NullAuth) ? 0 : 16);
          localy = paramch.j();
          ((ce)localObject1).a(localy);
          localy.a(this.i.length, a("\ra\034#~K\f"), a("\031R\031\"i'V\034#~"));
          localy.d(paramch.b(paramUuid2), a("\ba\026\"d\f[\r9U\021Z*9"), a("\ba\026\"d\f[\r9U\021Z"));
          localy.d(a(), a("\ra\034#~I\b"), a("\027N\0338g"));
          if (paramUuid1 != null) {
            localy.a(paramUuid1, a("7\\\037(i\f"));
          }
          localy.a(this.i, i4, i6, null);
          i4 += i6;
          localy.b(true);
          a(paramch, localy);
          paramch.a(localy.e());
          localy.a(localy.e());
        } while (i4 < this.i.length);
      } while (i12 != 0);
      if (d())
      {
        paramch.a(new Long(l));
        return;
      }
      Vector localVector2 = paramch.b(new Long(l));
      byte[] arrayOfByte = (byte[])localVector2.firstElement();
      x localx = paramch.b(arrayOfByte);
      boolean bool = localx.a();
      ce localce = new ce(localx);
      IRpcCommonHeader localIRpcCommonHeader = (IRpcCommonHeader)InternalInstanciator.getObj(this);
      if (localce.c() != localIRpcCommonHeader.getValue(1))
      {
        if (localce.c() == localIRpcCommonHeader.getValue(2))
        {
          localObject1 = new a(localx);
          localy.a(arrayOfByte);
          Object[] arrayOfObject = { Long.toString(((a)localObject1).a()), b(), Long.toString(l) };
          Log.a(cj.translate(cj.RPC_FAULT_RECEIVED, arrayOfObject));
          throw new AutomationException(((a)localObject1).a(), cj.INVOKE);
        }
        localObject1 = new Object[] { b(), Long.toString(l), Integer.toString(localce.c()) };
        Log.a(cj.translate(cj.RPC_PROTOCOL_ERROR, (Object[])localObject1));
        throw new RuntimeException(cj.translate(cj.EXPECTED_RESPONSE_BUT_GOT, Integer.toString(localce.c())));
      }
      Log.log(2, a("*[\026(c\016[\021m~\020[U?o\013N\032#y\035\036\001\"*") + b() + a("XL\020<\035M\001a*\017W\001%**n6mi\031R\031mc\034\036") + l);
      int i10 = (int)localx.e(a("\ra\034#~K\f"), a("\031R\031\"i'V\034#~"));
      localx.f(a("\ba\026\"d\f[\r9U\021Z*9"), a("\ba\026\"d\fa\034)"));
      localx.g(a("\ra\034#~@"), a("\033_\033.o\024a\026\"\026J"));
      localx.g(a("\ra\034#~@"), a("\n[\006(x\016[\021"));
      int i11 = localce.b();
      if (i11 != 0) {
        i11 += 8;
      }
      i11 += 24;
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(i10);
      Enumeration localEnumeration = localVector2.elements();
      if (i12 != 0) {
        arrayOfByte = (byte[])localEnumeration.nextElement();
      }
      do
      {
        localByteArrayOutputStream.write(arrayOfByte, 24, arrayOfByte.length - i11);
        if (localEnumeration.hasMoreElements()) {
          break;
        }
        this.j = localByteArrayOutputStream.toByteArray();
        localy.a(this.j);
        localx = paramch.a(this.j, bool);
        localx.b(true);
        b(localx);
      } while (i12 != 0);
    }
    finally
    {
      if ((paramLong != 0L) && (this.f != null)) {
        e.a(paramLong, b(), this.f);
      }
      ch.a(paramch);
    }
  }
  
  abstract void b(y paramy)
    throws IOException;
  
  abstract void b(x paramx)
    throws IOException;
  
  static
  {
    IRpcCommonHeader localIRpcCommonHeader = (IRpcCommonHeader)InternalInstanciator.getObj(new by());
    a = localIRpcCommonHeader.getValue(21) + 8;
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int k = arrayOfChar.length;
    int m = 0;
    while (m < k)
    {
      switch (m % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      62[117] = ((char)(0x4D ^ 0xA));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Rpc
 * JD-Core Version:    0.7.0.1
 */