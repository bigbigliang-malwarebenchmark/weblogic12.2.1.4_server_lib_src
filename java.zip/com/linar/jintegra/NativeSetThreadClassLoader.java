package com.linar.jintegra;

public class NativeSetThreadClassLoader
{
  private static ClassLoader a = ;
  
  public static void setClassLoader()
  {
    Thread.currentThread().setContextClassLoader(ClassLoader.getSystemClassLoader());
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.NativeSetThreadClassLoader
 * JD-Core Version:    0.7.0.1
 */