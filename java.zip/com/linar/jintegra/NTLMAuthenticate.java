package com.linar.jintegra;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class NTLMAuthenticate
{
  private Socket a;
  private short b = 0;
  PrintStream c = null;
  private String d;
  private static long e = 1L;
  static Class f;
  
  String a()
  {
    return this.d;
  }
  
  private byte[] a(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0)) {
      throw new RuntimeException(cj.translate(cj.INVALID_NAME, paramString));
    }
    if (paramString.length() > 16) {
      paramString = paramString.substring(0, 16);
    }
    paramString = paramString + c("{\001\b\036H{\001\b\036H{\001\b\036H{").substring(0, 16 - paramString.length());
    int i = 0;
    byte[] arrayOfByte = new byte[32];
    int j = 0;
    if (Dispatch.H != 0) {}
    while (j < paramString.length())
    {
      int k = (byte)paramString.charAt(j);
      int m = k & 0xF0;
      m >>= 4;
      m &= 0xF;
      m += 65;
      arrayOfByte[(i++)] = ((byte)(m & 0xFF));
      int n = k & 0xF;
      n += 65;
      arrayOfByte[(i++)] = ((byte)(0xFF & n));
      j++;
    }
    return arrayOfByte;
  }
  
  void a(y paramy, int paramInt)
    throws IOException
  {
    paramy.a(true);
    paramy.a(c("\025c|\036 >@L[\032"));
    paramy.c(paramInt, c("\016b`:"), c("\tDYK\r(U\bJ\021+D"));
    paramy.c(0, c("\016b`:"), c("\035MIY\033"));
    paramy.b(0, c("\016r`q:\017"), c("\013@KU\r/\001d[\006<U@\036@=HDR\r?\001APH7@\\[\032r"));
    paramy.c();
  }
  
  void a(byte[] paramArrayOfByte)
  {
    y.a(paramArrayOfByte, 2, paramArrayOfByte.length - 4, false);
  }
  
  void a(y paramy, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
    throws IOException
  {
    paramy.a(true);
    paramy.a(c("\blj\036 >@L[\032"));
    paramy.c(255, c("\016b`:"), c("\013SGJ\0078ND"));
    paramy.a(c("\blj"), c("\013SGJ\0078ND"));
    paramy.c(paramInt1, c("\016b`:"), c("\030NES\t5E"));
    paramy.a(0L, c("\016mgp/"), c("\bUIJ\035("));
    paramy.c(paramInt6, c("\016b`:"), c("\035MIY\033"));
    paramy.b(0, c("\016r`q:\017"), c("\035MIY\033i"));
    paramy.a(new byte[12], 0, 12, c("\013@LZ\0015F"));
    paramy.b(paramInt2, c("\016r`q:\017"), c("\017HL"));
    paramy.b(paramInt3, c("\016r`q:\017"), c("\013HL"));
    paramy.b(paramInt4, c("\016r`q:\017"), c("\016HL"));
    paramy.b(paramInt5, c("\016r`q:\017"), c("\026HL"));
    paramy.c();
  }
  
  void a(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (paramInt1 != 0) {
      paramArrayOfByte[36] = ((byte)(paramInt1 & 0xFF));
    }
    if (paramInt2 != 0) {
      y.a(paramArrayOfByte, 37 + paramInt1 * 2, paramInt2, true);
    }
  }
  
  public NTLMAuthenticate(String paramString)
    throws UnknownHostException, IOException
  {
    Log.log(3, c("\024QMP\0015F\b_H8NFP\r8UAQ\006{UG\036O") + paramString + c("|\001\\QH+DZX\007)L\b_\035/IMP\0342BIJ\0014O"));
    this.a = new Socket(paramString, 139);
    y localy = new y(false, this.c);
    localy.a(c("\br\022\036;>RAQ\006{sMO\035>R\\"));
    a(localy, 129);
    byte[] arrayOfByte = a(c("qre|;\036s~{:"));
    localy.c(32, c("\016r`q:\017"), c("\030@DR\r?oIS\r{mMP\017/I"));
    localy.a(arrayOfByte, 0, arrayOfByte.length, c(""));
    localy.c(0, c("\016b`:"), c("\017DZS\0015@\\Q\032"));
    Log.log(3, c("\030@DR\r?\001F_\005>\033\b\024;\026c{{:\rdz"));
    Object localObject1 = AuthInfo.d();
    arrayOfByte = a((String)localObject1);
    localy.c(32, c("\016r`q:\017"), c("\030@DR\0015F\bp\t6D\br\r5F\\V"));
    localy.a(arrayOfByte, 0, arrayOfByte.length, c("\030@DR\0015F\bp\t6D\b\026") + (String)localObject1 + ")");
    localy.c(0, c("\016b`:"), c("\017DZS\0015@\\Q\032"));
    Log.log(3, c("\030@DR\0015F\bP\t6D\022\036") + (String)localObject1);
    localy.c();
    arrayOfByte = localy.e();
    a(arrayOfByte);
    if (this.c != null) {
      NDRStream.a(arrayOfByte, arrayOfByte.length, this.c);
    }
    this.a.getOutputStream().write(arrayOfByte);
    localObject1 = new x(false, this.a.getInputStream(), this.c);
    ((NDRStream)localObject1).a(c("\br\022\036;>R[W\0075\001z[\033+NFM\r"));
    ((NDRStream)localObject1).a(c("\025c|\036 >@L[\032"));
    int i = ((x)localObject1).d(c("\016b`:"), c("\013@KU\r/\001\\G\030>"));
    int j = ((x)localObject1).d(c("\016b`:"), c("\013@KU\r/\001NR\t<R"));
    int k = ((x)localObject1).c(c("\bIGL\034"), c("\013@KU\r/\001d[\006<U@"));
    ((NDRStream)localObject1).c();
    ((NDRStream)localObject1).c();
    if ((i & 0xFF) != 130) {
      throw new IOException(cj.translate(cj.NBT_SESSION_REQUEST_FAILED, Integer.toString(i)));
    }
    synchronized (f == null ? (NTLMAuthenticate.f = b(c("8NE\020\0042OILF1HFJ\r<SI\020&\017me\035/IMP\0342BIJ\r"))) : f)
    {
      this.b = ((short)(int)e++);
    }
  }
  
  public NTLMAuthenticate(String paramString1, String paramString2)
    throws UnknownHostException, IOException
  {
    Log.log(3, c("\024QMP\0015F\b_H8NFP\r8UAQ\006{UG\036O") + paramString2 + c("|\001\\QH+DZX\007)L\b_\035/IMP\0342BIJ\0014O"));
    this.a = new Socket(paramString2, 139);
    y localy = new y(false, this.c);
    localy.a(c("\br\022\036;>RAQ\006{sMO\035>R\\"));
    a(localy, 129);
    byte[] arrayOfByte = a(c("qre|;\036s~{:"));
    localy.c(32, c("\016r`q:\017"), c("\030@DR\r?oIS\r{mMP\017/I"));
    localy.a(arrayOfByte, 0, arrayOfByte.length, c(""));
    localy.c(0, c("\016b`:"), c("\017DZS\0015@\\Q\032"));
    Log.log(3, c("\030@DR\r?\001F_\005>\033\b\024;\026c{{:\rdz"));
    if (paramString1 != null)
    {
      localObject1 = paramString1;
      if (Dispatch.H == 0) {}
    }
    else
    {
      localObject1 = AuthInfo.d();
    }
    arrayOfByte = a((String)localObject1);
    localy.c(32, c("\016r`q:\017"), c("\030@DR\0015F\bp\t6D\br\r5F\\V"));
    localy.a(arrayOfByte, 0, arrayOfByte.length, c("\030@DR\0015F\bp\t6D\b\026") + (String)localObject1 + ")");
    localy.c(0, c("\016b`:"), c("\017DZS\0015@\\Q\032"));
    Log.log(3, c("\030@DR\0015F\bP\t6D\022\036") + (String)localObject1);
    localy.c();
    arrayOfByte = localy.e();
    a(arrayOfByte);
    if (this.c != null) {
      NDRStream.a(arrayOfByte, arrayOfByte.length, this.c);
    }
    this.a.getOutputStream().write(arrayOfByte);
    Object localObject1 = new x(false, this.a.getInputStream(), this.c);
    ((NDRStream)localObject1).a(c("\br\022\036;>R[W\0075\001z[\033+NFM\r"));
    ((NDRStream)localObject1).a(c("\025c|\036 >@L[\032"));
    int i = ((x)localObject1).d(c("\016b`:"), c("\013@KU\r/\001\\G\030>"));
    int j = ((x)localObject1).d(c("\016b`:"), c("\013@KU\r/\001NR\t<R"));
    int k = ((x)localObject1).c(c("\bIGL\034"), c("\013@KU\r/\001d[\006<U@"));
    ((NDRStream)localObject1).c();
    ((NDRStream)localObject1).c();
    if ((i & 0xFF) != 130) {
      throw new IOException(cj.translate(cj.NBT_SESSION_REQUEST_FAILED, Integer.toString(i)));
    }
    synchronized (f == null ? (NTLMAuthenticate.f = b(c("8NE\020\0042OILF1HFJ\r<SI\020&\017me\035/IMP\0342BIJ\r"))) : f)
    {
      this.b = ((short)(int)e++);
    }
  }
  
  byte[] b()
    throws IOException
  {
    int i7 = Dispatch.H;
    y localy = new y(false, this.c);
    localy.a(c("\030\001F[\0174UA_\034>"));
    a(localy, 0);
    a(localy, 114, 0, 0, 0, 1537, 0);
    localy.c(0, c("\016b`:"), c("\fNZZ+4TFJ"));
    localy.b(12, c("\016r`q:\017"), c("\031X\\[+4TFJ"));
    localy.a(c("Yo|\036$\026\001\030\020Yi!"), c("\037HIR\r8U"));
    localy.c();
    byte[] arrayOfByte1 = localy.e();
    a(arrayOfByte1);
    if (this.c != null) {
      NDRStream.a(arrayOfByte1, arrayOfByte1.length, this.c);
    }
    this.a.getOutputStream().write(arrayOfByte1);
    this.a.getOutputStream().flush();
    x localx = new x(false, this.a.getInputStream(), this.c);
    localx.a(c("\t\001F[\0174UA_\034>"));
    localx.a(c("\025c|\036 >@L[\032"));
    int i = localx.d(c("\016b`:"), c("\013@KU\r/\001\\G\030>"));
    int j = localx.d(c("\016b`:"), c("\013@KU\r/\001NR\t<R"));
    int k = localx.c(c("\bIGL\034"), c("\013@KU\r/\001d[\006<U@"));
    localx.c();
    if (i != 0) {
      throw new IOException(cj.translate(cj.NEGOTIATE_REQUEST_FAILED, i));
    }
    localx.a(true);
    int m = localx.d(c("\016b`:"), c("\013SGJ\0078ND\036;/@ZJ"));
    String str = localx.a(3, c("\013SGJ\0078ND"));
    if ((m != -1) || (!str.equals(c("\blj")))) {
      throw new IOException(cj.translate(cj.INVALID_RESPONSE_TO_NEGOTIATE_REQUEST, Integer.toString(m), str));
    }
    int n = localx.d(c("\016b`:"), c("\030NES\t5E\b}\007?D"));
    long l = localx.e(c("\016mgp/"), c("\bUIJ\035("));
    int i1 = localx.d(c("\016b`:"), c("\035MIY\033"));
    int i2 = localx.c(c("\016r`q:\017"), c("\035MIY\033i"));
    localx.a(new byte[12], c("\013@LZ\0015F"));
    localx.c(c("\016r`q:\017"), c("\017HL"));
    localx.c(c("\016r`q:\017"), c("\013HL"));
    localx.c(c("\016r`q:\017"), c("\016HL"));
    int i3 = localx.c(c("\016r`q:\017"), c("\026HL"));
    int i4 = localx.d(c("\016b`:"), c("\fNZZ+4TFJ"));
    localx.c(c("\016r`q:\017"), c("\037HIR\r8UaP\f>Y"));
    localx.d(c("\016re$\027"), c("\bDKK\0322UQs\007?D"));
    localx.c(c("\016r`q:\017"), c("\026@Ps\030#bGK\006/"));
    localx.c(c("\016r`q:\017"), c("\026@Pp\0356CML>8R"));
    localx.b(c("\016mgp/"), c("\026@P|\035=GML;2[M"));
    localx.b(c("\016mgp/"), c("\026@Pl\t,rAD\r"));
    localx.b(c("\016mgp/"), c("\bD[M\0014Oc[\021"));
    localx.b(c("\016mgp/"), c("\030@X_\n2MAJ\001>R"));
    localx.b(c("\016mgp/"), c("\bX[J\r6uAS\r\027N_"));
    localx.b(c("\016mgp/"), c("\bX[J\r6uAS\r\023HOV"));
    localx.c(c("\016r`q:\017"), c("\bDZH\r)uAS\r\001NF["));
    localx.d(c("\016re$\027"), c("\036OKL\021+UAQ\006\020DQr\r5F\\V"));
    int i5 = localx.c(c("\016r`q:\017"), c("\031X\\[+4TFJ"));
    int i6 = localx.b() + i5;
    byte[] arrayOfByte2 = new byte[8];
    localx.a(arrayOfByte2, c("\036OKL\021+UAQ\006\020DQ"));
    if (i5 > 8) {
      this.d = localx.f(c("?NE_\0015"));
    }
    byte[] arrayOfByte3 = new byte[i6 - localx.b()];
    localx.a(arrayOfByte3, c(")DE_\0015HFY"));
    localx.c();
    if (Log.r) {
      Dispatch.H = ++i7;
    }
    return arrayOfByte2;
  }
  
  synchronized void c()
  {
    if (this.a != null)
    {
      try
      {
        this.a.close();
      }
      catch (IOException localIOException) {}
      this.a = null;
    }
  }
  
  synchronized boolean a(String paramString1, String paramString2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws IOException
  {
    try
    {
      y localy = new y(false, this.c);
      localy.a(c("\030\001[[\033(HGPH(D\\K\030{\007\bf"));
      a(localy, 0);
      a(localy, 115, 0, 0, 0, 1537, 16);
      localy.c(13, c("\016b`:"), c("\fNZZ+4TFJ"));
      localy.a(c("\fNZZH\013@Z_\005>UML\033"));
      localy.c(255, c("\016b`:"), c("\032OLf+4LE_\006?"));
      localy.c(0, c("\016b`:"), c("\032OLf:>RML\036>E"));
      localy.b(144, c("\016r`q:\017"), c("\032OLf)5Epq\016=RMJ:>RML\036>E"));
      localy.b(2920, c("\016r`q:\017"), c("\026@P|\035=GML;2[M"));
      localy.b(50, c("\016r`q:\017"), c("\026@Ps\030#bGK\006/"));
      localy.b(1, c("\016r`q:\017"), c("\rBfK\0059DZ"));
      localy.a(0, c("\016mgp/"), c("\bD[M\0014Oc[\021"));
      localy.b(paramArrayOfByte1.length, c("\016r`q:\017"), c("\030@[[!5RMP\0332UAH\r\013@[M\0374SLr\r5F\\V"));
      localy.b(paramArrayOfByte2.length, c("\016r`q:\017"), c("\030@[[;>O[W\0342WMn\t(R_Q\032?mMP\017/I"));
      localy.a(0, c("\016mgp/"), c("\tD[[\032-DL"));
      localy.a(5, c("\016mgp/"), c("\030@X_\n2MAJ\001>R"));
      localy.c();
      localy.b(0, c("\016r`q:\017"), c("\031X\\[+4TFJHsGAR\004>E\bW\006{MIJ\r)\b"));
      int i = localy.b();
      localy.a(c("\031X\\[H\013@Z_\005>UML\033"));
      localy.a(paramArrayOfByte2, 0, paramArrayOfByte2.length, c("\030@[[!5RMP\0332UAH\r\013@[M\0374SL"));
      localy.a(paramArrayOfByte1, 0, paramArrayOfByte1.length, c("\030@[[;>O[W\0342WMn\t(R_Q\032?"));
      localy.a(paramString2 + "", c("\032BKQ\0355Uf_\005>"));
      if ((paramString1 == null) || (paramString1.length() == 0)) {
        paramString1 = "?";
      }
      localy.a(paramString1 + "", c("\013SAS\t)XlQ\005:HF"));
      localy.a(c("\021@^_H\rHZJ\035:M\bs\t8IAP\r["), c("\025@\\W\036>n{"));
      localy.a(c("\021\faP\034>FZ_h"), c("\025@\\W\036>mIP%:O"));
      localy.c();
      localy.c();
      byte[] arrayOfByte = localy.e();
      a(arrayOfByte, 13, arrayOfByte.length - i);
      a(arrayOfByte);
      if (this.c != null) {
        NDRStream.a(arrayOfByte, arrayOfByte.length, this.c);
      }
      this.a.getOutputStream().write(arrayOfByte);
      this.a.getOutputStream().flush();
      x localx = new x(false, this.a.getInputStream(), this.c);
      localx.a(c("\t\001{[\033(HGPH\bD\\K\030"));
      localx.a(c("\025c|\036 >@L[\032"));
      int j = localx.d(c("\016b`:"), c("\013@KU\r/\001\\G\030>"));
      int k = localx.d(c("\016b`:"), c("\013@KU\r/\001NR\t<R"));
      int m = localx.c(c("\bIGL\034"), c("\013@KU\r/\001d[\006<U@"));
      localx.c();
      int n = localx.d(c("\016b`:"), c("\013SGJ\0078ND\036;/@ZJ"));
      String str = localx.a(3, c("\013SGJ\0078ND"));
      if ((n != -1) || (!str.equals(c("\blj")))) {
        throw new IOException(cj.translate(cj.INVALID_RESPONSE_TO_NEGOTIATE_REQUEST, Integer.toString(n), str));
      }
      int i1 = localx.d(c("\016b`:"), c("\030NES\t5E\b}\007?D"));
      long l = localx.e(c("\016mgp/"), c("\bUIJ\035("));
      boolean bool = l == 0L;
      return bool;
    }
    finally
    {
      this.a.close();
      this.a = null;
    }
  }
  
  public static void validate(String paramString1, String paramString2, String paramString3, String paramString4)
    throws IOException
  {
    NTLMAuthenticate localNTLMAuthenticate = new NTLMAuthenticate(paramString1);
    Log.log(3, c("?NE_\0015\001AMH") + paramString2);
    Log.log(3, c(".RMLH2R\b") + paramString3);
    byte[] arrayOfByte = localNTLMAuthenticate.b();
    c localc = c.a(new AuthInfo(paramString2, paramString3, paramString4));
    if ((localc instanceof PureAuth))
    {
      PureAuth localPureAuth = (PureAuth)localc;
      boolean bool = localNTLMAuthenticate.a(paramString2, paramString3, localPureAuth.ntResponseForChallenge(arrayOfByte), localPureAuth.a(arrayOfByte));
      if (!bool)
      {
        Log.log(3, c("\025uds).U@[\006/HK_\034>\001N_\0017DL\036E{HFH\t7HL\036\f4LIW\006tT[[\032tQIM\033,NZZF"));
        throw new SecurityException(cj.DOMAIN_USER_PASSWORD_INCORRECT);
      }
    }
    else
    {
      Log.log(3, c(""));
      throw new RuntimeException(cj.UNABLE_TO_ESTABLISH_PURE_AUTH);
    }
    Log.log(3, c("\025uds).U@[\006/HK_\034>\001[K\0138DMZ\r?\017"));
  }
  
  public static void validate(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws IOException
  {
    NTLMAuthenticate localNTLMAuthenticate = new NTLMAuthenticate(paramString1, paramString2);
    Log.log(3, c("?NE_\0015\001AMH") + paramString3);
    Log.log(3, c(".RMLH2R\b") + paramString4);
    byte[] arrayOfByte = localNTLMAuthenticate.b();
    c localc = c.a(new AuthInfo(paramString3, paramString4, paramString5));
    if ((localc instanceof PureAuth))
    {
      PureAuth localPureAuth = (PureAuth)localc;
      boolean bool = localNTLMAuthenticate.a(paramString3, paramString4, localPureAuth.ntResponseForChallenge(arrayOfByte), localPureAuth.a(arrayOfByte));
      if (!bool)
      {
        Log.log(3, c("\025uds).U@[\006/HK_\034>\001N_\0017DL\036E{HFH\t7HL\036\f4LIW\006tT[[\032tQIM\033,NZZF"));
        throw new SecurityException(cj.DOMAIN_USER_PASSWORD_INCORRECT);
      }
    }
    else
    {
      Log.log(3, c(""));
      throw new RuntimeException(cj.UNABLE_TO_ESTABLISH_PURE_AUTH);
    }
    Log.log(3, c("\025uds).U@[\006/HK_\034>\001[K\0138DMZ\r?\017"));
  }
  
  static Class b(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  private static String c(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      33[40] = ((char)(0x3E ^ 0x68));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.NTLMAuthenticate
 * JD-Core Version:    0.7.0.1
 */