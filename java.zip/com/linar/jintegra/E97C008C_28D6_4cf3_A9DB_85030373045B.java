package com.linar.jintegra;

public abstract interface E97C008C_28D6_4cf3_A9DB_85030373045B {}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.E97C008C_28D6_4cf3_A9DB_85030373045B
 * JD-Core Version:    0.7.0.1
 */