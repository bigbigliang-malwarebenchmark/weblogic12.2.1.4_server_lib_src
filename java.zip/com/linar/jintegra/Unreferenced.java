package com.linar.jintegra;

public abstract interface Unreferenced
{
  public abstract void objectUnreferenced(Object paramObject);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Unreferenced
 * JD-Core Version:    0.7.0.1
 */