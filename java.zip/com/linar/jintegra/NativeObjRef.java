package com.linar.jintegra;

import java.awt.Canvas;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Hashtable;

class NativeObjRef
  extends StdObjRef
{
  public int gitCookie;
  public long ptr;
  public long attachedToCanvas;
  public long windowHandleOfCreatedControl;
  private static Hashtable q = new Hashtable();
  private static Hashtable r = new Hashtable();
  private static boolean s = false;
  int t = 0;
  private boolean u = false;
  private static boolean v = false;
  private static final int w = 2;
  private static final int x = 0;
  private static final int y = 4;
  private static final int z = 8;
  private static int A = 0;
  private static boolean B = false;
  private static boolean C = bi.l();
  private static boolean D = bi.n();
  private static boolean E = false;
  static Hashtable F = new Hashtable();
  
  static void b(PrintStream paramPrintStream)
  {
    paramPrintStream.println(c("=D\t+`&E\020v0 B\001`0:X[") + F.size());
    paramPrintStream.println(c("=D\t+~2_\022su\024B\017Jr9N\030qcsX\022usB\b%") + q.size());
    paramPrintStream.println(c("=J\017lf6{\017w_1A\036fd \005\013p~8X[vy)N[lcs") + r.size());
  }
  
  private static synchronized void a(NativeObjRef paramNativeObjRef)
  {
    int i = Dispatch.H;
    Log.log(3, c("\001N\026jf6m\tj}\034I\021`s'g\022vd \013\024k0") + paramNativeObjRef);
    if (paramNativeObjRef.ptr != 0L)
    {
      Long localLong = new Long(paramNativeObjRef.ptr);
      Integer localInteger = (Integer)r.get(localLong);
      if (localInteger == null) {
        return;
      }
      localInteger = new Integer(localInteger.intValue() + -1);
      Log.log(3, c("\001N\026jf6m\tj}\034I\021`s'g\022vd \013\024k0#_\t% +") + Long.toHexString(localLong.longValue()) + c("sE\036r00D\016kdsB\b%") + localInteger);
      if (localInteger.intValue() > 0)
      {
        r.put(localLong, localInteger);
        if (i == 0) {}
      }
      else
      {
        r.remove(localLong);
        if (i == 0) {}
      }
    }
    else
    {
      Log.log(3, c("\001N\026jf6m\tj}\034I\021`s'g\022vd \013\024k04B\017%") + paramNativeObjRef.gitCookie);
      q.remove(new Integer(paramNativeObjRef.gitCookie));
    }
  }
  
  private static synchronized void b(NativeObjRef paramNativeObjRef)
  {
    if (s) {
      return;
    }
    if (paramNativeObjRef.ptr != 0L)
    {
      Long localLong = new Long(paramNativeObjRef.ptr);
      Integer localInteger = (Integer)r.get(localLong);
      if (localInteger == null) {
        localInteger = new Integer(0);
      }
      localInteger = new Integer(localInteger.intValue() + 1);
      Log.log(3, c("2O\037Q\034I\021`s'g\022vd \013\024k0#_\t% +") + Long.toHexString(localLong.longValue()) + c("sE\036r00D\016kdsB\b%") + localInteger);
      r.put(localLong, localInteger);
      if (Dispatch.H == 0) {}
    }
    else
    {
      Log.log(3, c("2O\037Q\034I\021`s'g\022vd \013\024k04B\017%") + paramNativeObjRef.gitCookie + c("sB\022a0:X[") + paramNativeObjRef.iid);
      q.put(new Integer(paramNativeObjRef.gitCookie), paramNativeObjRef.iid);
    }
  }
  
  public NativeObjRef(String paramString, int paramInt, long paramLong)
  {
    super(paramString == null ? null : new Uuid(paramString));
    this.gitCookie = paramInt;
    this.ptr = paramLong;
    this.attachedToCanvas = 0L;
    this.windowHandleOfCreatedControl = 0L;
    b(this);
  }
  
  NativeObjRef(String paramString1, Uuid paramUuid, String paramString2, boolean paramBoolean)
  {
    super(paramUuid);
    this.attachedToCanvas = 0L;
    this.windowHandleOfCreatedControl = 0L;
    if (s) {
      throw new RuntimeException(cj.ATTEMPT_TO_INVOKE_METHOD_AFTER_ALL_OBJS_RELEASED);
    }
    if (!v) {
      throw new RuntimeException(cj.CANNOT_USE_NATIVE_CODE_AS_INIT_FAILED);
    }
    if (!paramBoolean)
    {
      init(paramString1, paramUuid + "");
      if (Dispatch.H == 0) {}
    }
    else
    {
      initForGetActiveObject(paramString2, paramUuid + "");
    }
    b(this);
    super.checkToTrack();
  }
  
  NativeObjRef(String paramString1, String paramString2, String paramString3, AuthInfo paramAuthInfo)
  {
    super(new Uuid(paramString2));
    String str;
    if (s)
    {
      str = cj.ATTEMPT_TO_INVOKE_METHOD_AFTER_ALL_OBJS_RELEASED;
      Log.a(str);
      throw new RuntimeException(str);
    }
    if (!v)
    {
      str = cj.CANNOT_USE_NATIVE_CODE_AS_INIT_FAILED;
      Log.a(str);
      throw new RuntimeException(str);
    }
    if (paramString3.toLowerCase().equals(c("?D\030d|;D\bq"))) {
      paramString3 = null;
    }
    this.attachedToCanvas = 0L;
    this.windowHandleOfCreatedControl = 0L;
    init(paramString1, paramString2, paramString3, paramAuthInfo);
    b(this);
    super.checkToTrack();
  }
  
  NativeObjRef(String paramString, long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super(k.IID_IUNKNOWN);
    if (s) {
      throw new RuntimeException(cj.ATTEMPT_TO_INVOKE_METHOD_AFTER_ALL_OBJS_RELEASED);
    }
    if (!v) {
      throw new RuntimeException(cj.CANNOT_USE_NATIVE_CODE_AS_INIT_FAILED);
    }
    this.attachedToCanvas = paramLong;
    this.windowHandleOfCreatedControl = init(paramString, paramLong, paramInt1, paramInt2, paramInt3, paramInt4);
    b(this);
    super.checkToTrack();
  }
  
  native int nativeGetHashCode();
  
  public int hashCode()
  {
    if (this.t != 0) {
      return this.t;
    }
    this.t = nativeGetHashCode();
    return this.t;
  }
  
  public boolean equals(Object paramObject)
  {
    if (s) {
      throw new RuntimeException(cj.ATTEMPT_TO_INVOKE_METHOD_AFTER_ALL_OBJS_RELEASED);
    }
    NativeObjRef localNativeObjRef = null;
    if (paramObject == null) {
      return false;
    }
    if ((paramObject instanceof NativeObjRef)) {
      localNativeObjRef = (NativeObjRef)paramObject;
    } else if ((paramObject instanceof Dispatch)) {
      localNativeObjRef = (NativeObjRef)((Dispatch)paramObject).getObjRef();
    } else if ((paramObject instanceof RemoteObjRef)) {
      localNativeObjRef = (NativeObjRef)((RemoteObjRef)paramObject).getJintegraDispatch().getObjRef();
    }
    if (localNativeObjRef == null) {
      return false;
    }
    if (localNativeObjRef.u) {
      return false;
    }
    return nativeEquals(localNativeObjRef);
  }
  
  native String nativeGetObjrefMonikerDisplayName();
  
  native void nativeGetIdsOfNames(Rpc paramRpc);
  
  native void nativeIDispatchInvoke(Rpc paramRpc);
  
  static native String getObject(String paramString);
  
  private native void init(String paramString1, String paramString2);
  
  private native void init(String paramString1, String paramString2, String paramString3, AuthInfo paramAuthInfo);
  
  private native long init(String paramString, long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  private native void initForGetActiveObject(String paramString1, String paramString2);
  
  native void reparentControl(Canvas paramCanvas, long paramLong1, long paramLong2);
  
  native void resizeControl(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  static native void attachControlToWindow(NativeObjRef paramNativeObjRef, Canvas paramCanvas, long paramLong);
  
  static native long getJdk13WindowsHandle(Canvas paramCanvas);
  
  native void nativeVtblInvoke(Rpc paramRpc, byte[] paramArrayOfByte, String paramString1, int paramInt1, String paramString2, Param[] paramArrayOfParam, Object[] paramArrayOfObject, int paramInt2);
  
  native NativeObjRef nativeQueryInterface(String paramString);
  
  native void nativeRelease(AuthInfo paramAuthInfo);
  
  native boolean nativeEquals(NativeObjRef paramNativeObjRef);
  
  native void nativeFindConnectionPoint(Rpc paramRpc);
  
  native void nativeAdvise(Rpc paramRpc);
  
  native void nativeUnAdvise(Rpc paramRpc);
  
  static native NativeObjRef nativeGetMTSObjectContext();
  
  static native void nativeInitializeThreadCOM(int paramInt);
  
  static native void nativeIntializeCOMSecurity(String paramString1, String paramString2, String paramString3, int paramInt);
  
  void a(Rpc paramRpc, Uuid paramUuid, AuthInfo paramAuthInfo)
    throws IOException
  {
    if (s) {
      throw new RuntimeException(cj.ATTEMPT_TO_INVOKE_METHOD_AFTER_ALL_OBJS_RELEASED);
    }
    if (this.u) {
      throw new RuntimeException(cj.ATTEMPT_TO_INVOKE_METHOD_AFTER_RELEASED);
    }
    if ((paramRpc instanceof Request))
    {
      Request localRequest = (Request)paramRpc;
      nativeVtblInvoke(paramRpc, paramUuid.a(), paramUuid.toString(), paramRpc.a(), paramRpc.b(), localRequest.paramTypes, localRequest.paramValues, localRequest.paramValues.length);
      return;
    }
    if ((paramRpc instanceof GetIdsOfNames))
    {
      nativeGetIdsOfNames(paramRpc);
      return;
    }
    if ((paramRpc instanceof Invoke))
    {
      nativeIDispatchInvoke(paramRpc);
      return;
    }
    if ((paramRpc instanceof FindConnectionPoint))
    {
      nativeFindConnectionPoint(paramRpc);
      return;
    }
    if ((paramRpc instanceof Advise))
    {
      nativeAdvise(paramRpc);
      return;
    }
    if ((paramRpc instanceof UnAdvise))
    {
      nativeUnAdvise(paramRpc);
      return;
    }
    throw new RuntimeException(cj.translate(cj.UNIMPLEMENTED_INVOCATION, paramRpc.getClass()));
  }
  
  public String toString()
  {
    Object localObject = NativeObjectProxy.objectFor(this.ptr);
    if (localObject != null) {
      return localObject.toString();
    }
    Object[] arrayOfObject = { this.iid, Long.toHexString(this.ptr), Integer.toString(this.gitCookie) };
    return cj.translate(cj.NATIVE_OBJECT_REF_VIA_IID, arrayOfObject);
  }
  
  StdObjRef a(Uuid paramUuid, AuthInfo paramAuthInfo)
    throws IOException
  {
    if (s) {
      throw new RuntimeException(cj.ATTEMPT_TO_INVOKE_METHOD_AFTER_ALL_OBJS_RELEASED);
    }
    if (this.u) {
      throw new RuntimeException(cj.ATTEMPT_TO_INVOKE_METHOD_AFTER_RELEASED);
    }
    return nativeQueryInterface(paramUuid + "");
  }
  
  public void release(AuthInfo paramAuthInfo)
  {
    Log.log(3, c("!N\027`q N[fq?G\036a0<E[") + this + c("\013\t`|6J\b`tsM\027dwn") + this.u);
    if (this.u) {
      return;
    }
    super.f();
    this.u = true;
    a(this);
    try
    {
      nativeRelease(paramAuthInfo);
    }
    catch (Throwable localThrowable)
    {
      Log.a(cj.translate(cj.EXCEPTION_RELEASING_NATIVE_OBJ_REF, this, localThrowable));
    }
  }
  
  protected void finalize()
    throws Throwable
  {
    Log.log(3, this + c("sC\032v01N\036k05B\025d|:Q\036a"));
    release(null);
  }
  
  StdObjRef a(AuthInfo paramAuthInfo)
    throws IOException
  {
    if (s) {
      throw new RuntimeException(cj.ATTEMPT_TO_INVOKE_METHOD_AFTER_ALL_OBJS_RELEASED);
    }
    if (this.u) {
      throw new RuntimeException(cj.ATTEMPT_TO_INVOKE_METHOD_AFTER_RELEASED);
    }
    return nativeQueryInterface(this.iid + "");
  }
  
  static synchronized void p()
  {
    int j = Dispatch.H;
    if (s) {
      throw new RuntimeException(cj.ATTEMPT_TO_RELEASE_ALL_TWICE);
    }
    s = true;
    Log.log(3, c("\001N\027`q N:i|sH\032i|6O"));
    Log.log(3, c("\001N\027`q B\025b02G\027?0") + q);
    Enumeration localEnumeration = q.keys();
    if (j != 0) {}
    Object localObject1;
    Object localObject2;
    Object localObject3;
    do
    {
      while (localEnumeration.hasMoreElements())
      {
        localObject1 = (Integer)localEnumeration.nextElement();
        do
        {
          localObject2 = (Uuid)q.get(localObject1);
          if (localObject2 == null) {
            break;
          }
          localObject3 = new NativeObjRef(localObject2 + "", ((Integer)localObject1).intValue(), 0L);
        } while (j != 0);
        ((NativeObjRef)localObject3).release(null);
      }
      localObject1 = r.keys();
    } while (j != 0);
    if (j != 0) {}
    while (((Enumeration)localObject1).hasMoreElements())
    {
      localObject2 = (Long)((Enumeration)localObject1).nextElement();
      localObject3 = (Integer)r.get(localObject2);
      while (localObject3 != null)
      {
        int i = 0;
        if (j != 0) {
          if (j != 0) {
            break;
          }
        } else {
          while (i < ((Integer)localObject3).intValue())
          {
            NativeObjRef localNativeObjRef = new NativeObjRef(null, 0, ((Long)localObject2).longValue());
            localNativeObjRef.release(null);
            i++;
          }
        }
      }
    }
  }
  
  public static native String initializeCOM(int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5);
  
  static native void setLogLevel(int paramInt);
  
  static void q()
    throws UnsatisfiedLinkError
  {
    int i = Dispatch.H;
    if (E) {
      return;
    }
    E = true;
    if (!NativeInitInproc.a) {
      try
      {
        System.loadLibrary(c("=_\rl~%"));
        Log.log(3, c("\037D\032au7\013\025dd:]\036%s<O\036%y=]\024fq'B\024k0?B\031wq!R"));
        A = bi.u();
        Log.log(3, c("\006X\022kwsh4L^\032[sq?^\036%") + A);
        B = bi.v();
        if (B) {
          Log.log(3, c("\035d/%e B\025b0\024b/+0sh4H0\034I\021`s'X[hq*\013\026lc1N\023df6\013\fmu=\013\013dc N\037%r6_\f`u=\013\017mb6J\037v1"));
        }
        boolean bool = bi.K();
        String str = NativeInitThread.a(A, false, B, C, D, bool);
        if ((str != null) && (!str.startsWith("*")))
        {
          Log.log(3, c("\032E\022qy2G\022u7\013\025dd:]\036%s<O\036%y=]\024fq'B\024k0?B\031wq!RA%") + str);
          v = true;
          if (i == 0) {}
        }
        else
        {
          Log.log(1, cj.translate(cj.FAILED_TO_INITIALIZE_NATIVE_CODE_INVOCATION, str));
          throw new RuntimeException(cj.translate(cj.FAILED_TO_INITIALIZE_NATIVE_CODE_INVOCATION, str));
        }
      }
      catch (UnsatisfiedLinkError localUnsatisfiedLinkError)
      {
        throw localUnsatisfiedLinkError;
      }
      catch (Throwable localThrowable)
      {
        localThrowable.printStackTrace();
        if (i == 0) {
          return;
        }
      }
    } else {
      v = true;
    }
  }
  
  public static synchronized long getPunk(Object paramObject)
  {
    Long localLong = (Long)F.get(paramObject);
    if (localLong != null)
    {
      punkAddRef(localLong.longValue());
      return localLong.longValue();
    }
    localLong = new Long(newPunk(paramObject));
    F.put(paramObject, localLong);
    return localLong.longValue();
  }
  
  static native void punkAddRef(long paramLong);
  
  static native long newPunk(Object paramObject);
  
  public static synchronized void releasePunk(Object paramObject)
  {
    F.remove(paramObject);
  }
  
  public static synchronized void addPunk(Object paramObject, long paramLong)
  {
    F.put(paramObject, new Long(paramLong));
  }
  
  NativeObjectProxy r()
  {
    if (this.ptr == 0L) {
      return null;
    }
    Object localObject = NativeObjectProxy.objectFor(this.ptr);
    if (localObject == null) {
      return null;
    }
    return NativeObjectProxy.proxyFor(localObject);
  }
  
  Object g()
  {
    NativeObjRef localNativeObjRef = this;
    Object localObject = NativeObjectProxy.objectFor(localNativeObjRef.ptr);
    if (localObject != null)
    {
      localNativeObjRef.release(null);
      return localObject;
    }
    return null;
  }
  
  private static String c(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      43[123] = ((char)(0x5 ^ 0x10));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.NativeObjRef
 * JD-Core Version:    0.7.0.1
 */