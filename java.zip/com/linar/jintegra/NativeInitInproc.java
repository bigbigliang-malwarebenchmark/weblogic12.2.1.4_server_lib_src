package com.linar.jintegra;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Vector;

public class NativeInitInproc
  implements Runnable
{
  static boolean a = false;
  String[] b;
  private Method c;
  private static boolean d = false;
  static Class e;
  static Class f;
  
  private static native String initializeCOM(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
  
  private NativeInitInproc(Method paramMethod, String[] paramArrayOfString)
  {
    this.c = paramMethod;
    this.b = paramArrayOfString;
  }
  
  public void run()
  {
    try
    {
      this.c.invoke(null, new Object[] { this.b });
    }
    catch (Throwable localThrowable)
    {
      Log.log(3, c("\024o\t\026>%~\005\035n8y\034\034%8y\003\035)qz\013\032 k7") + localThrowable + c("qg\013\001/<dPS") + this.b);
    }
  }
  
  static synchronized void a(String paramString)
  {
    Log.log(3, c("\006v\003\007'?pJ\025!#7 %\003k7") + paramString + c("qc\005S,47\030\026)8d\036\026<4s"));
    if (Dispatch.H != 0) {}
    while (Jvm.a(paramString) == null) {
      try
      {
        (e == null ? (NativeInitInproc.e = b(c(""))) : e).wait();
      }
      catch (InterruptedException localInterruptedException) {}
    }
  }
  
  static synchronized void a()
  {
    (e == null ? (NativeInitInproc.e = b(c(""))) : e).notifyAll();
  }
  
  public static synchronized long getThunkForJvm(String paramString1, String paramString2)
  {
    try
    {
      init(paramString1, paramString2, null);
      Instanciator localInstanciator = Jvm.a(paramString2);
      if (localInstanciator == null)
      {
        if ((paramString1 == null) || (paramString1.length() == 0))
        {
          Jvm.register(paramString2);
          if (Dispatch.H == 0) {}
        }
        else
        {
          a(paramString2);
        }
        localInstanciator = Jvm.a(paramString2);
      }
      long l = NativeObjectProxy.thunkFor(Jvm.a(), c("g\"X\025}i/Z^|2&^^`s^^,f\"\f^|a#\tG(eq_C|a"));
      Log.flush();
      return l;
    }
    catch (Throwable localThrowable)
    {
      StringWriter localStringWriter = new StringWriter();
      localThrowable.printStackTrace(new PrintWriter(localStringWriter));
      Log.log(3, localStringWriter.toString());
    }
    return 0L;
  }
  
  public static synchronized String init(String paramString1, String paramString2)
  {
    return init(paramString1, paramString2, null);
  }
  
  public static synchronized String init(String paramString1, String paramString2, String paramString3)
  {
    int j = Dispatch.H;
    if ((paramString3 != null) && (paramString3.trim().length() != 0)) {
      try
      {
        PrintStream localPrintStream = new PrintStream(new FileOutputStream(paramString3));
        System.setOut(localPrintStream);
        System.setErr(localPrintStream);
      }
      catch (IOException localIOException) {}
    }
    a = true;
    if (d) {
      return c("\020{\030\026/5nJ\032 8c\003\022\"8m\017\027");
    }
    d = true;
    Log.log(3, c(""));
    try
    {
      boolean bool1 = bi.v();
      boolean bool2 = bi.l();
      boolean bool3 = bi.n();
      Object localObject;
      try
      {
        Class localClass1 = Class.forName(c(""));
        localObject = localClass1.getMethod(c("\"r\0360\"0d\031?!0s\017\001"), new Class[0]);
        ((Method)localObject).invoke(null, new Object[0]);
        Log.log(3, c("\002r\036S 0c\003\005+qt\006\022=\"7\006\034/5r\030"));
      }
      catch (Throwable localThrowable2) {}
      System.loadLibrary(c("?c\034\032 '"));
      String str = initializeCOM(bool1, bool2, bool3);
      if (str == null)
      {
        Log.a(cj.FAILED_TO_INITIALIZE_NATIVE_CODE_LIBRARY);
        Log.flush();
        return null;
      }
      Log.log(3, str);
      if ((paramString1 == null) || (paramString1.length() == 0))
      {
        Jvm.register(paramString2);
        if (j == 0) {}
      }
      else
      {
        localObject = new Vector();
        StringTokenizer localStringTokenizer = new StringTokenizer(paramString1);
        paramString1 = localStringTokenizer.nextToken();
        if (j != 0) {}
        String[] arrayOfString;
        int i;
        do
        {
          do
          {
            ((Vector)localObject).addElement(localStringTokenizer.nextElement());
          } while (localStringTokenizer.hasMoreTokens());
          arrayOfString = new String[((Vector)localObject).size()];
          i = 0;
        } while (j != 0);
        Enumeration localEnumeration = ((Vector)localObject).elements();
        if (j != 0) {}
        while (localEnumeration.hasMoreElements()) {
          arrayOfString[(i++)] = (localEnumeration.nextElement() + "");
        }
        Class localClass2 = Class.forName(paramString1);
        Method localMethod = localClass2.getMethod(c("<v\003\035"), new Class[] { f == null ? (NativeInitInproc.f = b(c(""))) : f });
        Thread localThread = new Thread(new NativeInitInproc(localMethod, arrayOfString), c("\037v\036\03284^\004\032:\030y:\001!2"));
        localThread.setDaemon(true);
        localThread.start();
        a(paramString2);
      }
      Log.flush();
      return c("\030y\003\007'0{\003\t+qd\037\020+4s\017\027tq") + str;
    }
    catch (Throwable localThrowable1)
    {
      Log.a(cj.translate(cj.INITIALIZE_FAILED, localThrowable1));
      Log.flush();
    }
    return null;
  }
  
  static Class b(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  private static String c(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      23[106] = ((char)(0x73 ^ 0x4E));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.NativeInitInproc
 * JD-Core Version:    0.7.0.1
 */