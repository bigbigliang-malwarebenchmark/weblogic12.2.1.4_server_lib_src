package com.linar.jintegra;

import java.io.IOException;

class UnAdvise
  extends Rpc
{
  long k;
  
  UnAdvise(long paramLong)
  {
    this.k = paramLong;
  }
  
  public long getCookie()
  {
    return this.k;
  }
  
  String b()
  {
    return b("oi\024qVCI\017vWHz\024vVR\020AJVgN\rvKC");
  }
  
  void b(y paramy)
    throws IOException
  {
    paramy.a(b("oi\024qVCI\017vWHz\024vVR\020AJVgN\rvKC\n\tzISO\bk"));
    a(paramy);
    paramy.a(this.k, b("SC\025kg\025\030"), b("EE\024tQC"));
    paramy.c();
  }
  
  void b(x paramx)
    throws IOException
  {
    paramx.a(b("oi\024qVCI\017vWHz\024vVR\020AJVgN\rvKC\n\tzKVE\025l]"));
    a(paramx);
    paramx.e(b("Su\022qL\025\030"), b("U^\032kMU"));
    paramx.c();
  }
  
  int a()
  {
    return 6;
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      42[123] = ((char)(0x1F ^ 0x38));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.UnAdvise
 * JD-Core Version:    0.7.0.1
 */