package com.linar.jintegra;

public abstract interface IRpcCommonHeader
{
  public static final int REQUEST_VAL = 0;
  public static final int RESPONSE_VAL = 1;
  public static final int FAULT_VAL = 2;
  public static final int BIND_VAL = 3;
  public static final int BIND_ACK_VAL = 4;
  public static final int BIND_NAK_VAL = 5;
  public static final int ALTER_CONTEXT_VAL = 6;
  public static final int ALTER_CONTEXT_RESP_VAL = 7;
  public static final int SECRET_VAL = 8;
  public static final int SHUTDOWN_VAL = 9;
  public static final int CO_CANCEL_VAL = 10;
  public static final int ORPHANED_VAL = 11;
  public static final int DREP_INTCHAR_FORMAT_BYTE_VAL = 12;
  public static final int DREP_FLOAT_FORMAT_BYTE_VAL = 13;
  public static final int DREP_CHAR_MASK_VAL = 14;
  public static final int DREP_ENDIAN_MASK_VAL = 15;
  public static final int DREP_ASCII_VAL = 16;
  public static final int DREP_EBCIDIC_VAL = 17;
  public static final int DREP_LITTLE_ENDIAN_VAL = 18;
  public static final int DREP_BIG_ENDIAN_VAL = 19;
  public static final int DREP_IEEE_FLOATS_VAL = 20;
  public static final int LENGTH_VAL = 21;
  public static final int RPC_VERSION_MAJOR_VAL = 22;
  public static final int RPC_VERSION_MINOR_VAL = 23;
  public static final int FLAG_FIRST_FRAG_VAL = 24;
  public static final int FLAG_LAST_FRAG_VAL = 25;
  public static final int FLAG_FIRST_AND_LAST_FRAG_VAL = 26;
  public static final int FLAG_NON_NULL_OID_VAL = 27;
  
  public abstract int getValue(int paramInt);
  
  public abstract void setValue(int paramInt1, int paramInt2);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.IRpcCommonHeader
 * JD-Core Version:    0.7.0.1
 */