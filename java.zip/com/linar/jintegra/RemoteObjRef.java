package com.linar.jintegra;

import java.io.Serializable;

public abstract interface RemoteObjRef
  extends Serializable
{
  public abstract Dispatch getJintegraDispatch();
  
  public abstract void release();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.RemoteObjRef
 * JD-Core Version:    0.7.0.1
 */