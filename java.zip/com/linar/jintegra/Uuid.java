package com.linar.jintegra;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Random;

public final class Uuid
{
  private int a;
  private long b;
  private int c;
  private int d;
  private int e;
  private int f;
  private int[] g = null;
  private static int[] h;
  private static String i;
  private static Object j;
  private static int k;
  byte[] l;
  static boolean m;
  private String n = null;
  
  private static int a(String paramString, int paramInt1, int paramInt2)
  {
    return Integer.parseInt(paramString.substring(paramInt1, paramInt2), 16);
  }
  
  public Uuid(String paramString)
  {
    this.n = paramString.toLowerCase().intern();
    this.a = this.n.hashCode();
  }
  
  Uuid(x paramx)
    throws IOException
  {
    this.b = paramx.e(null, null);
    this.c = paramx.f(null, null);
    this.d = paramx.f(null, null);
    this.e = paramx.g(null, null);
    this.f = paramx.g(null, null);
    byte[] arrayOfByte = new byte[6];
    paramx.a(arrayOfByte, null);
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
    this.g = new int[6];
    int i1 = 0;
    if (i2 != 0) {}
    do
    {
      do
      {
        this.g[i1] = localByteArrayInputStream.read();
        i1++;
      } while (i1 < 6);
      this.a = toString().hashCode();
    } while (i2 != 0);
  }
  
  Uuid(DataInputStream paramDataInputStream)
    throws IOException
  {
    this.b = paramDataInputStream.readLong();
    this.c = paramDataInputStream.readShort();
    this.d = paramDataInputStream.readShort();
    this.e = paramDataInputStream.readByte();
    this.f = paramDataInputStream.readByte();
    this.g = new int[6];
    int i1 = 0;
    if (i2 != 0) {}
    do
    {
      do
      {
        this.g[i1] = paramDataInputStream.read();
        i1++;
      } while (i1 < 6);
      this.a = toString().hashCode();
    } while (i2 != 0);
  }
  
  static byte[] a(String paramString)
    throws IOException
  {
    return new Uuid(paramString).a();
  }
  
  byte[] a()
    throws IOException
  {
    if (this.l == null)
    {
      y localy = new y(true, null);
      a(localy);
      this.l = localy.e();
    }
    return this.l;
  }
  
  public Uuid()
  {
    long l1 = System.currentTimeMillis();
    int i1;
    synchronized (j)
    {
      if (k >= 16384) {
        k = 1;
      }
      i1 = k++;
    }
    this.b = (l1 & 0xFFFFFFFF);
    this.c = ((int)(l1 >>> 32 & 0xFFFF));
    this.d = ((int)(l1 >>> 48 & 0xFFF));
    this.d |= 0x1000;
    this.f = (i1 & 0xFF);
    this.e = (i1 >>> 8 & 0x3F);
    this.e |= 0x50;
    this.g = h;
    this.a = toString().hashCode();
  }
  
  public String oldToString()
  {
    int i2 = Dispatch.H;
    if (this.n != null) {
      return this.n;
    }
    StringBuffer localStringBuffer1 = new StringBuffer(36);
    StringBuffer localStringBuffer2 = new StringBuffer(Long.toHexString(this.b));
    switch (localStringBuffer2.length())
    {
    case 7: 
      localStringBuffer2.insert(0, "0");
      if (i2 == 0) {
        break;
      }
    case 6: 
      localStringBuffer2.insert(0, b("[\033"));
      if (i2 == 0) {
        break;
      }
    case 5: 
      localStringBuffer2.insert(0, b("[\033O"));
      if (i2 == 0) {
        break;
      }
    case 4: 
      localStringBuffer2.insert(0, b("[\033OO"));
      if (i2 == 0) {
        break;
      }
    case 3: 
      localStringBuffer2.insert(0, b("[\033OO\017"));
      if (i2 == 0) {
        break;
      }
    case 2: 
      localStringBuffer2.insert(0, b("[\033OO\017["));
      if (i2 == 0) {
        break;
      }
    case 1: 
      localStringBuffer2.insert(0, b("[\033OO\017[\033"));
    }
    localStringBuffer1.append(localStringBuffer2 + "-");
    localStringBuffer2 = new StringBuffer(Integer.toHexString(this.c));
    switch (localStringBuffer2.length())
    {
    case 3: 
      localStringBuffer2.insert(0, "0");
      if (i2 == 0) {
        break;
      }
    case 2: 
      localStringBuffer2.insert(0, b("[\033"));
      if (i2 == 0) {
        break;
      }
    case 1: 
      localStringBuffer2.insert(0, b("[\033O"));
    }
    localStringBuffer1.append(localStringBuffer2 + "-");
    localStringBuffer2 = new StringBuffer(Integer.toHexString(this.d));
    switch (localStringBuffer2.length())
    {
    case 3: 
      localStringBuffer2.insert(0, "0");
      if (i2 == 0) {
        break;
      }
    case 2: 
      localStringBuffer2.insert(0, b("[\033"));
      if (i2 == 0) {
        break;
      }
    case 1: 
      localStringBuffer2.insert(0, b("[\033O"));
    }
    localStringBuffer1.append(localStringBuffer2 + "-");
    localStringBuffer2 = new StringBuffer(Integer.toHexString(this.e));
    if (localStringBuffer2.length() == 1) {
      localStringBuffer2.insert(0, "0");
    }
    localStringBuffer1.append(localStringBuffer2);
    localStringBuffer2 = new StringBuffer(Integer.toHexString(this.f));
    if (localStringBuffer2.length() == 1) {
      localStringBuffer2.insert(0, "0");
    }
    localStringBuffer1.append(localStringBuffer2 + "-");
    if (this.g == h)
    {
      localStringBuffer1.append(i);
      if (i2 == 0) {}
    }
    else
    {
      int i1 = 0;
      if (i2 != 0) {}
      while (i1 < this.g.length)
      {
        localStringBuffer1.append(this.g[i1] < 16 ? "0" : "");
        localStringBuffer1.append(Integer.toHexString(this.g[i1] & 0xFF));
        i1++;
      }
    }
    this.n = localStringBuffer1.toString().intern();
    return this.n;
  }
  
  public String toString()
  {
    int i2 = Dispatch.H;
    if (this.n != null) {
      return this.n;
    }
    if (m) {
      return oldToString();
    }
    char[] arrayOfChar1 = { '0', '0', '0', '0', '0', '0', '0', '0', '-', '0', '0', '0', '0', '-', '0', '0', '0', '0', '-', '0', '0', '0', '0', '-', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0' };
    char[] arrayOfChar2 = Long.toHexString(this.b).toCharArray();
    System.arraycopy(arrayOfChar2, 0, arrayOfChar1, 8 - arrayOfChar2.length, arrayOfChar2.length);
    arrayOfChar2 = Integer.toHexString(this.c).toCharArray();
    System.arraycopy(arrayOfChar2, 0, arrayOfChar1, 13 - arrayOfChar2.length, arrayOfChar2.length);
    arrayOfChar2 = Integer.toHexString(this.d).toCharArray();
    System.arraycopy(arrayOfChar2, 0, arrayOfChar1, 18 - arrayOfChar2.length, arrayOfChar2.length);
    arrayOfChar2 = Integer.toHexString(this.e).toCharArray();
    System.arraycopy(arrayOfChar2, 0, arrayOfChar1, 21 - arrayOfChar2.length, arrayOfChar2.length);
    arrayOfChar2 = Integer.toHexString(this.f).toCharArray();
    System.arraycopy(arrayOfChar2, 0, arrayOfChar1, 23 - arrayOfChar2.length, arrayOfChar2.length);
    if (this.g == h)
    {
      arrayOfChar2 = i.toCharArray();
      System.arraycopy(arrayOfChar2, 0, arrayOfChar1, 24, arrayOfChar2.length);
      if (i2 == 0) {}
    }
    else
    {
      StringBuffer localStringBuffer = new StringBuffer();
      int i1 = 0;
      if (i2 != 0) {}
      do
      {
        do
        {
          localStringBuffer.append(this.g[i1] < 16 ? "0" : "");
          localStringBuffer.append(Integer.toHexString(this.g[i1] & 0xFF));
          i1++;
        } while (i1 < this.g.length);
        arrayOfChar2 = localStringBuffer.toString().toCharArray();
      } while (i2 != 0);
      System.arraycopy(arrayOfChar2, 0, arrayOfChar1, 24, arrayOfChar2.length);
    }
    this.n = new String(arrayOfChar1).intern();
    return this.n;
  }
  
  final void a(y paramy)
    throws IOException
  {
    int i2 = Dispatch.H;
    int i1;
    if (this.g == null)
    {
      this.b = Long.valueOf(this.n.substring(0, 8), 16).longValue();
      this.c = a(this.n, 9, 13);
      this.d = a(this.n, 14, 18);
      this.e = a(this.n, 19, 21);
      this.f = a(this.n, 21, 23);
      this.g = new int[6];
      i1 = 0;
      if (i2 == 0) {}
    }
    do
    {
      do
      {
        this.g[i1] = a(this.n, 24 + i1 * 2, 24 + i1 * 2 + 2);
        i1++;
      } while (i1 < this.g.length);
      paramy.a(this.b, null, null);
      paramy.d(this.c, null, null);
      paramy.d(this.d, null, null);
      paramy.e(this.e, null, null);
      paramy.e(this.f, null, null);
      i1 = 0;
    } while (i2 != 0);
    if (i2 != 0) {}
    while (i1 < this.g.length)
    {
      paramy.e(this.g[i1], null, null);
      i1++;
    }
  }
  
  public int hashCode()
  {
    return this.a;
  }
  
  public boolean equals(Object paramObject)
  {
    return ((Uuid)paramObject).n == this.n;
  }
  
  static
  {
    int i3 = Dispatch.H;
    h = new int[6];
    j = new Object();
    k = 0;
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = InetAddress.getLocalHost().getAddress();
    }
    catch (Throwable localThrowable)
    {
      Log.a(cj.translate(cj.CANNOT_GENERATE_UUIDS_USING_IP_ADDRESS, localThrowable));
      arrayOfByte = new byte[6];
      new Random().nextBytes(arrayOfByte);
    }
    int i1 = 0;
    if (i3 != 0) {}
    while ((i1 < arrayOfByte.length) && (i1 < 6))
    {
      h[i1] = (arrayOfByte[i1] & 0xFF);
      i1++;
    }
    StringBuffer localStringBuffer = new StringBuffer();
    int i2 = 0;
    if (i3 != 0) {}
    do
    {
      do
      {
        localStringBuffer.append(h[i2] < 16 ? "0" : "");
        localStringBuffer.append(Integer.toHexString(h[i2] & 0xFF));
        i2++;
      } while (i2 < h.length);
      i = localStringBuffer.toString();
      m = false;
      m = bi.c();
    } while (i3 != 0);
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      43[127] = ((char)(0x7F ^ 0x3F));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Uuid
 * JD-Core Version:    0.7.0.1
 */