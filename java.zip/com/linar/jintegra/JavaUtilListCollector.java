package com.linar.jintegra;

import java.lang.reflect.Array;
import java.util.Enumeration;
import java.util.List;

public class JavaUtilListCollector
  implements Collectionable
{
  List a;
  
  JavaUtilListCollector()
    throws ClassNotFoundException
  {
    Class.forName(a("nO]jbqZBgbHGX"));
  }
  
  public Object item(Object paramObject)
    throws AutomationException
  {
    if ((paramObject != null) && (paramObject.getClass().isArray())) {
      paramObject = Array.get(paramObject, 0);
    }
    if ((paramObject == null) || (!(paramObject instanceof Number)))
    {
      Log.a(cj.translate(cj.PARAMETER_NOT_A_NUMBER, paramObject));
      throw new AutomationException(2147614725L);
    }
    int i = ((Number)paramObject).intValue() - 1;
    Object localObject = this.a.get(i);
    if (localObject == null) {
      throw new AutomationException(2147614725L);
    }
    return localObject;
  }
  
  public void add(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
    throws AutomationException
  {
    int j = Dispatch.H;
    if (paramObject2 != null) {
      throw new AutomationException(2147614725L, cj.KEY_CANNOT_BE_SPECIFIED);
    }
    int i;
    if (paramObject3 != null)
    {
      if (paramObject4 != null) {
        throw new AutomationException(2147614725L, cj.BEFORE_AND_AFTER_OBJECT_CANNOT_BE_SPECIFIED);
      }
      i = -1;
      if ((paramObject3 instanceof Number))
      {
        i = ((Number)paramObject3).intValue() - 1;
        if (j == 0) {}
      }
      else
      {
        i = this.a.indexOf(paramObject3);
        if (i == -1) {
          throw new AutomationException(2147614725L, cj.BEFORE_OBJECT_NOT_FOUND);
        }
      }
      this.a.add(i, paramObject1);
      return;
    }
    if (paramObject4 != null)
    {
      if (paramObject3 != null) {
        throw new AutomationException(2147614725L, cj.BEFORE_AND_AFTER_OBJECT_CANNOT_BE_SPECIFIED);
      }
      i = -1;
      if ((paramObject4 instanceof Number))
      {
        i = ((Number)paramObject4).intValue();
        if (j == 0) {}
      }
      else
      {
        i = this.a.indexOf(paramObject4) + 1;
        if (i == -1) {
          throw new AutomationException(2147614725L, cj.AFTER_OBJECT_NOT_FOUND);
        }
      }
      this.a.add(i, paramObject1);
      return;
    }
    this.a.add(paramObject1);
  }
  
  public int count()
    throws AutomationException
  {
    return this.a.size();
  }
  
  public Enumeration _NewEnum()
    throws AutomationException
  {
    return new EnumerationWrapper(new s(this.a.listIterator()));
  }
  
  public void remove(Object paramObject)
    throws AutomationException
  {
    if (paramObject == null) {
      throw new AutomationException(2147614725L);
    }
    int i = -1;
    if ((paramObject instanceof Number))
    {
      i = ((Number)paramObject).intValue() - 1;
      this.a.remove(i);
      if (Dispatch.H == 0) {}
    }
    else if (!this.a.remove(paramObject))
    {
      throw new AutomationException(2147614725L, cj.OBJECT_NOT_FOUND);
    }
  }
  
  public boolean canHandle(Object paramObject)
  {
    if ((paramObject instanceof List))
    {
      this.a = ((List)paramObject);
      return true;
    }
    return false;
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      46[43] = ((char)(0xB ^ 0x4C));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.JavaUtilListCollector
 * JD-Core Version:    0.7.0.1
 */