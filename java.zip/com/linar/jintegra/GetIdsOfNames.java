package com.linar.jintegra;

import java.io.IOException;

class GetIdsOfNames
  extends Rpc
{
  public String name;
  public int id;
  public boolean failed = false;
  
  boolean g()
  {
    return this.failed;
  }
  
  int h()
  {
    return this.id;
  }
  
  void a(int paramInt)
  {
    this.id = paramInt;
  }
  
  String i()
  {
    return this.name;
  }
  
  GetIdsOfNames(String paramString)
  {
    this.name = paramString;
  }
  
  String b()
  {
    return b("^\036\037t\025v.\025o_-\035\023s,S)9a+v7\023t");
  }
  
  void b(y paramy)
    throws IOException
  {
    paramy.a(b(""));
    a(paramy);
    paramy.a(k.NULL_UUID, b("~3\022"));
    paramy.a(1L, b("b3\030s:$h"), b(""));
    paramy.a(paramy.f(), b("b3\030s:$h"), b("+*\002uE~>H"));
    String str = this.name;
    if (this.name.charAt(this.name.length() - 1) != 0) {
      str = str + '\000';
    }
    paramy.a(str.length(), b("b3\030s:$h"), b("y;\033bE{?\030`\021"));
    paramy.a(0L, b("b3\030s:$h"), b(""));
    paramy.a(str.length(), b("b3\030s:$h"), b("y;\033bE{?\030`\021"));
    paramy.b(str, b(""));
    paramy.a(1L, b("b3\030s:$h"), b(""));
    paramy.a(1033L, b("b3\030s:$h"), b("{9\037c"));
    paramy.c();
  }
  
  void b(x paramx)
    throws IOException
  {
    paramx.a(b("^\036\037t\025v.\025o_-\035\023s,S)9a+v7\023tEe?\005w\ny)\023"));
    a(paramx);
    long l1 = paramx.e(b("b\005\037i\021$h"), b("e=\022n\026g3\022'\tr4\021s\r"));
    if (l1 != 1L)
    {
      Log.a(cj.translate(cj.RESPONSE_LENGTH_WAS_NOT_ONE, this.name, Long.toString(l1)));
      this.failed = true;
      return;
    }
    this.id = paramx.b(b("b\005\037i\021$h"), b("e=\022n\026g3\022"));
    long l2 = paramx.e(b("b\005\037i\021$h"), b("d.\027s\020d"));
    if (l2 != 0L)
    {
      Log.a(cj.translate(cj.RESPONSE_STATUS_NOT_OK, this.name, Long.toString(l2)));
      this.failed = true;
      return;
    }
    Log.log(3, b("^\036\037t\025v.\025o_-\035\023s,S)9a+v7\023tEx4V ") + this.name + b("0z\004b\021b(\030b\0017\0232'") + this.id);
  }
  
  int a()
  {
    return 5;
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      90[118] = ((char)(0x7 ^ 0x65));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.GetIdsOfNames
 * JD-Core Version:    0.7.0.1
 */