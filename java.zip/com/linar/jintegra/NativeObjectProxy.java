package com.linar.jintegra;

import com.intrinsyc.license.LicenseException;
import com.linar.spi.Executor;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Hashtable;

class NativeObjectProxy
  extends ObjectProxy
{
  static JHashtable s = new JHashtable();
  static Hashtable t = new Hashtable();
  Hashtable u = new Hashtable();
  Hashtable v = new Hashtable();
  Hashtable w = new Hashtable();
  private static ObjectExportChecker x = null;
  private static boolean y = false;
  static boolean z = bi.n();
  static boolean A = bi.p();
  private int B = 0;
  
  static void b(PrintStream paramPrintStream)
  {
    paramPrintStream.println(d("\004[!\006\036\b^4K\005\031`>x\003\005L8M\002JG8R\024J]\"\b") + s.size());
    paramPrintStream.println(d("\004[!\006\005\002A?C\002>[\036J\033\017W%[Q\031]+MQ\003Gq") + t.size());
  }
  
  protected static synchronized void x_3(Class paramClass)
  {
    String str = paramClass.getName();
    if (!str.startsWith(d("\t[<\006\035\003Z0Z"))) {
      throw new LicenseException(d("+\024\002M\003\034Q#\b\035\003W4F\002\017\0248[Q\004Q4L\024\016\0247G\003J@9A\002J[!M\003\013@8G\037F\0240F\025JUqK\035\003Q?\\Q\006]2M\037\031Qq_\020\031\0247G\004\004Pp%{:X4I\002\017\0242G\037\036U2\\Q#Z%Z\030\004G(KQ\036[qI\022\033A8Z\024J@9MQ\032F>X\024\030\024=A\022\017Z\"MKJ\\%\\\001P\033~B\\\003Z%M\026\030UA\037\036F8F\002\023WK\036\007"));
    }
    y = true;
  }
  
  static synchronized void a(ObjectExportChecker paramObjectExportChecker)
  {
    x = paramObjectExportChecker;
  }
  
  public static synchronized Object objectFor(long paramLong)
  {
    return t.get(new Long(paramLong));
  }
  
  static native long handleVtblInvokeCallback(long paramLong1, int paramInt, long paramLong2)
    throws AutomationException;
  
  static native void registerJvm(String paramString, IJintegraJvm2 paramIJintegraJvm2, boolean paramBoolean);
  
  public static long executeVtblCallback(long paramLong1, int paramInt, long paramLong2)
    throws AutomationException
  {
    if ((z) && (A))
    {
      Object localObject1 = objectFor(paramLong1);
      if (localObject1 != null)
      {
        NativeObjectProxy localNativeObjectProxy = proxyFor(localObject1);
        Log.b(d(">Q<X\036\030U#A\035\023\024\"M\005\036]?OQ\036\\#M\020\016]?OQ\t[?\\\024\022@q\\\036J") + localNativeObjectProxy.getThreadContext());
        Dispatch.f().setCurrentThreadContext(localNativeObjectProxy.getThreadContext());
      }
    }
    try
    {
      long l = handleVtblInvokeCallback(paramLong1, paramInt, paramLong2);
      return l;
    }
    finally
    {
      if ((z) && (A)) {
        Dispatch.f().clearCurrentThreadContext();
      }
    }
  }
  
  public Object invoke(long paramLong, int paramInt, Object[] paramArrayOfObject)
    throws AutomationException
  {
    InterfaceDesc localInterfaceDesc = (InterfaceDesc)this.v.get(new Long(paramLong));
    if (localInterfaceDesc == null)
    {
      Log.a(cj.CANNOT_FIND_INTERFACE_DESC_FOR_THUNK);
      throw new AutomationException(2147549183L);
    }
    return a(localInterfaceDesc, paramInt, paramArrayOfObject);
  }
  
  public Object invokeMatchThread(long paramLong1, long paramLong2, int paramInt, Object[] paramArrayOfObject)
    throws AutomationException
  {
    Object localObject1 = z ? new Long(paramLong1) : null;
    if ((A) && (!(this.g instanceof Jvm)))
    {
      localObject1 = getThreadContext();
      Log.b(d("?G8F\026J@9Z\024\013PqK\036\004@4P\005J") + localObject1);
    }
    NativeVtblInvokeExecutor localNativeVtblInvokeExecutor = new NativeVtblInvokeExecutor(this, paramLong2, paramInt, paramArrayOfObject);
    boolean bool = Dispatch.f().executeOnce(localNativeVtblInvokeExecutor, localObject1, null);
    if (bool)
    {
      localNativeVtblInvokeExecutor.d();
      Object localObject2 = localNativeVtblInvokeExecutor.a();
      localNativeVtblInvokeExecutor.b();
      return localObject2;
    }
    throw new AutomationException(2147549185L);
  }
  
  public Param[] getParams(long paramLong, int paramInt)
  {
    Log.log(3, d("&[>C\030\004SqN\036\030\024&Z\020\032D4ZQ\f[#\b\005\002A?CKJ") + paramLong);
    InterfaceDesc localInterfaceDesc = (InterfaceDesc)this.v.get(new Long(paramLong));
    Log.log(3, d("-[%\b\030\004@4Z\027\013W4l\024\031WqN\036\030\024%@\004\004_k\b") + localInterfaceDesc.b);
    if (localInterfaceDesc == null) {
      return null;
    }
    MemberDesc localMemberDesc = localInterfaceDesc.a(paramInt);
    if (localMemberDesc == null) {
      return null;
    }
    Log.log(3, d("-[%\b\034\017Y3M\003.Q\"KQ\f[#\b\036\032Z$EQ") + paramInt + d("P\024") + localMemberDesc);
    return localMemberDesc.c;
  }
  
  public static synchronized long thunkFor(Object paramObject, String paramString)
    throws a
  {
    Log.log(3, d("&[>C\030\004SqN\036\030\024%@\004\004_qN\036\030\024") + paramObject + d("JB8IQ\003Z%M\003\fU2MQ") + k.a(paramString));
    NativeObjectProxy localNativeObjectProxy1 = (NativeObjectProxy)s.get(paramObject);
    if (localNativeObjectProxy1 != null) {
      return localNativeObjectProxy1.queryInterface(paramString);
    }
    if ((x != null) && (!x.exportAllowed(paramObject)))
    {
      Log.log(3, d("/L!G\003\036\024>NQ\005V;M\022\036\016q") + paramObject + d("JV0Z\003\017P"));
      throw new a(2147549467L);
    }
    int i = 1;
    Object localObject = Dispatch.f().getCurrentThreadContext();
    localObject = localObject == null ? Thread.currentThread() : localObject;
    NativeObjectProxy localNativeObjectProxy2 = new NativeObjectProxy(paramObject, localObject);
    long l = localNativeObjectProxy2.queryInterface(paramString);
    return l;
  }
  
  public static synchronized NativeObjectProxy proxyFor(Object paramObject)
  {
    return (NativeObjectProxy)s.get(paramObject);
  }
  
  NativeObjectProxy(Object paramObject1, Object paramObject2)
  {
    super(paramObject1, paramObject2);
    long l1 = newThunk(k.IID_IUNKNOWN + "");
    long l2 = newThunk(k.IID_IDISPATCH + "");
    long l3 = newThunk(k.IID_ICONNECTION_POINT_CONTAINER + "");
    long l4 = newThunk(k.IID_ISUPPORT_ERROR_INFO + "");
    this.u.put(k.IID_IUNKNOWN.toString(), new Long(l1));
    this.u.put(k.IID_IDISPATCH.toString(), new Long(l2));
    this.u.put(k.IID_ICONNECTION_POINT_CONTAINER.toString(), new Long(l3));
    this.u.put(k.IID_ISUPPORT_ERROR_INFO.toString(), new Long(l4));
    t.put(new Long(l1), paramObject1);
    t.put(new Long(l2), paramObject1);
    s.put(paramObject1, this);
    if (ObjectProxy.f != 0L) {
      addRef();
    }
  }
  
  native long newThunk(String paramString);
  
  native void deleteThunk(long paramLong);
  
  public long enumConnectionPoints()
  {
    Log.a(cj.UNHANDLED_ENUM_CONNECTION_POINTS_CALL);
    return 0L;
  }
  
  public long findConnectionPoint(String paramString)
  {
    Uuid localUuid = new Uuid(paramString);
    bb localbb = (bb)this.d.get(localUuid);
    Object localObject;
    if (localbb == null)
    {
      localObject = ObjectProxy.b(localUuid);
      Class localClass1 = a((String)localObject);
      Class localClass2 = c(localClass1);
      Method localMethod1 = a((String)localObject, localClass2);
      Method localMethod2 = a(localMethod1);
      if ((localMethod1 != null) && (localMethod2 != null))
      {
        long l = newThunk(k.IID_ICONNECTION_POINT + "");
        Long localLong = new Long(l);
        Log.log(3, d("+P5A\037\r\024>]\005\r[8F\026JW>F\037\017W%A\036\004"));
        try
        {
          if (localClass1 != null)
          {
            localbb = new bb(this.g, localMethod1, localMethod2, localClass1, localLong, localUuid);
            if (Dispatch.H == 0) {}
          }
          else
          {
            Class[] arrayOfClass = localMethod1.getParameterTypes();
            localbb = new bb(this.g, localMethod1, localMethod2, arrayOfClass[0].getName(), localLong, localUuid);
          }
          this.d.put(localUuid, localbb);
          this.w.put(localLong, localbb);
        }
        catch (ClassNotFoundException localClassNotFoundException) {}catch (NoSuchMethodException localNoSuchMethodException) {}
      }
    }
    if (localbb != null)
    {
      localObject = (Long)localbb.a();
      Log.log(3, d(",]?L2\005Z?M\022\036]>F!\005]?\\Q\005Zq") + this.g + d("JR>ZQ") + localUuid + d("JF4\\\004\030Z8F\026J") + localObject);
      addRef();
      return ((Long)localObject).longValue();
    }
    Log.a(cj.translate(cj.FIND_CONNECTION_POINT_FAILED_ON, this));
    return 0L;
  }
  
  public String getConnectionInterface(long paramLong)
  {
    bb localbb = (bb)this.w.get(new Long(paramLong));
    String str = localbb.b() + "";
    Log.log(3, d("\rQ%k\036\004Z4K\005\003[?a\037\036Q#N\020\tQqG\037J") + paramLong + d("JF4\\\004\030Z8F\026J") + str);
    return str;
  }
  
  public long getConnectionPointContainer()
  {
    Long localLong = (Long)this.u.get(k.IID_ICONNECTION_POINT_CONTAINER.toString());
    Log.log(3, d("\rQ%k\036\004Z4K\005\003[?k\036\004@0A\037\017FqG\037J") + this.g + d("JF4\\\004\030Z8F\026J") + localLong);
    addRef();
    return localLong.longValue();
  }
  
  public long advise(long paramLong, StdObjRef paramStdObjRef)
  {
    Log.log(3, d("\013P'A\002\017\024>FQ") + paramLong + d("JR>ZQ") + paramStdObjRef);
    bb localbb = (bb)this.w.get(new Long(paramLong));
    try
    {
      long l = localbb == null ? 0L : localbb.a(paramStdObjRef);
      Log.log(3, d("\013P'A\002\017\024>FQ") + paramLong + d("JR>ZQ") + paramStdObjRef + d("JF4\\\004\030Z8F\026J") + l);
      return l;
    }
    catch (Exception localException)
    {
      Object[] arrayOfObject = { Long.toString(paramLong), paramStdObjRef, localException };
      Log.log(1, cj.translate(cj.ADVISE_ON_AND_GAVE_EXCEPTION, arrayOfObject));
    }
    return 0L;
  }
  
  public boolean unAdvise(long paramLong, int paramInt)
  {
    bb localbb = (bb)this.w.get(new Long(paramLong));
    try
    {
      Log.log(3, d("\037Z0L\007\003G4\b\036\004\024") + paramLong + d("JR>ZQ") + paramInt);
      if (localbb == null) {
        return false;
      }
      localbb.a(paramInt);
      return true;
    }
    catch (Exception localException)
    {
      Object[] arrayOfObject = { Long.toString(paramLong), Integer.toString(paramInt), localException };
      Log.log(1, cj.translate(cj.UNADVISE_ON_AND_GAVE_ERROR, arrayOfObject));
    }
    return false;
  }
  
  public long enumConnections(long paramLong)
  {
    bb localbb = (bb)this.w.get(new Long(paramLong));
    j localj = new j(localbb);
    NativeObjectProxy localNativeObjectProxy = new NativeObjectProxy(localj, null);
    long l = localNativeObjectProxy.newThunk(k.IID_IENUM_CONNECTIONS + "");
    localNativeObjectProxy.u.put(k.IID_IENUM_CONNECTIONS.toString(), new Long(l));
    t.put(new Long(l), localj);
    localNativeObjectProxy.addRef();
    Log.log(3, d("/Z$EQ)[?F\024\t@8G\037\031\024>FQ") + paramLong + d("JF4\\\004\030Z8F\026J") + l);
    return l;
  }
  
  public int enumConnectionsNext(long paramLong, long[] paramArrayOfLong, NativeObjRef[] paramArrayOfNativeObjRef)
    throws IOException
  {
    Long localLong = new Long(paramLong);
    j localj = (j)this.g;
    return localj.a(localLong, paramArrayOfLong, paramArrayOfNativeObjRef);
  }
  
  public synchronized int addRef()
  {
    this.B += 1;
    if (this.countZeroTime != -1L) {
      this.countZeroTime = 0L;
    }
    Log.log(3, d(")[$F\005J[?\b") + this + d("J]?K\003\017Y4F\005\017Pq\\\036J") + this.B);
    return this.B;
  }
  
  public final long queryInterface(String paramString)
  {
    Log.log(2, d(";A4Z\bJ]?\\\024\030R0K\024J[?\b") + this.g + d("JR>ZQ") + k.a(new Uuid(paramString)));
    Long localLong = (Long)this.u.get(paramString);
    if (localLong != null)
    {
      addRef();
      return localLong.longValue();
    }
    synchronized (this)
    {
      Uuid localUuid = new Uuid(paramString);
      if (localUuid.equals(k.IID_VB_COLLECTION))
      {
        localInterfaceDesc = _CollectionProxy.J;
        Collectionable localCollectionable = _CollectionProxy.a(this.g);
        if (localCollectionable != null)
        {
          localLong = new Long(newThunk(paramString));
          this.u.put(paramString, localLong);
          this.v.put(localLong, localInterfaceDesc);
          addIntermediary(localUuid, localCollectionable);
          Log.log(3, d("+P5M\025J@9]\037\001\033&Z\020\032D4ZKJ") + localLong + "/" + localInterfaceDesc.b);
          t.put(localLong, localCollectionable);
          addRef();
          Log.log(3, d("") + this.g + d("JR>ZQ\004Q&\b\030\004@4Z\027\013W4\022") + k.a(localUuid));
          long l2 = localLong.longValue();
          return l2;
        }
      }
      InterfaceDesc localInterfaceDesc = InterfaceDesc.a(localUuid);
      if (localInterfaceDesc == null)
      {
        a(localUuid);
        localInterfaceDesc = InterfaceDesc.a(localUuid);
        if (localInterfaceDesc == null)
        {
          Log.log(3, d(")U?\017\005JR8F\025J]?\\\024\030R0K\024.Q\"KQ\f[#\b") + localUuid);
          l1 = 0L;
          return l1;
        }
      }
      if (localInterfaceDesc.d.isInstance(this.g))
      {
        localLong = new Long(newThunk(paramString));
        this.u.put(paramString, localLong);
        this.v.put(localLong, localInterfaceDesc);
        Log.log(3, d("+P5M\025J@9]\037\001\033&Z\020\032D4ZKJ") + localLong + "/" + localInterfaceDesc.b);
        t.put(localLong, this.g);
        addRef();
        Log.log(3, d("") + this.g + d("JR>ZQ\004Q&\b\030\004@4Z\027\013W4\022") + k.a(localUuid));
        l1 = localLong.longValue();
        return l1;
      }
      Log.log(3, this.g + d("J]\"\b\037\005@qI\037J]?[\005\013Z2MQ\005Rq") + localInterfaceDesc.d);
      long l1 = 0L;
      return l1;
    }
  }
  
  void a()
  {
    release();
  }
  
  public synchronized int release()
  {
    int j = Dispatch.H;
    if (this.B == 0)
    {
      Log.a(cj.translate(cj.ATTEMPT_TO_RELEASE_A_RELEASED_OBJECT, this));
      return 0;
    }
    this.B -= 1;
    Log.log(3, d(")[$F\005J[?\b") + this + d("JP4K\003\017Y4F\005\017Pq\\\036J") + this.B);
    if (this.B != 0)
    {
      if ((this.countZeroTime != -1L) && (this.B == 1) && (ObjectProxy.f != 0L)) {
        this.countZeroTime = (System.currentTimeMillis() + ObjectProxy.f);
      }
      return this.B;
    }
    synchronized (getClass())
    {
      if (this.B == 0)
      {
        Log.log(3, this + d("J\\0[Q\bQ4FQ\030Q=M\020\031Q5"));
        Long localLong = (Long)this.u.get(k.IID_IENUM_CONNECTIONS.toString());
        Enumeration localEnumeration = this.u.elements();
        if (j != 0) {}
        do
        {
          do
          {
            localObject1 = (Long)localEnumeration.nextElement();
            t.remove(localObject1);
            deleteThunk(((Long)localObject1).longValue());
          } while (localEnumeration.hasMoreElements());
        } while (j != 0);
        Object localObject1 = this.w.keys();
        if (j != 0) {}
        Object localObject2;
        do
        {
          do
          {
            localObject2 = (Long)((Enumeration)localObject1).nextElement();
            this.w.remove(localObject2);
            deleteThunk(((Long)localObject2).longValue());
          } while (((Enumeration)localObject1).hasMoreElements());
        } while (j != 0);
        if ((localLong != null) && ((this.g instanceof j)))
        {
          localObject2 = (j)this.g;
          ((j)localObject2).a(localLong);
        }
        Object localObject3;
        if (this.u != null)
        {
          localObject2 = this.u.keys();
          if (j != 0) {}
          while (((Enumeration)localObject2).hasMoreElements())
          {
            localObject3 = (String)((Enumeration)localObject2).nextElement();
            this.u.remove(localObject3);
          }
        }
        if (this.d != null)
        {
          localObject2 = this.d.keys();
          if (j != 0) {}
          while (((Enumeration)localObject2).hasMoreElements())
          {
            localObject3 = (Uuid)((Enumeration)localObject2).nextElement();
            this.d.remove(localObject3);
          }
        }
        s.remove(this.g);
        ck.a(this.g);
        this.g = null;
        if (j == 0) {}
      }
      else
      {
        int i = this.B;
        return i;
      }
    }
    return this.B;
  }
  
  static
  {
    Log.log(3, d("'U%K\031J@9Z\024\013P\"\b\030\031\024") + z);
    Log.log(3, d("\030A?a\037:U#M\037\036G\022G\037\036Q)\\Q\003Gq") + A);
  }
  
  private static String d(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      52[81] = ((char)(0x28 ^ 0x71));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.NativeObjectProxy
 * JD-Core Version:    0.7.0.1
 */