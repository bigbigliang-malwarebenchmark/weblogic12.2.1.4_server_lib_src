package com.linar.jintegra;

import com.intrinsyc.license.Container;
import java.io.PrintStream;

public class InternalInstanciator
{
  private static Object a = null;
  private static Object b = new Object();
  private static final String c = "\035Y=O\032:V%\n+;Z9E\0061Y=\n+&R(^\001;Yil\t=[<X\r^g%O\t'RiI\007:C(I\034t~'^\032=Y:S\013tV=\020H<C=ZR{\030#\007\001:C,M\0325\031 D\034&^'Y\0217\031*E\005{";
  static Class d;
  
  protected static Object getObj(Object paramObject)
  {
    try
    {
      return a(paramObject);
    }
    catch (Exception localException)
    {
      if ((localException instanceof RuntimeException)) {
        throw new RuntimeException(localException.getMessage());
      }
      throw new RuntimeException(b("\035Y=O\032:V%\n+;Z9E\0061Y=\n+&R(^\001;Yil\t=[<X\r^g%O\t'RiI\007:C(I\034t~'^\032=Y:S\013tV=\020H<C=ZR{\030#\007\001:C,M\0325\031 D\034&^'Y\0217\031*E\005{"));
    }
  }
  
  private static Object a(Object paramObject)
  {
    try
    {
      if (!(paramObject instanceof D5F73474_B4DE_4f02_BDEB_ADAB1ABB5A7D)) {
        throw new RuntimeException(b("\035[%O\0175[ii\0045D:\n\t7T,Y\033tV=^\r9G,N"));
      }
      if (a != null) {
        return a;
      }
      synchronized (b)
      {
        try
        {
          HeaderFiller localHeaderFiller = null;
          localHeaderFiller = (HeaderFiller)Class.forName(b("7X$\004\004=Y(XF>^'^\r3E(\004 1V-O\032\022^%F\r&")).newInstance();
          localObject2 = localHeaderFiller.getHeader();
          a = localObject2;
          Object localObject3 = a;
          return localObject3;
        }
        catch (ClassNotFoundException localClassNotFoundException)
        {
          a = Container.getValue((d == null ? (InternalInstanciator.d = a(b(""))) : d).getName());
          if (null == a) {
            throw new RuntimeException(b("\035Y=O\032:V%\n+;Z9E\0061Y=\n+&R(^\001;Yil\t=[<X\r^g%O\t'RiI\007:C(I\034t~'^\032=Y:S\013tV=\020H<C=ZR{\030#\007\001:C,M\0325\031 D\034&^'Y\0217\031*E\005{"));
          }
          Object localObject2 = a;
          return localObject2;
        }
      }
    }
    catch (Exception localException)
    {
      System.err.println(b("\021O*O\030 ^&DIu\ri") + localException.getMessage());
      if ((localException instanceof RuntimeException)) {
        throw new RuntimeException(localException.getMessage());
      }
      throw new RuntimeException(b("\035Y=O\032:V%\n+;Z9E\0061Y=\n+&R(^\001;Yil\t=[<X\r^g%O\t'RiI\007:C(I\034t~'^\032=Y:S\013tV=\020H<C=ZR{\030#\007\001:C,M\0325\031 D\034&^'Y\0217\031*E\005{"));
    }
  }
  
  static Class a(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      55[73] = ((char)(0x2A ^ 0x68));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.InternalInstanciator
 * JD-Core Version:    0.7.0.1
 */