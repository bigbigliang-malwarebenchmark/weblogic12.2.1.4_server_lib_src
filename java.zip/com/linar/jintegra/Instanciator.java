package com.linar.jintegra;

public abstract interface Instanciator
{
  public abstract Object instanciate(String paramString)
    throws AutomationException;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Instanciator
 * JD-Core Version:    0.7.0.1
 */