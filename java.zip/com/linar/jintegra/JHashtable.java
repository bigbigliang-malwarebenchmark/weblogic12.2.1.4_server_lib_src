package com.linar.jintegra;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Dictionary;
import java.util.Enumeration;

public class JHashtable
  extends Dictionary
  implements Cloneable, Serializable
{
  private transient u[] a;
  private transient int b;
  private int c;
  private float d;
  private static final long serialVersionUID = 1421746759512286392L;
  
  public JHashtable(int paramInt, float paramFloat)
  {
    if ((paramInt <= 0) || (paramFloat <= 0.0D)) {
      throw new IllegalArgumentException();
    }
    this.d = paramFloat;
    this.a = new u[paramInt];
    this.c = ((int)(paramInt * paramFloat));
  }
  
  public JHashtable(int paramInt)
  {
    this(paramInt, 0.75F);
  }
  
  public JHashtable()
  {
    this(101, 0.75F);
  }
  
  public int size()
  {
    return this.b;
  }
  
  public boolean isEmpty()
  {
    return this.b == 0;
  }
  
  public synchronized Enumeration keys()
  {
    return new v(this.a, true);
  }
  
  public synchronized Enumeration elements()
  {
    return new v(this.a, false);
  }
  
  public synchronized boolean contains(Object paramObject)
  {
    int j = Dispatch.H;
    if (paramObject == null) {
      throw new NullPointerException();
    }
    u[] arrayOfu = this.a;
    int i = arrayOfu.length;
    if (j != 0) {}
    while (i-- > 0)
    {
      u localu = arrayOfu[i];
      if (j != 0) {}
      while (localu != null)
      {
        if (localu.c == paramObject) {
          return true;
        }
        localu = localu.d;
      }
    }
    return false;
  }
  
  public synchronized boolean containsKey(Object paramObject)
  {
    int k = Dispatch.H;
    u[] arrayOfu = this.a;
    int i = System.identityHashCode(paramObject);
    int j = (i & 0x7FFFFFFF) % arrayOfu.length;
    u localu = arrayOfu[j];
    if (k != 0) {}
    do
    {
      do
      {
        if ((localu.a == i) && (localu.b == paramObject)) {
          return true;
        }
        localu = localu.d;
      } while (localu != null);
    } while (k != 0);
    return false;
  }
  
  public synchronized Object get(Object paramObject)
  {
    u[] arrayOfu = this.a;
    int i = System.identityHashCode(paramObject);
    int j = (i & 0x7FFFFFFF) % arrayOfu.length;
    u localu = arrayOfu[j];
    if (Dispatch.H != 0) {}
    while (localu != null)
    {
      if ((localu.a == i) && (localu.b == paramObject)) {
        return localu.c;
      }
      localu = localu.d;
    }
    return null;
  }
  
  protected void rehash()
  {
    int n = Dispatch.H;
    int i = this.a.length;
    u[] arrayOfu1 = this.a;
    int j = i * 2 + 1;
    u[] arrayOfu2 = new u[j];
    this.c = ((int)(j * this.d));
    this.a = arrayOfu2;
    int k = i;
    if (n != 0) {}
    while (k-- > 0)
    {
      u localu1 = arrayOfu1[k];
      if (n != 0) {}
      while (localu1 != null)
      {
        u localu2 = localu1;
        localu1 = localu1.d;
        int m = (localu2.a & 0x7FFFFFFF) % j;
        localu2.d = arrayOfu2[m];
        arrayOfu2[m] = localu2;
      }
    }
  }
  
  public synchronized Object put(Object paramObject1, Object paramObject2)
  {
    int k = Dispatch.H;
    if (paramObject2 == null) {
      throw new NullPointerException();
    }
    u[] arrayOfu = this.a;
    int i = System.identityHashCode(paramObject1);
    int j = (i & 0x7FFFFFFF) % arrayOfu.length;
    u localu = arrayOfu[j];
    if (k != 0) {}
    do
    {
      do
      {
        if (localu.a == i) {
          if (localu.b == paramObject1)
          {
            localObject = localu.c;
            localu.c = paramObject2;
            return localObject;
          }
        }
        localu = localu.d;
      } while (localu != null);
    } while (k != 0);
    if (this.b >= this.c)
    {
      rehash();
      return put(paramObject1, paramObject2);
    }
    Object localObject = new u();
    ((u)localObject).a = i;
    ((u)localObject).b = paramObject1;
    ((u)localObject).c = paramObject2;
    ((u)localObject).d = arrayOfu[j];
    arrayOfu[j] = localObject;
    this.b += 1;
    return null;
  }
  
  public synchronized Object remove(Object paramObject)
  {
    u[] arrayOfu = this.a;
    int i = System.identityHashCode(paramObject);
    int j = (i & 0x7FFFFFFF) % arrayOfu.length;
    u localu1 = arrayOfu[j];
    u localu2 = null;
    while (localu1 != null)
    {
      if ((localu1.a == i) && (localu1.b == paramObject))
      {
        if (localu2 != null)
        {
          localu2.d = localu1.d;
          if (Dispatch.H == 0) {}
        }
        else
        {
          arrayOfu[j] = localu1.d;
        }
        this.b -= 1;
        return localu1.c;
      }
      localu2 = localu1;
      localu1 = localu1.d;
    }
    return null;
  }
  
  public synchronized void clear()
  {
    u[] arrayOfu = this.a;
    int i = arrayOfu.length;
    if (Dispatch.H != 0) {}
    do
    {
      arrayOfu[i] = null;
      i--;
    } while (i >= 0);
    this.b = 0;
  }
  
  public synchronized Object clone()
  {
    int j = Dispatch.H;
    try
    {
      JHashtable localJHashtable = (JHashtable)super.clone();
      localJHashtable.a = new u[this.a.length];
      int i = this.a.length;
      if (j != 0) {}
      do
      {
        do
        {
          localJHashtable.a[i] = (this.a[i] != null ? (u)this.a[i].clone() : null);
        } while (i-- > 0);
      } while (j != 0);
      return localJHashtable;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new InternalError();
    }
  }
  
  public synchronized String toString()
  {
    int k = Dispatch.H;
    int i = size() - 1;
    StringBuffer localStringBuffer = new StringBuffer();
    Enumeration localEnumeration1 = keys();
    Enumeration localEnumeration2 = elements();
    localStringBuffer.append("{");
    int j = 0;
    if (k != 0) {}
    do
    {
      do
      {
        String str1 = localEnumeration1.nextElement().toString();
        String str2 = localEnumeration2.nextElement().toString();
        localStringBuffer.append(str1 + "=" + str2);
        if (j < i) {
          localStringBuffer.append(a("\020\007"));
        }
        j++;
      } while (j <= i);
      localStringBuffer.append("}");
    } while (k != 0);
    return localStringBuffer.toString();
  }
  
  private synchronized void writeObject(ObjectOutputStream paramObjectOutputStream)
    throws IOException
  {
    int j = Dispatch.H;
    paramObjectOutputStream.defaultWriteObject();
    paramObjectOutputStream.writeInt(this.a.length);
    paramObjectOutputStream.writeInt(this.b);
    int i = this.a.length - 1;
    if (j != 0) {}
    while (i >= 0)
    {
      u localu = this.a[i];
      if (j != 0) {}
      while (localu != null)
      {
        paramObjectOutputStream.writeObject(localu.b);
        paramObjectOutputStream.writeObject(localu.c);
        localu = localu.d;
      }
      i--;
    }
  }
  
  private synchronized void readObject(ObjectInputStream paramObjectInputStream)
    throws IOException, ClassNotFoundException
  {
    paramObjectInputStream.defaultReadObject();
    int i = paramObjectInputStream.readInt();
    int j = paramObjectInputStream.readInt();
    int k = (int)(j * this.d) + j / 20 + 3;
    if ((k > j) && ((k & 0x1) == 0)) {
      k--;
    }
    if ((i > 0) && (k > i)) {
      k = i;
    }
    this.a = new u[k];
    this.b = 0;
    if (Dispatch.H != 0) {}
    while (j > 0)
    {
      Object localObject1 = paramObjectInputStream.readObject();
      Object localObject2 = paramObjectInputStream.readObject();
      put(localObject1, localObject2);
      j--;
    }
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      39[5] = ((char)(0x15 ^ 0xE));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.JHashtable
 * JD-Core Version:    0.7.0.1
 */