package com.linar.jintegra;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.Hashtable;

public class AutomationException
  extends IOException
{
  static final long a = 0L;
  static final long b = 1L;
  static final long c = 2147614726L;
  static final long d = 2147614727L;
  static final long e = 2147614729L;
  static final long f = 2147614725L;
  static final long g = 2147614731L;
  static final long h = 2147549459L;
  static final long i = 1745L;
  static final long j = 1766L;
  static final long k = 2147614719L;
  static final long l = 2147944310L;
  static final long m = 2147614724L;
  static final long n = 2147549445L;
  static final long o = 2147944312L;
  static final long p = 2147500034L;
  static final long q = 2147483652L;
  static final long r = 2147549460L;
  static final long s = 2147500033L;
  static final long t = 2147745801L;
  static final long u = 2147549183L;
  static final long v = 2147942672L;
  static final long w = 2147549467L;
  static final long x = 2147549185L;
  String y;
  String z;
  long A;
  static ExceptionInterceptor B;
  static Hashtable C = new Hashtable();
  
  public String getSource()
  {
    return this.y;
  }
  
  public String getDescription()
  {
    return this.z;
  }
  
  public long getCode()
  {
    return this.A;
  }
  
  public String toString()
  {
    String str = a("\fo\003(\t,n\036(\n\bb\024\"\0249s\030)^m*\017") + Long.toHexString(this.A) + a("m7W") + this.z;
    if ((this.y != null) && (this.y.length() != 0)) {
      str = str + a("ms\031gC") + this.y + "'";
    }
    return str;
  }
  
  public AutomationException(long paramLong, String paramString1, String paramString2)
  {
    super(a("\fo\003(\t,n\036(\n\bb\024\"\0249s\030)^m") + paramString2);
    this.A = paramLong;
    this.y = paramString1;
    this.z = paramString2;
  }
  
  public AutomationException(Throwable paramThrowable)
  {
    this.A = 2147614729L;
    StringWriter localStringWriter = new StringWriter();
    paramThrowable.printStackTrace(new PrintWriter(localStringWriter));
    this.y = localStringWriter.toString();
    this.z = (paramThrowable + "");
  }
  
  void a(long paramLong)
  {
    this.A = paramLong;
  }
  
  public static void setExceptionInterceptor(ExceptionInterceptor paramExceptionInterceptor)
  {
    B = paramExceptionInterceptor;
  }
  
  static AutomationException a(Throwable paramThrowable)
  {
    if ((paramThrowable instanceof InvocationTargetException)) {
      paramThrowable = ((InvocationTargetException)paramThrowable).getTargetException();
    }
    AutomationException localAutomationException = null;
    if (B != null) {
      localAutomationException = B.handleException(paramThrowable);
    }
    if (localAutomationException == null)
    {
      if ((paramThrowable instanceof AutomationException)) {
        return (AutomationException)paramThrowable;
      }
      StringWriter localStringWriter = new StringWriter();
      paramThrowable.printStackTrace(new PrintWriter(localStringWriter));
      String str1 = localStringWriter.toString();
      String str2 = paramThrowable.getMessage();
      if ((str2 == null) || (str2.length() == 0)) {
        str2 = paramThrowable + "";
      }
      long l1 = (paramThrowable instanceof IllegalArgumentException) ? 2147614725L : 2147614729L;
      localAutomationException = new AutomationException(l1, str1, str2);
    }
    return localAutomationException;
  }
  
  AutomationException(String paramString1, String paramString2, long paramLong)
  {
    super(a("\fo\003(\t,n\036(\n\bb\024\"\0249s\030)^m") + paramString2);
    paramString2 = paramString2 == null ? "" : paramString2;
    this.y = paramString1;
    this.z = paramString2;
    this.A = paramLong;
  }
  
  AutomationException(long paramLong, String paramString)
  {
    this(paramString, (String)C.get(new Long(paramLong)), paramLong);
  }
  
  AutomationException(long paramLong)
  {
    this(paramLong, "");
  }
  
  static
  {
    C.put(new Long(5L), cj._5L);
    C.put(new Long(12L), cj._12L);
    C.put(new Long(14L), cj._14L);
    C.put(new Long(32L), cj._32L);
    C.put(new Long(33L), cj._33L);
    C.put(new Long(58L), cj._58L);
    C.put(new Long(59L), cj._59L);
    C.put(new Long(64L), cj._64L);
    C.put(new Long(65L), cj._65L);
    C.put(new Long(67L), cj._67L);
    C.put(new Long(68L), cj._68L);
    C.put(new Long(69L), cj._69L);
    C.put(new Long(70L), cj._70L);
    C.put(new Long(71L), cj._71L);
    C.put(new Long(86L), cj._86L);
    C.put(new Long(89L), cj._89L);
    C.put(new Long(100L), cj._100L);
    C.put(new Long(101L), cj._101L);
    C.put(new Long(102L), cj._102L);
    C.put(new Long(103L), cj._103L);
    C.put(new Long(109L), cj._109L);
    C.put(new Long(111L), cj._111L);
    C.put(new Long(230L), cj._230L);
    C.put(new Long(231L), cj._231L);
    C.put(new Long(232L), cj._232L);
    C.put(new Long(233L), cj._233L);
    C.put(new Long(234L), cj._234L);
    C.put(new Long(240L), cj._240L);
    C.put(new Long(995L), cj._995L);
    C.put(new Long(996L), cj._996L);
    C.put(new Long(997L), cj._997L);
    C.put(new Long(998L), cj._998L);
    C.put(new Long(1001L), cj._1001L);
    C.put(new Long(1056L), cj._1056L);
    C.put(new Long(1057L), cj._1057L);
    C.put(new Long(1058L), cj._1058L);
    C.put(new Long(1059L), cj._1059L);
    C.put(new Long(1060L), cj._1060L);
    C.put(new Long(1061L), cj._1061L);
    C.put(new Long(1062L), cj._1062L);
    C.put(new Long(1064L), cj._1064L);
    C.put(new Long(1067L), cj._1067L);
    C.put(new Long(1069L), cj._1069L);
    C.put(new Long(1070L), cj._1070L);
    C.put(new Long(1114L), cj._1114L);
    C.put(new Long(1115L), cj._1115L);
    C.put(new Long(1150L), cj._1150L);
    C.put(new Long(1151L), cj._1151L);
    C.put(new Long(1152L), cj._1152L);
    C.put(new Long(1153L), cj._1153L);
    C.put(new Long(1154L), cj._1154L);
    C.put(new Long(2202L), cj._2202L);
    C.put(new Long(2250L), cj._2250L);
    C.put(new Long(2401L), cj._2401L);
    C.put(new Long(2402L), cj._2402L);
    C.put(new Long(2404L), cj._2404L);
    C.put(new Long(1200L), cj._1200L);
    C.put(new Long(1201L), cj._1201L);
    C.put(new Long(1203L), cj._1203L);
    C.put(new Long(1204L), cj._1204L);
    C.put(new Long(1205L), cj._1205L);
    C.put(new Long(1206L), cj._1206L);
    C.put(new Long(1209L), cj._1209L);
    C.put(new Long(1210L), cj._1210L);
    C.put(new Long(1211L), cj._1211L);
    C.put(new Long(1212L), cj._1212L);
    C.put(new Long(1213L), cj._1213L);
    C.put(new Long(1214L), cj._1214L);
    C.put(new Long(1216L), cj._1216L);
    C.put(new Long(1217L), cj._1217L);
    C.put(new Long(1218L), cj._1218L);
    C.put(new Long(1219L), cj._1219L);
    C.put(new Long(1220L), cj._1220L);
    C.put(new Long(1221L), cj._1221L);
    C.put(new Long(1222L), cj._1222L);
    C.put(new Long(1223L), cj._1223L);
    C.put(new Long(1225L), cj._1225L);
    C.put(new Long(1226L), cj._1226L);
    C.put(new Long(1228L), cj._1228L);
    C.put(new Long(1229L), cj._1229L);
    C.put(new Long(1230L), cj._1230L);
    C.put(new Long(1231L), cj._1231L);
    C.put(new Long(1232L), cj._1232L);
    C.put(new Long(1233L), cj._1233L);
    C.put(new Long(1234L), cj._1234L);
    C.put(new Long(1235L), cj._1235L);
    C.put(new Long(1236L), cj._1236L);
    C.put(new Long(1237L), cj._1237L);
    C.put(new Long(1238L), cj._1238L);
    C.put(new Long(1239L), cj._1239L);
    C.put(new Long(1240L), cj._1240L);
    C.put(new Long(1241L), cj._1241L);
    C.put(new Long(1242L), cj._1242L);
    C.put(new Long(1243L), cj._1243L);
    C.put(new Long(1244L), cj._1244L);
    C.put(new Long(1245L), cj._1245L);
    C.put(new Long(1300L), cj._1300L);
    C.put(new Long(1301L), cj._1301L);
    C.put(new Long(1302L), cj._1302L);
    C.put(new Long(1303L), cj._1303L);
    C.put(new Long(1304L), cj._1304L);
    C.put(new Long(1305L), cj._1305L);
    C.put(new Long(1306L), cj._1306L);
    C.put(new Long(1307L), cj._1307L);
    C.put(new Long(1308L), cj._1308L);
    C.put(new Long(1309L), cj._1309L);
    C.put(new Long(1310L), cj._1310L);
    C.put(new Long(1311L), cj._1311L);
    C.put(new Long(1312L), cj._1312L);
    C.put(new Long(1313L), cj._1313L);
    C.put(new Long(1314L), cj._1314L);
    C.put(new Long(1315L), cj._1315L);
    C.put(new Long(1316L), cj._1316L);
    C.put(new Long(1317L), cj._1317L);
    C.put(new Long(1318L), cj._1318L);
    C.put(new Long(1319L), cj._1319L);
    C.put(new Long(1320L), cj._1320L);
    C.put(new Long(1321L), cj._1321L);
    C.put(new Long(1322L), cj._1322L);
    C.put(new Long(1323L), cj._1323L);
    C.put(new Long(1324L), cj._1324L);
    C.put(new Long(1325L), cj._1325L);
    C.put(new Long(1326L), cj._1326L);
    C.put(new Long(1327L), cj._1327L);
    C.put(new Long(1328L), cj._1328L);
    C.put(new Long(1329L), cj._1329L);
    C.put(new Long(1330L), cj._1330L);
    C.put(new Long(1331L), cj._1331L);
    C.put(new Long(1332L), cj._1332L);
    C.put(new Long(1333L), cj._1333L);
    C.put(new Long(1334L), cj._1334L);
    C.put(new Long(1335L), cj._1335L);
    C.put(new Long(1336L), cj._1336L);
    C.put(new Long(1337L), cj._1337L);
    C.put(new Long(1338L), cj._1338L);
    C.put(new Long(1340L), cj._1340L);
    C.put(new Long(1341L), cj._1341L);
    C.put(new Long(1342L), cj._1342L);
    C.put(new Long(1343L), cj._1343L);
    C.put(new Long(1344L), cj._1344L);
    C.put(new Long(1345L), cj._1345L);
    C.put(new Long(1346L), cj._1346L);
    C.put(new Long(1347L), cj._1347L);
    C.put(new Long(1348L), cj._1348L);
    C.put(new Long(1349L), cj._1349L);
    C.put(new Long(1350L), cj._1350L);
    C.put(new Long(1351L), cj._1351L);
    C.put(new Long(1352L), cj._1352L);
    C.put(new Long(1353L), cj._1353L);
    C.put(new Long(1354L), cj._1354L);
    C.put(new Long(1355L), cj._1355L);
    C.put(new Long(1356L), cj._1356L);
    C.put(new Long(1357L), cj._1357L);
    C.put(new Long(1358L), cj._1358L);
    C.put(new Long(1359L), cj._1359L);
    C.put(new Long(1360L), cj._1360L);
    C.put(new Long(1361L), cj._1361L);
    C.put(new Long(1362L), cj._1362L);
    C.put(new Long(1363L), cj._1363L);
    C.put(new Long(1364L), cj._1364L);
    C.put(new Long(1365L), cj._1365L);
    C.put(new Long(1366L), cj._1366L);
    C.put(new Long(1367L), cj._1367L);
    C.put(new Long(1368L), cj._1368L);
    C.put(new Long(1369L), cj._1369L);
    C.put(new Long(1370L), cj._1370L);
    C.put(new Long(1371L), cj._1371L);
    C.put(new Long(1372L), cj._1372L);
    C.put(new Long(1373L), cj._1373L);
    C.put(new Long(1374L), cj._1374L);
    C.put(new Long(1375L), cj._1375L);
    C.put(new Long(1376L), cj._1376L);
    C.put(new Long(1377L), cj._1377L);
    C.put(new Long(1378L), cj._1378L);
    C.put(new Long(1379L), cj._1379L);
    C.put(new Long(1380L), cj._1380L);
    C.put(new Long(1381L), cj._1381L);
    C.put(new Long(1382L), cj._1382L);
    C.put(new Long(1383L), cj._1383L);
    C.put(new Long(1384L), cj._1384L);
    C.put(new Long(1385L), cj._1385L);
    C.put(new Long(1386L), cj._1386L);
    C.put(new Long(1387L), cj._1387L);
    C.put(new Long(1388L), cj._1388L);
    C.put(new Long(1389L), cj._1389L);
    C.put(new Long(1390L), cj._1390L);
    C.put(new Long(1391L), cj._1391L);
    C.put(new Long(1392L), cj._1392L);
    C.put(new Long(1393L), cj._1393L);
    C.put(new Long(1394L), cj._1394L);
    C.put(new Long(1395L), cj._1395L);
    C.put(new Long(1459L), cj._1459L);
    C.put(new Long(1460L), cj._1460L);
    C.put(new Long(1700L), cj._1700L);
    C.put(new Long(1701L), cj._1701L);
    C.put(new Long(1702L), cj._1702L);
    C.put(new Long(1703L), cj._1703L);
    C.put(new Long(1704L), cj._1704L);
    C.put(new Long(1705L), cj._1705L);
    C.put(new Long(1706L), cj._1706L);
    C.put(new Long(1707L), cj._1707L);
    C.put(new Long(1708L), cj._1708L);
    C.put(new Long(1709L), cj._1709L);
    C.put(new Long(1710L), cj._1710L);
    C.put(new Long(1711L), cj._1711L);
    C.put(new Long(1712L), cj._1712L);
    C.put(new Long(1713L), cj._1713L);
    C.put(new Long(1714L), cj._1714L);
    C.put(new Long(1715L), cj._1715L);
    C.put(new Long(1716L), cj._1716L);
    C.put(new Long(1717L), cj._1717L);
    C.put(new Long(1718L), cj._1718L);
    C.put(new Long(1719L), cj._1719L);
    C.put(new Long(1720L), cj._1720L);
    C.put(new Long(1721L), cj._1721L);
    C.put(new Long(1722L), cj._1722L);
    C.put(new Long(1723L), cj._1723L);
    C.put(new Long(1724L), cj._1724L);
    C.put(new Long(1725L), cj._1725L);
    C.put(new Long(1726L), cj._1726L);
    C.put(new Long(1727L), cj._1727L);
    C.put(new Long(1728L), cj._1728L);
    C.put(new Long(1730L), cj._1730L);
    C.put(new Long(1732L), cj._1732L);
    C.put(new Long(1733L), cj._1733L);
    C.put(new Long(1734L), cj._1734L);
    C.put(new Long(1735L), cj._1735L);
    C.put(new Long(1736L), cj._1736L);
    C.put(new Long(1737L), cj._1737L);
    C.put(new Long(1739L), cj._1739L);
    C.put(new Long(1740L), cj._1740L);
    C.put(new Long(1741L), cj._1741L);
    C.put(new Long(1742L), cj._1742L);
    C.put(new Long(1743L), cj._1743L);
    C.put(new Long(1744L), cj._1744L);
    C.put(new Long(1745L), cj._1745L);
    C.put(new Long(1746L), cj._1746L);
    C.put(new Long(1747L), cj._1747L);
    C.put(new Long(1748L), cj._1748L);
    C.put(new Long(1749L), cj._1749L);
    C.put(new Long(1750L), cj._1750L);
    C.put(new Long(1751L), cj._1751L);
    C.put(new Long(1752L), cj._1752L);
    C.put(new Long(1753L), cj._1753L);
    C.put(new Long(1754L), cj._1753L);
    C.put(new Long(1755L), cj._1755L);
    C.put(new Long(1756L), cj._1756L);
    C.put(new Long(1757L), cj._1757L);
    C.put(new Long(1758L), cj._1758L);
    C.put(new Long(1759L), cj._1759L);
    C.put(new Long(1760L), cj._1760L);
    C.put(new Long(1761L), cj._1761L);
    C.put(new Long(1762L), cj._1762L);
    C.put(new Long(1763L), cj._1763L);
    C.put(new Long(1764L), cj._1764L);
    C.put(new Long(1765L), cj._1765L);
    C.put(new Long(1766L), cj._1766L);
    C.put(new Long(1767L), cj._1767L);
    C.put(new Long(1768L), cj._1768L);
    C.put(new Long(1769L), cj._1769L);
    C.put(new Long(1770L), cj._1770L);
    C.put(new Long(1771L), cj._1771L);
    C.put(new Long(1772L), cj._1772L);
    C.put(new Long(1773L), cj._1773L);
    C.put(new Long(1774L), cj._1774L);
    C.put(new Long(1775L), cj._1775L);
    C.put(new Long(1777L), cj._1777L);
    C.put(new Long(1778L), cj._1778L);
    C.put(new Long(1779L), cj._1779L);
    C.put(new Long(1780L), cj._1780L);
    C.put(new Long(1781L), cj._1781L);
    C.put(new Long(1782L), cj._1782L);
    C.put(new Long(1783L), cj._1783L);
    C.put(new Long(1784L), cj._1784L);
    C.put(new Long(1785L), cj._1785L);
    C.put(new Long(1786L), cj._1786L);
    C.put(new Long(1787L), cj._1787L);
    C.put(new Long(1788L), cj._1788L);
    C.put(new Long(1789L), cj._1789L);
    C.put(new Long(1790L), cj._1790L);
    C.put(new Long(1791L), cj._1791L);
    C.put(new Long(1792L), cj._1792L);
    C.put(new Long(1793L), cj._1793L);
    C.put(new Long(1794L), cj._1794L);
    C.put(new Long(1795L), cj._1795L);
    C.put(new Long(1796L), cj._1796L);
    C.put(new Long(1797L), cj._1797L);
    C.put(new Long(1798L), cj._1798L);
    C.put(new Long(1799L), cj._1799L);
    C.put(new Long(1800L), cj._1800L);
    C.put(new Long(1801L), cj._1801L);
    C.put(new Long(1802L), cj._1802L);
    C.put(new Long(1803L), cj._1803L);
    C.put(new Long(1804L), cj._1804L);
    C.put(new Long(1805L), cj._1805L);
    C.put(new Long(1806L), cj._1806L);
    C.put(new Long(1807L), cj._1807L);
    C.put(new Long(1808L), cj._1808L);
    C.put(new Long(1809L), cj._1809L);
    C.put(new Long(1810L), cj._1810L);
    C.put(new Long(1811L), cj._1811L);
    C.put(new Long(1812L), cj._1812L);
    C.put(new Long(1813L), cj._1813L);
    C.put(new Long(1814L), cj._1814L);
    C.put(new Long(1815L), cj._1815L);
    C.put(new Long(1816L), cj._1816L);
    C.put(new Long(1817L), cj._1817L);
    C.put(new Long(1818L), cj._1818L);
    C.put(new Long(1819L), cj._1819L);
    C.put(new Long(1820L), cj._1820L);
    C.put(new Long(1821L), cj._1821L);
    C.put(new Long(1822L), cj._1822L);
    C.put(new Long(1823L), cj._1823L);
    C.put(new Long(1824L), cj._1824L);
    C.put(new Long(1825L), cj._1825L);
    C.put(new Long(1826L), cj._1826L);
    C.put(new Long(1827L), cj._1827L);
    C.put(new Long(1828L), cj._1828L);
    C.put(new Long(1829L), cj._1829L);
    C.put(new Long(1830L), cj._1830L);
    C.put(new Long(1831L), cj._1831L);
    C.put(new Long(1832L), cj._1832L);
    C.put(new Long(1898L), cj._1898L);
    C.put(new Long(1899L), cj._1899L);
    C.put(new Long(1900L), cj._1900L);
    C.put(new Long(1901L), cj._1901L);
    C.put(new Long(1902L), cj._1902L);
    C.put(new Long(1903L), cj._1903L);
    C.put(new Long(1904L), cj._1904L);
    C.put(new Long(1905L), cj._1905L);
    C.put(new Long(1906L), cj._1906L);
    C.put(new Long(1907L), cj._1907L);
    C.put(new Long(1908L), cj._1908L);
    C.put(new Long(1909L), cj._1909L);
    C.put(new Long(1910L), cj._1910L);
    C.put(new Long(1911L), cj._1911L);
    C.put(new Long(1912L), cj._1912L);
    C.put(new Long(1913L), cj._1913L);
    C.put(new Long(6118L), cj._6118L);
    C.put(new Long(2147549183L), cj._0X8000FFFFL);
    C.put(new Long(2147500033L), cj._0X80004001L);
    C.put(new Long(2147942414L), cj._0X8007000EL);
    C.put(new Long(2147942487L), cj._0X80070057L);
    C.put(new Long(2147500034L), cj._0X80004002L);
    C.put(new Long(2147500035L), cj._0X80004003L);
    C.put(new Long(2147942406L), cj._0X80070006L);
    C.put(new Long(2147500036L), cj._0X80004004L);
    C.put(new Long(2147500037L), cj._0X80004005L);
    C.put(new Long(2147942405L), cj._0X80070005L);
    C.put(new Long(2147483649L), cj._0X80000001L);
    C.put(new Long(2147483650L), cj._0X80000002L);
    C.put(new Long(2147483651L), cj._0X80000003L);
    C.put(new Long(2147483652L), cj._0X80000004L);
    C.put(new Long(2147483653L), cj._0X80000005L);
    C.put(new Long(2147483654L), cj._0X80000006L);
    C.put(new Long(2147483655L), cj._0X80000007L);
    C.put(new Long(2147483656L), cj._0X80000008L);
    C.put(new Long(2147483657L), cj._0X80000009L);
    C.put(new Long(2147483658L), cj._0X8000000AL);
    C.put(new Long(2147500038L), cj._0X80004006L);
    C.put(new Long(2147500039L), cj._0X80004007L);
    C.put(new Long(2147500040L), cj._0X80004008L);
    C.put(new Long(2147500041L), cj._0X80004009L);
    C.put(new Long(2147500042L), cj._0X8000400AL);
    C.put(new Long(2147500043L), cj._0X8000400BL);
    C.put(new Long(2147500044L), cj._0X8000400CL);
    C.put(new Long(2147500045L), cj._0X8000400DL);
    C.put(new Long(2147500046L), cj._0X8000400EL);
    C.put(new Long(2147500047L), cj._0X8000400FL);
    C.put(new Long(2147500048L), cj._0X80004010L);
    C.put(new Long(2147500049L), cj._0X80004011L);
    C.put(new Long(2147500050L), cj._0X80004012L);
    C.put(new Long(2147500051L), cj._0X80004013L);
    C.put(new Long(2147500052L), cj._0X80004014L);
    C.put(new Long(2147500053L), cj._0X80004015L);
    C.put(new Long(2147500054L), cj._0X80004016L);
    C.put(new Long(2147500055L), cj._0X80004017L);
    C.put(new Long(2147500056L), cj._0X80004018L);
    C.put(new Long(2147500057L), cj._0X80004019L);
    C.put(new Long(2147500058L), cj._0X8000401AL);
    C.put(new Long(2147500059L), cj._0X8000401BL);
    C.put(new Long(2147500060L), cj._0X8000401CL);
    C.put(new Long(2147500061L), cj._0X8000401DL);
    C.put(new Long(2147500062L), cj._0X8000401EL);
    C.put(new Long(2147500063L), cj._0X8000401FL);
    C.put(new Long(2147500064L), cj._0X80004020L);
    C.put(new Long(2147500065L), cj._0X80004021L);
    C.put(new Long(2147745792L), cj._0X80040000L);
    C.put(new Long(2147745793L), cj._0X80040001L);
    C.put(new Long(2147745794L), cj._0X80040002L);
    C.put(new Long(2147745795L), cj._0X80040003L);
    C.put(new Long(2147745796L), cj._0X80040004L);
    C.put(new Long(2147745797L), cj._0X80040005L);
    C.put(new Long(2147745798L), cj._0X80040006L);
    C.put(new Long(2147745799L), cj._0X80040007L);
    C.put(new Long(2147745800L), cj._0X80040008L);
    C.put(new Long(2147745801L), cj._0X80040009L);
    C.put(new Long(2147745802L), cj._0X8004000AL);
    C.put(new Long(2147745803L), cj._0X8004000BL);
    C.put(new Long(2147745804L), cj._0X8004000CL);
    C.put(new Long(2147745805L), cj._0X8004000DL);
    C.put(new Long(2147745806L), cj._0X8004000EL);
    C.put(new Long(2147745807L), cj._0X8004000FL);
    C.put(new Long(2147745808L), cj._0X80040010L);
    C.put(new Long(2147745809L), cj._0X80040011L);
    C.put(new Long(2147745810L), cj._0X80040012L);
    C.put(new Long(2147745892L), cj._0X80040064L);
    C.put(new Long(2147745893L), cj._0X80040065L);
    C.put(new Long(2147745894L), cj._0X80040066L);
    C.put(new Long(2147745895L), cj._0X80040067L);
    C.put(new Long(2147745896L), cj._0X80040068L);
    C.put(new Long(2147745897L), cj._0X80040069L);
    C.put(new Long(2147745898L), cj._0X8004006AL);
    C.put(new Long(2147745899L), cj._0X8004006BL);
    C.put(new Long(2147745900L), cj._0X8004006CL);
    C.put(new Long(2147745901L), cj._0X8004006DL);
    C.put(new Long(2147746064L), cj._0X80040110L);
    C.put(new Long(2147746065L), cj._0X80040111L);
    C.put(new Long(2147746112L), cj._0X80040140L);
    C.put(new Long(2147746128L), cj._0X80040150L);
    C.put(new Long(2147746129L), cj._0X80040151L);
    C.put(new Long(2147746130L), cj._0X80040152L);
    C.put(new Long(2147746131L), cj._0X80040153L);
    C.put(new Long(2147746132L), cj._0X80040154L);
    C.put(new Long(2147746133L), cj._0X80040155L);
    C.put(new Long(2147746160L), cj._0X80040170L);
    C.put(new Long(2147746176L), cj._0X80040180L);
    C.put(new Long(2147746177L), cj._0X80040181L);
    C.put(new Long(2147746208L), cj._0X800401A0L);
    C.put(new Long(2147746209L), cj._0X800401A1L);
    C.put(new Long(2147746240L), cj._0X800401C0L);
    C.put(new Long(2147746241L), cj._0X800401C1L);
    C.put(new Long(2147746242L), cj._0X800401C2L);
    C.put(new Long(2147746243L), cj._0X800401C3L);
    C.put(new Long(2147746244L), cj._0X800401C4L);
    C.put(new Long(2147746245L), cj._0X800401C5L);
    C.put(new Long(2147746256L), cj._0X800401D0L);
    C.put(new Long(2147746257L), cj._0X800401D1L);
    C.put(new Long(2147746258L), cj._0X800401D2L);
    C.put(new Long(2147746259L), cj._0X800401D3L);
    C.put(new Long(2147746260L), cj._0X800401D4L);
    C.put(new Long(2147746272L), cj._0X800401E0L);
    C.put(new Long(2147746273L), cj._0X800401E1L);
    C.put(new Long(2147746274L), cj._0X800401E2L);
    C.put(new Long(2147746275L), cj._0X800401E3L);
    C.put(new Long(2147746276L), cj._0X800401E4L);
    C.put(new Long(2147746277L), cj._0X800401E5L);
    C.put(new Long(2147746278L), cj._0X800401E6L);
    C.put(new Long(2147746279L), cj._0X800401E7L);
    C.put(new Long(2147746280L), cj._0X800401E8L);
    C.put(new Long(2147746281L), cj._0X800401E9L);
    C.put(new Long(2147746282L), cj._0X800401EAL);
    C.put(new Long(2147746283L), cj._0X800401EBL);
    C.put(new Long(2147746284L), cj._0X800401ECL);
    C.put(new Long(2147746285L), cj._0X800401EDL);
    C.put(new Long(2147746286L), cj._0X800401EEL);
    C.put(new Long(2147746287L), cj._0X800401EFL);
    C.put(new Long(2147746288L), cj._0X800401F0L);
    C.put(new Long(2147746289L), cj._0X800401F1L);
    C.put(new Long(2147746290L), cj._0X800401F2L);
    C.put(new Long(2147746291L), cj._0X800401F3L);
    C.put(new Long(2147746292L), cj._0X800401F4L);
    C.put(new Long(2147746293L), cj._0X800401F5L);
    C.put(new Long(2147746294L), cj._0X800401F6L);
    C.put(new Long(2147746295L), cj._0X800401F7L);
    C.put(new Long(2147746296L), cj._0X800401F8L);
    C.put(new Long(2147746297L), cj._0X800401F9L);
    C.put(new Long(2147746298L), cj._0X800401FAL);
    C.put(new Long(2147746299L), cj._0X800401FBL);
    C.put(new Long(2147746300L), cj._0X800401FCL);
    C.put(new Long(2147746301L), cj._0X800401FDL);
    C.put(new Long(2147746302L), cj._0X800401FEL);
    C.put(new Long(2147746303L), cj._0X800401FFL);
    C.put(new Long(262144L), cj._0X00040000L);
    C.put(new Long(262145L), cj._0X00040001L);
    C.put(new Long(262146L), cj._0X00040002L);
    C.put(new Long(262400L), cj._0X00040100L);
    C.put(new Long(262401L), cj._0X00040101L);
    C.put(new Long(262402L), cj._0X00040102L);
    C.put(new Long(262448L), cj._0X00040130L);
    C.put(new Long(262464L), cj._0X00040140L);
    C.put(new Long(262512L), cj._0X00040170L);
    C.put(new Long(262513L), cj._0X00040171L);
    C.put(new Long(262514L), cj._0X00040172L);
    C.put(new Long(262528L), cj._0X00040180L);
    C.put(new Long(262529L), cj._0X00040181L);
    C.put(new Long(262530L), cj._0X00040182L);
    C.put(new Long(262560L), cj._0X000401A0L);
    C.put(new Long(262592L), cj._0X000401C0L);
    C.put(new Long(262626L), cj._0X000401E2L);
    C.put(new Long(262628L), cj._0X000401E4L);
    C.put(new Long(262629L), cj._0X000401E5L);
    C.put(new Long(262630L), cj._0X000401E6L);
    C.put(new Long(262631L), cj._0X000401E7L);
    C.put(new Long(2148007937L), cj._0X80080001L);
    C.put(new Long(2148007938L), cj._0X80080002L);
    C.put(new Long(2148007939L), cj._0X80080003L);
    C.put(new Long(2148007940L), cj._0X80080004L);
    C.put(new Long(2148007941L), cj._0X80080005L);
    C.put(new Long(2148007942L), cj._0X80080006L);
    C.put(new Long(2148007943L), cj._0X80080007L);
    C.put(new Long(2148007944L), cj._0X80080008L);
    C.put(new Long(2148007945L), cj._0X80080009L);
    C.put(new Long(2148007952L), cj._0X80080010L);
    C.put(new Long(2148007953L), cj._0X80080011L);
    C.put(new Long(524306L), cj._0X00080012L);
    C.put(new Long(2147614721L), cj._0X80020001L);
    C.put(new Long(2147614723L), cj._0X80020003L);
    C.put(new Long(2147614724L), cj._0X80020004L);
    C.put(new Long(2147614725L), cj._0X80020005L);
    C.put(new Long(2147614726L), cj._0X80020006L);
    C.put(new Long(2147614727L), cj._0X80020007L);
    C.put(new Long(2147614728L), cj._0X80020008L);
    C.put(new Long(2147614729L), cj._0X80020009L);
    C.put(new Long(2147614730L), cj._0X8002000AL);
    C.put(new Long(2147614731L), cj._0X8002000BL);
    C.put(new Long(2147614732L), cj._0X8002000CL);
    C.put(new Long(2147614733L), cj._0X8002000DL);
    C.put(new Long(2147614734L), cj._0X8002000EL);
    C.put(new Long(2147614735L), cj._0X8002000FL);
    C.put(new Long(2147614736L), cj._0X80020010L);
    C.put(new Long(2147614737L), cj._0X80020011L);
    C.put(new Long(2147647510L), cj._0X80028016L);
    C.put(new Long(2147647512L), cj._0X80028018L);
    C.put(new Long(2147647513L), cj._0X80028019L);
    C.put(new Long(2147647516L), cj._0X8002801CL);
    C.put(new Long(2147647517L), cj._0X8002801DL);
    C.put(new Long(2147647527L), cj._0X80028027L);
    C.put(new Long(2147647528L), cj._0X80028028L);
    C.put(new Long(2147647529L), cj._0X80028029L);
    C.put(new Long(2147647530L), cj._0X8002802AL);
    C.put(new Long(2147647531L), cj._0X8002802BL);
    C.put(new Long(2147647532L), cj._0X8002802CL);
    C.put(new Long(2147647533L), cj._0X8002802DL);
    C.put(new Long(2147647534L), cj._0X8002802EL);
    C.put(new Long(2147647535L), cj._0X8002802FL);
    C.put(new Long(2147649725L), cj._0X800288BDL);
    C.put(new Long(2147649733L), cj._0X800288C5L);
    C.put(new Long(2147649734L), cj._0X800288C6L);
    C.put(new Long(2147649743L), cj._0X800288CFL);
    C.put(new Long(2147650720L), cj._0X80028CA0L);
    C.put(new Long(2147650721L), cj._0X80028CA1L);
    C.put(new Long(2147650722L), cj._0X80028CA2L);
    C.put(new Long(2147650723L), cj._0X80028CA3L);
    C.put(new Long(2147654730L), cj._0X80029C4AL);
    C.put(new Long(2147654787L), cj._0X80029C83L);
    C.put(new Long(2147654788L), cj._0X80029C84L);
    C.put(new Long(2147549185L), cj._0X80010001L);
    C.put(new Long(2147549186L), cj._0X80010002L);
    C.put(new Long(2147549187L), cj._0X80010003L);
    C.put(new Long(2147549188L), cj._0X80010004L);
    C.put(new Long(2147549189L), cj._0X80010005L);
    C.put(new Long(2147549190L), cj._0X80010006L);
    C.put(new Long(2147549191L), cj._0X80010007L);
    C.put(new Long(2147549192L), cj._0X80010008L);
    C.put(new Long(2147549193L), cj._0X80010009L);
    C.put(new Long(2147549194L), cj._0X8001000AL);
    C.put(new Long(2147549195L), cj._0X8001000BL);
    C.put(new Long(2147549196L), cj._0X8001000CL);
    C.put(new Long(2147549197L), cj._0X8001000DL);
    C.put(new Long(2147549198L), cj._0X8001000EL);
    C.put(new Long(2147549199L), cj._0X8001000FL);
    C.put(new Long(2147549200L), cj._0X80010010L);
    C.put(new Long(2147549201L), cj._0X80010011L);
    C.put(new Long(2147549202L), cj._0X80010012L);
    C.put(new Long(2147549440L), cj._0X80010100L);
    C.put(new Long(2147549441L), cj._0X80010101L);
    C.put(new Long(2147549442L), cj._0X80010102L);
    C.put(new Long(2147549443L), cj._0X80010103L);
    C.put(new Long(2147549444L), cj._0X80010104L);
    C.put(new Long(2147549445L), cj._0X80010105L);
    C.put(new Long(2147549446L), cj._0X80010106L);
    C.put(new Long(2147549447L), cj._0X80010107L);
    C.put(new Long(2147549448L), cj._0X80010108L);
    C.put(new Long(2147549449L), cj._0X80010109L);
    C.put(new Long(2147549450L), cj._0X8001010AL);
    C.put(new Long(2147549451L), cj._0X8001010BL);
    C.put(new Long(2147549452L), cj._0X8001010CL);
    C.put(new Long(2147549453L), cj._0X8001010DL);
    C.put(new Long(2147549454L), cj._0X8001010EL);
    C.put(new Long(2147549455L), cj._0X8001010FL);
    C.put(new Long(2147549456L), cj._0X80010110L);
    C.put(new Long(2147549457L), cj._0X80010111L);
    C.put(new Long(2147549458L), cj._0X80010112L);
    C.put(new Long(2147549459L), cj._0X80010113L);
    C.put(new Long(2147549460L), cj._0X80010114L);
    C.put(new Long(2147549461L), cj._0X80010115L);
    C.put(new Long(2147549462L), cj._0X80010116L);
    C.put(new Long(2147549463L), cj._0X80010117L);
    C.put(new Long(2147549464L), cj._0X80010118L);
    C.put(new Long(2147549465L), cj._0X80010119L);
    C.put(new Long(2147549466L), cj._0X8001011AL);
    C.put(new Long(2147549467L), cj._0X8001011BL);
    C.put(new Long(2147549468L), cj._0X8001011CL);
    C.put(new Long(2147549469L), cj._0X8001011DL);
    C.put(new Long(2147614719L), cj._0X8001FFFFL);
    C.put(new Long(2148073473L), cj._0X80090001L);
    C.put(new Long(2148073474L), cj._0X80090002L);
    C.put(new Long(2148073475L), cj._0X80090003L);
    C.put(new Long(2148073476L), cj._0X80090004L);
    C.put(new Long(2148073477L), cj._0X80090005L);
    C.put(new Long(2148073478L), cj._0X80090006L);
    C.put(new Long(2148073479L), cj._0X80090007L);
    C.put(new Long(2148073480L), cj._0X80090008L);
    C.put(new Long(2148073481L), cj._0X80090009L);
    C.put(new Long(2148073482L), cj._0X8009000AL);
    C.put(new Long(2148073483L), cj._0X8009000BL);
    C.put(new Long(2148073484L), cj._0X8009000CL);
    C.put(new Long(2148073485L), cj._0X8009000DL);
    C.put(new Long(2148073486L), cj._0X8009000EL);
    C.put(new Long(2148073487L), cj._0X8009000FL);
    C.put(new Long(2148073488L), cj._0X80090010L);
    C.put(new Long(2148073489L), cj._0X80090011L);
    C.put(new Long(2148073490L), cj._0X80090012L);
    C.put(new Long(2148073491L), cj._0X80090013L);
    C.put(new Long(2148073492L), cj._0X80090014L);
    C.put(new Long(2148073493L), cj._0X80090015L);
    C.put(new Long(2148073494L), cj._0X80090016L);
    C.put(new Long(2148073495L), cj._0X80090017L);
    C.put(new Long(2148073496L), cj._0X80090018L);
    C.put(new Long(2148073497L), cj._0X80090019L);
    C.put(new Long(2148073498L), cj._0X8009001AL);
    C.put(new Long(2148073499L), cj._0X8009001BL);
    C.put(new Long(2148073500L), cj._0X8009001CL);
    C.put(new Long(2148073501L), cj._0X8009001DL);
    C.put(new Long(2148073502L), cj._0X8009001EL);
    C.put(new Long(2148073503L), cj._0X8009001FL);
    C.put(new Long(2148073504L), cj._0X80090020L);
    C.put(new Long(2148073505L), cj._0X80090021L);
    C.put(new Long(2148204545L), cj._0X800B0001L);
    C.put(new Long(2148204546L), cj._0X800B0002L);
    C.put(new Long(2148204547L), cj._0X800B0003L);
    C.put(new Long(2148204548L), cj._0X800B0004L);
    C.put(new Long(2148204549L), cj._0X800B0005L);
    C.put(new Long(2148204550L), cj._0X800B0006L);
    C.put(new Long(2148204551L), cj._0X800B0007L);
    C.put(new Long(2148204552L), cj._0X800B0008L);
    C.put(new Long(2148204553L), cj._0X800B0009L);
    C.put(new Long(2148204554L), cj._0X800B000AL);
    C.put(new Long(2148204555L), cj._0X800B000BL);
    C.put(new Long(2148204800L), cj._0X800B0100L);
    C.put(new Long(2148204801L), cj._0X800B0101L);
    C.put(new Long(2148204802L), cj._0X800B0102L);
    C.put(new Long(2148204803L), cj._0X800B0103L);
    C.put(new Long(2148204804L), cj._0X800B0104L);
    C.put(new Long(2148204805L), cj._0X800B0105L);
    C.put(new Long(2148204806L), cj._0X800B0106L);
    C.put(new Long(2148204807L), cj._0X800B0107L);
    C.put(new Long(2148204808L), cj._0X800B0108L);
    C.put(new Long(2148204809L), cj._0X800B0109L);
    C.put(new Long(2148204810L), cj._0X800B010AL);
    C.put(new Long(2147803138L), a("\016U9\023!\025N(\002;\fX8\0250\b^"));
    C.put(new Long(2147803139L), a("\016U9\023!\025N(\002;\fX8\0250\004T0"));
    C.put(new Long(2147803140L), a("\016U9\023!\025N(\002;\003U4\b*\031_/\023"));
    C.put(new Long(2147803141L), a("\016U9\023!\025N(\002;\003U#\025!\nS$\023!\037_3"));
    C.put(new Long(2147803143L), a("\016U9\023!\025N(\002;\002V3\025!\013"));
    C.put(new Long(2147803148L), a("\016U9\023!\025N(\002;\037U;\002*\002N1\b1\003^"));
    C.put(new Long(2147803149L), a("\016U9\023!\025N(\002;\003U$\002'\030H>\023="));
    C.put(new Long(2147803150L), a("\016U9\023!\025N(\002;\032H8\t#\031R%\002%\t"));
    C.put(new Long(2147803151L), a("\016U9\023!\025N(\002;\031W9\b0\fL6\016(\fX;\002"));
    C.put(new Long(2147803168L), a("\016U9\023!\025N(\002;\004T$\022\"\013S4\016!\003N;\016'\bT$\0027"));
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      26[119] = ((char)(0x47 ^ 0x64));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.AutomationException
 * JD-Core Version:    0.7.0.1
 */