package com.linar.jintegra;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.IOException;
import java.io.PrintStream;

public class GetJvmMoniker
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    if (paramArrayOfString.length != 2)
    {
      System.out.println(cj.HOST_NAME_AND_PORT_NUMBER_MISSING);
      return;
    }
    String str1 = paramArrayOfString[0];
    int i = new Integer(paramArrayOfString[1]).intValue();
    n localn = new n();
    localn.a(7, str1 + "[" + i + "]");
    localn.a(10, 65535, "");
    localn.a(0, 0, "");
    y localy = new y(true, null);
    StdObjRef.a(localy, k.IID_IDISPATCH, 4096L, 0L, 7021788454466775370L, Jvm.d, k.ACTIVATOR_IPID, localn);
    byte[] arrayOfByte = localy.e();
    String str2 = a("\007xn\rC\016 ") + d.encode(arrayOfByte) + ":";
    String str3 = a("bPR2\006%uj\026M\rh$\fS\013ya\fU\016oh\023_Hyv\032G\034`Q,b");
    str3 = str3 + a("Y4$0HH") + str1 + a("Hip\036T\034:p\027CHPR2\006\004so\032\006\034rm\f\034b");
    str3 = str3 + a("H:$\025G\036{$Rb\"SJ+c/HE b+UI v'HPB") + i + a("HAi\036O\006Yh\036U\033G\016u");
    str3 = str3 + a("");
    str3 = str3 + a("H:$,C\034:n\tKH'$8C\034Uf\025C\013n,]") + str2 + a("J3\016u");
    str3 = str3 + a("[4$*U\r:p\027CHwk\021O\003v_R\007:e\034E\riw_l\tle_I\npa\034R\0334$9I\032:a\007G\005jh\032\034b");
    str3 = str3 + a("H:$,C\034:n\036P\tUf\025C\013n$B\006\002liQA\rn,]L\tleQS\034shQp\ryp\020TJ3\016u");
    System.out.println(str3);
    String str4 = a(";p_L\036w$B\006/p0D\002g\013\016J") + str2 + a("J3\016u");
    str4 = str4 + a(";p_L\tle0D\002g\013\006U:n\tKF}a\013\016Jpe\tGFop\026JFLa\034R\007h&V,");
    if (!bi.M())
    {
      Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(str4), null);
      System.out.println(a("B0$+N\r:e\035I\036$\013C\020n$\027G\033:f\032C\006:g\020V\001`_R\007:p\027CHyh\026V\nue\rBF\020"));
      if (Dispatch.H == 0) {}
    }
    else
    {
      System.out.println(a("B0$+N\r:e\035I\036$\013C\020n$\027G\033:J0rHxa\032HHyk\017O\r~$\013IHnl\032\006\013vm\017D\007{v\033\b"));
    }
    System.exit(0);
  }
  
  public static String get(String paramString, int paramInt)
    throws IOException
  {
    n localn = new n();
    localn.a(7, paramString + "[" + paramInt + "]");
    localn.a(10, 65535, "");
    localn.a(0, 0, "");
    y localy = new y(true, null);
    StdObjRef.a(localy, k.IID_IDISPATCH, 4096L, 0L, 7021788454466775370L, Jvm.d, k.ACTIVATOR_IPID, localn);
    byte[] arrayOfByte = localy.e();
    return a("\007xn\rC\016 ") + d.encode(arrayOfByte) + ":";
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      26[4] = ((char)(0x7F ^ 0x26));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.GetJvmMoniker
 * JD-Core Version:    0.7.0.1
 */