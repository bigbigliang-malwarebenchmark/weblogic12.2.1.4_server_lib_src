package com.linar.jintegra;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.Date;
import java.util.Stack;

class NDRStream
{
  private static final boolean a = false;
  static PrintStream b;
  int c = 0;
  int d = 0;
  boolean e;
  boolean f = false;
  Stack g = new Stack();
  boolean h;
  
  void a(boolean paramBoolean)
  {
    this.e = paramBoolean;
  }
  
  boolean a()
  {
    return this.e;
  }
  
  int b()
  {
    return this.c;
  }
  
  void a(int paramInt)
  {
    this.c = paramInt;
    this.d = paramInt;
  }
  
  void b(boolean paramBoolean)
  {
    this.f = paramBoolean;
  }
  
  final int b(int paramInt)
  {
    int i = this.c % paramInt;
    if (i == 0) {
      return 0;
    }
    return paramInt - i;
  }
  
  NDRStream(boolean paramBoolean, PrintStream paramPrintStream)
  {
    this.e = paramBoolean;
    this.h = (b != null);
  }
  
  final void a(String paramString)
    throws IOException
  {}
  
  final void c()
    throws IOException
  {}
  
  final void a(String paramString1, String paramString2, int paramInt)
    throws IOException
  {}
  
  final void a(String paramString1, String paramString2, long paramLong)
    throws IOException
  {}
  
  final void a(String paramString1, String paramString2, byte[] paramArrayOfByte)
    throws IOException
  {}
  
  final void a(String paramString1, String paramString2, String paramString3)
    throws IOException
  {}
  
  final void d()
    throws IOException
  {}
  
  void a(byte[] paramArrayOfByte) {}
  
  static String c(int paramInt)
  {
    String str = Integer.toHexString(paramInt & 0xFF);
    if (str.length() == 1) {
      str = "0" + str;
    }
    return str;
  }
  
  static void a(byte[] paramArrayOfByte, int paramInt, PrintStream paramPrintStream)
  {
    int n = Dispatch.H;
    StringBuffer localStringBuffer1 = new StringBuffer();
    StringBuffer localStringBuffer2 = new StringBuffer();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte, 0, paramInt);
    int i = 0;
    int j = 0;
    paramPrintStream.println(b("\017Ggh\002\017Gwx\002\037Vgx\020\017Wth\022\033Gw}\002\037Qgx\025\017Wh\022\026Gw\t\002\037%gxa\017W\003h\022jGw\016"));
    int k = localByteArrayInputStream.read();
    if (n != 0)
    {
      i++;
      localStringBuffer1.append(c(k) + " ");
    }
    StringBuffer localStringBuffer3;
    do
    {
      if ((k >= 32) && (k < 127))
      {
        localStringBuffer2.append((char)k);
        if (n == 0) {}
      }
      else
      {
        localStringBuffer2.append(".");
      }
      if (i == 16)
      {
        i = 0;
        localStringBuffer3 = new StringBuffer(Integer.toHexString(j));
        if (n != 0) {}
        do
        {
          do
          {
            localStringBuffer3.insert(0, "0");
          } while (localStringBuffer3.length() != 4);
          paramPrintStream.print(localStringBuffer3 + b("\025Gg"));
          paramPrintStream.print(localStringBuffer1);
          paramPrintStream.println(b("\017Gg") + localStringBuffer2);
          localStringBuffer1.setLength(0);
        } while (n != 0);
        localStringBuffer2.setLength(0);
        j += 16;
      }
      k = localByteArrayInputStream.read();
      if (k != -1) {
        break;
      }
    } while (n != 0);
    if (localStringBuffer1.length() != 0)
    {
      localStringBuffer3 = new StringBuffer(Integer.toHexString(j));
      if (n != 0) {}
      while (localStringBuffer3.length() != 4) {
        localStringBuffer3.insert(0, "0");
      }
      paramPrintStream.print(localStringBuffer3 + b("\025Gg"));
      paramPrintStream.print(localStringBuffer1);
      int m = i;
      if (n != 0) {}
      do
      {
        do
        {
          paramPrintStream.print(b("\017Gg"));
          m++;
        } while (m < 16);
      } while (n != 0);
      paramPrintStream.println(b("\017Gg") + localStringBuffer2);
    }
    paramPrintStream.flush();
  }
  
  void a(byte[] paramArrayOfByte, int paramInt) {}
  
  public static Date comDateToJavaDate(double paramDouble)
  {
    paramDouble -= 25569.0D;
    Calendar localCalendar = Calendar.getInstance();
    long l = Math.round(86400000.0D * paramDouble) - localCalendar.get(15);
    localCalendar.setTime(new Date(l));
    l -= localCalendar.get(16);
    return new Date(l);
  }
  
  public static double javaDateToComDate(Date paramDate)
  {
    if (paramDate == null) {
      return 0.0D;
    }
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.setTime(paramDate);
    long l = localCalendar.get(15) + localCalendar.get(16);
    double d1 = paramDate.getTime() + l;
    return 25569.0D + d1 / 86400000.0D;
  }
  
  public static void toBigDecimal(BigDecimal paramBigDecimal, int[] paramArrayOfInt1, int[] paramArrayOfInt2, long[] paramArrayOfLong1, long[] paramArrayOfLong2)
  {
    paramArrayOfInt1[0] = paramBigDecimal.scale();
    paramArrayOfInt2[0] = (paramBigDecimal.signum() < 0 ? '' : 0);
    BigInteger localBigInteger = paramBigDecimal.toBigInteger();
    byte[] arrayOfByte1 = paramBigDecimal.movePointRight(paramBigDecimal.scale()).toBigInteger().abs().toByteArray();
    if ((arrayOfByte1.length > 12) && ((arrayOfByte1.length != 13) || (arrayOfByte1[0] != 0))) {
      throw new NumberFormatException(cj.translate(cj.SIZE_EXCEEDED_COM_DECIMALS_MAX_SIZE, paramBigDecimal, Integer.toString(arrayOfByte1.length)));
    }
    byte[] arrayOfByte2 = arrayOfByte1;
    arrayOfByte1 = new byte[12];
    int i = arrayOfByte2[0] == 0 ? 1 : 0;
    int j = arrayOfByte2.length - i;
    int k = 12 - j;
    if (j != 0) {
      System.arraycopy(arrayOfByte2, i, arrayOfByte1, k, j);
    }
    paramArrayOfLong1[0] = x.a(false, arrayOfByte1, 0);
    paramArrayOfLong2[0] = (x.a(false, arrayOfByte1, 4) << 32 | x.a(false, arrayOfByte1, 8));
  }
  
  public static BigDecimal toBigDecimal(int paramInt1, int paramInt2, long paramLong1, long paramLong2)
  {
    int j = Dispatch.H;
    int i = 0;
    if (paramInt2 == 128)
    {
      i = -1;
      if (j == 0) {}
    }
    else if ((paramLong1 == 0L) && (paramLong2 == 0L))
    {
      i = 0;
      if (j == 0) {}
    }
    else
    {
      i = 1;
    }
    byte[] arrayOfByte = new byte[12];
    arrayOfByte[0] = ((byte)(int)(paramLong1 >> 24 & 0xFF));
    arrayOfByte[1] = ((byte)(int)(paramLong1 >> 16 & 0xFF));
    arrayOfByte[2] = ((byte)(int)(paramLong1 >> 8 & 0xFF));
    arrayOfByte[3] = ((byte)(int)(paramLong1 >> 0 & 0xFF));
    arrayOfByte[4] = ((byte)(int)(paramLong2 >> 56 & 0xFF));
    arrayOfByte[5] = ((byte)(int)(paramLong2 >> 48 & 0xFF));
    arrayOfByte[6] = ((byte)(int)(paramLong2 >> 40 & 0xFF));
    arrayOfByte[7] = ((byte)(int)(paramLong2 >> 32 & 0xFF));
    arrayOfByte[8] = ((byte)(int)(paramLong2 >> 24 & 0xFF));
    arrayOfByte[9] = ((byte)(int)(paramLong2 >> 16 & 0xFF));
    arrayOfByte[10] = ((byte)(int)(paramLong2 >> 8 & 0xFF));
    arrayOfByte[11] = ((byte)(int)(paramLong2 >> 0 & 0xFF));
    BigInteger localBigInteger = new BigInteger(i, arrayOfByte);
    return new BigDecimal(localBigInteger, paramInt1);
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      103[71] = ((char)(0x48 ^ 0x22));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.NDRStream
 * JD-Core Version:    0.7.0.1
 */