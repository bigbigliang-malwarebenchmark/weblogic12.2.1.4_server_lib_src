package com.linar.jintegra;

import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Vector;

public class Marshaller
{
  MemberDesc a;
  Uuid b;
  Object[] c;
  int d = 0;
  int e = 0;
  static volatile int f;
  x g;
  boolean h;
  Vector i = new Vector();
  static Class j;
  
  Marshaller(Uuid paramUuid, int paramInt, Object[] paramArrayOfObject)
    throws IOException, AutomationException
  {
    this.a = InterfaceDesc.a(paramUuid, paramInt);
    Log.log(3, b("+i2)g\007d,?}Fa.3{\017i,3|\003l`<`\024(") + this.a);
    this.c = paramArrayOfObject;
  }
  
  Marshaller(MemberDesc paramMemberDesc)
    throws IOException, AutomationException
  {
    this.a = paramMemberDesc;
    Log.log(3, b("+i2)g\007d,?}Fa.3{\017i,3|\003l`<`\024(") + paramMemberDesc);
  }
  
  void a(Uuid paramUuid)
  {
    this.b = paramUuid;
  }
  
  String a()
  {
    return this.a.a;
  }
  
  void a(int paramInt1, int paramInt2)
  {
    this.d = paramInt1;
    this.e = paramInt2;
  }
  
  Marshaller(x paramx)
  {
    this.g = paramx;
  }
  
  Object[] a(x paramx)
    throws IOException
  {
    int n = Dispatch.H;
    Object[] arrayOfObject = this.c;
    this.c = new Object[this.a.c.length - 1];
    if (arrayOfObject != null)
    {
      int k = 0;
      if (n != 0) {}
      while ((k < arrayOfObject.length) && (k < this.c.length))
      {
        this.c[k] = arrayOfObject[k];
        k++;
      }
    }
    this.g = paramx;
    Class[] arrayOfClass = this.a.b;
    if (this.a.g != null) {
      arrayOfClass = this.a.g.getParameterTypes();
    }
    int m = 0;
    if (n != 0) {}
    do
    {
      do
      {
        if (!this.a.c[m].a())
        {
          this.c[m] = Array.newInstance(arrayOfClass[m].getComponentType(), 1);
          if (n == 0) {}
        }
        else
        {
          Object localObject = a(this.a.a, this.a.c[m]);
          Log.log(3, b("/f0/{FX!(n\013m4?}F") + m + b("F ") + this.a.c[m].name + b("O(}z") + localObject);
          if (!this.a.c[m].e()) {
            if (this.a.c[m].b())
            {
              this.c[m] = Array.newInstance(arrayOfClass[m].getComponentType(), 1);
              Array.set(this.c[m], 0, localObject);
              if (n == 0) {}
            }
            else
            {
              this.c[m] = localObject;
            }
          }
        }
        m++;
      } while (m < this.c.length);
    } while (n != 0);
    if (!this.i.isEmpty()) {
      throw new RuntimeException(cj.UNCLAIMED_POINTER_IDS);
    }
    return this.c;
  }
  
  void a(y paramy, Object paramObject)
    throws IOException
  {
    int n = Dispatch.H;
    paramy.a(8);
    int k = 0;
    if (n != 0) {}
    int m;
    do
    {
      do
      {
        if (this.a.c[k].b())
        {
          Log.log(3, b(")}4*z\022(\020;}\007e%.j\024(") + k + b("F ") + this.a.c[k].name + b("O(}z") + Array.get(this.c[k], 0));
          a(this.a.a, this.a.c[k], this.c[k], paramy);
        }
        k++;
      } while (k < this.c.length);
      m = this.a.c.length - 1;
    } while (n != 0);
    if ((m >= 0) && (this.a.c[m].d()) && (this.a.c[m].vt != 24))
    {
      Log.log(3, b("4m4/}\b(6;c\023m`g/") + paramObject);
      a(this.a.a, this.a.c[m], new Object[] { paramObject }, paramy);
    }
  }
  
  y b()
    throws IOException
  {
    PrintStream localPrintStream = null;
    y localy = new y(true, localPrintStream);
    if (this.d == 0) {
      throw new RuntimeException(cj.COM_VERSION_NOT_INITIALIZED);
    }
    localy.a(40);
    localy.b(true);
    localy.a(this.a.a + b("Fz%+z\003{4z`\023|"));
    localy.a(b(")Z\020\031[.A\023z%)Z\020\031{\016a3"));
    localy.a(b("%G\r\fJ4[\t\025AF~%(|\017g."));
    localy.d(this.d, b("\023W)4{W>"), b("\013i*5}"));
    localy.d(this.e, b("\023W)4{W>"), b("\013a.5}"));
    localy.c();
    localy.a(0L, b("\023W)4{U:"), b(""));
    localy.a(0L, b("\023W)4{U:"), b("\024m3?}\020m$k"));
    localy.a(this.b, b("\005a$"));
    localy.a(0L, b("\023W)4{U:"), b("\003p4?a\022(!(}\007q`*{\024()>"));
    localy.c();
    int k = 0;
    if (Dispatch.H != 0) {}
    while (k < this.a.c.length)
    {
      if (this.a.c[k].a()) {
        a(this.a.a, this.a.c[k], this.c[k], localy);
      }
      k++;
    }
    return localy;
  }
  
  private void a(String paramString, Param paramParam, Object paramObject, y paramy)
    throws IOException
  {
    int i2 = Dispatch.H;
    Log.log(3, b("6z/9j\025{)4hFx!(n\013m4?}F") + paramParam.name);
    this.h = true;
    int k = paramParam.vt;
    k &= 0xFFFFBFFF;
    if (paramParam.b())
    {
      Log.log(3, b("") + paramParam.name);
      paramObject = Array.get(paramObject, 0);
    }
    if ((paramParam.isArray()) && (paramParam.fixedArrayDimensions == null))
    {
      Variant localVariant = new Variant(paramParam.name, k | 0x2000, paramObject);
      localVariant.a(paramy, paramParam.name);
      return;
    }
    int m;
    int n;
    if (paramParam.isArray())
    {
      paramy.d(a(paramParam));
      m = 0;
      if (i2 != 0) {}
      do
      {
        do
        {
          a(paramParam, Array.get(paramObject, m), paramString + b("Fx!(n\013m4?}F") + paramParam.name + "[" + m + "]", paramy);
          m++;
        } while (m < paramParam.fixedArrayDimensions[0]);
        this.h = false;
        n = 0;
      } while (i2 != 0);
      if (i2 != 0) {}
      while (n < paramParam.fixedArrayDimensions[0])
      {
        a(paramParam, Array.get(paramObject, n), paramString + b("Fx!(n\013m4?}F") + paramParam.name + "[" + n + "]", paramy);
        n++;
      }
      return;
    }
    if (paramParam.arraySizeParamIndex != -1)
    {
      m = 0;
      if (this.a.c[paramParam.arraySizeParamIndex].b())
      {
        m = ((Number)Array.get(this.c[paramParam.arraySizeParamIndex], 0)).intValue();
        if (i2 == 0) {}
      }
      else
      {
        m = ((Number)this.c[paramParam.arraySizeParamIndex]).intValue();
      }
      paramy.a(m, b("\013i8"), b("\023W)4{U:"));
      paramy.a(0L, b("\tn&)j\022"), b("\023W)4{U:"));
      paramy.a(m, b("\005g54{"), b("\023W)4{U:"));
      if ((m == 1) && (!paramObject.getClass().isArray()))
      {
        a(paramParam, paramObject, paramString + b("Fx!(n\013m4?}F") + paramParam.name, paramy);
        this.h = false;
        a(paramParam, paramObject, paramString + b("Fx!(n\013m4?}F") + paramParam.name, paramy);
        return;
      }
      n = 0;
      if (i2 != 0) {}
      int i1;
      do
      {
        do
        {
          a(paramParam, Array.get(paramObject, n), paramString + b("Fx!(n\013m4?}F") + paramParam.name + "[" + n + "]", paramy);
          n++;
        } while (n < m);
        this.h = false;
        i1 = 0;
        if (i2 == 0) {
          break;
        }
      } while (i2 != 0);
      while (i1 < m)
      {
        a(paramParam, Array.get(paramObject, i1), paramString + b("Fx!(n\013m4?}F") + paramParam.name + "[" + i1 + "]", paramy);
        i1++;
      }
      return;
    }
    a(paramParam, paramObject, paramString + b("Fx!(n\013m4?}F") + paramParam.name, paramy);
    this.h = false;
    a(paramParam, paramObject, paramString + b("Fx!(n\013m4?}F") + paramParam.name, paramy);
  }
  
  private Object a(String paramString, Param paramParam)
    throws IOException
  {
    int i3 = Dispatch.H;
    this.h = true;
    int k = paramParam.vt;
    k &= 0xFFFFBFFF;
    int i1;
    if (paramParam.isArray())
    {
      if (paramParam.fixedArrayDimensions == null)
      {
        int m = this.g.b(paramParam.name + b("Fx4(/\017l"), b("\017f4i="));
        Log.log(3, b("4m!>/\026|2zF\"2`") + m + b("Fn/(/") + paramParam.name);
        if (m != 0)
        {
          localObject2 = new Variant(paramParam.name);
          return ((Variant)localObject2).b(this.g, paramParam.vt);
        }
        return null;
      }
      if (paramParam.fixedArrayDimensions.length != 1) {
        throw new RuntimeException(cj.CANNOT_HANDLE_MULTI_DIMENTIONAL_ARRAYS);
      }
      Class localClass = paramParam.field.getType().getComponentType();
      Object localObject2 = Array.newInstance(localClass, paramParam.fixedArrayDimensions[0]);
      this.g.d(a(paramParam));
      int n = 0;
      if (i3 != 0) {}
      while (n < paramParam.fixedArrayDimensions[0])
      {
        Object localObject4 = a(paramParam, null, paramParam.name + "[" + n + "]");
        if (localObject4 != null) {
          Array.set(localObject2, n, localObject4);
        }
        n++;
      }
      i1 = 0;
      if (i3 != 0) {}
      do
      {
        do
        {
          Object localObject5 = Array.get(localObject2, i1);
          localObject5 = a(paramParam, localObject5, paramParam.name + "[" + i1 + "]");
          if (localObject5 != null) {
            Array.set(localObject2, i1, localObject5);
          }
          i1++;
        } while (i1 < paramParam.fixedArrayDimensions[0]);
      } while (i3 != 0);
      return localObject2;
    }
    if (paramParam.arraySizeParamIndex != -1)
    {
      this.g.e(b("\013i8"), b("\023W)4{U:"));
      this.g.e(b("\tn&)j\022"), b("\023W)4{U:"));
      long l = this.g.e(b("\005g54{"), b("\023W)4{U:"));
      this.h = true;
      Object localObject3 = Array.newInstance(paramParam.assocClass, (int)l);
      i1 = 0;
      if (i3 != 0) {}
      int i2;
      do
      {
        do
        {
          Array.set(localObject3, i1, a(paramParam, null, paramParam.name + "[" + i1 + "]"));
          i1++;
        } while (i1 < l);
        this.h = false;
        i2 = 0;
      } while (i3 != 0);
      if (i3 != 0) {}
      do
      {
        do
        {
          Array.set(localObject3, i2, a(paramParam, Array.get(localObject3, i2), paramParam.name + "[" + i2 + "]"));
          i2++;
        } while (i2 < l);
      } while (i3 != 0);
      return localObject3;
    }
    Object localObject1 = a(paramParam, null, paramParam.name);
    this.h = false;
    return a(paramParam, localObject1, paramParam.name);
  }
  
  private void a(Param paramParam, Object paramObject, String paramString, y paramy)
    throws IOException
  {
    int n = Dispatch.H;
    int k = paramParam.vt;
    k &= 0xFFFFBFFF;
    Uuid localUuid = paramParam.assocUuid;
    Object localObject1;
    Object localObject2;
    if (this.h)
    {
      localObject1 = (paramObject instanceof Number) ? (Number)paramObject : null;
      if (localObject1 == null) {
        if ((paramObject instanceof Character))
        {
          int m = ((Character)paramObject).charValue();
          localObject1 = new Short((short)m);
          if (n == 0) {}
        }
        else
        {
          localObject1 = new Long(0L);
        }
      }
      switch (k)
      {
      case 16: 
      case 17: 
        paramy.e(((Number)localObject1).byteValue(), paramString, b("\023W)4{^"));
        if (n == 0) {
          break;
        }
      case 2: 
      case 18: 
        paramy.b(((Number)localObject1).shortValue(), paramString, b("\017f4k9"));
        if (n == 0) {
          break;
        }
      case 3: 
      case 19: 
      case 22: 
      case 23: 
      case 24: 
        paramy.a(((Number)localObject1).intValue(), paramString, b("\017f4i="));
        if (n == 0) {
          break;
        }
      case 4: 
        paramy.a(((Number)localObject1).floatValue(), paramString, b("\025a.=c\003"));
        if (n == 0) {
          break;
        }
      case 5: 
        paramy.a(((Number)localObject1).doubleValue(), paramString, b("\002g58c\003"));
        if (n == 0) {
          break;
        }
      case 6: 
      case 20: 
      case 21: 
        paramy.c(((Number)localObject1).longValue(), paramString, b("\017f4l;"));
        if (n == 0) {
          break;
        }
      case 7: 
        paramy.a((Date)paramObject, paramString);
        if (n == 0) {
          break;
        }
      case 8: 
        paramy.d(4);
        paramy.a(b("3{%("), b("\026|2zf\002"));
        if (n == 0) {
          break;
        }
      case 10: 
      case 25: 
        paramy.a(((Number)localObject1).longValue(), paramString, b("\023W)4{U:"));
        if (n == 0) {
          break;
        }
      case 11: 
        if (paramObject != null)
        {
          paramy.b(((Boolean)paramObject).booleanValue() ? -1 : 0, paramString, b("\017f4k9F \"5`\nm!4&"));
          if (n == 0) {
            break;
          }
        }
        else
        {
          paramy.b(-1, paramString, b("\017f4k9F \"5`\nm!4&"));
          if (n == 0) {
            break;
          }
        }
        break;
      case 9: 
        paramy.d(4);
        paramy.a(paramObject == null ? 0L : paramy.f(), b("\026|2zf\002"), b("\023W)4{U:"));
        if (n == 0) {
          break;
        }
      case 13: 
        paramy.d(4);
        paramy.a(paramObject == null ? 0L : paramy.f(), b("\026|2zf\002"), b("\023W)4{U:"));
        if (n == 0) {
          break;
        }
      case 12: 
        paramy.d(4);
        paramy.a(b("3{%("), b("\026|2zf\002"));
        if (n == 0) {
          break;
        }
      case 14: 
        paramy.a((BigDecimal)paramObject, paramString);
        if (n == 0) {
          break;
        }
      case 30: 
        localObject2 = (String)paramObject;
        if (localObject2 == null) {
          localObject2 = "";
        }
        if ((((String)localObject2).length() == 0) || (((String)localObject2).charAt(((String)localObject2).length() - 1) != 0)) {
          localObject2 = (String)localObject2 + "";
        }
        paramy.a(((String)localObject2).length(), b("\023W)4{U:"), b("\nm."));
        paramy.a(0L, b("\023W)4{U:"), b("\tn&)j\022"));
        paramy.a(((String)localObject2).length(), b("\023W)4{U:"), b("\nm."));
        paramy.a((String)localObject2, paramString);
      case 31: 
        if ((n != 0) && (paramObject != null))
        {
          localObject2 = (String)paramObject;
          if (localObject2 == null) {
            localObject2 = "";
          }
          if ((((String)localObject2).length() == 0) || (((String)localObject2).charAt(((String)localObject2).length() - 1) != 0)) {
            localObject2 = (String)localObject2 + "";
          }
          paramy.a(((String)localObject2).length(), b("\023W)4{U:"), b("\nm."));
          paramy.a(0L, b("\023W)4{U:"), b("\tn&)j\022"));
          paramy.a(((String)localObject2).length(), b("\023W)4{U:"), b("\nm."));
          paramy.b((String)localObject2, paramString);
          if (n == 0) {
            break;
          }
        }
        break;
      case 36: 
        a(paramObject, paramy);
        if (n == 0) {
          break;
        }
      case 29: 
        if (paramParam.assocKind == 1)
        {
          a(paramObject, paramy);
          if (n == 0) {
            break;
          }
        }
        else
        {
          paramy.d(4);
          paramy.a(paramObject == null ? 0L : paramy.f(), b("\026|2zf\002"), b("\023W)4{U:"));
          if (n == 0) {
            break;
          }
        }
        break;
      case 15: 
      case 26: 
      case 27: 
      case 28: 
      case 32: 
      case 33: 
      case 34: 
      case 35: 
      default: 
        throw new RuntimeException(cj.translate(cj.CANNOT_HANDLE_COM_TYPE, paramString, Integer.toString(k)));
      }
      return;
    }
    switch (k)
    {
    case 12: 
      if ((paramObject instanceof Variant))
      {
        localObject2 = (Variant)paramObject;
        localObject1 = (((Variant)localObject2).vt == 10) && (((Variant)localObject2).returnValue == 2147614724L) ? new Variant(paramString, 10, 2147614724L) : new Variant(paramString, 12, paramObject);
        if (n == 0) {}
      }
      else
      {
        localObject1 = paramObject == null ? new Variant(paramString, 10, 2147614724L) : new Variant(paramString, 12, paramObject);
      }
      paramy.d(8);
      ((Variant)localObject1).c(paramy);
      return;
    case 8: 
      paramy.c((String)paramObject, paramString);
      return;
    case 29: 
      if (paramParam.assocKind == 1)
      {
        a(paramObject, paramy);
        if (n == 0) {}
      }
      else if (paramObject != null)
      {
        z.a(paramObject, localUuid, null).a(paramy, localUuid, false);
      }
      return;
    case 9: 
      if (paramObject != null)
      {
        localUuid = localUuid == null ? k.IID_IDISPATCH : localUuid;
        z.a(paramObject, localUuid, null).a(paramy, localUuid, false);
      }
      return;
    case 13: 
      if (paramObject != null)
      {
        localUuid = localUuid == null ? k.IID_IUNKNOWN : localUuid;
        z.a(paramObject, localUuid, null).a(paramy, localUuid, false);
      }
      return;
    case 36: 
      a(paramObject, paramy);
      return;
    }
  }
  
  void a(Object paramObject, y paramy)
    throws IOException
  {
    int i1 = Dispatch.H;
    StructDesc localStructDesc = StructDesc.b(paramObject.getClass());
    Param[] arrayOfParam = localStructDesc.fields;
    if (arrayOfParam == null) {
      throw new RuntimeException(cj.translate(cj.DO_NOT_KNOW_HOW_TO_MARSHAL, localStructDesc));
    }
    if (this.h) {
      paramy.d(localStructDesc.a());
    }
    paramy.a(b("5|2/l\022(") + localStructDesc.targetClass);
    int k = 0;
    if (i1 != 0) {
      Log.log(3, b("6z/9j\025{)4hFn)?c\002(") + arrayOfParam[k]);
    }
    do
    {
      Object localObject = null;
      try
      {
        localObject = arrayOfParam[k].field.get(paramObject);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        Log.a(cj.translate(cj.MARSHALLER_CANNOT_GET_FIELD, localIllegalAccessException, arrayOfParam[k].field));
        throw new RuntimeException(cj.translate(cj.MARSHALLER_CANNOT_GET_FIELD, localIllegalAccessException, arrayOfParam[k].field));
      }
      int m = arrayOfParam[k].vt;
      m &= 0xFFFFBFFF;
      if (arrayOfParam[k].isArray())
      {
        if (arrayOfParam[k].fixedArrayDimensions == null)
        {
          if (this.h)
          {
            paramy.d(4);
            paramy.a(b("3{%("), b("\026|2zf\002"));
            if (i1 == 0) {}
          }
          else
          {
            Variant localVariant = new Variant(arrayOfParam[k].name, m | 0x2000, localObject);
            y localy = paramy.g();
            localVariant.b(localy, arrayOfParam[k].name);
            paramy.d(4);
            byte[] arrayOfByte = localy.e();
            paramy.a(arrayOfByte, 0, arrayOfByte.length, b(""));
            if (i1 == 0) {}
          }
        }
        else
        {
          int n;
          if (this.h)
          {
            paramy.d(a(arrayOfParam[k]));
            n = 0;
            if (i1 != 0) {}
            while (n < arrayOfParam[k].fixedArrayDimensions[0])
            {
              a(arrayOfParam[k], Array.get(localObject, n), arrayOfParam[k].name, paramy);
              n++;
            }
          }
          else
          {
            n = 0;
            if (i1 != 0) {}
            while (n < arrayOfParam[k].fixedArrayDimensions[0])
            {
              a(arrayOfParam[k], Array.get(localObject, n), arrayOfParam[k].name + "[" + n + "]", paramy);
              n++;
            }
          }
        }
      }
      else {
        a(arrayOfParam[k], localObject, arrayOfParam[k].name, paramy);
      }
      k++;
      if (k < arrayOfParam.length) {
        break;
      }
      paramy.c();
    } while (i1 != 0);
  }
  
  void b(x paramx)
    throws IOException
  {
    int m = Dispatch.H;
    this.g = paramx;
    int k = 0;
    if (m != 0) {}
    do
    {
      do
      {
        if (this.a.c[k].b())
        {
          Object localObject = a(this.a.a, this.a.c[k]);
          Log.log(3, b(")}4*z\022(\020;}\007e%.j\024(") + k + b("F ") + this.a.c[k].name + b("O(}z") + localObject);
          try
          {
            if (this.c[k] == null)
            {
              Object[] arrayOfObject1 = { null };
              this.c[k] = arrayOfObject1;
            }
            Array.set(this.c[k], 0, localObject);
          }
          catch (IllegalArgumentException localIllegalArgumentException)
          {
            if (this.c[k].getClass() == (j == null ? (Marshaller.j = a(b("=D*;y\007&5.f\n&\0054z\013m2;{\017g.a"))) : j))
            {
              Array.set(this.c[k], 0, new VariantEnumeration(localObject));
              if (m == 0) {}
            }
            else
            {
              Class localClass = this.c[k].getClass().getComponentType();
              if ((localClass.isArray()) && (localObject.getClass().isArray()))
              {
                try
                {
                  Array.set(this.c[k], 0, Variant.coerceArray(localObject, localClass.getComponentType()));
                }
                catch (Throwable localThrowable)
                {
                  Object[] arrayOfObject3 = { localObject, this.c[k], this.a.c[k] };
                  throw new RuntimeException(cj.translate(cj.MARSHALLER_CANNOT_SET_VALUE, arrayOfObject3));
                }
              }
              else
              {
                Object[] arrayOfObject2 = { localObject, this.c[k], this.a.c[k] };
                throw new RuntimeException(cj.translate(cj.MARSHALLER_CANNOT_SET_VALUE, arrayOfObject2));
              }
            }
          }
        }
        k++;
      } while (k < this.a.c.length);
    } while (m != 0);
    if (!this.i.isEmpty()) {
      throw new RuntimeException(cj.translate(cj.UNCLAIMED_POINTER_IDS, this.i));
    }
  }
  
  Marshaller() {}
  
  Object a(Class paramClass, Object paramObject)
    throws IOException
  {
    int i1 = Dispatch.H;
    StructDesc localStructDesc = StructDesc.b(paramClass);
    Param[] arrayOfParam = localStructDesc.fields;
    if (arrayOfParam == null) {
      throw new RuntimeException(cj.translate(cj.DO_NOT_KNOW_HOW_TO_MARSHAL, paramClass));
    }
    if (this.h) {
      this.g.d(localStructDesc.a());
    }
    this.g.a(b("5|2/l\022(") + localStructDesc.targetClass + b("Fn)(|\022X!)|\\") + this.h);
    if (paramObject == null)
    {
      if (!this.h) {
        throw new RuntimeException(cj.STRUCTURE_NULL_ON_SECOND_PASS);
      }
      try
      {
        paramObject = paramClass.newInstance();
      }
      catch (InstantiationException localInstantiationException)
      {
        Log.a(cj.translate(cj.CREATE_INSTANCE_EXCEPTION, localInstantiationException, paramClass));
        throw new RuntimeException(cj.translate(cj.CREATE_INSTANCE_EXCEPTION, localInstantiationException, paramClass));
      }
      catch (IllegalAccessException localIllegalAccessException1)
      {
        Log.a(cj.translate(cj.CREATE_INSTANCE_EXCEPTION, localIllegalAccessException1, paramClass));
        throw new RuntimeException(cj.translate(cj.CREATE_INSTANCE_EXCEPTION, localIllegalAccessException1, paramClass));
      }
    }
    int k = 0;
    if (i1 != 0) {
      Log.log(3, b("6z/9j\025{)4hFn)?c\002(") + arrayOfParam[k]);
    }
    do
    {
      Object localObject1 = null;
      if (arrayOfParam[k].isArray())
      {
        Object localObject2;
        if (arrayOfParam[k].fixedArrayDimensions == null)
        {
          int m;
          if (this.h)
          {
            m = this.g.b(arrayOfParam[k].name + b("Fx4(/\017l"), b("\017f4i="));
            Log.log(3, b("4m!>/\026|2zF\"2`") + m + b("Fn/(/") + arrayOfParam[k].name);
            this.i.addElement(new Integer(m));
            if (i1 == 0) {}
          }
          else
          {
            m = ((Integer)this.i.firstElement()).intValue();
            this.i.removeElementAt(0);
            Log.log(3, b("3{)4hFx4(//Lzz") + m + b("Fn/(/") + arrayOfParam[k].name);
            if (m != 0)
            {
              localObject2 = new Variant(arrayOfParam[k].name);
              localObject1 = ((Variant)localObject2).b(this.g, arrayOfParam[k].vt);
            }
          }
        }
        else
        {
          if (arrayOfParam[k].fixedArrayDimensions.length != 1) {
            throw new RuntimeException(cj.CANNOT_HANDLE_MULTI_DIMENTIONAL_ARRAYS);
          }
          if (this.h)
          {
            Log.log(3, b(" a2){Fx!)|FN)?c\002(4#\003(") + arrayOfParam[k].field);
            Class localClass = arrayOfParam[k].field.getType().getComponentType();
            localObject1 = Array.newInstance(localClass, arrayOfParam[k].fixedArrayDimensions[0]);
          }
          else
          {
            Log.log(3, b("5m#5a\002(0;|\025(\0063j\nl`.v\026m`") + arrayOfParam[k].field);
            try
            {
              localObject1 = arrayOfParam[k].field.get(paramObject);
              if (localObject1 == null) {
                Log.a(cj.translate(cj.INTERNAL_ERROR_ON, paramObject));
              }
            }
            catch (IllegalAccessException localIllegalAccessException2)
            {
              Log.a(cj.translate(cj.MARSHALLER_CANNOT_GET_FIELD, localIllegalAccessException2, arrayOfParam[k].field));
              throw new RuntimeException(cj.translate(cj.MARSHALLER_CANNOT_GET_FIELD, localIllegalAccessException2, arrayOfParam[k].field));
            }
          }
          if (this.h) {
            this.g.d(a(arrayOfParam[k]));
          }
          int n = 0;
          if (i1 != 0) {}
          while (n < arrayOfParam[k].fixedArrayDimensions[0])
          {
            localObject2 = null;
            if (!this.h) {
              localObject2 = Array.get(localObject1, n);
            }
            localObject2 = a(arrayOfParam[k], localObject2, arrayOfParam[k].name + "[" + n + "]");
            if (localObject2 != null) {
              Array.set(localObject1, n, localObject2);
            }
            n++;
          }
        }
      }
      else
      {
        if (!this.h) {
          try
          {
            localObject1 = arrayOfParam[k].field.get(paramObject);
          }
          catch (IllegalAccessException localIllegalAccessException3)
          {
            Log.a(cj.translate(cj.MARSHALLER_CANNOT_GET_FIELD, localIllegalAccessException3, arrayOfParam[k].field));
            throw new RuntimeException(cj.translate(cj.MARSHALLER_CANNOT_GET_FIELD, localIllegalAccessException3, arrayOfParam[k].field));
          }
        }
        localObject1 = a(arrayOfParam[k], localObject1);
      }
      if (localObject1 != null) {
        try
        {
          Log.log(3, b("5m4.f\bo`<f\003d$z") + arrayOfParam[k].name + b("F|/z") + localObject1);
          arrayOfParam[k].field.set(paramObject, localObject1);
        }
        catch (IllegalAccessException localIllegalAccessException4)
        {
          Log.a(cj.translate(cj.MARSHALLER_CANNOT_SET_FIELD, localIllegalAccessException4, arrayOfParam[k].field));
          throw new RuntimeException(cj.translate(cj.MARSHALLER_CANNOT_SET_FIELD, localIllegalAccessException4, arrayOfParam[k].field));
        }
      }
      k++;
      if (k < arrayOfParam.length) {
        break;
      }
      this.g.c();
    } while (i1 != 0);
    return paramObject;
  }
  
  private Object a(Param paramParam, Object paramObject)
    throws IOException
  {
    return a(paramParam, paramObject, paramParam.name);
  }
  
  private Object a(Param paramParam, Object paramObject, String paramString)
    throws IOException
  {
    int k = paramParam.vt & 0xFFFFBFFF;
    Object localObject1;
    if (this.h)
    {
      switch (k)
      {
      case 16: 
      case 17: 
        return new Byte((byte)this.g.g(b("\023a..7"), paramString));
      case 2: 
      case 18: 
        return new Short(this.g.c(b("3[\b\025]2"), paramString));
      case 3: 
      case 19: 
      case 22: 
      case 23: 
        return new Integer(this.g.b(b("/F\024"), paramString));
      case 4: 
        return new Float(this.g.j(b("\025a.=c\003"), paramString));
      case 5: 
        return new Double(this.g.k(b("\002g58c\003"), paramString));
      case 6: 
      case 20: 
      case 21: 
        return new Long(this.g.i(b("\023W)4{P<"), paramString));
      case 7: 
        return this.g.g(paramString);
      case 10: 
      case 25: 
        return new Long(this.g.e(paramString, b("\023W)4{U:")));
      case 11: 
        return new Boolean(this.g.c(paramString, b("\017f4k9F \"5`\nm!4&")) != 0);
      case 14: 
        return this.g.c(paramString);
      case 30: 
        m = (int)this.g.e(b("\nm."), b("\023W)4{U:"));
        this.g.e(b("\tn&)j\022"), b("\023W)4{U:"));
        this.g.e(b("\nm."), b("\023W)4{U:"));
        localObject1 = this.g.a(m, paramString);
        if ((m != 0) && (((String)localObject1).charAt(m - 1) == 0)) {
          localObject1 = ((String)localObject1).substring(0, m - 1);
        }
        return localObject1;
      case 31: 
        m = (int)this.g.e(b("\nm."), b("\023W)4{U:"));
        this.g.e(b("\tn&)j\022"), b("\023W)4{U:"));
        this.g.e(b("\nm."), b("\023W)4{U:"));
        localObject1 = this.g.a(paramString, m);
        if ((m != 0) && (((String)localObject1).charAt(m - 1) == 0)) {
          localObject1 = ((String)localObject1).substring(0, m - 1);
        }
      case 8: 
      case 9: 
      case 12: 
      case 13: 
        m = this.g.b(paramString + b("Fx4(/\017l"), b("\017f4i="));
        Log.log(3, b("4m!>/\026|2zF\"2`") + m + b("Fn/(/") + paramString);
        this.i.addElement(new Integer(m));
        return null;
      case 36: 
        return a(paramParam.assocClass, paramObject);
      case 29: 
        if ((paramParam.assocKind == 4) || (paramParam.assocKind == 3) || (paramParam.assocKind == 5))
        {
          m = this.g.b(paramString + b("Fx4(/\017l"), b("\017f4i="));
          Log.log(3, b("4m!>/\026|2zF\"2`") + m + b("Fn/(/") + paramString);
          this.i.addElement(new Integer(m));
          return null;
        }
        if (paramParam.assocKind == 1) {
          return a(paramParam.assocClass, paramObject);
        }
        throw new RuntimeException(cj.translate(cj.TKIND_NOT_SUPPORTED, Integer.toString(paramParam.assocKind), paramParam));
      }
      throw new RuntimeException(cj.translate(cj.CANNOT_HANDLE_COM_TYPE, paramString, Integer.toString(k)));
    }
    switch (k)
    {
    case 2: 
    case 3: 
    case 4: 
    case 5: 
    case 6: 
    case 7: 
    case 10: 
    case 11: 
    case 14: 
    case 16: 
    case 17: 
    case 18: 
    case 19: 
    case 20: 
    case 21: 
    case 22: 
    case 23: 
    case 25: 
    case 30: 
    case 31: 
      return paramObject;
    case 36: 
      return a(paramParam.assocClass, paramObject);
    }
    int m = ((Integer)this.i.firstElement()).intValue();
    this.i.removeElementAt(0);
    if (m == 0) {
      return null;
    }
    Object localObject2;
    switch (k)
    {
    case 8: 
      return this.g.d(paramString);
    case 9: 
    case 13: 
      localObject1 = new StdObjRef(false, this.g);
      localObject2 = z.a((StdObjRef)localObject1);
      return localObject2 == null ? InterfaceDesc.a((StdObjRef)localObject1, ((StdObjRef)localObject1).iid) : localObject2;
    case 12: 
      localObject1 = new Variant(paramString);
      this.g.d(8);
      ((Variant)localObject1).a(this.g);
      return ((Variant)localObject1).getVARIANT();
    case 29: 
      if ((paramParam.assocKind == 4) || (paramParam.assocKind == 3) || (paramParam.assocKind == 5))
      {
        localObject2 = new StdObjRef(false, this.g);
        Object localObject3 = z.a((StdObjRef)localObject2);
        if (localObject3 != null) {
          return localObject3;
        }
        if (paramParam.assocClass != null) {
          return paramParam.wrap((StdObjRef)localObject2);
        }
        return InterfaceDesc.a((StdObjRef)localObject2, paramParam.assocUuid);
      }
      if (paramParam.assocKind == 1) {
        return a(paramParam.assocClass, paramObject);
      }
      throw new RuntimeException(cj.translate(cj.TKIND_NOT_SUPPORTED, Integer.toString(paramParam.assocKind), paramParam));
    }
    throw new RuntimeException(cj.translate(cj.CANNOT_HANDLE_COM_TYPE, paramString, Integer.toString(k)));
  }
  
  static int a(Param paramParam)
  {
    switch (paramParam.vt & 0xFFFFBFFF)
    {
    case 16: 
    case 17: 
      return 1;
    case 2: 
    case 11: 
    case 18: 
      return 2;
    case 3: 
    case 4: 
    case 8: 
    case 9: 
    case 10: 
    case 13: 
    case 19: 
    case 22: 
    case 23: 
    case 25: 
      return 4;
    case 5: 
    case 6: 
    case 7: 
    case 12: 
    case 20: 
    case 21: 
      return 8;
    case 29: 
      if ((paramParam.assocKind == 4) || (paramParam.assocKind == 3) || (paramParam.assocKind == 5)) {
        return 4;
      }
    case 36: 
      if (paramParam.isArray()) {
        return 4;
      }
      return StructDesc.a(paramParam.assocClass);
    }
    Log.a(cj.translate(cj.UNKNOWN_ALIGNMENT_FOR, paramParam));
    return 0;
  }
  
  static Class a(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int k = arrayOfChar.length;
    int m = 0;
    while (m < k)
    {
      switch (m % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      8[64] = ((char)(0x5A ^ 0xF));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Marshaller
 * JD-Core Version:    0.7.0.1
 */