package com.linar.jintegra;

import java.io.IOException;
import java.io.Serializable;
import java.net.UnknownHostException;

public class IJintegraJvm2Proxy
  extends Dispatch
  implements IJintegraJvm2, Serializable
{
  public static final Class targetClass = J == null ? (IJintegraJvm2Proxy.J = c(d(""))) : J;
  static final int I = 0;
  static Class J;
  static Class K;
  static Class L;
  
  protected String getJintegraVersion()
  {
    return cj.CONFIG_VERSION;
  }
  
  public IJintegraJvm2Proxy(String paramString1, String paramString2, AuthInfo paramAuthInfo)
    throws UnknownHostException, IOException
  {
    super(paramString1, d("H\031\003\024{F\024\001_z\035\035\005_yOH\005_*I\031W_zN\030RF.JJ\004BzN"), paramString2, paramAuthInfo);
  }
  
  public IJintegraJvm2Proxy() {}
  
  public IJintegraJvm2Proxy(Object paramObject)
    throws IOException
  {
    super(paramObject, d("H\031\003\024{F\024\001_z\035\035\005_yOH\005_*I\031W_zN\030RF.JJ\004BzN"));
  }
  
  protected IJintegraJvm2Proxy(Object paramObject, String paramString)
    throws IOException
  {
    super(paramObject, paramString);
  }
  
  public IJintegraJvm2Proxy(String paramString1, String paramString2, boolean paramBoolean)
    throws UnknownHostException, IOException
  {
    super(paramString1, d("H\031\003\024{F\024\001_z\035\035\005_yOH\005_*I\031W_zN\030RF.JJ\004BzN"), paramString2, null);
  }
  
  protected IJintegraJvm2Proxy(String paramString1, String paramString2, String paramString3, AuthInfo paramAuthInfo)
    throws IOException
  {
    super(paramString1, paramString2, paramString3, paramAuthInfo);
  }
  
  public void addListener(String paramString, Object paramObject1, Object paramObject2)
    throws IOException
  {
    super.addListener(paramString, paramObject1, paramObject2);
  }
  
  public void removeListener(String paramString, Object paramObject)
    throws IOException
  {
    super.removeListener(paramString, paramObject);
  }
  
  public Object getPropertyByName(String paramString)
    throws NoSuchFieldException, IOException, AutomationException
  {
    Variant[] arrayOfVariant = new Variant[0];
    return super.invoke(paramString, super.getDispatchIdOfName(paramString), 2L, arrayOfVariant).getVARIANT();
  }
  
  public Object getPropertyByName(String paramString, Object paramObject)
    throws NoSuchFieldException, IOException, AutomationException
  {
    Variant[] arrayOfVariant = { paramObject == null ? new Variant(d("\fDB"), 10, 2147614724L) : new Variant(d("\fDB"), 12, paramObject) };
    return super.invoke(paramString, super.getDispatchIdOfName(paramString), 2L, arrayOfVariant).getVARIANT();
  }
  
  public Object invokeMethodByName(String paramString, Object[] paramArrayOfObject)
    throws NoSuchMethodException, IOException, AutomationException
  {
    int j = Dispatch.H;
    Variant[] arrayOfVariant = new Variant[paramArrayOfObject.length];
    int i = 0;
    if (j != 0) {
      arrayOfVariant[i] = (paramArrayOfObject[i] == null ? new Variant("p" + i, 10, 2147614724L) : new Variant("p" + i, 12, paramArrayOfObject[i]));
    }
    for (;;)
    {
      i++;
      if (i < paramArrayOfObject.length) {
        break;
      }
      try
      {
        if (j != 0) {
          continue;
        }
        return super.invoke(paramString, super.getDispatchIdOfName(paramString), 1L, arrayOfVariant).getVARIANT();
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        throw new NoSuchMethodException(cj.translate(cj.NO_SUCH_METHOD, paramString));
      }
    }
  }
  
  public Object newInstance(String paramString1, String paramString2)
    throws IOException, AutomationException
  {
    Object[] arrayOfObject1 = { null };
    Object[] arrayOfObject2 = { paramString1, paramString2, arrayOfObject1 };
    vtblInvoke(d("\020IF;&\rXP\034+\033"), 7, arrayOfObject2);
    return arrayOfObject1[0];
  }
  
  public IJintegraJvm2 getRef(String paramString1, String paramString2, String paramString3, int paramInt)
    throws IOException, AutomationException
  {
    IJintegraJvm2[] arrayOfIJintegraJvm2 = { null };
    Object[] arrayOfObject = { paramString1, paramString2, paramString3, new Integer(paramInt), arrayOfIJintegraJvm2 };
    vtblInvoke(d("\031IE -\030"), 8, arrayOfObject);
    return arrayOfIJintegraJvm2[0];
  }
  
  static Class c(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  static
  {
    InterfaceDesc.add(d("H\031\003\024{F\024\001_z\035\035\005_yOH\005_*I\031W_zN\030RF.JJ\004BzN"), K == null ? (IJintegraJvm2Proxy.K = c(d(""))) : K, null, 7, new MemberDesc[] { new MemberDesc(d("\020IF;&\rXP\034+\033"), new Class[] { L == null ? (IJintegraJvm2Proxy.L = c(d("\024MG\023f\022M_\025f-XC\033&\031"))) : L, L == null ? (IJintegraJvm2Proxy.L = c(d("\024MG\023f\022M_\025f-XC\033&\031"))) : L }, new Param[] { new Param(d("\024Z\\;,"), 8, 2, 8, null, null), new Param(d("\024MG\023\013\022MB\001"), 8, 2, 8, null, null), new Param(d("\fIB"), 9, 20, 8, null, null) }), new MemberDesc(d("\031IE -\030"), new Class[] { L == null ? (IJintegraJvm2Proxy.L = c(d("\024MG\023f\022M_\025f-XC\033&\031"))) : L, L == null ? (IJintegraJvm2Proxy.L = c(d("\024MG\023f\022M_\025f-XC\033&\031"))) : L, L == null ? (IJintegraJvm2Proxy.L = c(d("\024MG\023f\022M_\025f-XC\033&\031"))) : L, Integer.TYPE }, new Param[] { new Param(d("\024Z\\;,"), 8, 2, 8, null, null), new Param(d("\032@]\")\nD"), 8, 2, 8, null, null), new Param(d("\bIC\001!\021Bb\006:"), 8, 2, 8, null, null), new Param(d("\032@]:)\020H]\027"), 3, 2, 8, null, null), new Param(d("\fZ"), 29, 20, 4, d("H\031\003\024{F\024\001_z\035\035\005_yOH\005_*I\031W_zN\030RF.JJ\004BzN"), K == null ? (IJintegraJvm2Proxy.K = c(d(""))) : K) }) });
  }
  
  private static String d(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      44[49] = ((char)(0x72 ^ 0x48));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.IJintegraJvm2Proxy
 * JD-Core Version:    0.7.0.1
 */