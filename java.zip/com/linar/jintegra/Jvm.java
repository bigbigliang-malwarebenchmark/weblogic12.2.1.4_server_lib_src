package com.linar.jintegra;

import java.io.IOException;
import java.io.PrintStream;
import java.util.Hashtable;

public final class Jvm
  implements IJintegraJvm2, Instanciator
{
  static int a = 0;
  private static Hashtable b = new Hashtable();
  private static Jvm c;
  static long d = 7299612979407642964L;
  static Class e;
  static Class f;
  
  public Object instanciate(String paramString)
    throws AutomationException
  {
    try
    {
      return Class.forName(paramString).newInstance();
    }
    catch (Throwable localThrowable)
    {
      localThrowable.printStackTrace();
      Log.a(cj.translate(cj.CREATE_INSTANCE_FAILED, paramString, localThrowable));
      throw new AutomationException(localThrowable);
    }
  }
  
  public static int getDllHandle()
  {
    return a;
  }
  
  public IJintegraJvm2 getRef(String paramString1, String paramString2, String paramString3, int paramInt)
  {
    Log.log(3, c("g)eGbHc^H6@kB@}Hv\fOy_$f[\r#") + paramString1 + c("\n$_]w_pIM8\r$heZ\rTM]~\rm_\t1") + paramString2 + c("\n$MGr\rrI[eDkB\t^$\013") + paramString3 + "'");
    a = paramInt;
    return this;
  }
  
  static Instanciator a(String paramString)
  {
    return (Instanciator)b.get(paramString);
  }
  
  public Object get(String paramString)
    throws Exception
  {
    int i = paramString.indexOf(":");
    if (i == -1) {
      return Class.forName(paramString).newInstance();
    }
    return c.newInstance(paramString.substring(0, i), paramString.substring(i + 1));
  }
  
  public Object newInstance(String paramString1, String paramString2)
    throws AutomationException
  {
    Instanciator localInstanciator = (Instanciator)b.get(paramString1);
    if (localInstanciator == null)
    {
      Log.a(cj.translate(cj.INSTANCIATE_CLASS_IN_UNREGISTERED_JVM, paramString2, paramString1));
      throw new AutomationException(2147745801L);
    }
    return localInstanciator.instanciate(paramString2);
  }
  
  static void a(PrintStream paramPrintStream)
  {
    paramPrintStream.println(c("Dj_]wCgEHbBv_\teD~I\t^$") + b.size());
  }
  
  static Jvm a()
  {
    return c;
  }
  
  public static void init()
  {
    init(-1);
  }
  
  public static synchronized void init(int paramInt)
  {
    if (c != null) {
      return;
    }
    if (!Dispatch.isNativeMode())
    {
      g.a(paramInt);
      if (Dispatch.H == 0) {}
    }
    else
    {
      NativeObjRef.q();
    }
    c = new Jvm();
    if (!Dispatch.isNativeMode()) {
      try
      {
        ba localba = new ba(c, d, null);
        localba.a(5);
        z.a(c, localba);
        localba.a(k.ACTIVATOR_IPID, new Uuid(c("\0331\036O%\025<\034\004$N5\030\004'\034`\030\004t\0321J\004$\0350O\035p\031b\031\031$\035")));
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
  }
  
  public static String getMoniker()
    throws IOException
  {
    init(-1);
    y localy = new y(true, null);
    StdObjRef.a(localy, k.IID_IDISPATCH, 4096L, 0L, 7021788454466775370L, d, k.ACTIVATOR_IPID, bc.a());
    byte[] arrayOfByte = localy.e();
    return c("BfF[sK>") + d.encode(arrayOfByte) + ":";
  }
  
  public static void register(String paramString)
  {
    init(-1);
    b.put(paramString, c);
    if (Dispatch.isNativeMode())
    {
      NativeObjectProxy.registerJvm(paramString, c, Dispatch.c());
      NativeInitInproc.a();
    }
  }
  
  public static void register(String paramString, int paramInt)
  {
    init(paramInt);
    b.put(paramString, c);
    if (Dispatch.isNativeMode())
    {
      NativeObjectProxy.registerJvm(paramString, c, Dispatch.c());
      NativeInitInproc.a();
    }
  }
  
  public static void register(String paramString, Instanciator paramInstanciator)
  {
    init(-1);
    b.put(paramString, paramInstanciator);
    if (Dispatch.isNativeMode())
    {
      NativeObjectProxy.registerJvm(paramString, c, Dispatch.c());
      NativeInitInproc.a();
    }
  }
  
  public static void register(String paramString, Instanciator paramInstanciator, int paramInt)
  {
    init(paramInt);
    b.put(paramString, paramInstanciator);
    if (Dispatch.isNativeMode())
    {
      NativeObjectProxy.registerJvm(paramString, c, Dispatch.c());
      NativeInitInproc.a();
    }
  }
  
  static Class b(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  static
  {
    InterfaceDesc.add(c("\0331\036O%\025<\034\004$N5\030\004'\034`\030\004t\0321J\004$\0350O\035p\031b\031\031$\035"), e == null ? (Jvm.e = b(c("NkA\007zDjM[8GmB]sJvM\007_gmB]sJvMc`@6|[yU}"))) : e, null, 7, new MemberDesc[] { new MemberDesc(c("Ca[`x^pMGuH"), new Class[] { f == null ? (Jvm.f = b(c("GeZH8AeBN8~p^@xJ"))) : f, f == null ? (Jvm.f = b(c("GeZH8AeBN8~p^@xJ"))) : f }, new Param[] { new Param(c("GrA`r"), 8, 2, 8, null, null), new Param(c("GeZHUAe_Z"), 8, 2, 8, null, null), new Param(c("_a_"), 9, 20, 8, null, null) }), new MemberDesc(c("JaX{sK"), new Class[] { f == null ? (Jvm.f = b(c("GeZH8AeBN8~p^@xJ"))) : f, f == null ? (Jvm.f = b(c("GeZH8AeBN8~p^@xJ"))) : f, f == null ? (Jvm.f = b(c("GeZH8AeBN8~p^@xJ"))) : f, Integer.TYPE }, new Param[] { new Param(c("GrA`r"), 8, 2, 8, null, null), new Param(c("Ih@ywYl"), 8, 2, 8, null, null), new Param(c("[a^ZBj]d"), 8, 2, 8, null, null), new Param(c("Ih@awC`@L"), 3, 2, 8, null, null), new Param(c("_r"), 29, 20, 4, c("\0331\036O%\025<\034\004$N5\030\004'\034`\030\004t\0321J\004$\0350O\035p\031b\031\031$\035"), e == null ? (Jvm.e = b(c("NkA\007zDjM[8GmB]sJvM\007_gmB]sJvMc`@6|[yU}"))) : e) }) });
  }
  
  private static String c(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      4[44] = ((char)(0x29 ^ 0x16));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Jvm
 * JD-Core Version:    0.7.0.1
 */