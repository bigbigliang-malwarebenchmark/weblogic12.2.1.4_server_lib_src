package com.linar.jintegra;

import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Variant
{
  public static final long DISP_E_MEMBERNOTFOUND = 2147614723L;
  public static final long DISP_E_PARAMNOTFOUND = 2147614724L;
  public static final int VT_EMPTY = 0;
  public static final int VT_NULL = 1;
  public static final int VT_I2 = 2;
  public static final int VT_I4 = 3;
  public static final int VT_R4 = 4;
  public static final int VT_R8 = 5;
  public static final int VT_CY = 6;
  public static final int VT_DATE = 7;
  public static final int VT_BSTR = 8;
  public static final int VT_DISPATCH = 9;
  public static final int VT_ERROR = 10;
  public static final int VT_BOOL = 11;
  public static final int VT_VARIANT = 12;
  public static final int VT_UNKNOWN = 13;
  public static final int VT_DECIMAL = 14;
  public static final int VT_I1 = 16;
  public static final int VT_UI1 = 17;
  public static final int VT_UI2 = 18;
  public static final int VT_UI4 = 19;
  public static final int VT_I8 = 20;
  public static final int VT_UI8 = 21;
  public static final int VT_INT = 22;
  public static final int VT_UINT = 23;
  public static final int VT_VOID = 24;
  public static final int VT_HRESULT = 25;
  public static final int VT_PTR = 26;
  public static final int VT_SAFEARRAY = 27;
  public static final int VT_CARRAY = 28;
  public static final int VT_USERDEFINED = 29;
  public static final int VT_LPSTR = 30;
  public static final int VT_LPWSTR = 31;
  public static final int VT_RECORD = 36;
  public static final int VT_FILETIME = 64;
  public static final int VT_BLOB = 65;
  public static final int VT_STREAM = 66;
  public static final int VT_STORAGE = 67;
  public static final int VT_STREAMED_OBJECT = 68;
  public static final int VT_STORED_OBJECT = 69;
  public static final int VT_BLOB_OBJECT = 70;
  public static final int VT_CF = 71;
  public static final int VT_CLSID = 72;
  public static final int VT_BSTR_BLOB = 4095;
  public static final int VT_VECTOR = 4096;
  public static final int VT_ARRAY = 8192;
  public static final int VT_BYREF = 16384;
  public static final int VT_RESERVED = 32768;
  static final int a = 10;
  static final int b = 16;
  static final int c = 2;
  static final int d = 3;
  static final int e = 20;
  static final int f = 8;
  static final int g = 13;
  static final int h = 9;
  static final int i = 12;
  static final int j = 36;
  public static final int FADF_AUTO = 1;
  public static final int FADF_STATIC = 2;
  public static final int FADF_EMBEDDED = 4;
  public static final int FADF_FIXEDSIZE = 16;
  public static final int FADF_RECORD = 32;
  public static final int FADF_HAVEIID = 64;
  public static final int FADF_HAVEVARTYPE = 128;
  public static final int FADF_BSTR = 256;
  public static final int FADF_UNKNOWN = 512;
  public static final int FADF_DISPATCH = 1024;
  public static final int FADF_VARIANT = 2048;
  int k;
  String l;
  public int vt;
  private int m = 0;
  private static final Class n = "".getClass();
  private static final Class o = new Date().getClass();
  static final Class p = new Object().getClass();
  static final Class q = new Object[0].getClass();
  static final Class r = new String[0].getClass();
  static final Class s = new Date[0].getClass();
  static final Class t = new byte[0].getClass();
  static final Class u = new short[0].getClass();
  static final Class v = new char[0].getClass();
  static final Class w = new int[0].getClass();
  static final Class x = new long[0].getClass();
  static final Class y = new float[0].getClass();
  static final Class z = new double[0].getClass();
  static final Class A = new boolean[0].getClass();
  private static SimpleDateFormat B = new SimpleDateFormat();
  public byte bVal;
  public short iVal;
  public int lVal;
  public int intVal;
  public float fltVal;
  public double dblVal;
  public boolean bool;
  public long returnValue;
  public long cyVal;
  public Date date;
  public String bstrVal;
  public BigDecimal decVal;
  public StdObjRef pdispVal;
  public Object parray;
  public byte[] pbVal = { 0 };
  public short[] piVal = { 0 };
  public int[] plVal = { 0 };
  public int[] pintVal = { 0 };
  public float[] pfltVal = { 0.0F };
  public double[] pdblVal = { 0.0D };
  public boolean[] pbool = { false };
  public long[] preturnValue = { 0L };
  public long[] pcyVal = { 0L };
  public Date[] pdate = { null };
  public String[] pbstrVal = { null };
  public BigDecimal[] pdecVal = { null };
  public StdObjRef[] ppdispVal = { null };
  public Variant[] pvarVal = { null };
  public Object[] pvalue = { null };
  public Object recordValue;
  static Class C;
  static Class D;
  static Class E;
  static Class F;
  static Class G;
  static Class H;
  static Class I;
  static Class J;
  static Class K;
  static Class L;
  static Class M;
  static Class N;
  static Class O;
  static Class P;
  static Class Q;
  static Class R;
  
  public boolean isByRef()
  {
    return (this.vt & 0x4000) != 0;
  }
  
  public boolean isByRef(int paramInt)
  {
    return (paramInt & 0x4000) != 0;
  }
  
  static boolean a(int paramInt)
  {
    return (paramInt & 0x2000) != 0;
  }
  
  public boolean isArray()
  {
    return (this.vt & 0x2000) != 0;
  }
  
  boolean a()
  {
    return this.vt == 0;
  }
  
  public int getVT()
  {
    return this.vt;
  }
  
  void a(String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
    if (paramInt1 != paramInt2)
    {
      Object[] arrayOfObject1 = { paramString1, Integer.toString(paramInt1), paramString2 };
      Log.a(cj.translate(cj.ATTEMPT_TO_CONSTRUCT_VARIANT_ERROR, arrayOfObject1));
      Object[] arrayOfObject2 = { paramString1, Integer.toString(paramInt1), paramString2 };
      throw new RuntimeException(cj.translate(cj.ATTEMPT_TO_CONSTRUCT_VARIANT_EXCEPTION, arrayOfObject2));
    }
    this.vt = paramInt1;
    this.l = paramString2;
  }
  
  public Variant(String paramString)
  {
    this.vt = 0;
    this.l = paramString;
  }
  
  public Variant(String paramString, int paramInt)
  {
    this.vt = paramInt;
    this.l = paramString;
  }
  
  public Variant(String paramString, int paramInt, byte paramByte)
  {
    a(c("o\f\023rzt\007\004;~r\003\022"), paramString, paramInt, 17);
    this.bVal = paramByte;
  }
  
  public Variant(String paramString, int paramInt, short paramShort)
  {
    if (paramInt == 18)
    {
      a(c("i\n\017ii"), paramString, paramInt, 18);
      if (Dispatch.H == 0) {}
    }
    else
    {
      a(c("i\n\017ii"), paramString, paramInt, 2);
    }
    this.iVal = paramShort;
  }
  
  public Variant(String paramString, int paramInt1, int paramInt2)
  {
    if (paramInt1 == 22)
    {
      a(c("s\f\024"), paramString, paramInt1, 22);
      this.intVal = paramInt2;
      if (i1 == 0) {}
    }
    else if (paramInt1 == 19)
    {
      a(c("O+T"), paramString, paramInt1, 19);
      this.lVal = paramInt2;
      if (i1 == 0) {}
    }
    else
    {
      a(c("SV"), paramString, paramInt1, 3);
      this.lVal = paramInt2;
    }
  }
  
  public Variant(String paramString, int paramInt, float paramFloat)
  {
    a(c("|\016\017zi"), paramString, paramInt, 4);
    this.fltVal = paramFloat;
  }
  
  public Variant(String paramString, int paramInt, double paramDouble)
  {
    a(c("~\r\025yq"), paramString, paramInt, 5);
    this.dblVal = paramDouble;
  }
  
  public Variant(String paramString, int paramInt, long paramLong)
  {
    if (paramInt == 6)
    {
      a(c("y\027\022ixt\001\031"), paramString, paramInt, 6);
      this.cyVal = paramLong;
      if (Dispatch.H == 0) {}
    }
    else
    {
      a(c("I\001\017x"), paramString, paramInt, paramInt == 1 ? 1 : 10);
      this.returnValue = paramLong;
    }
  }
  
  public Variant(String paramString, int paramInt, Date paramDate)
  {
    a(c("~\003\024~"), paramString, paramInt, 7);
    this.date = paramDate;
  }
  
  public Variant(String paramString, int paramInt, boolean paramBoolean)
  {
    a(c("x\r\017wx{\f"), paramString, paramInt, 11);
    this.bool = paramBoolean;
  }
  
  public Variant(String paramString, int paramInt, BigDecimal paramBigDecimal)
  {
    a(c("^\007\003rp{\016"), paramString, paramInt, 14);
    this.decVal = paramBigDecimal;
  }
  
  public Variant(String paramString1, int paramInt, String paramString2)
  {
    a(c("I\026\022rs}"), paramString1, paramInt, 8);
    this.bstrVal = paramString2;
  }
  
  public Variant(String paramString, int paramInt, Object paramObject)
    throws IOException
  {
    if ((paramInt & 0x2000) != 0)
    {
      Log.log(3, c("S\f\tot{\016\tax~B\001io{\033"));
      this.vt = paramInt;
      this.parray = paramObject;
      return;
    }
    Object localObject1;
    if (paramInt == 9)
    {
      this.vt = paramInt;
      if (paramObject == null)
      {
        this.pdispVal = null;
        if (i1 == 0) {}
      }
      else if ((paramObject instanceof RemoteObjRef))
      {
        localObject1 = ((RemoteObjRef)paramObject).getJintegraDispatch();
        this.pdispVal = ((Dispatch)localObject1).getObjRef().a(k.IID_IDISPATCH, null);
        if (i1 == 0) {}
      }
      else if ((paramObject instanceof Dispatch))
      {
        localObject1 = (Dispatch)paramObject;
        this.pdispVal = ((Dispatch)localObject1).getObjRef().a(k.IID_IDISPATCH, null);
        if (i1 == 0) {}
      }
      else
      {
        this.pdispVal = z.a(paramObject, null, null);
      }
      return;
    }
    if (paramInt == 13)
    {
      this.vt = paramInt;
      if (paramObject == null)
      {
        this.pdispVal = null;
        if (i1 == 0) {}
      }
      else if ((paramObject instanceof RemoteObjRef))
      {
        localObject1 = ((RemoteObjRef)paramObject).getJintegraDispatch();
        this.pdispVal = ((Dispatch)localObject1).getObjRef().a(k.IID_IUNKNOWN, null);
        if (i1 == 0) {}
      }
      else if ((paramObject instanceof Dispatch))
      {
        localObject1 = (Dispatch)paramObject;
        this.pdispVal = ((Dispatch)localObject1).getObjRef().a(k.IID_IUNKNOWN, null);
        if (i1 == 0) {}
      }
      else
      {
        this.pdispVal = z.a(paramObject, k.IID_IUNKNOWN, null);
      }
      return;
    }
    if (paramInt == 36)
    {
      this.vt = 36;
      this.recordValue = paramObject;
      return;
    }
    if (paramInt == 16396) {
      paramInt = 12;
    }
    a(c("L\003\022r|t\026"), paramString, paramInt, 12);
    if (paramObject == null)
    {
      this.vt = 0;
      if (i1 == 0) {}
    }
    else if ((paramObject instanceof Number))
    {
      localObject1 = (Number)paramObject;
      if ((paramObject instanceof Double))
      {
        this.dblVal = ((Number)localObject1).doubleValue();
        this.vt = 5;
        if (i1 == 0) {}
      }
      else if ((paramObject instanceof Float))
      {
        this.fltVal = ((Number)localObject1).floatValue();
        this.vt = 4;
        if (i1 == 0) {}
      }
      else if ((paramObject instanceof Integer))
      {
        this.lVal = ((Number)localObject1).intValue();
        this.vt = 3;
        if (i1 == 0) {}
      }
      else if ((paramObject instanceof Byte))
      {
        this.bVal = ((Number)localObject1).byteValue();
        this.vt = 17;
        if (i1 == 0) {}
      }
      else if ((paramObject instanceof Short))
      {
        this.iVal = ((Number)localObject1).shortValue();
        this.vt = 2;
        if (i1 == 0) {}
      }
      else if ((paramObject instanceof BigDecimal))
      {
        this.decVal = ((BigDecimal)paramObject);
        this.vt = 14;
        if (i1 == 0) {}
      }
      else if ((paramObject instanceof Long))
      {
        this.cyVal = ((Number)localObject1).longValue();
        this.vt = 6;
        if (i1 == 0) {}
      }
    }
    else if ((paramObject instanceof Character))
    {
      this.lVal = ((Character)paramObject).charValue();
      this.vt = 3;
      if (i1 == 0) {}
    }
    else if ((paramObject instanceof String))
    {
      this.bstrVal = ((String)paramObject);
      this.vt = 8;
      if (i1 == 0) {}
    }
    else if (paramObject.getClass() == (C == null ? (Variant.C = b(c("p\003\026z3o\026\tw3^\003\024~"))) : C))
    {
      this.date = ((Date)paramObject);
      this.vt = 7;
      if (i1 == 0) {}
    }
    else if ((paramObject instanceof Boolean))
    {
      this.bool = ((Boolean)paramObject).booleanValue();
      this.vt = 11;
      if (i1 == 0) {}
    }
    else if (((paramObject instanceof byte[])) || ((paramObject instanceof byte[][])))
    {
      this.parray = paramObject;
      this.vt = 8209;
      if (i1 == 0) {}
    }
    else if (((paramObject instanceof short[])) || ((paramObject instanceof short[][])))
    {
      this.parray = paramObject;
      this.vt = 8194;
      if (i1 == 0) {}
    }
    else if (((paramObject instanceof int[])) || ((paramObject instanceof int[][])))
    {
      this.parray = paramObject;
      this.vt = 8195;
      if (i1 == 0) {}
    }
    else if (((paramObject instanceof char[])) || ((paramObject instanceof char[][])))
    {
      this.parray = paramObject;
      this.vt = 8195;
      if (i1 == 0) {}
    }
    else if (((paramObject instanceof long[])) || ((paramObject instanceof long[][])))
    {
      this.parray = paramObject;
      this.vt = 8198;
      if (i1 == 0) {}
    }
    else if (((paramObject instanceof float[])) || ((paramObject instanceof float[][])))
    {
      this.parray = paramObject;
      this.vt = 8196;
      if (i1 == 0) {}
    }
    else if (((paramObject instanceof double[])) || ((paramObject instanceof double[][])))
    {
      this.parray = paramObject;
      this.vt = 8197;
      if (i1 == 0) {}
    }
    else if (((paramObject instanceof Date[])) || ((paramObject instanceof Date[][])))
    {
      this.parray = paramObject;
      this.vt = 8199;
      if (i1 == 0) {}
    }
    else if (((paramObject instanceof String[])) || ((paramObject instanceof String[][])))
    {
      this.parray = paramObject;
      this.vt = 8200;
      if (i1 == 0) {}
    }
    else if (((paramObject instanceof boolean[])) || ((paramObject instanceof boolean[][])))
    {
      this.parray = paramObject;
      this.vt = 8203;
      if (i1 == 0) {}
    }
    else if ((paramObject instanceof Object[]))
    {
      localObject1 = (Object[])paramObject;
      if (localObject1.length == 0)
      {
        this.vt = 0;
        if (i1 == 0) {}
      }
      else
      {
        this.parray = paramObject;
        this.vt = 8204;
        if (i1 == 0) {}
      }
    }
    else if (paramObject == EmptyVariant.TYPE)
    {
      this.vt = 0;
      if (i1 == 0) {}
    }
    else if (paramObject == NullVariant.TYPE)
    {
      this.vt = 1;
      if (i1 == 0) {}
    }
    else if (!paramObject.getClass().isArray())
    {
      if (StructDesc.a(paramObject))
      {
        this.vt = 36;
        this.recordValue = paramObject;
        return;
      }
      localObject1 = k.IID_IDISPATCH;
      if (bi.C())
      {
        this.vt = 13;
        localObject1 = k.IID_IUNKNOWN;
        if (i1 == 0) {}
      }
      else
      {
        this.vt = 9;
      }
      Object localObject2;
      if ((paramObject instanceof RemoteObjRef))
      {
        localObject2 = ((RemoteObjRef)paramObject).getJintegraDispatch();
        this.pdispVal = ((Dispatch)localObject2).getObjRef().a((Uuid)localObject1, null);
        if (i1 == 0) {}
      }
      else if ((paramObject instanceof Dispatch))
      {
        localObject2 = (Dispatch)paramObject;
        this.pdispVal = ((Dispatch)localObject2).getObjRef().a((Uuid)localObject1, null);
        if (i1 == 0) {}
      }
      else if ((paramObject instanceof StdObjRef))
      {
        localObject2 = (StdObjRef)paramObject;
        this.pdispVal = ((StdObjRef)localObject2).a((Uuid)localObject1, null);
        if (i1 == 0) {}
      }
      else
      {
        this.pdispVal = z.a(paramObject, (Uuid)localObject1, null);
        if (i1 == 0) {}
      }
    }
    else
    {
      localObject1 = cj.translate(cj.CANNOT_CREATE_VARIANT_FOR, paramObject, paramObject.getClass());
      Log.a((String)localObject1);
      throw new RuntimeException((String)localObject1);
    }
  }
  
  private void a(String paramString, Object[] paramArrayOfObject)
  {
    if (paramArrayOfObject.length != 1) {
      throw new IllegalArgumentException(cj.translate(cj.PARAMETER_MUST_BE_ONE_ELEMENT_ARRAY, paramString));
    }
  }
  
  void b()
  {
    int i1 = Dispatch.H;
    if ((this.vt & 0x2000) != 0)
    {
      this.vt |= 0x4000;
      return;
    }
    switch (this.vt)
    {
    case 0: 
    case 1: 
      if (i1 == 0) {
        break;
      }
    case 16: 
    case 17: 
      this.pbVal[0] = this.bVal;
      if (i1 == 0) {
        break;
      }
    case 2: 
    case 18: 
      this.piVal[0] = this.iVal;
      if (i1 == 0) {
        break;
      }
    case 3: 
    case 19: 
      this.plVal[0] = this.lVal;
      if (i1 == 0) {
        break;
      }
    case 22: 
      this.pintVal[0] = this.intVal;
      if (i1 == 0) {
        break;
      }
    case 4: 
      this.pfltVal[0] = this.fltVal;
      if (i1 == 0) {
        break;
      }
    case 5: 
      this.pdblVal[0] = this.dblVal;
      if (i1 == 0) {
        break;
      }
    case 11: 
      this.pbool[0] = this.bool;
      if (i1 == 0) {
        break;
      }
    case 10: 
      this.preturnValue[0] = this.returnValue;
      if (i1 == 0) {
        break;
      }
    case 6: 
      this.pcyVal[0] = this.cyVal;
      if (i1 == 0) {
        break;
      }
    case 7: 
      this.pdate[0] = this.date;
      if (i1 == 0) {
        break;
      }
    case 8: 
      this.pbstrVal[0] = this.bstrVal;
      if (i1 == 0) {
        break;
      }
    case 14: 
      this.pdecVal[0] = this.decVal;
      if (i1 == 0) {
        break;
      }
    case 9: 
      this.ppdispVal[0] = this.pdispVal;
      if (i1 == 0) {
        break;
      }
    case 12: 
    case 13: 
    case 15: 
    case 20: 
    case 21: 
    default: 
      throw new IllegalArgumentException(cj.translate(cj.CANNOT_SEND_WITH, Integer.toHexString(this.vt), this.l));
    }
    this.vt |= 0x4000;
  }
  
  public Variant(String paramString, int paramInt, short[] paramArrayOfShort)
  {
    if (paramArrayOfShort == null) {
      paramArrayOfShort = new short[1];
    }
    if (paramArrayOfShort.length != 1) {
      throw new IllegalArgumentException(cj.translate(cj.PARAMETER_MUST_BE_SINGLE_ELEMENT_ARRAY, paramString));
    }
    if (paramInt == 16402) {
      this.piVal = paramArrayOfShort;
    }
    a(c("i\n\017iiA?"), paramString, paramInt, 16386);
    this.piVal = paramArrayOfShort;
  }
  
  public Variant(String paramString, int paramInt, byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null) {
      paramArrayOfByte = new byte[1];
    }
    if (paramArrayOfByte.length != 1) {
      throw new IllegalArgumentException(cj.translate(cj.PARAMETER_MUST_BE_SINGLE_ELEMENT_ARRAY, paramString));
    }
    a(c("o\f\023rzt\007\004;~r\003\022@@"), paramString, paramInt, 16401);
    this.pbVal = paramArrayOfByte;
  }
  
  public Variant(String paramString, int paramInt, int[] paramArrayOfInt)
  {
    if (paramArrayOfInt == null) {
      paramArrayOfInt = new int[1];
    }
    if (paramArrayOfInt.length != 1) {
      throw new IllegalArgumentException(cj.translate(cj.PARAMETER_MUST_BE_SINGLE_ELEMENT_ARRAY, paramString));
    }
    if (paramInt == 16406) {
      paramInt = 16387;
    }
    if (paramInt == 16406)
    {
      a(c("s\f\024@@"), paramString, paramInt, 16406);
      this.pintVal = paramArrayOfInt;
      if (i1 == 0) {}
    }
    else if (paramInt == 16403)
    {
      a(c("s\f\024@@"), paramString, paramInt, 16403);
      this.plVal = paramArrayOfInt;
      if (i1 == 0) {}
    }
    else
    {
      a(c("s\f\024@@"), paramString, paramInt, 16387);
      this.plVal = paramArrayOfInt;
    }
  }
  
  public Variant(String paramString, int paramInt, float[] paramArrayOfFloat)
  {
    if (paramArrayOfFloat == null) {
      paramArrayOfFloat = new float[1];
    }
    if (paramArrayOfFloat.length != 1) {
      throw new IllegalArgumentException(cj.translate(cj.PARAMETER_MUST_BE_SINGLE_ELEMENT_ARRAY, paramString));
    }
    a(c("|\016\017ziA?"), paramString, paramInt, 16388);
    this.pfltVal = paramArrayOfFloat;
  }
  
  public Variant(String paramString, int paramInt, double[] paramArrayOfDouble)
  {
    if (paramArrayOfDouble == null) {
      paramArrayOfDouble = new double[1];
    }
    if (paramArrayOfDouble.length != 1) {
      throw new IllegalArgumentException(cj.translate(cj.PARAMETER_MUST_BE_SINGLE_ELEMENT_ARRAY, paramString));
    }
    a(c("~\r\025yq9="), paramString, paramInt, 16389);
    this.pdblVal = paramArrayOfDouble;
  }
  
  public Variant(String paramString, int paramInt, long[] paramArrayOfLong)
  {
    if (paramArrayOfLong == null) {
      paramArrayOfLong = new long[1];
    }
    if (paramArrayOfLong.length != 1) {
      throw new IllegalArgumentException(cj.translate(cj.PARAMETER_MUST_BE_SINGLE_ELEMENT_ARRAY, paramString));
    }
    if (paramInt == 16390)
    {
      a(c("v\r\016|FG"), paramString, paramInt, 16390);
      this.pcyVal = paramArrayOfLong;
      if (Dispatch.H == 0) {}
    }
    else
    {
      a(c("v\r\016|FG"), paramString, paramInt, 16394);
      this.preturnValue = paramArrayOfLong;
    }
  }
  
  public Variant(String paramString, int paramInt, Date[] paramArrayOfDate)
  {
    if (paramArrayOfDate == null) {
      paramArrayOfDate = new Date[1];
    }
    a(paramString, paramArrayOfDate);
    a(c("^\003\024~FG"), paramString, paramInt, 16391);
    this.pdate = paramArrayOfDate;
  }
  
  public Variant(String paramString, int paramInt, BigDecimal[] paramArrayOfBigDecimal)
  {
    if (paramArrayOfBigDecimal == null) {
      paramArrayOfBigDecimal = new BigDecimal[1];
    }
    a(paramString, paramArrayOfBigDecimal);
    a(c("^\007\003rp{\016;F"), paramString, paramInt, 16398);
    this.pdecVal = paramArrayOfBigDecimal;
  }
  
  public Variant(String paramString, int paramInt, boolean[] paramArrayOfBoolean)
  {
    if (paramInt == 8203)
    {
      this.vt = paramInt;
      this.parray = paramArrayOfBoolean;
      return;
    }
    if (paramArrayOfBoolean == null) {
      paramArrayOfBoolean = new boolean[1];
    }
    if (paramArrayOfBoolean.length != 1) {
      throw new IllegalArgumentException(cj.translate(cj.PARAMETER_MUST_BE_SINGLE_ELEMENT_ARRAY, paramString));
    }
    a(c("x\r\017wx{\f;F"), paramString, paramInt, 16395);
    this.pbool = paramArrayOfBoolean;
  }
  
  public Variant(String paramString, int paramInt, String[] paramArrayOfString)
  {
    if (paramArrayOfString == null) {
      paramArrayOfString = new String[1];
    }
    a(paramString, paramArrayOfString);
    a(c("I\026\022rs}9="), paramString, paramInt, 16392);
    this.pbstrVal = paramArrayOfString;
  }
  
  public Variant(String paramString, Variant paramVariant)
  {
    this.l = paramString;
    this.vt = 16396;
    this.pvarVal = new Variant[1];
    this.pvarVal[0] = paramVariant;
  }
  
  public Variant(String paramString, int paramInt, Object[] paramArrayOfObject)
    throws IOException
  {
    if (paramArrayOfObject == null) {
      paramArrayOfObject = new Object[1];
    }
    Object localObject;
    if ((!isByRef(paramInt)) && (a(paramInt)))
    {
      this.vt = paramInt;
      this.l = paramString;
      this.parray = paramArrayOfObject;
      if ((this.parray != null) && (!this.parray.getClass().isArray()))
      {
        localObject = cj.translate(cj.ATTEMPT_TO_CONSTRUCT_ARRAY_FROM_NON_ARRAY, this.parray.getClass());
        Log.a((String)localObject);
        throw new RuntimeException((String)localObject);
      }
      return;
    }
    a(paramString, paramArrayOfObject);
    if (a(paramInt))
    {
      this.vt = paramInt;
      this.l = paramString;
      this.parray = paramArrayOfObject[0];
      if ((this.parray != null) && (!this.parray.getClass().isArray()))
      {
        localObject = cj.translate(cj.ATTEMPT_TO_CONSTRUCT_ARRAY_FROM_NON_ARRAY, this.parray.getClass());
        Log.a((String)localObject);
        throw new RuntimeException((String)localObject);
      }
      return;
    }
    switch (paramInt)
    {
    case 16396: 
      this.vt = paramInt;
      this.l = paramString;
      this.pvarVal = new Variant[1];
      localObject = new Variant(paramString, 12, paramArrayOfObject[0]);
      this.pvarVal[0] = localObject;
      this.pvalue = paramArrayOfObject;
      if (i1 == 0) {
        break;
      }
    case 16393: 
      this.vt = paramInt;
      this.l = paramString;
      if (paramArrayOfObject[0] != null) {
        this.pdispVal = z.a(paramArrayOfObject[0], k.IID_IDISPATCH, null);
      }
      this.ppdispVal[0] = this.pdispVal;
      this.pvalue = paramArrayOfObject;
      if (i1 == 0) {
        break;
      }
    case 16397: 
      this.vt = paramInt;
      this.l = paramString;
      if (paramArrayOfObject[0] != null) {
        this.pdispVal = z.a(paramArrayOfObject[0], k.IID_IUNKNOWN, null);
      }
      this.ppdispVal[0] = this.pdispVal;
      this.pvalue = paramArrayOfObject;
      if (i1 == 0) {
        break;
      }
    case 16392: 
      a(c("I\026\022rs}9="), paramString, paramInt, 16392);
      this.pbstrVal = ((String[])paramArrayOfObject);
      if (i1 == 0) {
        break;
      }
    case 16394: 
    case 16395: 
    default: 
      Log.a(cj.translate(cj.VARIANT_NOT_SUPPORTED, paramString));
      throw new RuntimeException(cj.translate(cj.VARIANT_NOT_SUPPORTED_FOR_PARAMETER, paramString, Integer.toString(paramInt)));
    }
  }
  
  private static void a(y paramy, int paramInt)
    throws IOException
  {
    paramy.a(0L, c("^5/IY"), c("h\022\003Ixi\007\022mx~"));
    paramy.d(paramInt, c("O1(TON"), c("l\026"));
    paramy.d(98, c("O1(TON"), c("m0\005hxh\024\005,"));
    paramy.d(54081, c("O1(TON"), c("m0\005hxh\024\005/"));
    paramy.d(4029, c("O1(TON"), c("m0\005hxh\024\005."));
    if ((paramInt & 0x6000) == 0)
    {
      paramy.a(paramInt, c("o=\tui)P"), c("l\026"));
      if (Dispatch.H == 0) {}
    }
    else
    {
      paramy.a(24576L, c("o=\tui)P"), c("l\026"));
    }
  }
  
  static void a(y paramy)
    throws IOException
  {
    paramy.a(c("L\003\022r|t\026"));
    paramy.a(3L, c("^5/IY"), c("y\0163rg"));
    a(paramy, 0);
    paramy.c();
  }
  
  static void b(y paramy)
    throws IOException
  {
    paramy.a(c("L\003\022r|t\026"));
    paramy.a(3L, c("^5/IY"), c("y\0163rg"));
    a(paramy, 0);
    paramy.c();
  }
  
  void c(y paramy)
    throws IOException
  {
    int i3 = Dispatch.H;
    paramy.d(8);
    paramy.a(c("H\007\001w=L\003\022r|t\026@3") + this.l + ")");
    y localy = paramy.g();
    localy.a(paramy.b() + 4);
    localy.a(c("N\007\rk=L\003\022r|t\026@3") + this.l + ")");
    Object localObject;
    switch (this.vt)
    {
    case 0: 
    case 1: 
    case 16385: 
      a(localy, this.vt);
      if (i3 == 0) {
        break;
      }
    case 16: 
      a(localy, this.vt);
      localy.c(this.bVal, c("s\f\024#"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16400: 
      a(localy, this.vt);
      localy.a(4L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.c(this.pbVal[0], c("s\f\024#"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 17: 
      a(localy, this.vt);
      localy.e(this.bVal, c("s\f\024#"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16401: 
      a(localy, this.vt);
      localy.a(4L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.e(this.pbVal[0], c("s\f\024#"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 2: 
    case 18: 
      a(localy, this.vt);
      localy.b(this.iVal, c("s\f\024*+"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16386: 
    case 16402: 
      a(localy, this.vt);
      localy.a(4L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.b(this.piVal[0], c("s\f\024*+"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 3: 
    case 19: 
      a(localy, this.vt);
      localy.a(this.lVal, c("s\f\024(/"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16387: 
    case 16403: 
      a(localy, this.vt);
      localy.a(4L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.a(this.plVal[0], c("s\f\024(/"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 22: 
      a(localy, this.vt);
      localy.a(this.intVal, c("s\f\024(/"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16406: 
      a(localy, this.vt);
      localy.a(4L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.a(this.pintVal[0], c("s\f\024(/"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 4: 
      a(localy, this.vt);
      localy.a(this.fltVal, c("|\016\017zi"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16388: 
      a(localy, this.vt);
      localy.a(4L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.a(this.pfltVal[0], c("|\016\017zi"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 5: 
      a(localy, this.vt);
      localy.a(this.dblVal, c("~\r\025yq"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16389: 
      a(localy, this.vt);
      localy.a(8L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.a(this.pdblVal[0], c("~\r\025yq"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 11: 
      a(localy, this.vt);
      localy.b(this.bool ? -1 : 0, c("x\r\017wx{\f"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16395: 
      a(localy, this.vt);
      localy.a(4L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.b(this.pbool[0] != 0 ? -1 : 0, c("x\r\017wx{\f"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 10: 
      a(localy, this.vt);
      localy.a(this.returnValue, c("_\020\022to"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16394: 
      a(localy, this.vt);
      localy.a(4L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.a(this.preturnValue[0], c("_\020\022to"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 6: 
      a(localy, this.vt);
      localy.c(this.cyVal, c("Y;"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16390: 
      a(localy, this.vt);
      localy.a(8L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.c(this.pcyVal[0], c("Y;"), c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 7: 
      a(localy, this.vt);
      localy.a(this.date, c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16391: 
      a(localy, this.vt);
      localy.a(8L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.a(this.pdate[0], c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 14: 
      a(localy, this.vt);
      localy.a(this.decVal, c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16398: 
      a(localy, this.vt);
      localy.a(8L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.a(this.pdecVal[0], c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 8: 
      a(localy, this.vt);
      localy.a(localy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
      localy.c(this.bstrVal, c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 16392: 
      a(localy, this.vt);
      localy.a(4L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.a(localy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
      localy.c(this.pbstrVal[0], c("l\003\fnx"));
      if (i3 == 0) {
        break;
      }
    case 36: 
      a(localy, this.vt);
      localObject = localy.g();
      Marshaller localMarshaller = new Marshaller();
      localMarshaller.h = true;
      localMarshaller.a(this.recordValue, (y)localObject);
      localMarshaller.h = false;
      localMarshaller.a(this.recordValue, (y)localObject);
      byte[] arrayOfByte2 = ((y)localObject).e();
      localy.a(localy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
      localy.a(1L, c("o=\tui)P"), c("[\016\027zdiBQ$"));
      localy.a(arrayOfByte2.length, c("o=\tui)P"), c("h\007\003to~B\002n{:\016\005uzn\n"));
      localy.a(c("O\021\005i"), c("O\021\005i"));
      localy.a(localy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
      localy.a(92L, c("o=\tui)P"), c(""));
      StdObjRef.writeRecordCustomObjRef(StructDesc.b(this.recordValue.getClass()), localy);
      localy.a(arrayOfByte2.length, c("o=\tui)P"), c("h\007\003to~B\002n{:\016\005uzn\n"));
      localy.a(arrayOfByte2, 0, arrayOfByte2.length, c("N\n\005;o\001\017iy"));
      if (i3 == 0) {
        break;
      }
    case 9: 
      a(localy, this.vt);
      if (this.pdispVal == null)
      {
        localy.a(0L, c("o=\tui)P"), c("&\022\024i=s\006^"));
        if (i3 == 0) {
          break;
        }
      }
      else
      {
        this.pdispVal.a(localy, k.IID_IDISPATCH);
        if (i3 == 0) {
          break;
        }
      }
      break;
    case 16393: 
      a(localy, this.vt);
      localy.a(4L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localObject = this.pdispVal.i();
      if (localObject == null)
      {
        this.pdispVal.a(localy, k.IID_IDISPATCH);
        if (i3 == 0) {
          break;
        }
      }
      else
      {
        this.pdispVal.a(localy, (Uuid)localObject);
        if (i3 == 0) {
          break;
        }
      }
      break;
    case 13: 
      a(localy, this.vt);
      if (this.pdispVal == null)
      {
        localy.a(0L, c("o=\tui)P"), c("&\022\024i=s\006^"));
        if (i3 == 0) {
          break;
        }
      }
      else
      {
        localObject = this.pdispVal.i();
        if (localObject == null) {
          localObject = k.IID_IUNKNOWN;
        }
        this.pdispVal.a(localy, (Uuid)localObject);
        if (i3 == 0) {
          break;
        }
      }
      break;
    case 16397: 
      a(localy, this.vt);
      localy.a(4L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localObject = this.pdispVal.i();
      if (localObject == null) {
        localObject = k.IID_IUNKNOWN;
      }
      this.pdispVal.a(localy, (Uuid)localObject);
      if (i3 == 0) {
        break;
      }
    case 16396: 
      a(localy, this.vt);
      localy.a(16L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
      localy.a(localy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
      localy.d(8);
      this.pvarVal[0].c(localy);
      if (i3 == 0) {
        break;
      }
    default: 
      if (a(this.vt))
      {
        a(localy, this.vt);
        if ((this.vt & 0x4000) != 0) {
          localy.a(4L, c("s\f\024(/"), c("n\025\tyv\007\023oty\t\023"));
        }
        int i1 = a(localy, "");
        if (i3 == 0) {
          break;
        }
      }
      else
      {
        if (this.vt == 16396) {
          throw new RuntimeException(cj.PASSING_VARIANTS_BY_REF_NOT_SUPPORTED);
        }
        throw new RuntimeException(cj.translate(cj.PASSING_VARIANTS_BY_REF_NOT_SUPPORTED_WITH_VT, Integer.toString(this.vt), this.l));
      }
      break;
    }
    byte[] arrayOfByte1 = localy.e();
    int i2 = (arrayOfByte1.length + 4) / 8;
    if ((arrayOfByte1.length + 4) % 8 != 0) {
      i2++;
    }
    localy.c();
    paramy.a(i2, c("^5/IY"), c("y\0163rg"));
    paramy.a(arrayOfByte1, 0, arrayOfByte1.length, c("y\r\016oxt\026\023"));
    paramy.c();
  }
  
  void a(x paramx)
    throws IOException
  {
    int i1 = Dispatch.H;
    paramx.a(c("L\003\022r|t\026@3") + this.l + ")");
    long l1 = paramx.e(c("^5/IY"), c("y\0163rg"));
    paramx.e(c("^5/IY"), c("h\007\023~ol\007\004"));
    this.vt = paramx.f(c("O1(TON"), c("l\026"));
    paramx.f(c("O1(TON"), c("h\007\023~ol\007\004"));
    paramx.f(c("O1(TON"), c("h\007\023~ol\007\004"));
    paramx.f(c("O1(TON"), c("h\007\023~ol\007\004"));
    long l2 = paramx.e(c("^5/IY"), c("l\026"));
    long l3;
    Object localObject;
    switch (this.vt)
    {
    case 0: 
    case 1: 
      if ((i1 == 0) || (i1 == 0)) {
        break;
      }
    case 16: 
      this.bVal = ((byte)paramx.g(c("o\013\016o%"), c("l\003\fnx")));
      if (i1 == 0) {
        break;
      }
    case 16400: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.pbVal[0] = ((byte)paramx.g(c("s\f\024#"), c("l\003\fnx")));
      if (i1 == 0) {
        break;
      }
    case 17: 
      this.bVal = ((byte)paramx.g(c("o=\tui\""), c("l\003\fnx")));
      if (i1 == 0) {
        break;
      }
    case 16401: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.pbVal[0] = ((byte)paramx.g(c("o=\tui\""), c("l\003\fnx")));
      if (i1 == 0) {
        break;
      }
    case 2: 
    case 18: 
      this.iVal = paramx.c(c("O1(TON"), c("i\n\017ii:\024\001wh"));
      if (i1 == 0) {
        break;
      }
    case 16386: 
    case 16402: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.piVal[0] = paramx.c(c("O1(TON"), c("i\n\017ii:\024\001wh"));
      if (i1 == 0) {
        break;
      }
    case 3: 
      this.lVal = paramx.b(c("S,4"), c("s\f\024;k{\016\025~"));
      if (i1 == 0) {
        break;
      }
    case 19: 
      this.lVal = paramx.b(c("S,4"), c("s\f\024;k{\016\025~"));
      if (i1 == 0) {
        break;
      }
    case 16387: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.plVal[0] = paramx.b(c("S,4"), c("s\f\024;k{\016\025~"));
      if (i1 == 0) {
        break;
      }
    case 16403: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.plVal[0] = paramx.b(c("S,4"), c("s\f\024;k{\016\025~"));
      if (i1 == 0) {
        break;
      }
    case 22: 
      this.intVal = paramx.b(c("S,4"), c("s\f\024;k{\016\025~"));
      if (i1 == 0) {
        break;
      }
    case 16406: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.pintVal[0] = paramx.b(c("S,4"), c("s\f\024;k{\016\025~"));
      if (i1 == 0) {
        break;
      }
    case 4: 
      this.fltVal = paramx.j(c("|\016\017zi"), c("|\016\017zi:\024\001wh"));
      if (i1 == 0) {
        break;
      }
    case 16388: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.pfltVal[0] = paramx.j(c("|\016\017zi"), c("|\016\017zi:\024\001wh"));
      if (i1 == 0) {
        break;
      }
    case 5: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.dblVal = paramx.k(c("~\r\025yq"), c("~\r\025yqB\026zqo\007"));
      if (i1 == 0) {
        break;
      }
    case 16389: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.pdblVal[0] = paramx.k(c("~\r\025yq"), c("~\r\025yqB\026zqo\007"));
      if (i1 == 0) {
        break;
      }
    case 6: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.cyVal = paramx.i(c("Y;"), c("l\003\fnx"));
      if (i1 == 0) {
        break;
      }
    case 16390: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.pcyVal[0] = paramx.i(c("Y;"), c("l\003\fnx"));
      if (i1 == 0) {
        break;
      }
    case 7: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.date = paramx.g(c("l\003\fnx"));
      if (i1 == 0) {
        break;
      }
    case 16391: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.pdate[0] = paramx.g(c("l\003\fnx"));
      if (i1 == 0) {
        break;
      }
    case 10: 
      this.returnValue = paramx.e(c("I!/_X"), c("l\003\fnx"));
      if (i1 == 0) {
        break;
      }
    case 16394: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.preturnValue[0] = paramx.e(c("I!/_X"), c("l\003\fnx"));
      if (i1 == 0) {
        break;
      }
    case 8: 
      l3 = paramx.b(c("o=\tui)P"), c("&\022\024i=s\006^"));
      if (l3 != 0L)
      {
        this.bstrVal = paramx.d(c("l\003\fnx"));
        if (i1 == 0) {
          break;
        }
      }
      break;
    case 16392: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      l3 = paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
      if (l3 != 0L)
      {
        this.pbstrVal[0] = paramx.d(c("l\003\fnx"));
        if (i1 == 0) {
          break;
        }
      }
      break;
    case 11: 
      this.bool = (paramx.c(c("x\r\017w"), c("l\003\fnx")) != 0);
      if (i1 == 0) {
        break;
      }
    case 16395: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.pbool[0] = (paramx.c(c("x\r\017w"), c("l\003\fnx")) != 0 ? 1 : false);
      if (i1 == 0) {
        break;
      }
    case 16396: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      paramx.b(c("o=\tui)P"), c("&\022\024i=s\006^"));
      paramx.d(8);
      localObject = new Variant(c("[B6zos\003\016o"));
      ((Variant)localObject).a(paramx);
      this.pvarVal[0] = localObject;
      if (this.pvalue != null)
      {
        this.pvalue[0] = ((Variant)localObject).getVARIANT();
        if (i1 == 0) {
          break;
        }
      }
      break;
    case 14: 
      this.decVal = paramx.c(c("[B$~~s\017\001w=L\003\fnx"));
      if (i1 == 0) {
        break;
      }
    case 16398: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      this.pdecVal[0] = paramx.c(c("[B$~~s\017\001w=L\003\fnx"));
      if (i1 == 0) {
        break;
      }
    case 9: 
    case 13: 
      l3 = paramx.b(c("o=\tui)P"), c("&\022\024i=s\006^"));
      this.pdispVal = (l3 == 0L ? null : new StdObjRef(false, paramx));
      if (i1 == 0) {
        break;
      }
    case 16393: 
    case 16397: 
      paramx.b(c("o=\tui)P"), c("%]_"));
      l3 = paramx.b(c("o=\tui)P"), c("&\022\024i=s\006^"));
      this.pdispVal = (l3 == 0L ? null : new StdObjRef(false, paramx));
      this.vt = 9;
      if (this.pvalue != null)
      {
        this.pvalue[0] = this.pdispVal;
        if (i1 == 0) {
          break;
        }
      }
      break;
    case 36: 
      this.vt = 36;
      l3 = paramx.b(c("o=\tui)P"), c("&\022\024i=s\006^"));
      paramx.b(c("o=\tui)P"), c("%BHzqm\003\031h=+]"));
      paramx.b(c("o=\tui)P"), c("v\007\016|ir]"));
      paramx.b(c("o=\tui)P"), c("O\021\005i"));
      paramx.b(c("o=\tui)P"), c("J\026\022;T^"));
      paramx.b(c("o=\tui)P"), c("v\007\016|ir]"));
      localObject = new StdObjRef(false, false, paramx);
      Uuid localUuid = ((StdObjRef)localObject).o();
      if (localUuid == null) {
        throw new RuntimeException(cj.ERROR_READING_CUSTOM_MARSHALLED_IRECORDINFO);
      }
      paramx.b(c("o=\tui)P"), c("|\016\001|n"));
      Class localClass = StructDesc.a(localUuid).targetClass;
      Marshaller localMarshaller = new Marshaller(paramx);
      localMarshaller.h = true;
      this.recordValue = localMarshaller.a(localClass, null);
      localMarshaller.h = false;
      this.recordValue = localMarshaller.a(localClass, this.recordValue);
      if (i1 == 0) {
        break;
      }
    default: 
      if (a(this.vt))
      {
        if (isByRef()) {
          paramx.b(c("o=\tui)P"), c("%]_"));
        }
        this.parray = a(paramx, this.vt);
        if (this.pvalue != null)
        {
          this.pvalue[0] = this.parray;
          if (i1 == 0) {
            break;
          }
        }
      }
      else
      {
        localObject = cj.translate(cj.CANNOT_READ_VT, Integer.toString(this.vt), this.l);
        Log.a((String)localObject);
        throw new RuntimeException((String)localObject);
      }
      break;
    }
    paramx.c();
  }
  
  void b(int paramInt)
  {
    if (this.vt != paramInt)
    {
      Object[] arrayOfObject1 = { Integer.toString(paramInt), Integer.toString(this.vt), this.l };
      Log.a(cj.translate(cj.MISMATCH_GETTING_VT_VARIANT, arrayOfObject1));
      Object[] arrayOfObject2 = { Integer.toString(paramInt), Integer.toString(this.vt), this.l };
      throw new RuntimeException(cj.translate(cj.MISMATCH_GETTING_VT, arrayOfObject2));
    }
  }
  
  public byte getUI1()
  {
    b(17);
    return this.bVal;
  }
  
  public byte getI1()
  {
    b(16);
    return this.bVal;
  }
  
  public short getI2()
  {
    if (this.vt == 18) {
      return this.iVal;
    }
    b(2);
    return this.iVal;
  }
  
  public int getI4()
  {
    if (this.vt == 10) {
      return (int)this.returnValue;
    }
    if (this.vt == 2) {
      return this.iVal;
    }
    if (this.vt == 22) {
      return this.intVal;
    }
    b(3);
    return this.lVal;
  }
  
  public int getUI4()
  {
    b(19);
    return this.lVal;
  }
  
  public int getINT()
  {
    if (this.vt == 3) {
      return this.lVal;
    }
    b(22);
    return this.intVal;
  }
  
  public float getR4()
  {
    b(4);
    return this.fltVal;
  }
  
  public double getR8()
  {
    b(5);
    return this.dblVal;
  }
  
  public boolean getBOOL()
  {
    b(11);
    return this.bool;
  }
  
  public long getERROR()
  {
    b(10);
    return this.returnValue;
  }
  
  public long getCY()
  {
    b(6);
    return this.cyVal;
  }
  
  public Date getDATE()
  {
    if ((this.vt == 0) || (this.vt == 1)) {
      return null;
    }
    b(7);
    return this.date;
  }
  
  public String getBSTR()
  {
    if ((this.vt == 0) || (this.vt == 1)) {
      return null;
    }
    b(8);
    return this.bstrVal;
  }
  
  public Object getUNKNOWN()
  {
    if ((this.vt == 0) || (this.vt == 1)) {
      return null;
    }
    if (this.vt == 9)
    {
      if (this.pdispVal == null) {
        return null;
      }
      localObject = z.a(this.pdispVal);
      return localObject == null ? this.pdispVal : localObject;
    }
    b(13);
    if (this.pdispVal == null) {
      return null;
    }
    Object localObject = z.a(this.pdispVal);
    return localObject == null ? this.pdispVal : localObject;
  }
  
  public BigDecimal getDECIMAL()
  {
    b(14);
    return this.decVal;
  }
  
  public Object getDISPATCH()
  {
    if ((this.vt == 0) || (this.vt == 1)) {
      return null;
    }
    if (this.vt == 13)
    {
      if (this.pdispVal == null) {
        return null;
      }
      localObject = z.a(this.pdispVal);
      return localObject == null ? this.pdispVal : localObject;
    }
    b(9);
    if (this.pdispVal == null) {
      return null;
    }
    Object localObject = z.a(this.pdispVal);
    return localObject == null ? this.pdispVal : localObject;
  }
  
  public Object getVARIANT()
  {
    if (a(this.vt)) {
      return this.parray;
    }
    Object localObject;
    switch (this.vt)
    {
    case 0: 
    case 1: 
      return null;
    case 16396: 
      localObject = new Object[] { this.pvarVal[0].getVARIANT() };
      return localObject;
    case 16: 
    case 17: 
      return new Byte(this.bVal);
    case 16400: 
    case 16401: 
      return this.pbVal;
    case 2: 
    case 18: 
      return new Short(this.iVal);
    case 16386: 
    case 16402: 
      return this.piVal;
    case 3: 
    case 19: 
      return new Integer(this.lVal);
    case 16387: 
      return this.plVal;
    case 22: 
      return new Integer(this.intVal);
    case 16406: 
      return this.pintVal;
    case 4: 
      return new Float(this.fltVal);
    case 16388: 
      return this.pfltVal;
    case 5: 
      return new Double(this.dblVal);
    case 16389: 
      return this.pdblVal;
    case 7: 
      return this.date;
    case 16391: 
      return this.pdate;
    case 11: 
      return new Boolean(this.bool);
    case 16395: 
      return this.pbool;
    case 10: 
      if (this.returnValue == 2147614724L) {
        return null;
      }
      return new Long(this.returnValue);
    case 16394: 
      return this.preturnValue;
    case 6: 
      return new Long(this.cyVal);
    case 16390: 
      return this.pcyVal;
    case 8: 
      return this.bstrVal;
    case 16392: 
      return this.pbstrVal;
    case 14: 
      return this.decVal;
    case 16398: 
      return this.pdecVal;
    case 9: 
    case 13: 
      localObject = z.a(this.pdispVal);
      return localObject == null ? this.pdispVal : localObject;
    case 16393: 
    case 16397: 
      localObject = z.a(this.ppdispVal[0]);
      return localObject == null ? this.ppdispVal[0] : localObject;
    case 36: 
      return this.recordValue;
    }
    Log.a(cj.translate(cj.CANNOT_HANDLE_GETTING_VARIANT_ERROR, Integer.toString(this.vt)));
    throw new RuntimeException(cj.translate(cj.CANNOT_HANDLE_GETTING_VARIANT_EXCEPTION, Integer.toString(this.vt)));
  }
  
  int a(y paramy, String paramString)
    throws IOException
  {
    paramy.a(c("O\021\005i"), c("O\021\005i"));
    return b(paramy, paramString);
  }
  
  int b(y paramy, String paramString)
    throws IOException
  {
    int i9 = Dispatch.H;
    paramy.a(c("E\025\tixI#&^\\H0!B=") + paramString);
    if (this.parray == null)
    {
      paramy.a(0L, c("o=\tui)P"), c("&\022\024i=s\006^"));
      paramy.c();
      return 0;
    }
    long l1 = paramy.f();
    paramy.a(l1, c("o=\tui)P"), c("&\022\024i=s\006^"));
    int i1 = 1;
    int i2 = 1;
    int i3 = 1;
    if (this.parray.getClass().getComponentType().isArray())
    {
      i2 = 2;
      i3 = 2;
    }
    paramy.a(i2, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021@3|v\025\001bn:S_$\"%K^"));
    paramy.d(i3, c("o=\tui+T"), c("y&\tvn"));
    Object localObject1;
    int i4;
    int i5;
    int i6;
    label7336:
    label8268:
    Object localObject2;
    switch (this.vt)
    {
    case 8209: 
    case 24593: 
      if (i3 == 1)
      {
        i1 = 1;
        localObject1 = (byte[])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(1L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(16L, c("o=\tui)P"), c("I$?R,"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {
          paramy.e(localObject1[i4], c("s\f\024#"), c("\016\005vxt\026;") + i4 + "]");
        }
        do
        {
          i4++;
          if (i4 < localObject1.length) {
            break;
          }
          paramy.c();
        } while (i9 != 0);
        if (i9 == 0) {
          break;
        }
      }
      else
      {
        i1 = 1;
        localObject1 = (byte[][])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(1L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(16L, c("o=\tui)P"), c("I$?R,"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        paramy.a(localObject1[0].length, c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {}
        while (i4 < localObject1[0].length)
        {
          i5 = 0;
          if (i9 != 0) {}
          while (i5 < localObject1.length)
          {
            paramy.e(localObject1[i5][i4], c("s\f\024#"), c("\016\005vxt\026;") + i5 + c("G9") + i4 + "]");
            i5++;
          }
          i4++;
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      break;
    case 8203: 
    case 24587: 
      if (i3 == 1)
      {
        i1 = 4;
        localObject1 = (boolean[])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(2L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(2L, c("o=\tui)P"), c("I$?R/"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {
          paramy.b(localObject1[i4] != 0 ? -1 : 0, c("s\f\024*+"), c("\016\005vxt\026;") + i4 + "]");
        }
        do
        {
          i4++;
          if (i4 < localObject1.length) {
            break;
          }
          paramy.c();
          if (i9 == 0) {
            break label9165;
          }
        } while (i9 != 0);
      }
      else
      {
        i1 = 4;
        localObject1 = (boolean[][])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(2L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(2L, c("o=\tui)P"), c("I$?R/"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        paramy.a(localObject1[0].length, c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {}
        while (i4 < localObject1[0].length)
        {
          i5 = 0;
          if (i9 != 0) {}
          while (i5 < localObject1.length)
          {
            paramy.b(localObject1[i5][i4] != 0 ? -1 : 0, c("s\f\024*+"), c("\016\005vxt\026;") + i5 + c("G9") + i4 + "]");
            i5++;
          }
          i4++;
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      break;
    case 8194: 
    case 24578: 
      if (i3 == 1)
      {
        i1 = 4;
        localObject1 = (short[])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(2L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(2L, c("o=\tui)P"), c("I$?R/"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {
          paramy.b(localObject1[i4], c("s\f\024*+"), c("\016\005vxt\026;") + i4 + "]");
        }
        do
        {
          i4++;
          if (i4 < localObject1.length) {
            break;
          }
          paramy.c();
          if (i9 == 0) {
            break label9165;
          }
        } while (i9 != 0);
      }
      else
      {
        i1 = 4;
        localObject1 = (short[][])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(2L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(2L, c("o=\tui)P"), c("I$?R/"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        paramy.a(localObject1[0].length, c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {}
        while (i4 < localObject1[0].length)
        {
          i5 = 0;
          if (i9 != 0) {}
          while (i5 < localObject1.length)
          {
            paramy.b(localObject1[i5][i4], c("s\f\024*+"), c("\016\005vxt\026;") + i5 + c("G9") + i4 + "]");
            i5++;
          }
          i4++;
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      break;
    case 8195: 
    case 8214: 
    case 24579: 
    case 24598: 
      if (i3 == 1)
      {
        i1 = 4;
        if ((this.parray instanceof char[]))
        {
          localObject1 = (char[])this.parray;
          paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
          paramy.a(4L, c("o=\tui)P"), c(""));
          paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
          paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
          paramy.a(3L, c("o=\tui)P"), c("I$?R/"));
          paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
          paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
          paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
          paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
          paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
          i4 = 0;
          if (i9 != 0) {}
          while (i4 < localObject1.length)
          {
            paramy.a(localObject1[i4], c("s\f\024(/"), c("\016\005vxt\026;") + i4 + "]");
            i4++;
          }
        }
        else
        {
          localObject1 = (int[])this.parray;
          paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
          paramy.a(4L, c("o=\tui)P"), c(""));
          paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
          paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
          paramy.a(3L, c("o=\tui)P"), c("I$?R/"));
          paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
          paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
          paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
          paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
          paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
          i4 = 0;
          if (i9 != 0) {}
          while (i4 < localObject1.length)
          {
            paramy.a(localObject1[i4], c("s\f\024(/"), c("\016\005vxt\026;") + i4 + "]");
            i4++;
          }
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      else
      {
        i1 = 4;
        if ((this.parray instanceof char[][]))
        {
          localObject1 = (char[][])this.parray;
          paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
          paramy.a(4L, c("o=\tui)P"), c(""));
          paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
          paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
          paramy.a(3L, c("o=\tui)P"), c("I$?R)"));
          paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
          paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
          paramy.a(localObject1.length, c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
          paramy.a(0L, c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
          paramy.a(localObject1[0].length, c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
          paramy.a(0L, c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
          paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
          i4 = 0;
          if (i9 != 0) {}
          while (i4 < localObject1[0].length)
          {
            i5 = 0;
            if (i9 != 0) {}
            while (i5 < localObject1.length)
            {
              paramy.a(localObject1[i5][i4], c("s\f\024(/"), c("\016\005vxt\026;") + i5 + c("G9") + i4 + "]");
              i5++;
            }
            i4++;
          }
        }
        else
        {
          localObject1 = (int[][])this.parray;
          paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
          paramy.a(4L, c("o=\tui)P"), c(""));
          paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
          paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
          paramy.a(3L, c("o=\tui)P"), c("I$?R)"));
          paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
          paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
          paramy.a(localObject1.length, c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
          paramy.a(0L, c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
          paramy.a(localObject1[0].length, c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
          paramy.a(0L, c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
          paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
          i4 = 0;
          if (i9 != 0) {}
          while (i4 < localObject1[0].length)
          {
            i5 = 0;
            if (i9 != 0) {}
            while (i5 < localObject1.length)
            {
              paramy.a(localObject1[i5][i4], c("s\f\024(/"), c("\016\005vxt\026;") + i5 + c("G9") + i4 + "]");
              i5++;
            }
            i4++;
          }
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      break;
    case 8202: 
    case 24586: 
      if (i3 == 1)
      {
        i1 = 4;
        localObject1 = (long[])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(4L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(3L, c("o=\tui)P"), c("I$?R)"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {
          paramy.a(localObject1[i4], c("s\f\024(/"), c("\016\005vxt\026;") + i4 + "]");
        }
        do
        {
          i4++;
          if (i4 < localObject1.length) {
            break;
          }
          paramy.c();
        } while (i9 != 0);
        if (i9 == 0) {
          break;
        }
      }
      else
      {
        i1 = 4;
        localObject1 = (long[][])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(4L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(3L, c("o=\tui)P"), c("I$?R)"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        paramy.a(localObject1[0].length, c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {}
        while (i4 < localObject1[0].length)
        {
          i5 = 0;
          if (i9 != 0) {}
          while (i5 < localObject1.length)
          {
            paramy.a(localObject1[i5][i4], c("s\f\024(/"), c("\016\005vxt\026;") + i5 + c("G9") + i4 + "]");
            i5++;
          }
          i4++;
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      break;
    case 8196: 
    case 24580: 
      if (i3 == 1)
      {
        i1 = 4;
        localObject1 = (float[])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(4L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(3L, c("o=\tui)P"), c("I$?R)"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {
          paramy.a(localObject1[i4], c("|\016\017zi"), c("\016\005vxt\026;") + i4 + "]");
        }
        do
        {
          i4++;
          if (i4 < localObject1.length) {
            break;
          }
          paramy.c();
        } while (i9 != 0);
        if (i9 == 0) {
          break;
        }
      }
      else
      {
        i1 = 4;
        localObject1 = (float[][])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(4L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(3L, c("o=\tui)P"), c("I$?R)"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        paramy.a(localObject1[0].length, c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {}
        while (i4 < localObject1[0].length)
        {
          i5 = 0;
          if (i9 != 0) {}
          while (i5 < localObject1.length)
          {
            paramy.a(localObject1[i5][i4], c("|\016\017zi"), c("\016\005vxt\026;") + i5 + c("G9") + i4 + "]");
            i5++;
          }
          i4++;
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      break;
    case 8197: 
    case 24581: 
      if (i3 == 1)
      {
        i1 = 8;
        localObject1 = (double[])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(8L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(20L, c("o=\tui)P"), c("I$?R%"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {
          paramy.a(localObject1[i4], c("~\r\025yq"), c("\016\005vxt\026;") + i4 + "]");
        }
        do
        {
          i4++;
          if (i4 < localObject1.length) {
            break;
          }
          paramy.c();
          if (i9 == 0) {
            break label9165;
          }
        } while (i9 != 0);
      }
      else
      {
        i1 = 8;
        localObject1 = (double[][])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(8L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(20L, c("o=\tui)P"), c("I$?R%"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        paramy.a(localObject1[0].length, c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {}
        while (i4 < localObject1[0].length)
        {
          i5 = 0;
          if (i9 != 0) {}
          while (i5 < localObject1.length)
          {
            paramy.a(localObject1[i5][i4], c("~\r\025yq"), c("\016\005vxt\026;") + i5 + c("G9") + i4 + "]");
            i5++;
          }
          i4++;
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      break;
    case 8199: 
    case 24583: 
      if (i3 == 1)
      {
        i1 = 8;
        localObject1 = (Date[])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(8L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(20L, c("o=\tui)P"), c("I$?R/"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0)
        {
          if (localObject1[i4] == null) {
            throw new IllegalArgumentException(cj.ELEMENT_IN_DATE_ARRAY_IS_NULL);
          }
          paramy.a(localObject1[i4], c("\016\005vxt\026;") + i4 + "]");
        }
        do
        {
          i4++;
          if (i4 < localObject1.length) {
            break;
          }
          paramy.c();
        } while (i9 != 0);
        if (i9 == 0) {
          break;
        }
      }
      else
      {
        i1 = 8;
        localObject1 = (Date[][])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(8L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(20L, c("o=\tui)P"), c("I$?R%"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        paramy.a(localObject1[0].length, c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {}
        while (i4 < localObject1[0].length)
        {
          i5 = 0;
          if (i9 != 0) {}
          while (i5 < localObject1.length)
          {
            paramy.a(localObject1[i5][i4], c("\016\005vxt\026;") + i5 + c("G9") + i4 + "]");
            i5++;
          }
          i4++;
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      break;
    case 8198: 
    case 24582: 
      if (i3 == 1)
      {
        i1 = 8;
        localObject1 = (long[])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(8L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(20L, c("o=\tui)P"), c("I$?R%"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {
          paramy.c(localObject1[i4], c("R\033\020~o"), c("\016\005vxt\026;") + i4 + "]");
        }
        do
        {
          i4++;
          if (i4 < localObject1.length) {
            break;
          }
          paramy.c();
        } while (i9 != 0);
        if (i9 == 0) {
          break;
        }
      }
      else
      {
        i1 = 8;
        localObject1 = (long[][])this.parray;
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(8L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(20L, c("o=\tui)P"), c("I$?R%"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        paramy.a(localObject1[0].length, c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {}
        while (i4 < localObject1[0].length)
        {
          i5 = 0;
          if (i9 != 0) {}
          while (i5 < localObject1.length)
          {
            paramy.c(localObject1[i5][i4], c("R\033\020~o"), c("\016\005vxt\026;") + i5 + c("G9") + i4 + "]");
            i5++;
          }
          i4++;
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      break;
    case 8200: 
    case 24584: 
      if (i3 == 1)
      {
        i1 = 4;
        localObject1 = (String[])this.parray;
        this.m = (this.m == 0 ? 256 : this.m);
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(4L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(8L, c("o=\tui)P"), c("I$?YNN0"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {}
        do
        {
          do
          {
            l1 = localObject1[i4] == null ? 0L : paramy.f();
            paramy.a(l1, c("o=\tui)P"), c("&\022\024i=s\006^"));
            i4++;
          } while (i4 < localObject1.length);
          i5 = 0;
        } while (i9 != 0);
        if (i9 != 0) {
          if (localObject1[i5] != null) {
            paramy.c(localObject1[i5], c("l\003\fnx"));
          }
        }
        do
        {
          i5++;
          if (i5 < localObject1.length) {
            break;
          }
          paramy.c();
          if (i9 == 0) {
            break label9165;
          }
        } while (i9 != 0);
      }
      else
      {
        if (i3 != 2)
        {
          localObject1 = cj.translate(cj.MULTI_DIMENSIONAL_ARRAYS_NOT_SUPPORTED, Integer.toString(this.vt));
          Log.a((String)localObject1);
          throw new RuntimeException((String)localObject1);
        }
        i1 = 4;
        localObject1 = (String[][])this.parray;
        this.m = (this.m == 0 ? 256 : this.m);
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(4L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(8L, c("o=\tui)P"), c("I$?YNN0"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=*B@t{|\021\005o#"));
        paramy.a(localObject1[0].length, c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=+B@t{|\021\005o#"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0)
        {
          i5 = 0;
          if (i9 == 0) {}
        }
        do
        {
          while (i5 < localObject1.length)
          {
            l1 = localObject1[i5][i4] == null ? 0L : paramy.f();
            paramy.a(l1, c("o=\tui)P"), c("&\022\024i=s\006^"));
            i5++;
          }
          i4++;
          if (i4 < localObject1[0].length) {
            break;
          }
          i5 = 0;
          if (i9 == 0) {
            break label7336;
          }
        } while (i9 != 0);
        while (i5 < localObject1[0].length)
        {
          i6 = 0;
          if (i9 != 0) {}
          while (i6 < localObject1.length)
          {
            if (localObject1[i6][i5] != null) {
              paramy.c(localObject1[i6][i5], c("\016\005vxt\026;") + i6 + c("G9") + i5 + "]");
            }
            i6++;
          }
          i5++;
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      break;
    case 8201: 
    case 8205: 
    case 24585: 
    case 24589: 
      if (i3 != 1)
      {
        localObject1 = cj.translate(cj.MULTI_DIMENSIONAL_ARRAYS_NOT_SUPPORTED, Integer.toString(this.vt));
        Log.a((String)localObject1);
        throw new RuntimeException((String)localObject1);
      }
      i1 = 4;
      localObject1 = (Object[])this.parray;
      if ((this.vt & 0xFFFFDFFF) == 13)
      {
        this.m = (this.m == 0 ? 512 : this.m);
        if (i9 == 0) {}
      }
      else
      {
        this.m = (this.m == 0 ? 1024 : this.m);
      }
      paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
      paramy.a(4L, c("o=\tui)P"), c(""));
      paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
      paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
      if ((this.vt & 0xFFFFDFFF) == 13)
      {
        paramy.a(13L, c("o=\tui)P"), c("I$?NSQ,/LS"));
        if (i9 == 0) {}
      }
      else
      {
        paramy.a(9L, c("o=\tui)P"), c("I$?_TI2!O^R"));
      }
      paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
      paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
      paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
      paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
      paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
      i4 = 0;
      if (i9 != 0) {}
      do
      {
        do
        {
          l1 = localObject1[i4] == null ? 0L : paramy.f();
          paramy.a(l1, c("o=\tui)P"), c("&\022\024i=s\006^"));
          i4++;
        } while (i4 < localObject1.length);
        i5 = 0;
      } while (i9 != 0);
      if (i9 != 0) {
        if (localObject1[i5] != null) {
          if ((this.vt & 0xFFFFDFFF) == 13)
          {
            z.a(localObject1[i5], k.IID_IUNKNOWN, null).a(paramy, k.IID_IUNKNOWN, false);
            if (i9 == 0) {}
          }
          else
          {
            z.a(localObject1[i5], k.IID_IDISPATCH, null).a(paramy, k.IID_IDISPATCH, false);
          }
        }
      }
      do
      {
        i5++;
        if (i5 < localObject1.length) {
          break;
        }
        paramy.c();
        if (i9 == 0) {
          break label9165;
        }
      } while (i9 != 0);
      break;
    case 8204: 
    case 24588: 
      if ((this.parray instanceof Object[][]))
      {
        localObject1 = (Object[][])this.parray;
        this.m = (this.m == 0 ? 2048 : this.m);
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(16L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(12L, c("o=\tui)P"), c("I$?M\\H+!UI"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=*B@t{|\021\005o#"));
        paramy.a(localObject1[0].length, c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramy.a(0L, c("o=\tui)P"), c("&\006\tv=+B@t{|\021\005o#"));
        paramy.a(localObject1.length * localObject1[0].length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0)
        {
          i5 = 0;
          if (i9 == 0) {}
        }
        do
        {
          while (i5 < localObject1[0].length)
          {
            paramy.a(c("O\021\005i"), c("O\021\005i"));
            i5++;
          }
          i4++;
          if (i4 < localObject1.length) {
            break;
          }
          paramy.d(8);
          i5 = 0;
          if (i9 == 0) {
            break label8268;
          }
        } while (i9 != 0);
        while (i5 < localObject1[0].length)
        {
          i6 = 0;
          if (i9 != 0) {}
          while (i6 < localObject1.length)
          {
            Variant localVariant = new Variant(c("\016\005vxt\026;") + i6 + c("G9") + i5 + "]", 12, localObject1[i6][i5]);
            paramy.d(8);
            localVariant.c(paramy);
            i6++;
          }
          i5++;
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      else
      {
        i1 = 4;
        localObject1 = (Object[])this.parray;
        this.m = (this.m == 0 ? 2048 : this.m);
        paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
        paramy.a(16L, c("o=\tui)P"), c(""));
        paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
        paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
        paramy.a(12L, c("o=\tui)P"), c("I$?M\\H+!UI"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        i4 = 0;
        if (i9 != 0) {
          paramy.a(c("O\021\005i"), c("O\021\005i"));
        }
        do
        {
          i4++;
          if (i4 < localObject1.length) {
            break;
          }
          paramy.d(8);
          i5 = 0;
          if (i9 == 0) {
            break label8609;
          }
        } while (i9 != 0);
        while (i5 < localObject1.length)
        {
          localObject2 = new Variant(c("\016\005vxt\026;") + i5 + "]", 12, localObject1[i5]);
          paramy.d(8);
          ((Variant)localObject2).c(paramy);
          i5++;
        }
        paramy.c();
        if (i9 == 0) {
          break;
        }
      }
      break;
    case 8228: 
      if (i3 != 1)
      {
        localObject1 = cj.translate(cj.MULTI_DIMENSIONAL_ARRAYS_NOT_SUPPORTED, Integer.toString(this.vt));
        Log.a((String)localObject1);
        throw new RuntimeException((String)localObject1);
      }
      localObject1 = (Object[])this.parray;
      StructDesc localStructDesc = StructDesc.b(localObject1.getClass().getComponentType());
      this.m = (this.m == 0 ? 32 : this.m);
      paramy.d(this.m, c("o=\tui+T"), c("|$\005zio\020\005h"));
      paramy.a(StructDesc.getSize(localObject1.getClass().getComponentType()), c("o=\tui)P"), c(""));
      paramy.a(0L, c("o=\tui)P"), c("v\r\003pn"));
      paramy.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
      y localy = paramy.g();
      localObject2 = new Marshaller();
      int i7 = 0;
      if (i9 != 0)
      {
        ((Marshaller)localObject2).h = true;
        ((Marshaller)localObject2).a(localObject1[i7], localy);
        ((Marshaller)localObject2).h = false;
        ((Marshaller)localObject2).a(localObject1[i7], localy);
      }
      do
      {
        i7++;
        if (i7 < localObject1.length) {
          break;
        }
        byte[] arrayOfByte = localy.e();
        paramy.a(36L, c("o=\tui)P"), c("I$?IXY-2_"));
        paramy.a(1L, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(localObject1.length, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(0L, c("o=\tui)P"), c("&\r\006}n\026^"));
        paramy.a(1L, c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramy.a(c("O\021\005i"), c("O\021\005i"));
        paramy.a(1L, c("o=\tui)P"), c("{\016\t|sw\007\016o=j\003\004tt\005_"));
        paramy.a(arrayOfByte.length, c("o=\tui)P"), c("v\007\016|ir]"));
        paramy.a(c("O\021\005i"), c("O\021\005i"));
        paramy.a(paramy.f(), c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramy.a(92L, c("o=\tui)P"), c("v\007\016|ir"));
        StdObjRef.writeRecordCustomObjRef(localStructDesc, paramy);
        paramy.b(true);
        paramy.a(arrayOfByte.length, c("o=\tui)P"), c("v\007\016|ir]"));
        int i8 = localStructDesc.a();
        paramy.d(localStructDesc.a());
        paramy.a(arrayOfByte, 0, arrayOfByte.length, c("H\007\003to~B\002n{"));
      } while (i9 != 0);
      if (i9 == 0) {
        break;
      }
    default: 
      label8609:
      Log.a(cj.translate(cj.SENDING_ARRAYS_OF_TYPE_NOT_SUPPORTED_ERROR, Integer.toHexString(this.vt)));
      throw new RuntimeException(cj.translate(cj.SENDING_ARRAYS_OF_TYPE_NOT_SUPPORTED_EXCEPTION, Integer.toHexString(this.vt)));
    }
    label9165:
    paramy.c();
    return i1;
  }
  
  Object a(x paramx, int paramInt)
    throws IOException
  {
    long l1 = paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
    if (l1 == 0L) {
      return null;
    }
    return b(paramx, paramInt);
  }
  
  Object b(x paramx, int paramInt)
    throws IOException
  {
    int i24 = Dispatch.H;
    Object localObject1 = null;
    paramx.a(c("E\025\tixI#&^\\H0!B"));
    long l1 = paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
    if (l1 == 0L) {
      return null;
    }
    long l2 = paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021@3|v\025\001bn:SI%"));
    int i1 = paramx.f(c("O1(TON"), c("y&\tvn"));
    this.m = paramx.f(c("O1(TON"), c("|$\005zio\020\005h"));
    paramx.e(c("O./UZ"), c(""));
    paramx.e(c("O./UZ"), c("y.\017xvi"));
    paramx.a(c("I#&^\\H0!BHT+/U=o#\022i|c1\024ihy\026\023"));
    int i2 = paramx.b(c("O./UZ"), c("i\0044bm"));
    if ((i1 > 2) && (i2 != 12) && ((i1 != 3) || (i1 != 4))) {
      throw new RuntimeException(cj.ARRAYS_WITH_MORE_THAN_TWO_DIMENSIONS_NOT_SUPPORTED);
    }
    paramInt &= 0xFFFFBFFF;
    paramInt &= 0xFFFFDFFF;
    int i3 = (i2 & 0x8000) != 0 ? 1 : 0;
    i2 &= 0xFFFF7FFF;
    int i4;
    int i10;
    Object localObject5;
    int i14;
    int i15;
    int i9;
    label3477:
    int i20;
    label3796:
    int i16;
    Object localObject6;
    label4042:
    long l5;
    int i12;
    int i13;
    int i21;
    switch (i2)
    {
    case 16: 
      if (i1 == 1)
      {
        i4 = paramx.b(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\r\006}n\026^"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        if (paramInt == 17)
        {
          byte[] arrayOfByte = new byte[i4];
          i10 = 0;
          if (i24 != 0) {}
          do
          {
            do
            {
              arrayOfByte[i10] = ((byte)paramx.g(c("s\f\024#"), c("l\003\fnx")));
              i10++;
            } while (i10 < i4);
          } while (i24 != 0);
          localObject1 = arrayOfByte;
        }
        else
        {
          Log.a(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED_ERROR, Integer.toString(paramInt)));
          throw new RuntimeException(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED, Integer.toString(paramInt)));
        }
      }
      else
      {
        i4 = paramx.b(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        int i6 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        i10 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        if ((this.parray != null) || ((this.parray instanceof byte[][])))
        {
          localObject5 = (byte[][])this.parray;
          if (i24 == 0) {}
        }
        else
        {
          localObject5 = new byte[i6][i10];
        }
        i14 = 0;
        if (i24 != 0) {}
        while (i14 < i10)
        {
          i15 = 0;
          if (i24 != 0) {}
          while (i15 < i6)
          {
            localObject5[i15][i14] = ((byte)paramx.g(c("x\033\024~"), c("l\003\fnxA") + i15 + c("G9") + i14 + "]"));
            i15++;
          }
          i14++;
        }
        localObject1 = localObject5;
      }
      break;
    case 2: 
      if (i1 == 1)
      {
        i4 = paramx.b(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\r\006}n\026^"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        Object localObject2;
        if (paramInt == 2)
        {
          localObject2 = new short[i4];
          i10 = 0;
          if (i24 != 0) {}
          do
          {
            do
            {
              localObject2[i10] = paramx.c(c("s\f\024*+"), c("l\003\fnx"));
              i10++;
            } while (i10 < i4);
          } while (i24 != 0);
          localObject1 = localObject2;
        }
        else if (paramInt == 11)
        {
          localObject2 = new boolean[i4];
          i10 = 0;
          if (i24 != 0) {}
          do
          {
            do
            {
              localObject2[i10] = (paramx.c(c("s\f\024*+"), c("l\003\fnx")) == -1 ? 1 : 0);
              i10++;
            } while (i10 < i4);
          } while (i24 != 0);
          localObject1 = localObject2;
        }
        else
        {
          Log.a(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED_ERROR, Integer.toString(paramInt)));
          throw new RuntimeException(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED, Integer.toString(paramInt)));
        }
      }
      else
      {
        i4 = paramx.b(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        int i7 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        i10 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        if (paramInt == 2)
        {
          if ((this.parray != null) || ((this.parray instanceof short[][])))
          {
            localObject5 = (short[][])this.parray;
            if (i24 == 0) {}
          }
          else
          {
            localObject5 = new short[i7][i10];
          }
          i14 = 0;
          if (i24 != 0) {}
          while (i14 < i10)
          {
            i15 = 0;
            if (i24 != 0) {}
            while (i15 < i7)
            {
              localObject5[i15][i14] = paramx.c(c("s\f\024*+"), c("l\003\fnxA") + i15 + c("G9") + i14 + "]");
              i15++;
            }
            i14++;
          }
          localObject1 = localObject5;
        }
        else if (paramInt == 11)
        {
          if ((this.parray != null) || ((this.parray instanceof boolean[][])))
          {
            localObject5 = (boolean[][])this.parray;
            if (i24 == 0) {}
          }
          else
          {
            localObject5 = new boolean[i7][i10];
          }
          i14 = 0;
          if (i24 != 0) {}
          while (i14 < i10)
          {
            i15 = 0;
            if (i24 != 0) {}
            while (i15 < i7)
            {
              localObject5[i15][i14] = (paramx.c(c("s\f\024*+"), c("l\003\fnxA") + i15 + c("G9") + i14 + "]") == -1 ? 1 : 0);
              i15++;
            }
            i14++;
          }
          localObject1 = localObject5;
        }
        else
        {
          Log.a(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED_ERROR, Integer.toString(paramInt)));
          throw new RuntimeException(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED, Integer.toString(paramInt)));
        }
      }
      break;
    case 3: 
      if (i1 == 1)
      {
        i4 = paramx.b(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\r\006}n\026^"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        Object localObject3;
        if (paramInt == 4)
        {
          localObject3 = new float[i4];
          i10 = 0;
          if (i24 != 0) {}
          do
          {
            do
            {
              localObject3[i10] = paramx.j(c("|\016\017zi"), c("l\003\fnx"));
              i10++;
            } while (i10 < i4);
          } while (i24 != 0);
          localObject1 = localObject3;
        }
        else if ((paramInt == 3) || (paramInt == 22))
        {
          localObject3 = new int[i4];
          i10 = 0;
          if (i24 != 0) {}
          do
          {
            do
            {
              localObject3[i10] = paramx.b(c("s\f\024(/"), c("l\003\fnx"));
              i10++;
            } while (i10 < i4);
          } while (i24 != 0);
          localObject1 = localObject3;
        }
        else if (paramInt == 10)
        {
          localObject3 = new long[i4];
          i10 = 0;
          if (i24 != 0) {}
          do
          {
            do
            {
              localObject3[i10] = paramx.e(c("o=\tui)P"), c("l\003\fnx"));
              i10++;
            } while (i10 < i4);
          } while (i24 != 0);
          localObject1 = localObject3;
        }
        else
        {
          Log.a(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED_ERROR, Integer.toString(paramInt)));
          throw new RuntimeException(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED, Integer.toString(paramInt)));
        }
      }
      else
      {
        i4 = paramx.b(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        int i8 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        i10 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        if (paramInt == 4)
        {
          if ((this.parray != null) || ((this.parray instanceof float[][])))
          {
            localObject5 = (float[][])this.parray;
            if (i24 == 0) {}
          }
          else
          {
            localObject5 = new float[i8][i10];
          }
          i14 = 0;
          if (i24 != 0) {}
          while (i14 < i10)
          {
            i15 = 0;
            if (i24 != 0) {}
            while (i15 < i8)
            {
              localObject5[i15][i14] = paramx.j(c("|\016\017zi"), c("l\003\fnxA") + i15 + c("G9") + i14 + "]");
              i15++;
            }
            i14++;
          }
          localObject1 = localObject5;
        }
        else if ((paramInt == 3) || (paramInt == 22))
        {
          if ((this.parray != null) || ((this.parray instanceof int[][])))
          {
            localObject5 = (int[][])this.parray;
            if (i24 == 0) {}
          }
          else
          {
            localObject5 = new int[i8][i10];
          }
          i14 = 0;
          if (i24 != 0) {}
          while (i14 < i10)
          {
            i15 = 0;
            if (i24 != 0) {}
            while (i15 < i8)
            {
              localObject5[i15][i14] = paramx.b(c("SV"), c("l\003\fnxA") + i15 + c("G9") + i14 + "]");
              i15++;
            }
            i14++;
          }
          localObject1 = localObject5;
        }
        else if (paramInt == 10)
        {
          if ((this.parray != null) || ((this.parray instanceof long[][])))
          {
            localObject5 = (long[][])this.parray;
            if (i24 == 0) {}
          }
          else
          {
            localObject5 = new long[i8][i10];
          }
          i14 = 0;
          if (i24 != 0) {}
          while (i14 < i10)
          {
            i15 = 0;
            if (i24 != 0) {}
            while (i15 < i8)
            {
              localObject5[i15][i14] = paramx.b(c("SV"), c("l\003\fnxA") + i15 + c("G9") + i14 + "]");
              i15++;
            }
            i14++;
          }
          localObject1 = localObject5;
        }
        else
        {
          Log.a(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED_ERROR, Integer.toString(paramInt)));
          throw new RuntimeException(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED, Integer.toString(paramInt)));
        }
      }
      break;
    case 20: 
      if (i1 == 1)
      {
        i4 = paramx.b(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\r\006}n\026^"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        Object localObject4;
        if (paramInt == 5)
        {
          if ((this.parray != null) || ((this.parray instanceof double[])))
          {
            localObject4 = (double[])this.parray;
            if (i24 == 0) {}
          }
          else
          {
            localObject4 = new double[i4];
          }
          i10 = 0;
          if (i24 != 0) {}
          do
          {
            do
            {
              localObject4[i10] = paramx.k(c("~\r\025yq"), c("l\003\fnx"));
              i10++;
            } while (i10 < i4);
          } while (i24 != 0);
          localObject1 = localObject4;
        }
        else if (paramInt == 7)
        {
          localObject4 = new Date[i4];
          i10 = 0;
          if (i24 != 0) {}
          do
          {
            do
            {
              localObject4[i10] = paramx.g(c("l\003\fnx"));
              i10++;
            } while (i10 < i4);
          } while (i24 != 0);
          localObject1 = localObject4;
        }
        else if ((paramInt == 6) || (paramInt == 10))
        {
          localObject4 = new long[i4];
          i10 = 0;
          if (i24 != 0) {}
          do
          {
            do
            {
              localObject4[i10] = paramx.i(c("s\f\024-)"), c("l\003\fnx"));
              i10++;
            } while (i10 < i4);
          } while (i24 != 0);
          localObject1 = localObject4;
        }
        else
        {
          Log.a(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED_ERROR, Integer.toString(paramInt)));
          throw new RuntimeException(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED, Integer.toString(paramInt)));
        }
      }
      else
      {
        i4 = paramx.b(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        i9 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        i10 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        if (paramInt == 5)
        {
          if ((this.parray != null) || ((this.parray instanceof double[][])))
          {
            localObject5 = (double[][])this.parray;
            if (i24 == 0) {}
          }
          else
          {
            localObject5 = new double[i9][i10];
          }
          i14 = 0;
          if (i24 != 0) {}
          while (i14 < i10)
          {
            i15 = 0;
            if (i24 != 0) {}
            while (i15 < i9)
            {
              localObject5[i15][i14] = paramx.k(c("~\r\025yq"), c("l\003\fnxA") + i15 + c("G9") + i14 + "]");
              i15++;
            }
            i14++;
          }
          localObject1 = localObject5;
        }
        else if (paramInt == 7)
        {
          localObject5 = new Date[i9][i10];
          i14 = 0;
          if (i24 != 0) {}
          while (i14 < i10)
          {
            i15 = 0;
            if (i24 != 0) {}
            while (i15 < i9)
            {
              localObject5[i15][i14] = paramx.g(c("l\003\fnxA") + i15 + c("G9") + i14 + "]");
              i15++;
            }
            i14++;
          }
          localObject1 = localObject5;
        }
        else if ((paramInt == 6) || (paramInt == 10))
        {
          localObject5 = new long[i9][i10];
          i14 = 0;
          if (i24 != 0) {}
          while (i14 < i10)
          {
            i15 = 0;
            if (i24 != 0) {}
            while (i15 < i9)
            {
              localObject5[i15][i14] = paramx.i(c("v\r\016|"), c("l\003\fnxA") + i15 + c("G9") + i14 + "]");
              i15++;
            }
            i14++;
          }
          localObject1 = localObject5;
        }
        else
        {
          Log.a(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED_ERROR, Integer.toString(paramInt)));
          throw new RuntimeException(cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED, Integer.toString(paramInt)));
        }
      }
      break;
    case 8: 
      if (i1 == 1)
      {
        paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\r\006}n\026^"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        long l3 = paramx.e(c("O./UZ"), c("&\f\022;xv\007\r~sn\021^"));
        long[] arrayOfLong1 = new long[(int)l3];
        localObject5 = new String[(int)l3];
        i14 = 0;
        if (i24 != 0) {
          arrayOfLong1[i14] = paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        }
        do
        {
          i14++;
          if (i14 < l3) {
            break;
          }
          i15 = 0;
          if (i24 == 0) {
            break label3477;
          }
        } while (i24 != 0);
        break label3477;
        if (arrayOfLong1[i15] != 0L) {}
        do
        {
          localObject5[i15] = paramx.d(c("l\003\fnx"));
          i15++;
          if (i15 < l3) {
            break;
          }
        } while (i24 != 0);
        localObject1 = localObject5;
      }
      else
      {
        int i5 = (int)paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        i9 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
        int i11 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        localObject5 = new long[i5];
        i14 = 0;
        if (i24 != 0) {
          localObject5[i14] = paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^@") + i14 + "]");
        }
        String[][] arrayOfString;
        int i17;
        int i19;
        do
        {
          i14++;
          if (i14 < i5) {
            break;
          }
          arrayOfString = new String[i9][i11];
          i17 = 0;
          i19 = 0;
          i20 = 0;
          if (i24 == 0) {
            break label3796;
          }
        } while (i24 != 0);
        break label3796;
        if (localObject5[i20] != 0L) {}
        do
        {
          arrayOfString[i17][i19] = paramx.d(c("l\003\fnxA") + i17 + "," + i19 + "]");
          i17++;
          if (i17 >= i9)
          {
            i17 = 0;
            i19++;
          }
          i20++;
          if (i20 < i5) {
            break;
          }
        } while (i24 != 0);
        localObject1 = arrayOfString;
      }
      break;
    case 9: 
    case 13: 
      if (i1 == 1)
      {
        long l4 = paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        if (i3 != 0) {
          paramx.a(c("O\027\t"), c("O\027\t"));
        }
        l4 = paramx.e(c("O./UZ"), c("&\f\022;xv\007\r~sn\021^"));
        paramx.e(c("o=\tui)P"), c("&\r\006}n\026^"));
        paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
        long[] arrayOfLong2 = new long[(int)l4];
        localObject5 = new Object[(int)l4];
        i14 = 0;
        if (i24 != 0) {
          arrayOfLong2[i14] = paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
        }
        do
        {
          i14++;
          if (i14 < l4) {
            break;
          }
          i16 = 0;
          if (i24 == 0) {
            break label4042;
          }
        } while (i24 != 0);
        while (i16 < l4)
        {
          if (arrayOfLong2[i16] != 0L)
          {
            StdObjRef localStdObjRef2 = new StdObjRef(false, paramx);
            localObject6 = z.a(localStdObjRef2);
            localObject5[i16] = (localObject6 == null ? localStdObjRef2 : localObject6);
          }
          i16++;
        }
        localObject1 = localObject5;
      }
      else
      {
        String str1 = cj.translate(cj.TWO_DIMENSIONAL_ARRAYS_OF_TYPE_NOT_SUPPORTED, Integer.toString(paramInt));
        Log.a(str1);
        throw new RuntimeException(str1);
      }
      break;
    case 12: 
      l5 = paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
      paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
      i12 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
      paramx.e(c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
      i13 = 0;
      if (i1 >= 2)
      {
        i13 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
      }
      i14 = 0;
      if (i1 >= 3)
      {
        i14 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=(B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=(B\017}{i\007\024%"));
      }
      i16 = 0;
      if (i1 >= 4)
      {
        i16 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=)B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=)B\017}{i\007\024%"));
      }
      paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
      int i18 = 0;
      if (i24 != 0) {}
      while (i18 < l5)
      {
        paramx.a(4, c("=7\023~o="));
        i18++;
      }
      if (l5 > 0L) {
        paramx.d(8);
      }
      if (i1 == 1)
      {
        localObject6 = new Object[i12];
        i20 = 0;
        if (i24 != 0) {}
        while (i20 < l5)
        {
          Variant localVariant1 = new Variant(c("\016\005vxt\026;") + i20 + "]");
          localVariant1.a(paramx);
          localObject6[i20] = localVariant1.getVARIANT();
          if (i20 != l5 - 1L) {
            paramx.d(8);
          }
          i20++;
        }
        localObject1 = localObject6;
      }
      else if (i1 == 2)
      {
        localObject6 = new Object[i12][i13];
        i20 = 0;
        if (i24 != 0) {}
        while (i20 < i13)
        {
          i21 = 0;
          if (i24 != 0) {}
          while (i21 < i12)
          {
            Variant localVariant2 = new Variant(c("\016\005vxt\026;") + i21 + "," + i20 + "]");
            localVariant2.a(paramx);
            localObject6[i21][i20] = localVariant2.getVARIANT();
            if ((i21 != i12 - 1) || (i20 != i13 - 1)) {
              paramx.d(8);
            }
            i21++;
          }
          i20++;
        }
        localObject1 = localObject6;
      }
      else
      {
        int i22;
        if (i1 == 3)
        {
          localObject6 = new Object[i12][i13][i14];
          i20 = 0;
          if (i24 != 0) {}
          while (i20 < i14)
          {
            i21 = 0;
            if (i24 != 0) {}
            while (i21 < i13)
            {
              i22 = 0;
              if (i24 != 0) {}
              while (i22 < i12)
              {
                Variant localVariant3 = new Variant(c("\016\005vxt\026;") + i22 + "," + i21 + "," + i20 + "]");
                localVariant3.a(paramx);
                localObject6[i22][i21][i20] = localVariant3.getVARIANT();
                if ((i22 != i12 - 1) || (i21 != i13 - 1) || (i20 != i14 - 1)) {
                  paramx.d(8);
                }
                i22++;
              }
              i21++;
            }
            i20++;
          }
          localObject1 = localObject6;
        }
        else if (i1 == 4)
        {
          localObject6 = new Object[i12][i13][i14][i16];
          i20 = 0;
          if (i24 != 0) {}
          while (i20 < i16)
          {
            i21 = 0;
            if (i24 != 0) {}
            while (i21 < i14)
            {
              i22 = 0;
              if (i24 != 0) {}
              while (i22 < i13)
              {
                int i23 = 0;
                if (i24 != 0) {}
                while (i23 < i12)
                {
                  Variant localVariant4 = new Variant(c("\016\005vxt\026;") + i23 + "," + i22 + "," + i21 + "]");
                  localVariant4.a(paramx);
                  localObject6[i23][i22][i21][i20] = localVariant4.getVARIANT();
                  if ((i23 != i12 - 1) || (i22 != i13 - 1) || (i21 != i14 - 1) || (i20 != i16 - 1)) {
                    paramx.d(8);
                  }
                  i23++;
                }
                i22++;
              }
              i21++;
            }
            i20++;
          }
          localObject1 = localObject6;
        }
      }
      break;
    case 36: 
      l5 = paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
      paramx.e(c("o=\tui)P"), c("&\022\024i=s\006^"));
      i12 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=*B\016i=\016\005vxt\026\023%"));
      paramx.e(c("o=\tui)P"), c("&\006\tv=*B\017}{i\007\024%"));
      i13 = 0;
      if (i1 == 2)
      {
        i13 = (int)paramx.e(c("o=\tui)P"), c("&\006\tv=+B\016i=\016\005vxt\026\023%"));
        paramx.e(c("o=\tui)P"), c("&\006\tv=+B\017}{i\007\024%"));
      }
      paramx.e(c("o=\tui)P"), c("&\f\022;xv\007\r~sn\021^"));
      i14 = 0;
      if (i24 != 0) {
        paramx.a(4, c("=7\023~o="));
      }
      Uuid localUuid;
      do
      {
        i14++;
        if (i14 < l5) {
          break;
        }
        paramx.e(c("o=\tui)P"), c("j\003\004tt\005@}q{\005"));
        paramx.e(c("o=\tui)P"), c("h\007\003to~B\f~s}\026\b"));
        paramx.e(c("o=\tui)P"), c("O\021\005i"));
        paramx.e(c("o=\tui)P"), c("J\026\022;T^"));
        paramx.e(c("o=\tui)P"), c("V\007\016|ir"));
        StdObjRef localStdObjRef1 = new StdObjRef(false, false, paramx);
        localUuid = localStdObjRef1.o();
      } while (i24 != 0);
      if (localUuid == null) {
        throw new RuntimeException(cj.ERROR_READING_CUSTOM_MARSHALLED_IRECORDINFO);
      }
      localObject6 = StructDesc.a(localUuid).targetClass;
      if (localObject6 == null)
      {
        Log.a(cj.translate(cj.UNKNOWN_STRUCT_UUID, localUuid));
        throw new RuntimeException(cj.translate(cj.UNKNOWN_STRUCT_UUID, localUuid));
      }
      paramx.d(4);
      paramx.e(c("o=\tui)P"), c("H\007\003to~B,~s}\026\b"));
      Marshaller localMarshaller = new Marshaller(paramx);
      localObject1 = Array.newInstance((Class)localObject6, i12);
      i21 = 0;
      if (i24 != 0) {}
      while (i21 < i12)
      {
        localMarshaller.h = true;
        Object localObject7 = localMarshaller.a((Class)localObject6, null);
        localMarshaller.h = false;
        localObject7 = localMarshaller.a((Class)localObject6, localObject7);
        Array.set(localObject1, i21, localObject7);
        i21++;
      }
      break;
    case 4: 
    case 5: 
    case 6: 
    case 7: 
    case 10: 
    case 11: 
    case 14: 
    case 15: 
    case 17: 
    case 18: 
    case 19: 
    case 21: 
    case 22: 
    case 23: 
    case 24: 
    case 25: 
    case 26: 
    case 27: 
    case 28: 
    case 29: 
    case 30: 
    case 31: 
    case 32: 
    case 33: 
    case 34: 
    case 35: 
    default: 
      String str2 = cj.translate(cj.ARRAYS_OF_TYPE_NOT_SUPPORTED, Integer.toString(i2));
      Log.a(str2);
      throw new RuntimeException(str2);
    }
    paramx.c();
    paramx.c();
    return localObject1;
  }
  
  private String c()
  {
    switch (this.vt)
    {
    case 0: 
    case 1: 
      return null;
    case 2: 
      return this.iVal + "";
    case 16386: 
      return this.piVal[0] + "";
    case 3: 
    case 19: 
      return this.lVal + "";
    case 16387: 
    case 16403: 
      return this.plVal[0] + "";
    case 22: 
      return this.intVal + "";
    case 16406: 
      return this.pintVal[0] + "";
    case 4: 
      return this.fltVal + "";
    case 16388: 
      return this.pfltVal[0] + "";
    case 5: 
      return this.dblVal + "";
    case 16389: 
      return this.pdblVal[0] + "";
    case 6: 
      return this.cyVal + "";
    case 16390: 
      return this.pcyVal[0] + "";
    case 7: 
      return this.date + "";
    case 16391: 
      return this.pdate[0] + "";
    case 8: 
      return this.bstrVal;
    case 16392: 
      return this.pbstrVal[0];
    case 10: 
      return this.returnValue + "";
    case 16394: 
      return this.preturnValue[0] + "";
    case 11: 
      return this.bool + "";
    case 16395: 
      return this.pbool[0] + "";
    case 17: 
      return this.bVal + "";
    case 16401: 
      return this.pbVal[0] + "";
    case 14: 
      return this.decVal + "";
    case 16398: 
      return this.pdecVal[0] + "";
    case 9: 
    case 13: 
      return this.pdispVal + "";
    case 16393: 
    case 16397: 
      return this.ppdispVal[0] + "";
    }
    throw new IllegalArgumentException(cj.translate(cj.CANNOT_CONVERT_FROM_COM_VT_TO, Integer.toString(this.vt), n));
  }
  
  Number a(Class paramClass)
  {
    switch (this.vt)
    {
    case 0: 
    case 1: 
      return new Integer(0);
    case 2: 
      return new Short(this.iVal);
    case 16386: 
      return new Short(this.piVal[0]);
    case 3: 
    case 19: 
      return new Integer(this.lVal);
    case 16387: 
    case 16403: 
      return new Integer(this.plVal[0]);
    case 22: 
      return new Integer(this.intVal);
    case 16406: 
      return new Integer(this.pintVal[0]);
    case 4: 
      return new Float(this.fltVal);
    case 16388: 
      return new Float(this.pfltVal[0]);
    case 5: 
      return new Double(this.dblVal);
    case 16389: 
      return new Double(this.pdblVal[0]);
    case 6: 
      return new Long(this.cyVal);
    case 16390: 
      return new Long(this.pcyVal[0]);
    case 10: 
      return new Long(this.returnValue);
    case 16394: 
      return new Long(this.preturnValue[0]);
    case 11: 
      return new Integer(this.bool ? 1 : 0);
    case 16395: 
      return new Integer(this.pbool[0] != 0 ? 1 : 0);
    case 16: 
      return new Byte(this.bVal);
    case 16400: 
      return new Byte(this.pbVal[0]);
    case 17: 
      return new Byte(this.bVal);
    case 16401: 
      return new Byte(this.pbVal[0]);
    case 8: 
    case 16392: 
      return null;
    case 14: 
      return this.decVal;
    case 16398: 
      return this.pdecVal[0];
    }
    throw new IllegalArgumentException(cj.translate(cj.CANNOT_CONVERT_FROM_COM_VT_TO, Integer.toString(this.vt), n));
  }
  
  Object b(Class paramClass)
  {
    Object localObject1;
    if ((isArray()) && (paramClass.isArray()))
    {
      Log.log(3, c("S\021@zoh\003\031"));
      localObject1 = getVARIANT();
      if (localObject1.getClass() == paramClass) {
        return localObject1;
      }
      if (!paramClass.getComponentType().isPrimitive())
      {
        localObject1 = coerceArray(localObject1, paramClass.getComponentType());
        if (localObject1 != null) {
          return localObject1;
        }
        throw new IllegalArgumentException(cj.translate(cj.CANNOT_CONVERT_FROM_COM_VT_TO, Integer.toString(this.vt), n));
      }
    }
    if ((isByRef()) && (paramClass.isArray()))
    {
      Log.log(3, c("S\021@ydh\007\006;|h\020\001b"));
      if ((paramClass == A) && (this.vt == 16395)) {
        return this.pbool;
      }
      if ((paramClass == r) && (this.vt == 16392)) {
        return this.pbstrVal;
      }
      if ((paramClass == s) && (this.vt == 16391)) {
        return this.pdate;
      }
      if ((paramClass == t) && (this.vt == 16401)) {
        return this.pbVal;
      }
      if ((paramClass == u) && (this.vt == 16386)) {
        return this.piVal;
      }
      if ((paramClass == v) && (this.vt == 16386)) {
        return this.piVal;
      }
      if ((paramClass == w) && (this.vt == 16387)) {
        return this.plVal;
      }
      if ((paramClass == w) && (this.vt == 16403)) {
        return this.plVal;
      }
      if ((paramClass == x) && (this.vt == 16390)) {
        return this.pcyVal;
      }
      if ((paramClass == y) && (this.vt == 16388)) {
        return this.pfltVal;
      }
      if ((paramClass == z) && (this.vt == 16389)) {
        return this.pdblVal;
      }
      if ((paramClass == A) && (this.vt == 16395)) {
        return this.pbool;
      }
      if ((!paramClass.getComponentType().isPrimitive()) && (this.vt == 16396))
      {
        localObject1 = coerceArray(this.pvarVal, paramClass.getComponentType());
        if (localObject1 != null) {
          return localObject1;
        }
      }
      else if ((paramClass == q) && (this.vt == 16396))
      {
        return this.pvarVal;
      }
      throw new IllegalArgumentException(cj.translate(cj.CANNOT_CONVERT_FROM_COM_VT_TO, Integer.toString(this.vt), n));
    }
    if (this.vt == 12)
    {
      localObject1 = this.pvarVal[0];
      return ((Variant)localObject1).b(paramClass);
    }
    if (this.vt == 16396)
    {
      localObject1 = this.pvarVal[0];
      return ((Variant)localObject1).b(paramClass);
    }
    try
    {
      if (paramClass.equals(n)) {
        return c();
      }
      if (paramClass.equals(o))
      {
        if (this.vt == 7) {
          return this.date;
        }
        if (this.vt == 16391) {
          return this.pdate[0];
        }
        try
        {
          if (this.vt == 8) {
            return B.parse(this.bstrVal);
          }
          if (this.vt == 16392) {
            return B.parse(this.pbstrVal[0]);
          }
        }
        catch (ParseException localParseException)
        {
          throw new IllegalArgumentException(localParseException + "");
        }
        throw new IllegalArgumentException(cj.translate(cj.CANNOT_CONVERT_FROM_COM_VT_TO, Integer.toString(this.vt), n));
      }
      Number localNumber;
      if (paramClass == Character.TYPE)
      {
        if (this.vt == 8)
        {
          if (this.bstrVal.length() != 1) {
            throw new IllegalArgumentException(cj.CAN_ONLY_CONVERT_SINGLE_ELEMENT_STR_TO_CHARACTER);
          }
          return new Character(this.bstrVal.charAt(0));
        }
        if (this.vt == 16392)
        {
          if (this.pbstrVal[0].length() != 1) {
            throw new IllegalArgumentException(cj.CAN_ONLY_CONVERT_SINGLE_ELEMENT_STR_TO_CHARACTER);
          }
          return new Character(this.pbstrVal[0].charAt(0));
        }
        localNumber = a(paramClass);
        return localNumber == null ? null : new Character((char)localNumber.intValue());
      }
      if (paramClass == Boolean.TYPE)
      {
        if (this.vt == 11) {
          return new Boolean(this.bool);
        }
        if (this.vt == 16395) {
          return new Boolean(this.pbool[0]);
        }
        if (this.vt == 8)
        {
          if (this.bstrVal.equalsIgnoreCase(c("n\020\025~"))) {
            return new Boolean(true);
          }
          if (this.bstrVal.equalsIgnoreCase(c("|\003\fhx"))) {
            return new Boolean(false);
          }
          throw new IllegalArgumentException(cj.translate(cj.CANNOT_CONVERT_FROM_COM_VT_TO, Integer.toString(this.vt), (D == null ? (Variant.D = b(c("p\003\026z3v\003\016|3X\r\017wx{\f"))) : D).getName()));
        }
        if (this.vt == 16392)
        {
          if (this.pbstrVal[0].equalsIgnoreCase(c("n\020\025~"))) {
            return new Boolean(true);
          }
          if (this.pbstrVal[0].equalsIgnoreCase(c("|\003\fhx"))) {
            return new Boolean(false);
          }
          throw new IllegalArgumentException(cj.translate(cj.CANNOT_CONVERT_FROM_COM_VT_TO, Integer.toString(this.vt), (D == null ? (Variant.D = b(c("p\003\026z3v\003\016|3X\r\017wx{\f"))) : D).getName()));
        }
        localNumber = a(paramClass);
        return localNumber == null ? null : new Boolean(localNumber.intValue() != 0);
      }
      if (paramClass == Byte.TYPE)
      {
        localNumber = a(paramClass);
        localNumber = (localNumber == null) && (this.vt == 8) ? a(this.bstrVal) : localNumber;
        localNumber = (localNumber == null) && (this.vt == 16392) ? a(this.pbstrVal[0]) : localNumber;
        return localNumber == null ? null : new Byte(localNumber.byteValue());
      }
      if (paramClass == Short.TYPE)
      {
        localNumber = a(paramClass);
        localNumber = (localNumber == null) && (this.vt == 8) ? a(this.bstrVal) : localNumber;
        localNumber = (localNumber == null) && (this.vt == 16392) ? a(this.pbstrVal[0]) : localNumber;
        return localNumber == null ? null : new Short(localNumber.shortValue());
      }
      if (paramClass == Integer.TYPE)
      {
        localNumber = a(paramClass);
        localNumber = (localNumber == null) && (this.vt == 8) ? a(this.bstrVal) : localNumber;
        localNumber = (localNumber == null) && (this.vt == 16392) ? a(this.pbstrVal[0]) : localNumber;
        return localNumber == null ? null : new Integer(localNumber.intValue());
      }
      if (paramClass == Long.TYPE)
      {
        localNumber = a(paramClass);
        localNumber = (localNumber == null) && (this.vt == 8) ? a(this.bstrVal) : localNumber;
        localNumber = (localNumber == null) && (this.vt == 16392) ? a(this.pbstrVal[0]) : localNumber;
        return localNumber == null ? null : new Long(localNumber.longValue());
      }
      if (paramClass == (E == null ? (Variant.E = b(c("p\003\026z3w\003\024s3X\013\007_xy\013\rzq"))) : E))
      {
        localNumber = a(paramClass);
        localNumber = (localNumber == null) && (this.vt == 8) ? new BigDecimal(this.bstrVal) : localNumber;
        localNumber = (localNumber == null) && (this.vt == 16392) ? new BigDecimal(this.pbstrVal[0]) : localNumber;
        return localNumber == null ? null : new BigDecimal(localNumber + "");
      }
      if (paramClass == Float.TYPE)
      {
        localNumber = a(paramClass);
        localNumber = (localNumber == null) && (this.vt == 8) ? a(this.bstrVal) : localNumber;
        localNumber = (localNumber == null) && (this.vt == 16392) ? a(this.pbstrVal[0]) : localNumber;
        return localNumber == null ? null : new Float(localNumber.floatValue());
      }
      if (paramClass == Double.TYPE)
      {
        localNumber = a(paramClass);
        localNumber = (localNumber == null) && (this.vt == 8) ? a(this.bstrVal) : localNumber;
        localNumber = (localNumber == null) && (this.vt == 16392) ? a(this.pbstrVal[0]) : localNumber;
        return localNumber == null ? null : new Double(localNumber.doubleValue());
      }
    }
    catch (NumberFormatException localNumberFormatException)
    {
      throw new IllegalArgumentException(cj.translate(cj.CANNOT_CONVERT_FROM_COM_VT_TO, Integer.toString(this.vt), n));
    }
    Object localObject2 = getVARIANT();
    if ((localObject2 != null) && (!paramClass.isArray()) && ((this.vt & 0x4000) != 0) && ((this.vt & 0x2000) == 0) && (localObject2.getClass().isArray())) {
      localObject2 = Array.get(localObject2, 0);
    }
    return localObject2;
  }
  
  public static Object coerceArray(Object paramObject, String paramString)
  {
    if (paramObject == null) {
      return paramObject;
    }
    if (paramString.endsWith(c("A?"))) {
      paramString = paramString.substring(0, paramString.length() - 2);
    }
    Class localClass = null;
    try
    {
      localClass = Class.forName(paramString);
    }
    catch (Exception localException)
    {
      Log.a(cj.translate(cj.CANNOT_FIND_CLASS_TO_BUILD_RETURNED_ARRAY, paramString, localException));
      return null;
    }
    return coerceArray(paramObject, localClass);
  }
  
  public static Object coerceArray(Object paramObject, Class paramClass)
  {
    int i2 = Dispatch.H;
    if (paramObject == null) {
      return paramObject;
    }
    if (paramObject.getClass() != (F == null ? (Variant.F = b(c("A.\003tp4\016\tu|hL\nrsn\007\007i|44\001it{\f\024 "))) : F)) {
      if (paramClass.isAssignableFrom(paramObject.getClass().getComponentType())) {
        return paramObject;
      }
    }
    InterfaceDesc localInterfaceDesc = InterfaceDesc.a(paramClass);
    Constructor localConstructor = null;
    if (localInterfaceDesc != null) {
      try
      {
        localConstructor = localInterfaceDesc.b.getConstructor(new Class[] { G == null ? (Variant.G = b(c(""))) : G });
      }
      catch (NoSuchMethodException localNoSuchMethodException) {}
    }
    Object localObject1 = Array.newInstance(paramClass, Array.getLength(paramObject));
    int i1 = 0;
    if (i2 != 0) {}
    do
    {
      do
      {
        Object localObject2 = Array.get(paramObject, i1);
        if ((localObject2 instanceof Variant)) {
          localObject2 = ((Variant)localObject2).getVARIANT();
        }
        if ((localConstructor != null) && (!paramClass.isInstance(localObject2)) && ((localObject2 instanceof StdObjRef))) {
          try
          {
            localObject2 = localConstructor.newInstance(new Object[] { localObject2 });
          }
          catch (InstantiationException localInstantiationException) {}catch (IllegalAccessException localIllegalAccessException) {}catch (InvocationTargetException localInvocationTargetException) {}
        }
        Array.set(localObject1, i1, localObject2);
        i1++;
      } while (i1 < Array.getLength(paramObject));
    } while (i2 != 0);
    return localObject1;
  }
  
  Number a(String paramString)
  {
    if (paramString.indexOf('.') != -1) {
      return new Double(paramString);
    }
    return new Long(paramString);
  }
  
  public String[] getBSTRArray()
  {
    return (String[])b(H == null ? (Variant.H = b(c("A.\nzk{L\fzs}L3oos\f\007 "))) : H);
  }
  
  public Object[] getVARIANTArray()
  {
    return (Object[])b(I == null ? (Variant.I = b(c("A.\nzk{L\fzs}L/yw\001\024 "))) : I);
  }
  
  public short[] getI2Array()
  {
    return (short[])b(J == null ? (Variant.J = b(c("A1"))) : J);
  }
  
  public int[] getI4Array()
  {
    return (int[])b(K == null ? (Variant.K = b(c("A+"))) : K);
  }
  
  public boolean[] getBOOLArray()
  {
    return (boolean[])b(L == null ? (Variant.L = b(c("A8"))) : L);
  }
  
  public long[] getCYArray()
  {
    return (long[])b(M == null ? (Variant.M = b(c("A("))) : M);
  }
  
  public Date[] getDATEArray()
  {
    return (Date[])b(N == null ? (Variant.N = b(c("A.\nzk{L\025otvL$ziY"))) : N);
  }
  
  public BigDecimal[] getDECIMALArray()
  {
    return (BigDecimal[])b(O == null ? (Variant.O = b(c("A.\nzk{L\rzirL\"rz^\007\003rp{\016["))) : O);
  }
  
  public Object[] getDISPATCHArray()
  {
    return (Object[])b(I == null ? (Variant.I = b(c("A.\nzk{L\fzs}L/yw\001\024 "))) : I);
  }
  
  public byte[] getI1Array()
  {
    return (byte[])b(P == null ? (Variant.P = b(c("A "))) : P);
  }
  
  public int[] getINTArray()
  {
    return (int[])b(K == null ? (Variant.K = b(c("A+"))) : K);
  }
  
  public float[] getR4Array()
  {
    return (float[])b(Q == null ? (Variant.Q = b(c("A$"))) : Q);
  }
  
  public double[] getR8Array()
  {
    return (double[])b(R == null ? (Variant.R = b(c("A&"))) : R);
  }
  
  public byte[] getUI1Array()
  {
    return (byte[])b(P == null ? (Variant.P = b(c("A "))) : P);
  }
  
  public int[] getUI4Array()
  {
    return (int[])b(K == null ? (Variant.K = b(c("A+"))) : K);
  }
  
  public Object[] getUNKNOWNArray()
  {
    return (Object[])b(I == null ? (Variant.I = b(c("A.\nzk{L\fzs}L/yw\001\024 "))) : I);
  }
  
  static Class b(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  private static String c(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      98[96] = ((char)(0x1B ^ 0x1D));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Variant
 * JD-Core Version:    0.7.0.1
 */