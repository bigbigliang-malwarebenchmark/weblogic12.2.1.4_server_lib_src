package com.linar.jintegra;

import com.linar.spi.DES;
import com.linar.spi.Manager;
import java.io.ByteArrayInputStream;
import java.io.IOException;

public class PureAuth
  extends c
{
  private boolean a;
  private byte[] b;
  private String c;
  String d;
  private AuthInfo e;
  private static final long f = 1L;
  private static final long g = 2L;
  static final long h = 3L;
  static final long i = 1L;
  static final long j = 2L;
  static final long k = 4L;
  private static final long l = 16L;
  private static final long m = 32L;
  private static final long n = 64L;
  private static final long o = 128L;
  private static final long p = 256L;
  private static final long q = 512L;
  static final long r = 4096L;
  static final long s = 8192L;
  private static final long t = 16384L;
  private static final long u = 32768L;
  static final long v = 65536L;
  static final long w = 33554432L;
  static Class x;
  static Class y;
  
  public byte[] ntResponseForChallenge(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = this.e.e();
    return arrayOfByte == null ? new byte[0] : a(paramArrayOfByte, arrayOfByte);
  }
  
  byte[] a(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = this.e.f();
    return arrayOfByte == null ? new byte[0] : a(paramArrayOfByte, arrayOfByte);
  }
  
  void a(x paramx)
    throws IOException
  {
    paramx.a(b("\bXWCkE'\036vl\024}[rv\016/_Xk\025XRHq\032sV\004B]fKYw\"q_Aj\030\\c\rQ)Ks\rE\022i["));
    paramx.a(7, b(".nYC~\trLH"));
    paramx.d(4);
    paramx.e(b("\bXWCkN5"), b("0bM^~\032bjTo\030'\026^w\022rRI?\037b\036nW<KrhQ:B\036\020?O"));
    int i1 = paramx.f(b("\bXWCkL1"), b("\031hSLv\023'RHq\032sV"));
    paramx.f(b("\bXWCkL1"), b("\020fF\r{\022j_Dq]k[Cx\to"));
    paramx.e(b("\bXWCkN5"), b("\031hSLv\023'QKy\016bJ"));
    long l1 = paramx.e(b("\bXWCkN5"), b("3bYB|\024fJH?;k_Jl"));
    this.a = ((l1 & 0x2) != 0L);
    this.b = new byte[8];
    paramx.a(this.b, b("\036o_As\030iYH"));
    this.c = paramx.a(i1, b("\031hSLv\023"));
    paramx.c();
  }
  
  void b(y paramy)
    throws IOException
  {
    byte[] arrayOfByte1 = this.e.e();
    byte[] arrayOfByte2 = this.e.f();
    byte[] arrayOfByte3 = new byte[0];
    byte[] arrayOfByte4 = arrayOfByte1 == null ? arrayOfByte3 : a(this.b, arrayOfByte1);
    byte[] arrayOfByte5 = arrayOfByte2 == null ? arrayOfByte3 : a(this.b, arrayOfByte2);
    String str1 = this.e.a();
    String str2 = this.e.b();
    String str3 = AuthInfo.d();
    paramy.a(b("\bXWCkE'\036vl\024}[rv\016/_Xk\025XRHq\032sV\004B]fKYw\"q_Aj\030\\c\rQ)Ks\rE\022i["));
    int i1 = 64;
    int i2 = i1 + str1.length() * 2;
    int i3 = this.a ? str2.length() : str2.length() * 2;
    int i4 = i2 + i3;
    int i5 = i4 + str3.length() * 2;
    int i6 = i5 + arrayOfByte5.length;
    int i7 = i6 + arrayOfByte4.length;
    paramy.a(b("3Sr`L.W"), b(".nYC~\trLH"));
    paramy.e(0, b("\bXWCkE"), b("\016nY\rk\030uSDq\034sQ_"));
    paramy.a(3L, b("\bXWCkN5"), b("0bM^~\032bjTo\030'\026cK1Ja`Z.TjZ\"Sg}Z\"FkyW8Ijd\\<S{\004"));
    paramy.d(arrayOfByte5.length, b("\bXWCkL1"), b("1J\036_z\016wQCl\030'RHq\032sV\022"));
    paramy.d(arrayOfByte5.length, b("\bXWCkL1"), b("1J\036_z\016wQCl\030'RHq\032sV\022"));
    paramy.a(i5, b("\bXWCkN5"), b("1J\036z\016wQCl\030'QKy\016bJ"));
    paramy.d(arrayOfByte4.length, b("\bXWCkL1"), b("3S\036_z\016wQCl\030'RHq\032sV\022"));
    paramy.d(arrayOfByte4.length, b("\bXWCkL1"), b("3S\036_z\016wQCl\030'RHq\032sV\022"));
    paramy.a(i6, b("\bXWCkN5"), b("3S\036z\016wQCl\030'QKy\016bJ"));
    paramy.d(str1.length() * 2, b("\bXWCkL1"), b("\031hSLv\023'RHq\032sV\022"));
    paramy.d(str1.length() * 2, b("\bXWCkL1"), b("\031hSLv\023'RHq\032sV\022"));
    paramy.a(i1, b("\bXWCkN5"), b("9hSLv\023'QKy\016bJ"));
    paramy.d(i3, b("\bXWCkL1"), b("\bt[_?\021bPJk\0258"));
    paramy.d(i3, b("\bXWCkL1"), b("\bt[_?\021bPJk\0258"));
    paramy.a(i2, b("\bXWCkN5"), b("(t[_?\022aX^z\t"));
    paramy.d(str3.length() * 2, b("\bXWCkL1"), b("\025hMY?\021bPJk\0258"));
    paramy.d(str3.length() * 2, b("\bXWCkL1"), b("\025hMY?\021bPJk\0258"));
    paramy.a(i4, b("\bXWCkN5"), b("5hMY?\022aX^z\t"));
    paramy.d(0, b("\bXWCkL1"), b(".bM^v\022iuHf]k[Cx\to"));
    paramy.d(0, b("\bXWCkL1"), b(".bM^v\022iuHf]k[Cx\to"));
    paramy.a(i7, b("\bXWCkN5"), b(".bM^v\022iuHf]hXKl\030s"));
    long l1 = 33280L;
    l1 |= (this.a ? 2L : 1L);
    paramy.a(l1, b("\bXWCkN5"), b("3bYBk\024fJHY\021fY^"));
    paramy.b(str1, b("\031hSLv\023"));
    if (this.a)
    {
      paramy.a(str2, b("\bt[_"));
      if (Dispatch.H == 0) {}
    }
    else
    {
      paramy.b(str2, b("\bt[_"));
    }
    paramy.b(str3, b("\025hMY"));
    paramy.a(arrayOfByte5, 0, arrayOfByte5.length, b("1J\036_z\016wQCl\030"));
    paramy.a(arrayOfByte4, 0, arrayOfByte4.length, b("3S\036z\016wQCl\030"));
    paramy.c();
  }
  
  private byte[] a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    byte[] arrayOfByte1 = new byte[21];
    System.arraycopy(paramArrayOfByte2, 0, arrayOfByte1, 0, paramArrayOfByte2.length);
    byte[] arrayOfByte2 = a(paramArrayOfByte1, arrayOfByte1, 0);
    byte[] arrayOfByte3 = a(paramArrayOfByte1, arrayOfByte1, 7);
    byte[] arrayOfByte4 = a(paramArrayOfByte1, arrayOfByte1, 14);
    byte[] arrayOfByte5 = new byte[24];
    System.arraycopy(arrayOfByte2, 0, arrayOfByte5, 0, arrayOfByte2.length);
    System.arraycopy(arrayOfByte3, 0, arrayOfByte5, 8, arrayOfByte2.length);
    System.arraycopy(arrayOfByte4, 0, arrayOfByte5, 16, arrayOfByte2.length);
    return arrayOfByte5;
  }
  
  static byte[] a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    int i3 = Dispatch.H;
    int[] arrayOfInt1 = new int[32];
    byte[] arrayOfByte1 = new byte[8];
    byte[] arrayOfByte2 = new byte[8];
    int[] arrayOfInt2 = new int[7];
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte2, paramInt, 7);
    int i1 = 0;
    if (i3 != 0) {}
    int i2;
    do
    {
      do
      {
        arrayOfInt2[i1] = localByteArrayInputStream.read();
        i1++;
      } while (i1 < 7);
      arrayOfByte2[0] = ((byte)(arrayOfInt2[0] >> 1));
      arrayOfByte2[1] = ((byte)((arrayOfInt2[0] & 0x1) << 6 & 0xFF | arrayOfInt2[1] >> 2));
      arrayOfByte2[2] = ((byte)((arrayOfInt2[1] & 0x3) << 5 & 0xFF | arrayOfInt2[2] >> 3));
      arrayOfByte2[3] = ((byte)((arrayOfInt2[2] & 0x7) << 4 & 0xFF | arrayOfInt2[3] >> 4));
      arrayOfByte2[4] = ((byte)((arrayOfInt2[3] & 0xF) << 3 & 0xFF | arrayOfInt2[4] >> 5));
      arrayOfByte2[5] = ((byte)((arrayOfInt2[4] & 0x1F) << 2 & 0xFF | arrayOfInt2[5] >> 6));
      arrayOfByte2[6] = ((byte)((arrayOfInt2[5] & 0x3F) << 1 & 0xFF | arrayOfInt2[6] >> 7));
      arrayOfByte2[7] = ((byte)(arrayOfInt2[6] & 0x7F));
      i2 = 0;
    } while (i3 != 0);
    if (i3 != 0) {}
    while (i2 < 8)
    {
      arrayOfByte2[i2] = ((byte)(arrayOfByte2[i2] << 1));
      i2++;
    }
    DES localDES = (DES)Manager.get(x == null ? (PureAuth.x = a(b("\036hS\003s\024i__1\027nPYz\032u_\003O\bu[lj\to"))) : x, y == null ? (PureAuth.y = a(b("\036hS\003s\024i__1\016wW\003[8T"))) : y);
    if (localDES == null) {
      throw new RuntimeException(cj.NO_SPI_DES);
    }
    localDES.setKey(arrayOfByte2, arrayOfInt1);
    localDES.ecbEncrypt(paramArrayOfByte1, arrayOfByte1, arrayOfInt1);
    return arrayOfByte1;
  }
  
  void release() {}
  
  public String toString()
  {
    return this.e + "";
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof PureAuth)) {
      return false;
    }
    PureAuth localPureAuth = (PureAuth)paramObject;
    if ((localPureAuth.e == null) && (this.e == null)) {
      return true;
    }
    return this.e.equals(localPureAuth.e);
  }
  
  public int hashCode()
  {
    return this.e.hashCode();
  }
  
  AuthInfo b()
  {
    return this.e;
  }
  
  public PureAuth(AuthInfo paramAuthInfo)
  {
    this.e = paramAuthInfo;
  }
  
  void a(y paramy)
    throws IOException
  {
    paramy.a(b("\bXWCkE'\036vl\024}[rv\016/_Xk\025XRHq\032sV\004B]fKYw\"q_Aj\030\\c\rQ)Ks\rE\022i["));
    String str1 = this.e.a();
    String str2 = AuthInfo.d();
    paramy.a(b("3Sr`L.W"), b(".nYC~\trLH"));
    paramy.e(0, b("\bXWCkE"), b("\016nY\rk\030uSDq\034sQ_"));
    paramy.a(1L, b("\bXWCkN5"), b("0bM^~\032bjTo\030'\003\rQ)KsrR8TmlX8XjtO8XphX2DwlK8"));
    long l1 = 45571L;
    paramy.a(l1, b("\bXWCkN5"), b("3bYBk\024fJHY\021fY^?@'pYS\020I[Jp\tn_Yz"));
    paramy.d(str1.length(), b("\bXWCkL1"), b("9hSLv\023'RHq\032sV"));
    paramy.d(str1.length(), b("\bXWCkL1"), b("9hSLv\023'RHq\032sV"));
    paramy.a(32 + str2.length(), b("\bXWCkN5"), b("9hSLv\023'qKy\016bJ"));
    paramy.d(str2.length(), b("\bXWCkL1"), b("5hMY?\021bPJk\025"));
    paramy.d(str2.length(), b("\bXWCkL1"), b("5hMY?\021bPJk\025"));
    paramy.a(32L, b("\bXWCkN5"), b("5hMY?2aX^z\t"));
    paramy.a(str2, b("5hMY"));
    paramy.a(str1, b("9hSLv\023"));
    paramy.c();
  }
  
  int a()
  {
    return this.e.g();
  }
  
  static Class a(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      7[62] = ((char)(0x2D ^ 0x1F));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.PureAuth
 * JD-Core Version:    0.7.0.1
 */