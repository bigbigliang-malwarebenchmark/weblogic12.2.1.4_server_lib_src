package com.linar.jintegra;

import java.net.URL;

public class HttpTunnel
{
  private static URL a;
  
  static URL a()
  {
    return a;
  }
  
  public static void over(URL paramURL)
  {
    a = paramURL;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.HttpTunnel
 * JD-Core Version:    0.7.0.1
 */