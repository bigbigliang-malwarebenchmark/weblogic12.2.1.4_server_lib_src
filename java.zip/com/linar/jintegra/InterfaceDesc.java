package com.linar.jintegra;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.Hashtable;

public class InterfaceDesc
{
  Uuid a;
  Class b;
  String c;
  Class d;
  InterfaceDesc e;
  Uuid f;
  int g;
  MemberDesc[] h;
  boolean i;
  boolean j = false;
  static Hashtable k = new Hashtable();
  static Hashtable l = new Hashtable();
  static Class m;
  static Class n;
  
  public String toString()
  {
    String str = "";
    if (this.h != null)
    {
      int i1 = 0;
      if (Dispatch.H != 0) {}
      while (i1 < this.h.length)
      {
        str = str + "{" + i1 + b("2}") + (i1 + this.g) + b(";h") + this.h[i1] + "}";
        i1++;
      }
    }
    return b("[;AlZt4Vllw&V)S2<\\m\025") + this.a + "\n" + b("e'TyXw'veIa&\b") + this.b + "\n" + b("e'TyXw'veIa&{hEwh") + this.c + "\n" + b("f4GnMf\026Yh[ah") + this.d + "\n" + b("p4Fl\025") + this.e + "\n" + b("p4Fla[\021\b") + this.f + "\n" + b("}%[|E]3SzMfh") + this.g + "\n" + b("{&pM|!\b") + this.i + "\n" + b("`0FfDd0Q4") + this.j + "\n" + b("0XkM`&\b") + str;
  }
  
  public static void add(String paramString1, Class paramClass, String paramString2, int paramInt, MemberDesc[] paramArrayOfMemberDesc)
  {
    Uuid localUuid = new Uuid(paramString1);
    InterfaceDesc localInterfaceDesc = new InterfaceDesc(localUuid, paramClass, paramString2, paramInt, paramArrayOfMemberDesc);
    k.put(localUuid, localInterfaceDesc);
    try
    {
      Object localObject = paramClass.getField(b("f4GnMf\026Yh[a")).get(null);
      if (localObject != null) {
        l.put(localObject, localInterfaceDesc);
      }
    }
    catch (Throwable localThrowable) {}
  }
  
  InterfaceDesc(Uuid paramUuid, Class paramClass, String paramString, int paramInt, MemberDesc[] paramArrayOfMemberDesc)
  {
    this.a = paramUuid;
    this.b = paramClass;
    this.f = (paramString == null ? null : new Uuid(paramString));
    this.g = paramInt;
    this.h = paramArrayOfMemberDesc;
  }
  
  static InterfaceDesc a(Class paramClass)
  {
    InterfaceDesc localInterfaceDesc = (InterfaceDesc)l.get(paramClass);
    if (localInterfaceDesc == null) {
      return null;
    }
    if (!localInterfaceDesc.j) {
      localInterfaceDesc.a();
    }
    return localInterfaceDesc;
  }
  
  static InterfaceDesc a(Uuid paramUuid)
  {
    if (paramUuid.equals(k.IID_IDISPATCH)) {
      return null;
    }
    InterfaceDesc localInterfaceDesc = (InterfaceDesc)k.get(paramUuid);
    if (localInterfaceDesc == null)
    {
      try
      {
        Class.forName(ObjectProxy.l + ObjectProxy.b(paramUuid) + b("E'TyXw'"));
        localInterfaceDesc = (InterfaceDesc)k.get(paramUuid);
      }
      catch (Throwable localThrowable) {}
      if (localInterfaceDesc == null) {
        return null;
      }
    }
    if (!localInterfaceDesc.j) {
      localInterfaceDesc.a();
    }
    return localInterfaceDesc;
  }
  
  static MemberDesc a(Uuid paramUuid, int paramInt)
  {
    return a(paramUuid).a(paramInt);
  }
  
  MemberDesc a(int paramInt)
  {
    if ((paramInt < this.g) || (this.g == 0))
    {
      if (this.e == null) {
        return null;
      }
      return this.e.a(paramInt);
    }
    int i1 = paramInt - this.g;
    if ((i1 >= this.h.length) || (i1 < 0)) {
      throw new RuntimeException(cj.translate(cj.INTERFACE_DESC_INTERNAL_ERROR, Integer.toString(paramInt), this));
    }
    return this.h[i1];
  }
  
  static Object a(StdObjRef paramStdObjRef, Class paramClass)
  {
    return a(paramStdObjRef, a(paramClass), paramClass.toString());
  }
  
  static Object a(StdObjRef paramStdObjRef, Uuid paramUuid)
  {
    if ((paramUuid == null) || (paramUuid.equals(k.IID_IDISPATCH)) || (paramUuid.equals(k.IID_IUNKNOWN))) {
      return paramStdObjRef;
    }
    return a(paramStdObjRef, a(paramUuid), paramUuid.toString());
  }
  
  static Object a(StdObjRef paramStdObjRef, InterfaceDesc paramInterfaceDesc, String paramString)
  {
    if (paramInterfaceDesc == null)
    {
      Log.log(3, b("Q4[.\\2\"GhX2") + paramString);
      return paramStdObjRef;
    }
    paramInterfaceDesc.a();
    if (paramInterfaceDesc.b == null) {
      return paramStdObjRef;
    }
    try
    {
      Constructor localConstructor = paramInterfaceDesc.b.getConstructor(new Class[] { m == null ? (InterfaceDesc.m = a(b("x4Ch\006~4[n\006]7_lKf"))) : m });
      return localConstructor.newInstance(new Object[] { paramStdObjRef });
    }
    catch (Exception localException)
    {
      Object[] arrayOfObject = { localException, paramInterfaceDesc.b, paramStdObjRef };
      Log.a(cj.translate(cj.INTERFACE_DESC_EXCEPTION, arrayOfObject));
    }
    return paramStdObjRef;
  }
  
  private synchronized void a()
  {
    if (this.j) {
      return;
    }
    try
    {
      if (this.b == null) {
        this.b = Class.forName(this.c);
      }
      this.d = ((Class)this.b.getField(b("f4GnMf\026Yh[a")).get(null));
      this.i = (n == null ? (InterfaceDesc.n = a(b("x4Ch\006g!\\e\006W#Pg\\^<F}M|0G"))) : n).isAssignableFrom(this.d);
      if (this.h != null)
      {
        int i1 = 0;
        if (Dispatch.H != 0) {}
        while (i1 < this.h.length)
        {
          try
          {
            if (this.h[i1] != null) {
              this.h[i1].resolve(this.d, this.i);
            }
          }
          catch (NoSuchMethodException localNoSuchMethodException)
          {
            Object[] arrayOfObject1 = { this.d, this.h[i1], localNoSuchMethodException };
            str2 = cj.translate(cj.INTERFACE_DESC_ERROR_RESOLVING_TARGET_CLASS, arrayOfObject1);
            Log.a(str2);
            throw new RuntimeException(str2);
          }
          i1++;
        }
      }
      if (this.f != null) {
        this.e = a(this.f);
      }
    }
    catch (Exception localException)
    {
      if ((localException instanceof RuntimeException)) {
        throw ((RuntimeException)localException);
      }
      String str1 = b("g;^gGe;");
      try
      {
        str1 = "'" + System.getProperty(b("x4Ch\006q9Tz[<%T}@")) + "'";
      }
      catch (Throwable localThrowable) {}
      Object[] arrayOfObject2 = { this.b, localException, str1 };
      String str2 = cj.translate(cj.INTERFACE_DESC_ERROR_RESOLVING_WRAPPER_CLASS, arrayOfObject2);
      Log.a(str2);
      throw new RuntimeException(str2);
    }
    finally
    {
      this.j = true;
    }
  }
  
  static Class a(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      85[53] = ((char)(0x9 ^ 0x28));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.InterfaceDesc
 * JD-Core Version:    0.7.0.1
 */