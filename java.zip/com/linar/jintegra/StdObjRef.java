package com.linar.jintegra;

import java.io.ByteArrayInputStream;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Hashtable;

class StdObjRef
  implements Externalizable
{
  private long a;
  private long b;
  private Uuid c;
  private int d = 1;
  protected Uuid iid;
  private n e = null;
  private boolean f = false;
  private long g;
  private bl h = null;
  private static Hashtable i = new Hashtable();
  private String j = b("]k@o\nEe]#\nQhQ");
  static final int k = 4096;
  AutomationException l;
  Uuid m;
  Uuid n;
  int o;
  int p;
  
  int a()
  {
    return this.h.b();
  }
  
  int b()
  {
    return this.h.c();
  }
  
  public String getIIDString()
  {
    return this.iid.toString();
  }
  
  void a(n paramn, bl parambl, Uuid paramUuid)
  {
    this.iid = paramUuid;
    this.e = paramn;
    this.h = parambl;
    parambl.a(this.c, this.b, this.d);
    checkToTrack();
  }
  
  void a(Rpc paramRpc, Uuid paramUuid, AuthInfo paramAuthInfo)
    throws IOException
  {
    if (this.f)
    {
      String str = cj.translate(cj.ATTEMPT_TO_INVOKE_RPC_ON_A_RELEASED_OBJ, paramRpc, this);
      Log.a(str);
      throw new RuntimeException(str);
    }
    this.h.a(this.c, paramRpc, paramUuid, paramAuthInfo);
  }
  
  StdObjRef a(Uuid paramUuid, AuthInfo paramAuthInfo)
    throws IOException
  {
    if (this.f)
    {
      String str = cj.translate(cj.ATTEMPT_TO_QUERY_INTERFACE_ON_A_RELEASED_OBJ, this);
      Log.a(str);
      throw new RuntimeException(str);
    }
    if (this.iid.equals(paramUuid)) {
      return a(paramAuthInfo);
    }
    return this.h.a(this.c, paramUuid, paramAuthInfo);
  }
  
  static void a(PrintStream paramPrintStream)
  {
    paramPrintStream.println(b("") + i.size());
  }
  
  protected void checkToTrack()
  {
    bg localbg = (bg)i.get(Thread.currentThread());
    if ((localbg != null) && (this.h != null)) {
      localbg.a(this);
    }
  }
  
  static void c()
  {
    if (i.contains(Thread.currentThread())) {
      return;
    }
    i.put(Thread.currentThread(), new bg());
  }
  
  static void d()
  {
    bg localbg = (bg)i.remove(Thread.currentThread());
    if (localbg == null) {
      throw new RuntimeException(cj.TRACK_OBJECTS_IN_CURRENT_THREAD_NOT_CALLED);
    }
    int i1 = 0;
    if (Dispatch.H != 0) {}
    while (i1 < localbg.c)
    {
      StdObjRef localStdObjRef = (StdObjRef)localbg.b[i1];
      if (!localStdObjRef.f) {
        localStdObjRef.release(null);
      }
      i1++;
    }
  }
  
  protected void finalize()
    throws Throwable
  {
    if (this.f) {
      return;
    }
    this.f = true;
    try
    {
      super.finalize();
      this.h.a(this.c, this.b, this.d, false, null);
    }
    catch (Throwable localThrowable) {}
  }
  
  String e()
  {
    return this.j;
  }
  
  void f()
  {
    try
    {
      try
      {
        throw new Exception(cj.DELIBERATE_EXCEPTION_TO_PRINT_STACK_TRACE);
      }
      catch (Exception localException)
      {
        StringWriter localStringWriter = new StringWriter();
        PrintWriter localPrintWriter = new PrintWriter(localStringWriter);
        localException.printStackTrace(localPrintWriter);
        localPrintWriter.close();
        this.j = localStringWriter.toString();
      }
      return;
    }
    catch (Throwable localThrowable) {}
  }
  
  void release(AuthInfo paramAuthInfo)
  {
    if (this.f)
    {
      String str = cj.translate(cj.ATTEMPT_TO_RELEASE_A_RELEASED_OBJECT, this);
      Log.a(str);
      throw new RuntimeException(str);
    }
    try
    {
      f();
      this.f = true;
      this.h.a(this.c, this.b, this.d, true, paramAuthInfo);
    }
    catch (IOException localIOException)
    {
      Log.a(cj.translate(cj.FAILED_TO_RELEASE, this, localIOException));
    }
  }
  
  Object g()
  {
    StdObjRef localStdObjRef = this;
    if (localStdObjRef.l() != z.c()) {
      return null;
    }
    ba localba = z.a(new Long(localStdObjRef.k()));
    Object localObject = localba.c();
    localba.a(localStdObjRef.getCPublicRefs());
    localStdObjRef.d = 0;
    return localObject;
  }
  
  synchronized StdObjRef a(AuthInfo paramAuthInfo)
    throws IOException
  {
    if (this.f)
    {
      String str = cj.translate(cj.ATTEMPT_TO_GET_REF_ON_A_RELEASED_OBJ, this);
      Log.a(str);
      throw new RuntimeException(str);
    }
    if (this.d > 1) {
      return new StdObjRef(this);
    }
    this.h.a(this.c, this.b, 5, paramAuthInfo);
    this.d += 5;
    return new StdObjRef(this);
  }
  
  n h()
  {
    return this.e;
  }
  
  void a(Uuid paramUuid)
  {
    this.iid = paramUuid;
  }
  
  Uuid i()
  {
    return this.iid;
  }
  
  Uuid j()
  {
    return this.c;
  }
  
  public int getCPublicRefs()
  {
    return this.d;
  }
  
  long k()
  {
    return this.b;
  }
  
  long l()
  {
    return this.a;
  }
  
  StdObjRef(long paramLong1, long paramLong2, n paramn, Uuid paramUuid)
  {
    this.e = paramn;
    this.b = paramLong1;
    this.a = paramLong2;
    this.c = paramUuid;
    this.d = 5;
    checkToTrack();
  }
  
  StdObjRef(Uuid paramUuid)
  {
    this.b = -1L;
    this.a = -1L;
    this.c = null;
    this.d = 0;
    this.iid = paramUuid;
  }
  
  StdObjRef(StdObjRef paramStdObjRef)
  {
    this.b = paramStdObjRef.b;
    this.a = paramStdObjRef.a;
    this.c = paramStdObjRef.c;
    this.e = paramStdObjRef.e;
    this.iid = paramStdObjRef.iid;
    this.h = paramStdObjRef.h;
    this.d = 1;
    paramStdObjRef.d -= 1;
    checkToTrack();
  }
  
  public String toString()
  {
    return cj.translate(cj.COM_OBJ_REFERENCE_VIA_IID, this.iid);
  }
  
  private void a(x paramx)
    throws IOException
  {
    paramx.a(b(""));
    this.g = paramx.e(b(""), b("UhU(\030"));
    this.d = ((int)paramx.e(b(""), b("PTA-\007Zgf*\r@")));
    this.a = paramx.h(b("[}D*\031"), b("\\|]+"));
    this.b = paramx.h(b("[}D*\031"), b("\\mP"));
    this.c = paramx.a(b("zT}\013"), b("Zt]+"));
    paramx.c();
  }
  
  void a(y paramy)
    throws IOException
  {
    a(paramy, 0L, this.d, this.a, this.b, this.c);
  }
  
  static void a(y paramy, long paramLong1, long paramLong2, long paramLong3, long paramLong4, Uuid paramUuid)
    throws IOException
  {
    paramy.a(b(""));
    paramy.a(paramLong1, b(""), b("UhU(\030"));
    paramy.a(paramLong2, b(""), b("PTA-\007Zgf*\r@"));
    paramy.b(paramLong3, b("[}D*\031"), b("\\|]+"));
    paramy.b(paramLong4, b("[}D*\031"), b("\\mP"));
    paramy.a(paramUuid, b("Zt]+"));
    paramy.c();
  }
  
  StdObjRef(x paramx)
    throws IOException
  {
    a(paramx);
  }
  
  int m()
  {
    return 64 + this.e.f() * 2;
  }
  
  void a(y paramy, Uuid paramUuid)
    throws IOException
  {
    a(paramy, paramUuid, true);
  }
  
  void a(y paramy, Uuid paramUuid, boolean paramBoolean)
    throws IOException
  {
    if (this.f)
    {
      String str = cj.translate(cj.ATTEMPT_TO_SEND_A_REF_TO_A_RELEASED_OBJ, this);
      Log.a(str);
      throw new RuntimeException(str);
    }
    paramy.a(b("~MZ;\016AbU,\016ck]!\037Vv\024eACt}!\037VvR.\bV@U;\n"));
    if (paramBoolean) {
      paramy.a(m(), b(""), b("\017eF=\nJ$[)\r@a@q"));
    }
    paramy.a(m(), b(""), b("\017eF=\nJ$X*\005Tp\\q"));
    paramy.a(m(), b(""), b("\017eF=\nJ$X*\005Tp\\q"));
    c(paramy, paramUuid);
    paramy.c();
  }
  
  void b(y paramy, Uuid paramUuid)
    throws IOException
  {
    a(paramy, paramUuid, 4096L, 0L, this.a, this.b, this.c, this.e);
  }
  
  void c(y paramy, Uuid paramUuid)
    throws IOException
  {
    a(paramy, paramUuid, 0L, this.d, this.a, this.b, this.c, this.e);
    this.f = true;
    if (this.h != null)
    {
      this.h.b(this.c, this.b, this.d);
      this.h = null;
    }
  }
  
  static void a(y paramy, Uuid paramUuid1, long paramLong1, long paramLong2, long paramLong3, long paramLong4, Uuid paramUuid2, n paramn)
    throws IOException
  {
    paramy.a(b("|F~\035.u$U-/RpU\0246"));
    paramy.a(1464812877L, b(""), b("plQ<\003ZvQ"));
    paramy.a(1L, b(""), b("UhU(\030"));
    paramy.a(paramUuid1, b("ZmP"));
    paramy.a(b("PeG*C|F~\035.u[g\033*}@u\035/\032Y"));
    a(paramy, paramLong1, paramLong2, paramLong3, paramLong4, paramUuid2);
    paramn.a(paramy);
    paramy.c();
    paramy.c();
  }
  
  StdObjRef(boolean paramBoolean, x paramx)
    throws IOException
  {
    this(true, paramBoolean, paramx);
  }
  
  public StdObjRef() {}
  
  static StdObjRef a(String paramString)
    throws IOException
  {
    if ((!paramString.startsWith(b("\\f^=\016U>"))) || (!paramString.endsWith(":"))) {
      throw new AutomationException(2147746276L);
    }
    paramString = paramString.substring(7);
    paramString = paramString.substring(0, paramString.length() - 1);
    byte[] arrayOfByte = d.decode(paramString);
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
    x localx = new x(true, localByteArrayInputStream, null);
    StdObjRef localStdObjRef = new StdObjRef();
    localStdObjRef.b(localx);
    return localStdObjRef;
  }
  
  private void b(x paramx)
    throws IOException
  {
    int i2 = Dispatch.H;
    paramx.a(b("|F~\035.u$U-/RpU\0246"));
    boolean bool = paramx.a();
    paramx.a(true);
    try
    {
      long l1 = paramx.e(b(""), b("plQ<\003ZvQ"));
      if (l1 != 1464812877L)
      {
        l1 = paramx.e(b(""), b("plQ<\003ZvQ"));
        if (l1 != 1464812877L)
        {
          Log.a(cj.OBJ_REF_MEOW_NOT_FOUND);
          throw new RuntimeException(cj.OBJREF_SIG_NOT_FOUND);
        }
      }
      int i1 = (int)paramx.e(b(""), b("UhU(\030"));
      this.iid = paramx.a(b("tQ}\013"), b("ZmP"));
      Object localObject1;
      switch (i1)
      {
      case 1: 
        paramx.a(b("PeG*C|F~\035.u[g\033*}@u\035/\032Y"));
        a(paramx);
        this.e = new n(paramx);
        this.e.a(135);
        if (this.a != z.c())
        {
          localObject1 = bm.a(this.e, null);
          this.h = ((bm)localObject1).a(this.a);
          if (this.d == 0)
          {
            this.h.a(this.c, this.b, 5, null);
            this.d += 5;
            if (i2 == 0) {}
          }
          else
          {
            this.h.a(this.c, this.b, this.d);
          }
        }
        paramx.c();
        if (i2 == 0) {
          break;
        }
      case 4: 
        paramx.a(b("PeG*C|F~\035.u[w\0328gKyf6"));
        localObject1 = paramx.a(b("pHg\006/"), b("PhG&\017"));
        long l2 = paramx.e(b(""), b("Pfq7\037VjG&\004]"));
        long l3 = paramx.e(b(""), b("@mN*"));
        if (((Uuid)localObject1).equals(k.ERROR_HANDLER_CLSID))
        {
          c(paramx);
          if (i2 == 0) {
            break;
          }
        }
        else if (((Uuid)localObject1).equals(k.RECORD_HANDLER_CLSID))
        {
          a(paramx, (int)l3);
          if (i2 == 0) {
            break;
          }
        }
        else
        {
          Log.a(cj.translate(cj.CUSTOM_OBJ_REF_RECEIVED_WITH_UNKNOWN_CLSID, localObject1, Long.toString(l3)));
          byte[] arrayOfByte = new byte[(int)l3 - 16];
          paramx.a(arrayOfByte, 0, arrayOfByte.length, b("C@U;\n"));
          if (i2 == 0) {
            break;
          }
        }
        break;
      default: 
        Log.a(cj.translate(cj.CANNOT_READ_OBJREFS_LOG_MESSAGE, i1));
        throw new RuntimeException(cj.translate(cj.CANNOT_READ_OBJREFS, i1));
      }
    }
    finally
    {
      paramx.a(bool);
    }
    paramx.c();
  }
  
  StdObjRef(boolean paramBoolean1, boolean paramBoolean2, x paramx)
    throws IOException
  {
    paramx.a(b("~MZ;\016AbU,\016ck]!\037Vv\024eACt}!\037VvR.\bV@U;\n"));
    if (paramBoolean1) {
      paramx.e(b(""), b("\017eF=\nJ$[)\r@a@q"));
    }
    long l1 = paramx.e(b(""), b("\017eF=\nJ$X*\005Tp\\q"));
    if (paramBoolean2) {
      l1 = paramx.e(b(""), b("\017eF=\nJ$X*\005Tp\\q"));
    }
    b(paramx);
    paramx.c();
    checkToTrack();
  }
  
  static int a(AutomationException paramAutomationException)
  {
    return 72 + b(paramAutomationException) + 16;
  }
  
  static int b(AutomationException paramAutomationException)
  {
    return 16 + (paramAutomationException.getSource().length() + 1) * 2 + 4 + 12 + (paramAutomationException.getDescription().length() + 1) * 2 + 4 + 24;
  }
  
  public static void writeErrorCustomObjRef(y paramy, AutomationException paramAutomationException)
    throws IOException
  {
    paramy.a(b("~MZ;\016AbU,\016ck]!\037Vv\024eACt}!\037VvR.\bV@U;\n\023kA;"));
    paramy.b(false);
    paramy.a(a(paramAutomationException), b(""), b("\017eF=\nJ$X*\005Tp\\q"));
    paramy.a(b("|F~\035.u$U-/RpU\0246"));
    paramy.a(1464812877L, b(""), b("plQ<\003ZvQ"));
    paramy.a(4L, b(""), b("UhU(\030"));
    paramy.a(k.IID_IUNKNOWN, b("ZmP"));
    paramy.a(b("PeG*C|F~\035.u[w\0328gKyf6"));
    paramy.a(k.ERROR_HANDLER_CLSID, b("pHg\006/"));
    paramy.a(0L, b(""), b("Pfq7\037VjG&\004]"));
    paramy.a(b(paramAutomationException), b(""), b("\017w]5\016\r"));
    paramy.a(b("vvF \031\023mZ)\004\023iU=\030[eX#\016W$V6KEeX:\016"));
    paramy.a(0L, b(""), b("CeP"));
    paramy.a(1000440L, b(""), b("[aX?KPkZ;\016Kp"));
    paramy.a(k.NULL_UUID, b("ZmP"));
    paramy.a(-1L, b(""), b("~eF$\016A"));
    paramy.a(paramAutomationException.getSource().length() + 1, b(""), b("_aZ(\037["));
    paramy.a(0L, b(""), b("\\bR<\016G"));
    paramy.a(paramAutomationException.getSource().length() + 1, b(""), b("_aZ(\037["));
    paramy.b(paramAutomationException.getSource() + "", b("`kA=\bV"));
    paramy.a(-1L, b(""), b("~eF$\016A"));
    paramy.a(paramAutomationException.getDescription().length() + 1, b(""), b("_aZ(\037["));
    paramy.a(0L, b(""), b("\\bR<\016G"));
    paramy.a(paramAutomationException.getDescription().length() + 1, b(""), b("_aZ(\037["));
    paramy.b(paramAutomationException.getDescription() + "", b("waG,\031Zt@&\004]"));
    paramy.a(0L, b(""), b("~eF$\016A"));
    paramy.a(new byte[24], 0, 24, "?");
    paramy.c();
    paramy.a(new byte[16], 0, 16, "?");
    paramy.c();
    paramy.c();
    int i1 = paramy.b() - 4;
    int i2 = 8 - i1 % 8;
    i2 = i2 == 8 ? 0 : i2;
    paramy.a(new byte[i2], 0, i2, b("ceP+\002]c"));
  }
  
  AutomationException n()
  {
    return this.l;
  }
  
  Uuid o()
  {
    return this.m;
  }
  
  void a(x paramx, int paramInt)
    throws IOException
  {
    int i1 = paramx.b() + paramInt;
    paramx.b(false);
    paramx.a(b("aaW \031W$}!\r\\$Y.\031@lU#\007V`\024-\022\023rU#\036V$\034#\n@p\024-\022Ga\024rK") + Integer.toHexString(i1) + ")");
    this.n = paramx.a(b("g}D*\007Zf\024\032>z@"), b("ZmP"));
    this.o = paramx.f(b("F[]!\037\0022"), b("G}D*\007Zfy.\001\\vb*\031@m[!"));
    this.p = paramx.f(b("F[]!\037\0022"), b("G}D*\007Zfy&\005\\vb*\031@m[!"));
    this.m = paramx.a(b("tQ}\013"), b("aaW \031W$a\032\"w"));
    paramx.b(b("UmX#\016A"), b(""));
    paramx.b(b("UmX#\016A"), b(""));
    paramx.b(true);
    paramx.c();
  }
  
  void a(y paramy, StructDesc paramStructDesc)
    throws IOException
  {
    paramy.b(false);
    paramy.a(b("aaW \031W$}!\r\\$Y.\031@lU#\007V`\024-\022\023rU#\036V"));
    paramy.a(paramStructDesc.b, b("g}D*\007Zf\024\032>z@"));
    paramy.b(paramStructDesc.c, b("G}D*\007Zf\024\"\nYkFo\035VvG&\004]"), b("F[]!\037\0022"));
    paramy.b(paramStructDesc.d, b("G}D*\007Zf\024\"\002]kFo\035VvG&\004]"), b("F[]!\037\0022"));
    paramy.a(paramStructDesc.a, b("`pF:\bG$a\032\"w"));
    paramy.a(0, b("UmX#\016A"), b(""));
    paramy.a(0, b("UmX#\016A"), b(""));
    paramy.b(true);
    paramy.c();
  }
  
  public static void writeRecordCustomObjRef(StructDesc paramStructDesc, y paramy)
    throws IOException
  {
    paramy.a(b("~MZ;\016AbU,\016ck]!\037Vv\024eACt}!\037VvR.\bV@U;\n\023kA;"));
    paramy.b(false);
    paramy.a(92L, b(""), b("\017eF=\nJ$X*\005Tp\\q"));
    paramy.a(b("|F~\035.u$U-/RpU\0246"));
    paramy.a(1464812877L, b(""), b("plQ<\003ZvQ"));
    paramy.a(4L, b(""), b("UhU(\030"));
    paramy.a(k.RECORD_HANDLER_CLSID, b("ZmP"));
    paramy.a(b("PeG*C|F~\035.u[w\0328gKyf6"));
    paramy.a(k.RECORD_HANDLER_CLSID2, b("pHg\006/"));
    paramy.a(0L, b(""), b("Pfq7\037VjG&\004]"));
    paramy.a(44L, b(""), b("\017w]5\016\r"));
    paramy.a(b("aaW \031W$]!\r\\$Y.\031@lU#\007V`\024-\022\023rU#\036V"));
    paramy.a(paramStructDesc.b, b("g}D*\007Zf\024\032>z@"));
    paramy.d(paramStructDesc.c, b("F[]!\037\0022"), b("g}D*\007Zf\024\"\nYkF"));
    paramy.d(paramStructDesc.d, b("F[]!\037\0022"), b("g}D*\007Zf\024\"\002]kF"));
    paramy.a(paramStructDesc.a, b("aaW \031W$a\032\"w"));
    paramy.a(0L, b(""), b("umX#\016A"));
    paramy.a(0L, b(""), b("umX#\016A"));
    paramy.c();
    paramy.c();
    paramy.c();
  }
  
  void c(x paramx)
    throws IOException
  {
    paramx.b(false);
    String str1 = null;
    String str2 = null;
    Object localObject = null;
    paramx.a(b("vvF \031\023mZ)\004\023iU=\030[eX#\016W$V6KEeX:\016"));
    paramx.e(b(""), b("CeP"));
    long l1 = paramx.e(b(""), b("PkZ;\016Kp"));
    paramx.a(b("tQ}\013"), b("ZmPp"));
    long l2 = paramx.e(b("~eF$\016A;"), b(""));
    if (l2 != 0L) {
      str1 = paramx.d(b("`kA=\bV"));
    }
    l2 = paramx.e(b("~eF$\016A;"), b(""));
    if (l2 != 0L) {
      str2 = paramx.d(b("waG,\031Zt@&\004]"));
    }
    this.l = new AutomationException(0L, str1, str2);
    paramx.b(true);
    paramx.c();
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == null) {
      return false;
    }
    if ((paramObject instanceof RemoteObjRef)) {
      paramObject = ((RemoteObjRef)paramObject).getJintegraDispatch();
    }
    if ((paramObject instanceof Dispatch))
    {
      localObject = (Dispatch)paramObject;
      paramObject = ((Dispatch)localObject).getObjRef();
    }
    if ((paramObject == null) || (!(paramObject instanceof StdObjRef))) {
      return false;
    }
    Object localObject = (StdObjRef)paramObject;
    return (this.b == ((StdObjRef)localObject).b) && (this.a == ((StdObjRef)localObject).a) && (this.e.equals(((StdObjRef)localObject).e));
  }
  
  public int hashCode()
  {
    String str = "" + this.b + "" + this.a;
    return str.hashCode();
  }
  
  public void writeExternal(ObjectOutput paramObjectOutput)
    throws IOException
  {
    Log.log(3, b("dv];\002]cq7\037VvZ.\007\t$") + this);
    y localy = new y(true, null);
    b(localy, this.iid);
    byte[] arrayOfByte = localy.e();
    paramObjectOutput.writeObject(arrayOfByte);
  }
  
  public void readExternal(ObjectInput paramObjectInput)
    throws IOException, ClassNotFoundException
  {
    Log.log(3, b("aaU+\002]cq7\037VvZ.\007\023eZo8G`{-\001aaR"));
    byte[] arrayOfByte = (byte[])paramObjectInput.readObject();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
    x localx = new x(true, localByteArrayInputStream, null);
    b(localx);
    Log.log(3, b("aaU+.KpQ=\005Rh\016o") + this);
  }
  
  private static String b(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      4[52] = ((char)(0x4F ^ 0x6B));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.StdObjRef
 * JD-Core Version:    0.7.0.1
 */