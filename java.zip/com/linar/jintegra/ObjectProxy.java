package com.linar.jintegra;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.EventListener;
import java.util.Hashtable;

abstract class ObjectProxy
{
  Hashtable a;
  Hashtable b;
  Hashtable c = new Hashtable();
  Hashtable d = new Hashtable();
  private Hashtable e = new Hashtable();
  protected long countZeroTime = 0L;
  static long f = ;
  Object g;
  private Object h;
  Object i;
  static Hashtable j = new Hashtable();
  static Hashtable k = new Hashtable();
  static String l;
  private static boolean m = bi.I();
  static Class n;
  static Class o;
  static Class p;
  static Class q;
  static Class r;
  
  public String toString()
  {
    return this.g == null ? null : this.g.toString();
  }
  
  protected void addIntermediary(Uuid paramUuid, Object paramObject)
  {
    this.e.put(paramUuid, paramObject);
  }
  
  abstract void a();
  
  public Object getThreadContext()
  {
    return this.h;
  }
  
  void b()
  {
    this.h = new Object();
  }
  
  void a(Object paramObject)
  {
    Log.log(3, c("\013z(ch6x|rw=q(7r7j.tdxk37&") + paramObject + c("?:xsx") + this.g);
    this.i = paramObject;
  }
  
  Param[] a(Class paramClass, int paramInt)
  {
    try
    {
      Field localField = paramClass.getField(c("\027O\022BL\007") + paramInt + c("\007O\035E@\025L"));
      return (Param[])localField.get(null);
    }
    catch (Throwable localThrowable)
    {
      Object[] arrayOfObject = { Integer.toString(paramInt), this.g, paramClass.getName(), localThrowable };
      Log.a(cj.translate(cj.ERROR_GETTING_PARAMETERS, arrayOfObject));
    }
    return null;
  }
  
  private void a(Object paramObject, String paramString)
  {
    if (paramObject == null)
    {
      Log.log(3, paramString + c("x\"|0o-s00"));
      return;
    }
    if (!paramObject.getClass().isArray())
    {
      Log.log(3, paramString + c("x\"|0") + paramObject + "'");
      return;
    }
    Log.log(3, paramString + c("xv/7`6?=es9f|`h,w|") + Array.getLength(paramObject) + c("xz0rl=q(d"));
    int i1 = 0;
    if (Dispatch.H != 0) {}
    while (i1 < Array.getLength(paramObject))
    {
      Object localObject = Array.get(paramObject, i1);
      a(localObject, paramString + "[" + i1 + "]");
      i1++;
    }
  }
  
  Object a(InterfaceDesc paramInterfaceDesc, int paramInt, Object[] paramArrayOfObject)
    throws AutomationException
  {
    int i5 = Dispatch.H;
    MemberDesc localMemberDesc = paramInterfaceDesc.a(paramInt);
    Member localMember = localMemberDesc.d;
    try
    {
      Object localObject1 = null;
      Object localObject2;
      if ((localMember instanceof Method))
      {
        localObject2 = (Method)localMember;
        localObject3 = ((Method)localObject2).getParameterTypes();
        int i2 = 0;
        int i3 = 0;
        if (i5 != 0) {
          if (localObject3[i3] == Character.TYPE)
          {
            i2 = 1;
            paramArrayOfObject[i3] = new Character((char)((Number)paramArrayOfObject[i3]).shortValue());
          }
        }
        Object localObject4;
        do
        {
          if ((i5 != 0) && (paramArrayOfObject.length >= i3 + 1) && (paramArrayOfObject[i3] != null)) {
            if ((!localObject3[i3].isInstance(paramArrayOfObject[i3])) && (localObject3[i3].isArray()) && (paramArrayOfObject[i3].getClass().isArray())) {
              paramArrayOfObject[i3] = Variant.coerceArray(paramArrayOfObject[i3], localObject3[i3].getComponentType());
            }
          }
          i3++;
          if (i3 < localObject3.length) {
            break;
          }
          localObject4 = this.e.get(paramInterfaceDesc.a);
        } while (i5 != 0);
        if (localObject4 == null) {
          localObject4 = this.g;
        }
        Log.log(3, c("\021q*xj1q;7L=k4xex") + localMember + c("xp27") + localObject4);
        if (paramInterfaceDesc.i)
        {
          Log.log(3, c("\021q*xj1q;7d.z2c!") + localMemberDesc.d + c("xp27") + localObject4);
          Object localObject5 = localMemberDesc.h.newInstance(new Object[] { this.i });
          localMemberDesc.g.invoke(localObject5, paramArrayOfObject);
          localObject1 = ((Method)localMemberDesc.d).invoke(localObject4, new Object[] { localObject5 });
        }
        else
        {
          Log.log(3, c("\021q*xj1q;7") + localMemberDesc.d + c("xp27") + localObject4 + c("xh5cix") + paramArrayOfObject.length + c("xo=e`5z(rs+"));
          try
          {
            localObject1 = ((Method)localMemberDesc.d).invoke(localObject4, paramArrayOfObject);
          }
          catch (IllegalArgumentException localIllegalArgumentException)
          {
            Object[] arrayOfObject = { localMemberDesc.a, localObject4.getClass(), localMemberDesc.d.getDeclaringClass() };
            Log.a(cj.translate(cj.INVOKING_METHOD_ON_OBJECT_OF_TYPE, arrayOfObject));
            throw localIllegalArgumentException;
          }
        }
        if (i2 != 0)
        {
          int i4 = 0;
          if (i5 != 0) {}
          while (i4 < localObject3.length)
          {
            if (localObject3[i4] == Character.TYPE) {
              paramArrayOfObject[i4] = new Short((short)((Character)paramArrayOfObject[i4]).charValue());
            }
            i4++;
          }
        }
        if (((Method)localObject2).getReturnType() == Character.TYPE) {
          localObject1 = new Short((short)((Character)localObject1).charValue());
        }
      }
      else if ((localMember instanceof Field))
      {
        localObject2 = (Field)localMember;
        if (paramArrayOfObject.length == 0)
        {
          Log.log(3, c("\037z(ch6x|Qh=s87") + localMember + c("xp27") + this.g);
          localObject1 = ((Field)localObject2).get(this.g);
          if ((localObject1 instanceof Character)) {
            localObject1 = new Short((short)((Character)localObject1).charValue());
          }
        }
        else
        {
          if (((Field)localObject2).getType() == Character.TYPE)
          {
            paramArrayOfObject[0] = new Character((char)((Number)paramArrayOfObject[0]).shortValue());
            if (i5 == 0) {}
          }
          else if ((paramArrayOfObject[0] != null) && (!((Field)localObject2).getType().isInstance(paramArrayOfObject[0])) && (((Field)localObject2).getType().isArray()) && (paramArrayOfObject[0].getClass().isArray()))
          {
            paramArrayOfObject[0] = Variant.coerceArray(paramArrayOfObject[0], ((Field)localObject2).getType().getComponentType());
          }
          Log.log(3, c("\013z(ch6x|Qh=s87") + localMember + c("xp27") + this.g);
          ((Field)localObject2).set(this.g, paramArrayOfObject[0]);
        }
      }
      if (Log.a()) {
        a(localObject1, c("\nz(bs6?*vm-z"));
      }
      return localObject1;
    }
    catch (Throwable localThrowable1)
    {
      Object localObject3;
      Throwable localThrowable2;
      if ((localThrowable1 instanceof InvocationTargetException))
      {
        localThrowable2 = ((InvocationTargetException)localThrowable1).getTargetException();
        if (!(localThrowable2 instanceof AutomationException))
        {
          Log.log(1, cj.translate(cj.EXCEPTION_INVOKING_MEMBER, localMember, localThrowable2));
          Log.printStackTrace(localThrowable2);
          localThrowable2.printStackTrace();
          if (i5 == 0) {}
        }
      }
      else
      {
        Log.log(1, cj.translate(cj.EXCEPTION_INVOKING_MEMBER, localMember, localThrowable2));
        Log.printStackTrace(localThrowable2);
        localThrowable2.printStackTrace();
      }
      Log.log(2, c("\035m.xsxv2an3v2p!5z(n<?") + paramInt + c("xv27") + this.g + c("xj/~o??") + paramInterfaceDesc + c("b?") + localThrowable2);
      int i1 = 0;
      if (i5 != 0) {}
      while (i1 < paramArrayOfObject.length)
      {
        localObject3 = "p" + i1 + c("x\"|") + paramArrayOfObject[i1];
        if (paramArrayOfObject[i1] != null) {
          localObject3 = (String)localObject3 + (paramArrayOfObject[i1] == null ? "" : new StringBuffer().append(" ").append(paramArrayOfObject[i1].getClass()).toString());
        }
        Log.log(3, (String)localObject3);
        i1++;
      }
      throw AutomationException.a(localThrowable2);
    }
  }
  
  void a(Class paramClass, int paramInt, Variant[] paramArrayOfVariant)
    throws AutomationException
  {
    int i4 = Dispatch.H;
    try
    {
      Field localField = paramClass.getField(c("\027O\022BL\007") + paramInt + c("\007R\031CI\027["));
      Method localMethod = (Method)localField.get(null);
      Object[] arrayOfObject = new Object[paramArrayOfVariant.length - 1];
      int i1 = 0;
      if (i4 != 0) {}
      while (i1 < paramArrayOfVariant.length - 1)
      {
        arrayOfObject[i1] = paramArrayOfVariant[i1].getVARIANT();
        i1++;
      }
      if (Log.a())
      {
        Log.log(3, c("\021[5dq9k?!\021q*xj1q;7") + localMethod + c("xp27") + this.g);
        int i2 = 0;
        if (i4 != 0) {}
        while (i2 < arrayOfObject.length)
        {
          a(arrayOfObject[i2], c("\032z:xs=?\025yw7t97Q9m=zd,z.7") + i2);
          i2++;
        }
      }
      Object localObject1 = localMethod.invoke(this.g, arrayOfObject);
      if ((localObject1 != null) && (paramArrayOfVariant[(paramArrayOfVariant.length - 1)] != null))
      {
        Object localObject2 = paramArrayOfVariant[(paramArrayOfVariant.length - 1)].getVARIANT();
        if (localObject2 != null) {
          Array.set(localObject2, 0, localObject1);
        }
      }
      if (Log.a())
      {
        Log.log(3, c("\021[5dq9k?!\021q*xj={|") + localMethod + c("xp27") + this.g);
        int i3 = 0;
        if (i4 != 0) {}
        while (i3 < arrayOfObject.length)
        {
          a(arrayOfObject[i3], c("\031y(rsxv2an3z|G`*~1ru=m|") + i3);
          i3++;
        }
      }
    }
    catch (Throwable localThrowable)
    {
      Log.log(2, c("\035m.xsxv2an3v2p!5z(n<?") + paramInt + c("xv27") + this.g + c("xj/~o??") + paramClass.getName() + c("b?") + localThrowable);
      throw AutomationException.a(localThrowable);
    }
  }
  
  public int getIdOfName(String paramString)
  {
    Integer localInteger = (Integer)this.a.get(paramString.toUpperCase());
    int i1 = localInteger == null ? -1 : localInteger.intValue();
    return i1;
  }
  
  Object c()
  {
    return this.g;
  }
  
  static void a(PrintStream paramPrintStream)
  {
    paramPrintStream.println(c("7ort`;w9sL=k4xe+^2sG1z0srxl5mdxv/7") + j.size());
    paramPrintStream.println(c("7orut1s(~o\017m=gq=m/7r1e97h+?") + k.size());
  }
  
  ObjectProxy(Object paramObject1, Object paramObject2)
  {
    this.g = paramObject1;
    this.h = paramObject2;
    if (paramObject2 == null) {
      paramObject2 = new Object();
    }
    Class localClass = paramObject1.getClass();
    Object[] arrayOfObject = (Object[])j.get(localClass);
    if (arrayOfObject != null)
    {
      Log.b(c("\rl5yfx|=ti={|zd,w3srx~2s!>v9{e+"));
      this.a = ((Hashtable)arrayOfObject[0]);
      this.b = ((Hashtable)arrayOfObject[1]);
      return;
    }
    this.a = new Hashtable();
    this.b = new Hashtable();
    InterfaceDesc localInterfaceDesc = InterfaceDesc.a(localClass);
    if (localInterfaceDesc != null)
    {
      Log.b(c("\rl5yfxv2cd*y=tdx{9dbxk37f=k|sh+o5s"));
      a(localInterfaceDesc);
      try
      {
        Method localMethod = localClass.getMethod(c(",p\017cs1q;"), new Class[0]);
        Hashtable localHashtable = new Hashtable();
        localHashtable.put(new Integer(0), localMethod);
        this.b.put(new Integer(0), localHashtable);
      }
      catch (NoSuchMethodException localNoSuchMethodException) {}catch (SecurityException localSecurityException)
      {
        if (i2 == 0) {
          break label319;
        }
      }
    }
    else
    {
      Log.b(c("\026p(7T+v2p!1q(rs>~?r!<z/t!,p|pd,?8~r(v8"));
      if (i2 != 0)
      {
        b(localClass);
        a(localClass);
      }
      Class[] arrayOfClass;
      int i1;
      do
      {
        localClass = localClass.getSuperclass();
        if (localClass != null) {
          break;
        }
        arrayOfClass = paramObject1.getClass().getInterfaces();
        i1 = 0;
        if (i2 == 0) {
          break label311;
        }
      } while (i2 != 0);
      label311:
      while (i1 < arrayOfClass.length)
      {
        b(arrayOfClass[i1]);
        i1++;
      }
    }
    label319:
    j.put(this.g.getClass(), new Object[] { this.a, this.b });
  }
  
  void a(InterfaceDesc paramInterfaceDesc)
  {
    int i3 = Dispatch.H;
    int i1 = 0;
    if (i3 != 0) {}
    while (i1 < paramInterfaceDesc.h.length)
    {
      MemberDesc localMemberDesc = paramInterfaceDesc.h[i1];
      if (localMemberDesc.e)
      {
        a((Field)localMemberDesc.d, localMemberDesc.f);
        if (i3 == 0) {}
      }
      else
      {
        Method localMethod = (Method)localMemberDesc.d;
        String str = localMethod.getName().toUpperCase();
        Integer localInteger = new Integer(localMemberDesc.f);
        this.a.put(str, localInteger);
        this.b.put(localInteger, new Hashtable());
        Hashtable localHashtable = (Hashtable)this.b.get(localInteger);
        int i2 = localMethod.getParameterTypes().length;
        if (localHashtable.get(new Integer(i2)) == null) {
          localHashtable.put(new Integer(i2), localMethod);
        }
      }
      i1++;
    }
  }
  
  void a(Class paramClass)
  {
    if (!Modifier.isPublic(paramClass.getModifiers()))
    {
      Log.b(c("\f~.pd,?5d!6p(7q-}0~b"));
      return;
    }
    Field[] arrayOfField = paramClass.getFields();
    if (arrayOfField == null)
    {
      Log.a(cj.translate(cj.ERROR_USING_INTROSPECTION_ON, paramClass));
      return;
    }
    int i1 = 0;
    if (Dispatch.H != 0) {}
    while (i1 < arrayOfField.length)
    {
      if (Modifier.isPublic(arrayOfField[i1].getDeclaringClass().getModifiers())) {
        a(arrayOfField[i1], this.a.size() + 2048);
      }
      i1++;
    }
  }
  
  void a(Field paramField, int paramInt)
  {
    String str = paramField.getName().toUpperCase();
    Integer localInteger = (Integer)this.a.get(str);
    if (localInteger != null) {
      return;
    }
    localInteger = new Integer(paramInt);
    this.a.put(str, localInteger);
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), paramField);
    localHashtable.put(new Integer(1), paramField);
    this.b.put(localInteger, localHashtable);
  }
  
  void b(Class paramClass)
  {
    int i3 = Dispatch.H;
    if (!Modifier.isPublic(paramClass.getModifiers())) {
      return;
    }
    Method[] arrayOfMethod = paramClass.getMethods();
    if (arrayOfMethod == null)
    {
      Log.a(cj.translate(cj.ERROR_USING_INTROSPECTION_ON, paramClass));
      return;
    }
    int i1 = 0;
    if (i3 != 0) {}
    while (i1 < arrayOfMethod.length)
    {
      if (Modifier.isPublic(arrayOfMethod[i1].getDeclaringClass().getModifiers()))
      {
        String str1 = arrayOfMethod[i1].getName().toUpperCase();
        Integer localInteger1 = (Integer)this.a.get(str1);
        if (localInteger1 == null)
        {
          if (str1.equals(c("\fP\017CS\021Q\033")))
          {
            localInteger1 = new Integer(0);
            if (i3 == 0) {}
          }
          else
          {
            localInteger1 = new Integer(this.a.size() + 2048);
          }
          this.a.put(str1, localInteger1);
          this.b.put(localInteger1, new Hashtable());
        }
        Hashtable localHashtable = (Hashtable)this.b.get(localInteger1);
        int i2 = arrayOfMethod[i1].getParameterTypes().length;
        if (localHashtable.get(new Integer(i2)) == null) {
          localHashtable.put(new Integer(i2), arrayOfMethod[i1]);
        }
        if ((str1.length() > 3) && ((str1.startsWith(c("\037Z\b"))) || (str1.startsWith(c("\013Z\b")))))
        {
          String str2 = str1.substring(3);
          Integer localInteger2 = (Integer)this.a.get(str2);
          if (localInteger2 == null)
          {
            localInteger2 = new Integer(localInteger1.intValue() * 2);
            this.a.put(str2, localInteger2);
            this.b.put(localInteger2, new Hashtable());
          }
          localHashtable = (Hashtable)this.b.get(localInteger2);
          if (localHashtable.get(new Integer(i2)) == null) {
            localHashtable.put(new Integer(i2), arrayOfMethod[i1]);
          }
        }
      }
      i1++;
    }
  }
  
  Class a(Uuid paramUuid)
  {
    int i2 = Dispatch.H;
    if (k.b(paramUuid)) {
      return null;
    }
    Log.log(3, c("\031k(rl(k5yfxk37g1q87v*~,gd*?:xsx") + k.a(paramUuid));
    Class localClass1 = (Class)k.get(paramUuid);
    if (localClass1 != null) {
      return localClass1;
    }
    String str1 = b(paramUuid);
    Object localObject;
    try
    {
      Log.b(c("\024p3|h6x|qn*?") + str1 + c("xv27") + this.g.getClass());
      Field localField1 = this.g.getClass().getField(str1);
      Log.log(3, c("\037p(7G1z0s!") + localField1);
      String str2 = localField1.getDeclaringClass().getName() + c("\bm3ox");
      try
      {
        Log.log(3, c("\034p5yfx\\0vr+1:xs\026~1r)z") + str2 + c("z6"));
        Class localClass2 = Class.forName(str2);
        localObject = c("-q7yn/q");
        try
        {
          Field localField3 = localClass2.getField(c(",~.pd,\\0vr+"));
          localObject = localField3.get(null) + "";
        }
        catch (Throwable localThrowable2) {}
        Log.log(3, c("\024p=sd<?") + localClass2 + c("xy3e!,~.pd,?") + (String)localObject);
        return localClass2;
      }
      catch (Throwable localThrowable1)
      {
        Log.a(cj.translate(cj.CANNOT_FIND_PROXY_EXCEPTION, str2, localThrowable1));
      }
      Log.b(c("\024p3|h6x|qn*?5yu=m:vb=l"));
    }
    catch (NoSuchFieldException localNoSuchFieldException1) {}
    Class[] arrayOfClass = this.g.getClass().getInterfaces();
    int i1 = 0;
    if (i2 != 0) {}
    for (;;)
    {
      try
      {
        Log.b(c("\024p3|h6x|qn*?") + str1 + c("xv27") + arrayOfClass[i1]);
        Field localField2 = arrayOfClass[i1].getField(str1);
        Log.log(3, c("\037p(7G1z0s!") + localField2);
        localObject = arrayOfClass[i1].getName() + c("\bm3ox");
        try
        {
          return Class.forName((String)localObject);
        }
        catch (ClassNotFoundException localClassNotFoundException)
        {
          Log.a(cj.translate(cj.CANNOT_FIND_PROXY, localObject));
        }
        i1++;
      }
      catch (NoSuchFieldException localNoSuchFieldException2) {}
      if (i1 >= arrayOfClass.length)
      {
        String str3 = l + str1 + c("\017m=gq=m");
        try
        {
          localObject = Class.forName(str3);
          Class localClass3 = (Class)((Class)localObject).getField(c(",~.pd,\\0vr+")).get(null);
          if (i2 == 0) {
            if (localClass3.isInstance(this.g)) {
              return localObject;
            }
          }
        }
        catch (Exception localException)
        {
          Log.log(3, c("\036~5{d<?(x!4p=s!1q(rs>~?r!/m=gq=m|xsxo.xy!?:xsx\\\023Z!1q(rs>~?r!") + paramUuid);
        }
      }
    }
    return null;
  }
  
  public Variant performIDispatchInvoke(int paramInt, long paramLong, Variant[] paramArrayOfVariant)
    throws AutomationException
  {
    int i5 = Dispatch.H;
    Log.log(3, c("(z.qn*r\025Sh+o=cb0V2an3z|t`4s9s/"));
    Log.log(3, c("5z1~ex\"|") + paramInt);
    Log.log(3, c("<h\032{`?l|*!") + paramLong);
    Log.log(3, c(".~.~`6k\035ef+?a7") + paramArrayOfVariant);
    Object localObject1 = this.g;
    try
    {
      if (paramInt == -4)
      {
        localObject2 = _CollectionProxy.b(localObject1);
        if (localObject2 != null)
        {
          Log.log(3, c("\nz?rh.z87r-|9dr>j07^\026z+Ro-r|t`4s|xox") + this + c("v?\016ru-m2~o??") + localObject2);
          return localObject2;
        }
        Log.log(2, c("\nz?rh.z87t6l)td+l:bmx@\022rv\035q)z!;~0{!7q|") + this);
      }
      Object localObject2 = null;
      try
      {
        String str = c("\034V\017GH\034@") + (paramInt < 0 ? "_" + Math.abs(paramInt) : new StringBuffer().append("").append(paramInt).toString()) + c("\007Q\035ZD");
        Log.log(3, c("\024p3|h6x|qn*?:~d4{f7") + str);
        localObject4 = localObject1.getClass().getField(str);
        localObject5 = ((Field)localObject4).getDeclaringClass();
        Log.log(3, c("\037p(7g1z0s;x") + localObject4);
        localObject2 = (Member)this.c.get(new Integer(paramInt));
        if (localObject2 == null)
        {
          localObject6 = (String)((Field)localObject4).get(null);
          localObject7 = ((Class)localObject5).getMethods();
          int i2 = 0;
          if (i5 != 0) {}
          while (i2 < localObject7.length)
          {
            if (localObject7[i2].getName().equals(localObject6))
            {
              localObject2 = localObject7[i2];
              this.c.put(new Integer(paramInt), localObject2);
              if (i5 == 0) {
                break;
              }
            }
            i2++;
          }
        }
        if (localObject2 == null) {
          throw new NoSuchMethodException();
        }
      }
      catch (Exception localException)
      {
        Object localObject4 = (Hashtable)this.b.get(new Integer(paramInt));
        if (localObject4 == null)
        {
          Log.log(1, cj.translate(cj.IDISPATCH_INVOKE_ATTEMPT_ON_INVALID_MEMID, Integer.toString(paramInt), this));
          throw new RuntimeException(cj.translate(cj.CANNOT_MAP_MEMID_TO_MEMBER, paramInt));
        }
        localObject2 = (Member)((Hashtable)localObject4).get(new Integer(paramArrayOfVariant.length));
        if (localObject2 == null)
        {
          localObject5 = new Object[] { Integer.toString(paramInt), Integer.toString(paramArrayOfVariant.length), this };
          Log.log(1, cj.translate(cj.IDISPATCH_INVOKE_MEMBER_NOT_FOUND, (Object[])localObject5));
          throw new RuntimeException(cj.translate(cj.IDISPATCH_INVOKE_NO_MEMBER_WITH_ID, Integer.toString(paramInt), Integer.toString(paramArrayOfVariant.length)));
        }
      }
      Log.log(2, c("\021[5dq9k?;bV2an3z|ed)j9duxm9td1i9s!>p.7") + localObject2 + c("xp27") + this);
      localObject3 = localObject2;
      if (((localObject2 instanceof Method)) && ((localObject1 instanceof EventListener)) && (((Method)localObject2).getParameterTypes().length == 1)) {}
      int i1 = (n == null ? (ObjectProxy.n = b(c("2~*v/-k5{/\035i9yu\027}6rb,"))) : n).isAssignableFrom(((Method)localObject2).getParameterTypes()[0]) ? 1 : 0;
      Object[] arrayOfObject;
      if (i1 != 0)
      {
        Log.log(3, c("\021l|voxz*ro,"));
        localObject5 = ((Method)localObject2).getParameterTypes()[0];
        localObject6 = new Class[] { o == null ? (ObjectProxy.o = b(c("2~*v/4~2p/\027}6rb,"))) : o };
        localObject7 = ((Class)localObject5).getConstructor((Class[])localObject6);
        arrayOfObject = new Object[] { this.i };
        Object localObject8 = ((Constructor)localObject7).newInstance(arrayOfObject);
        arrayOfObject[0] = null;
        Method[] arrayOfMethod = ((Class)localObject5).getDeclaredMethods();
        Method localMethod = null;
        int i4 = 0;
        if (i5 != 0) {
          if (arrayOfMethod[i4].getName().equals(c("1q5c"))) {
            localMethod = arrayOfMethod[i4];
          }
        }
        do
        {
          continue;
          i4++;
          if (i4 < arrayOfMethod.length) {
            break;
          }
        } while (i5 != 0);
        if (localMethod == null)
        {
          Log.a(cj.translate(cj.IDISPATCH_INVOKE_FOR_AN_EVENT, ((Class)localObject5).getName()));
          throw new RuntimeException(cj.translate(cj.IDISPATCH_INVOKE_FOR_AN_EVENT, ((Class)localObject5).getName()));
        }
        localObject2 = localMethod;
        localObject1 = localObject8;
      }
      Object localObject5 = null;
      if ((localObject2 instanceof Method))
      {
        localObject5 = ((Method)localObject2).getParameterTypes();
      }
      else if ((paramLong & 0x2) != 0L)
      {
        localObject5 = new Class[0];
      }
      else if (((paramLong & 0x4) != 0L) || ((paramLong & 0x8) != 0L))
      {
        localObject5 = new Class[1];
        localObject5[0] = ((Field)localObject2).getType();
      }
      else
      {
        Log.log(1, cj.translate(cj.IDISPATCH_INVOKE_GOT_ATTEMPT_TO_INVOKE_MEMBER, localObject2, this));
        throw new RuntimeException(cj.ATTEMPT_TO_INVOKE_METHOD_ON_PROPERTY);
      }
      Object localObject6 = new Object[paramArrayOfVariant.length];
      a(paramArrayOfVariant, paramArrayOfVariant.length, (Object[])localObject6, (Class[])localObject5, (Member)localObject2);
      Object localObject7 = null;
      if ((localObject2 instanceof Method)) {
        localObject7 = ((Method)localObject2).invoke(localObject1, (Object[])localObject6);
      } else if ((paramLong & 0x2) != 0L) {
        localObject7 = ((Field)localObject2).get(localObject1);
      } else {
        ((Field)localObject2).set(localObject1, localObject6[0]);
      }
      if (i1 != 0)
      {
        Log.log(3, c("\035i9yuxo=e`5z(rsxv/7") + localObject1);
        arrayOfObject = new Object[] { localObject1 };
        Log.log(3, c("\021q*xj1q;7") + localObject3 + c("xp27") + this.g);
        localObject7 = ((Method)localObject3).invoke(this.g, arrayOfObject);
        Log.log(3, c("\021q*xj={"));
        localObject1 = null;
      }
      else
      {
        int i3 = 0;
        if (i5 != 0) {}
        while (i3 < localObject6.length)
        {
          if ((localObject6[i3] != null) && (!localObject6[i3].getClass().isArray()))
          {
            paramArrayOfVariant[i3] = null;
            if (i5 == 0) {}
          }
          else if ((localObject6[i3] != null) && (localObject6[i3].getClass().isArray()) && (Array.getLength(localObject6[i3]) == 1) && (paramArrayOfVariant[i3].getVT() == 16396))
          {
            paramArrayOfVariant[i3].pvarVal[0] = new Variant(c(".~0bd"), 12, Array.get(localObject6[i3], 0));
          }
          i3++;
        }
      }
      if ((localObject7 == null) && (m)) {
        return new Variant(c("\nz/bm,"), 9);
      }
      return new Variant(c("\nz/bm,"), 12, localObject7);
    }
    catch (Throwable localThrowable)
    {
      Object localObject3 = new StringWriter();
      localThrowable.printStackTrace(new PrintWriter((Writer)localObject3));
      Log.log(3, ((StringWriter)localObject3).toString());
      throw AutomationException.a(localThrowable);
    }
  }
  
  void a(Variant[] paramArrayOfVariant, int paramInt, Object[] paramArrayOfObject, Class[] paramArrayOfClass, Member paramMember)
    throws ClassNotFoundException, IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException
  {
    int i2 = Dispatch.H;
    int i1 = 0;
    if (i2 != 0) {}
    while (i1 < paramInt)
    {
      Variant localVariant = paramArrayOfVariant[i1];
      Log.log(3, c("\021[5dq9k?;bV2an3z|tn=m?~o??") + paramMember.getName() + c("xo=e`5z(rsx") + i1 + c("xy.xlxI\b71 ") + Integer.toHexString(localVariant.getVT()) + c("xk37") + paramArrayOfClass[i1]);
      if (localVariant.getVT() != 9)
      {
        paramArrayOfObject[i1] = localVariant.b(paramArrayOfClass[i1]);
        if (i2 == 0) {}
      }
      else
      {
        if (paramArrayOfClass[i1].isPrimitive()) {
          throw new IllegalArgumentException(cj.translate(cj.ATTEMPT_TO_CONVERT_DISPATCH_TO, paramArrayOfClass[i1]));
        }
        if (paramArrayOfClass[i1] == (o == null ? (ObjectProxy.o = b(c("2~*v/4~2p/\027}6rb,"))) : o))
        {
          paramArrayOfObject[i1] = localVariant.getDISPATCH();
          if (i2 == 0) {}
        }
        else if (paramArrayOfClass[i1] == (p == null ? (ObjectProxy.p = b(c("2~*v/4~2p/\013k.~o?"))) : p))
        {
          paramArrayOfObject[i1] = (localVariant.getDISPATCH() + "");
          if (i2 == 0) {}
        }
        else
        {
          if (paramArrayOfClass[i1] == (q == null ? (ObjectProxy.q = b(c("2~*v/-k5{/\034~(r"))) : q)) {
            throw new IllegalArgumentException(cj.CANNOT_CONVERT_FROM_COM_IDISPATCH_TO_JAVA_DATE);
          }
          if (paramArrayOfClass[i1] == (r == null ? (ObjectProxy.r = b(c("2~*v/5~(/\032v;Sd;v1vm"))) : r)) {
            throw new IllegalArgumentException(cj.CANNOT_CONVERT_FROM_COM_IDISPATCH_TO_JAVA_BIG_DEC);
          }
          Class localClass = Class.forName(paramArrayOfClass[i1].getName());
          Object localObject1 = localVariant.getDISPATCH();
          if ((localObject1 == null) || (localClass.isInstance(localObject1)))
          {
            paramArrayOfObject[i1] = localObject1;
            if (i2 == 0) {}
          }
          else
          {
            if (localClass.isInterface()) {
              try
              {
                localClass = Class.forName(paramArrayOfClass[i1].getName() + c("\bm3ox"));
              }
              catch (ClassNotFoundException localClassNotFoundException)
              {
                localObject2 = InterfaceDesc.a(localClass);
                if (localObject2 == null) {
                  throw localClassNotFoundException;
                }
                localClass = ((InterfaceDesc)localObject2).b;
              }
            }
            Log.log(3, c("\031k(rl(k5yfxk37b7q/cs-|(7`6?5yr,~2tdxp:7") + localClass.getName());
            Class[] arrayOfClass = { o == null ? (ObjectProxy.o = b(c("2~*v/4~2p/\027}6rb,"))) : o };
            Object localObject2 = localClass.getConstructor(arrayOfClass);
            Object[] arrayOfObject = { localObject1 };
            paramArrayOfObject[i1] = ((Constructor)localObject2).newInstance(arrayOfObject);
          }
        }
      }
      i1++;
    }
  }
  
  Class a(String paramString)
  {
    String str = l + paramString + c("\017m=gq=m");
    try
    {
      Log.log(3, c("\031k(rl(k5yfxk37m7~87b4~/d!") + str);
      return Class.forName(str);
    }
    catch (Exception localException) {}
    return null;
  }
  
  Class c(Class paramClass)
  {
    if (paramClass == null) {
      return null;
    }
    try
    {
      return (Class)paramClass.getField(c(",~.pd,\\0vr+")).get(null);
    }
    catch (Exception localException) {}
    return null;
  }
  
  Method a(String paramString, Class paramClass)
  {
    int i2 = Dispatch.H;
    Method[] arrayOfMethod = this.g.getClass().getMethods();
    int i1 = 0;
    if (i2 != 0) {}
    label214:
    while (i1 < arrayOfMethod.length)
    {
      String str = arrayOfMethod[i1].getName();
      if ((str.startsWith(c("9{8"))) && (str.endsWith(c("\024v/cd6z."))))
      {
        Class[] arrayOfClass = arrayOfMethod[i1].getParameterTypes();
        if ((arrayOfClass.length == 1) && (arrayOfClass[0].isInterface()))
        {
          if (paramClass != null)
          {
            if (!arrayOfClass[0].isAssignableFrom(paramClass)) {
              break label214;
            }
          }
          else {
            try
            {
              Log.log(3, c("\033p2dh<z.~o??") + arrayOfMethod[i1]);
              Field localField = arrayOfClass[0].getField(paramString);
              if (!localField.getDeclaringClass().equals(arrayOfClass[0])) {
                break label214;
              }
            }
            catch (NoSuchFieldException localNoSuchFieldException)
            {
              if (i2 == 0) {
                break label214;
              }
            }
          }
          Log.log(3, c("\rl5yfx") + arrayOfMethod[i1]);
          return arrayOfMethod[i1];
        }
      }
      i1++;
    }
    return null;
  }
  
  Method a(Method paramMethod)
  {
    if (paramMethod == null) {
      return null;
    }
    try
    {
      String str = c("*z1xw=") + paramMethod.getName().substring(3);
      Class[] arrayOfClass = paramMethod.getParameterTypes();
      return this.g.getClass().getMethod(str, arrayOfClass);
    }
    catch (Exception localException) {}
    return null;
  }
  
  static String b(Uuid paramUuid)
  {
    StringBuffer localStringBuffer = new StringBuffer(c("\021V\030") + paramUuid);
    localStringBuffer.setCharAt(11, '_');
    localStringBuffer.setCharAt(16, '_');
    localStringBuffer.setCharAt(21, '_');
    localStringBuffer.setCharAt(26, '_');
    return localStringBuffer.toString();
  }
  
  static Class b(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  static
  {
    try
    {
      Class.forName(c(";p19m1q=e/2v2cd?m=9D6j1rs9k5xo\017m=gq=m"));
      Class.forName(c(";p19m1q=e/2v2cd?m=9^\033p0{d;k5xo\bm3ox"));
      if (f != 0L)
      {
        Log.log(3, c("\013k=eu1q;7q*p$n!=g,~s9k5xox|4rb3z.;!*j2yh6x|rw=m%7") + f + c("xr5{m1l9tn6{/"));
        bj.a();
      }
    }
    catch (Throwable localThrowable1) {}
    try
    {
      Class.forName(c("\021V\030^o1k"));
    }
    catch (Throwable localThrowable2) {}
    l = "";
    String str = bi.t();
    if (str != null)
    {
      l = str + ".";
      Log.log(3, c("\022v2cd?m=7t+v2p!(m3oxxo=tj9x97") + str);
    }
  }
  
  private static String c(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      31[92] = ((char)(0x17 ^ 0x1));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.ObjectProxy
 * JD-Core Version:    0.7.0.1
 */