package com.linar.jintegra;

import java.net.InetAddress;

public abstract interface ConnectionListener
{
  public abstract boolean newConnection(InetAddress paramInetAddress, String paramString1, String paramString2, boolean paramBoolean);
  
  public abstract void connectionClosed(InetAddress paramInetAddress);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.ConnectionListener
 * JD-Core Version:    0.7.0.1
 */