package com.linar.jintegra;

import java.lang.reflect.Field;
import java.util.Hashtable;

public class StructDesc
{
  Uuid a;
  Uuid b;
  int c;
  int d;
  public Class targetClass;
  public Param[] fields;
  private int e = -1;
  static Hashtable f = new Hashtable();
  static Hashtable g = new Hashtable();
  boolean h = false;
  
  public static void add(StructDesc paramStructDesc)
  {
    f.put(paramStructDesc.a, paramStructDesc);
    g.put(paramStructDesc.targetClass, paramStructDesc);
  }
  
  public StructDesc(String paramString1, String paramString2, int paramInt1, int paramInt2, Class paramClass, Param[] paramArrayOfParam)
  {
    this.a = new Uuid(paramString1);
    this.b = new Uuid(paramString2);
    this.c = paramInt1;
    this.d = paramInt2;
    this.targetClass = paramClass;
    this.fields = paramArrayOfParam;
  }
  
  static StructDesc a(Uuid paramUuid)
  {
    StructDesc localStructDesc = (StructDesc)f.get(paramUuid);
    if (localStructDesc == null)
    {
      String str = cj.translate(cj.UNKNOWN_STRUCT_UUID, paramUuid);
      Log.a(str);
      throw new RuntimeException(str);
    }
    localStructDesc.b();
    return localStructDesc;
  }
  
  static int a(Class paramClass)
  {
    return b(paramClass).a();
  }
  
  int a()
  {
    int m = Dispatch.H;
    if (this.e != -1) {
      return this.e;
    }
    synchronized (this)
    {
      if (this.e != -1)
      {
        i = this.e;
        return i;
      }
      int i = 0;
      int j = 0;
      int k;
      if (m != 0) {
        k = Marshaller.a(this.fields[j]);
      }
      do
      {
        if (k > i) {
          i = k;
        }
        j++;
        if (j < this.fields.length) {
          break;
        }
        this.e = i;
        k = this.e;
      } while (m != 0);
      return k;
    }
  }
  
  public static int getSize(Class paramClass)
  {
    try
    {
      return paramClass.getDeclaredField(a("&\005zl|\025?TkW\r)fQ")).getInt(null);
    }
    catch (Exception localException) {}
    return 0;
  }
  
  static boolean a(Object paramObject)
  {
    if (paramObject == null) {
      return false;
    }
    return g.get(paramObject.getClass()) != null;
  }
  
  static StructDesc b(Class paramClass)
  {
    StructDesc localStructDesc;
    if (paramClass == null)
    {
      localStructDesc = null;
      if (Dispatch.H == 0) {}
    }
    else
    {
      localStructDesc = (StructDesc)g.get(paramClass);
    }
    if (localStructDesc == null)
    {
      Object localObject;
      if (paramClass != null)
      {
        localObject = paramClass.getComponentType();
        if (localObject != null) {
          localStructDesc = (StructDesc)g.get(localObject);
        }
      }
      if (localStructDesc == null)
      {
        localObject = cj.translate(cj.UNKNOWN_STRUCT_CLASS, paramClass);
        throw new RuntimeException((String)localObject);
      }
    }
    localStructDesc.b();
    return localStructDesc;
  }
  
  void b()
  {
    if (this.h) {
      return;
    }
    this.h = true;
    int i = 0;
    if (Dispatch.H != 0) {}
    while (i < this.fields.length)
    {
      this.fields[i].a(this.targetClass);
      i++;
    }
  }
  
  public String getTargetJNI()
  {
    return getEncodingOfClass(this.targetClass);
  }
  
  public static String getEncodingOfClass(Class paramClass)
  {
    int k = Dispatch.H;
    if (paramClass == null) {
      return new String("");
    }
    if (paramClass.isPrimitive())
    {
      if (paramClass == Boolean.TYPE) {
        return "Z";
      }
      if (paramClass == Byte.TYPE) {
        return "B";
      }
      if (paramClass == Character.TYPE) {
        return "C";
      }
      if (paramClass == Double.TYPE) {
        return "D";
      }
      if (paramClass == Float.TYPE) {
        return "F";
      }
      if (paramClass == Integer.TYPE) {
        return "I";
      }
      if (paramClass == Long.TYPE) {
        return "J";
      }
      if (paramClass == Short.TYPE) {
        return "S";
      }
      if (paramClass == Void.TYPE) {
        return "V";
      }
      throw new RuntimeException(a(",4R`V\0164\031~K\0207PzP\017?\031mU\030)J.") + paramClass);
    }
    if (paramClass.isArray()) {
      return '[' + getEncodingOfClass(paramClass.getComponentType());
    }
    String str = paramClass.getName();
    int i = str.length();
    char[] arrayOfChar = new char[i + 2];
    arrayOfChar[0] = 'L';
    str.getChars(0, i, arrayOfChar, 1);
    int j = 1;
    if (k != 0) {}
    do
    {
      do
      {
        if (arrayOfChar[j] == '.') {
          arrayOfChar[j] = '/';
        }
        j++;
      } while (j <= i);
      arrayOfChar[j] = ';';
    } while (k != 0);
    return new String(arrayOfChar);
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      90[57] = ((char)(0xE ^ 0x39));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.StructDesc
 * JD-Core Version:    0.7.0.1
 */