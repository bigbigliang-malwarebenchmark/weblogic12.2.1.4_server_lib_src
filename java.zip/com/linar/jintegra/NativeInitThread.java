package com.linar.jintegra;

public class NativeInitThread
  implements Runnable
{
  static Object a = new Object();
  static boolean b = false;
  int c;
  boolean d;
  boolean e;
  boolean f;
  boolean g;
  boolean h;
  static String i = null;
  
  private NativeInitThread(int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5)
  {
    this.c = paramInt;
    this.d = paramBoolean1;
    this.e = paramBoolean2;
    this.f = paramBoolean3;
    this.g = paramBoolean4;
    this.h = paramBoolean5;
  }
  
  public void run()
  {
    try
    {
      Log.b(a(""));
      i = NativeObjRef.initializeCOM(this.c, this.d, this.e, this.f, this.g, this.h);
    }
    catch (Throwable localThrowable)
    {
      Log.a(cj.translate(cj.ERROR_CALLING_INITIALIZE_COM, localThrowable));
    }
    b = true;
    synchronized (a)
    {
      a.notifyAll();
    }
    try
    {
      if (Dispatch.H != 0) {}
      for (;;)
      {
        Thread.sleep(100000L);
      }
    }
    catch (InterruptedException localInterruptedException) {}
  }
  
  static String a(int paramInt, boolean paramBoolean)
    throws InterruptedException
  {
    return a(paramInt, paramBoolean, false, false, false, false);
  }
  
  static String a(int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5)
    throws InterruptedException
  {
    int j = Dispatch.H;
    if (b) {
      return i;
    }
    synchronized (a)
    {
      if (b)
      {
        localObject2 = i;
        return localObject2;
      }
      Object localObject2 = new Thread(new NativeInitThread(paramInt, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5));
      ((Thread)localObject2).setDaemon(true);
      ((Thread)localObject2).setName(a(""));
      ((Thread)localObject2).start();
      if (j != 0) {}
      do
      {
        do
        {
          a.wait();
        } while (!b);
      } while (j != 0);
    }
    return i;
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int j = arrayOfChar.length;
    int k = 0;
    while (k < j)
    {
      switch (k % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      51[23] = ((char)(0x61 ^ 0x35));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.NativeInitThread
 * JD-Core Version:    0.7.0.1
 */