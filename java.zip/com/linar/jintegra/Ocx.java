package com.linar.jintegra;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.font.TextLayout;
import java.awt.geom.RectangularShape;
import java.beans.Beans;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Hashtable;

public abstract class Ocx
  extends Canvas
  implements RemoteObjRef
{
  private int a = bi.a(getClass().getName());
  private int b = bi.b(getClass().getName());
  private transient long c = 0L;
  private transient long d = 0L;
  private boolean e = true;
  transient String f;
  transient NativeObjRef g;
  private static boolean h = ;
  private static boolean i = bi.N();
  private Hashtable j = new Hashtable();
  private Hashtable k = new Hashtable();
  int l = 0;
  int m = 0;
  int n = 0;
  int o = 0;
  
  protected Ocx(String paramString)
  {
    this.f = paramString;
    if (i)
    {
      Log.b(a(""));
      this.g = new NativeObjRef(paramString, k.IID_IUNKNOWN.toString(), a("<iv\fn8if\031"), null);
    }
  }
  
  protected Ocx(String paramString, Object paramObject)
  {
    this.f = paramString;
    this.g = ((NativeObjRef)paramObject);
  }
  
  protected void checkIfVisible()
  {
    if (this.g == null) {
      throw new RuntimeException(cj.ATTEMPT_TO_INVOKE_METHOD_BEFORE_VISIBLE);
    }
  }
  
  private long a()
  {
    long l1 = 0L;
    WindowsHandleGettable localWindowsHandleGettable = null;
    if (localWindowsHandleGettable != null)
    {
      l1 = localWindowsHandleGettable.getHandleForCanvas(this);
      if (Dispatch.H == 0) {}
    }
    else
    {
      synchronized (getClass())
      {
        try
        {
          localWindowsHandleGettable = (WindowsHandleGettable)Class.forName(a("3ixCn9ht\037,:o{\031g7ttCv")).newInstance();
          if (localWindowsHandleGettable != null) {
            l1 = localWindowsHandleGettable.getHandleForCanvas(this);
          }
        }
        catch (Throwable localThrowable1)
        {
          l1 = 0L;
        }
        if (l1 == 0L) {
          try
          {
            localWindowsHandleGettable = (WindowsHandleGettable)Class.forName(a("3ixCn9ht\037,:o{\031g7ttC`8")).newInstance();
            if (localWindowsHandleGettable != null) {
              l1 = localWindowsHandleGettable.getHandleForCanvas(this);
            }
          }
          catch (Throwable localThrowable2)
          {
            localWindowsHandleGettable = null;
            Log.log(1, localThrowable2.toString() + "\n" + cj.IF_JAVA_VER_1_4_PUT_JRE_BIN_ON_SYS_PATH);
            throw new RuntimeException(localThrowable2.toString() + "\n" + cj.IF_JAVA_VER_1_4_PUT_JRE_BIN_ON_SYS_PATH);
          }
        }
      }
    }
    return l1;
  }
  
  public Dimension getPreferredSize()
  {
    Log.b(a("7ca=p5`p\037p5bF\004x5&v\fn<cqMm>&") + this + a("ptp\031w\"h|\003ep") + new Dimension(this.a, this.b));
    return new Dimension(this.a, this.b);
  }
  
  public Dimension getMinimumSize()
  {
    Log.b(a("7ca k>ox\030o\003oo\b\"3gy\001g4&z\003\"") + this + a("ptp\031w\"h|\003ep") + new Dimension(1, 1));
    return new Dimension(1, 1);
  }
  
  protected void zz_queueSet(String paramString1, String paramString2, boolean paramBoolean)
  {
    zz_queueSet(paramString1, paramString2, new Boolean(paramBoolean));
  }
  
  protected void zz_queueSet(String paramString1, String paramString2, char paramChar)
  {
    zz_queueSet(paramString1, paramString2, new Character(paramChar));
  }
  
  protected void zz_queueSet(String paramString1, String paramString2, double paramDouble)
  {
    zz_queueSet(paramString1, paramString2, new Double(paramDouble));
  }
  
  protected void zz_queueSet(String paramString1, String paramString2, float paramFloat)
  {
    zz_queueSet(paramString1, paramString2, new Float(paramFloat));
  }
  
  protected void zz_queueSet(String paramString1, String paramString2, int paramInt)
  {
    zz_queueSet(paramString1, paramString2, new Integer(paramInt));
  }
  
  protected void zz_queueSet(String paramString1, String paramString2, short paramShort)
  {
    zz_queueSet(paramString1, paramString2, new Short(paramShort));
  }
  
  protected void zz_queueSet(String paramString1, String paramString2, long paramLong)
  {
    zz_queueSet(paramString1, paramString2, new Long(paramLong));
  }
  
  protected void zz_get(String paramString, boolean[] paramArrayOfBoolean)
  {
    Boolean localBoolean = (Boolean)this.j.get(paramString);
    paramArrayOfBoolean[0] = (localBoolean == null ? 0 : localBoolean.booleanValue());
  }
  
  protected void zz_get(String paramString, char[] paramArrayOfChar)
  {
    Character localCharacter = (Character)this.j.get(paramString);
    paramArrayOfChar[0] = (localCharacter == null ? 0 : localCharacter.charValue());
  }
  
  protected void zz_get(String paramString, double[] paramArrayOfDouble)
  {
    Double localDouble = (Double)this.j.get(paramString);
    paramArrayOfDouble[0] = (localDouble == null ? 0.0D : localDouble.doubleValue());
  }
  
  protected void zz_get(String paramString, float[] paramArrayOfFloat)
  {
    Float localFloat = (Float)this.j.get(paramString);
    paramArrayOfFloat[0] = (localFloat == null ? 0.0F : localFloat.floatValue());
  }
  
  protected void zz_get(String paramString, int[] paramArrayOfInt)
  {
    Integer localInteger = (Integer)this.j.get(paramString);
    paramArrayOfInt[0] = (localInteger == null ? 0 : localInteger.intValue());
  }
  
  protected void zz_get(String paramString, short[] paramArrayOfShort)
  {
    Short localShort = (Short)this.j.get(paramString);
    paramArrayOfShort[0] = (localShort == null ? 0 : localShort.shortValue());
  }
  
  protected void zz_get(String paramString, long[] paramArrayOfLong)
  {
    Long localLong = (Long)this.j.get(paramString);
    paramArrayOfLong[0] = (localLong == null ? 0L : localLong.longValue());
  }
  
  protected void zz_get(String paramString, byte[] paramArrayOfByte)
  {
    Byte localByte = (Byte)this.j.get(paramString);
    paramArrayOfByte[0] = (localByte == null ? 0 : localByte.byteValue());
  }
  
  protected void zz_get(String paramString, Object[] paramArrayOfObject)
  {
    paramArrayOfObject[0] = this.j.get(paramString);
  }
  
  protected synchronized void zz_queueSet(String paramString1, String paramString2, Object paramObject)
  {
    this.j.put(paramString2.substring(3), paramObject);
    Hashtable localHashtable = (Hashtable)this.k.get(paramString1);
    if (localHashtable == null)
    {
      localHashtable = new Hashtable();
      this.k.put(paramString1, localHashtable);
    }
    localHashtable.put(paramString2, paramObject);
  }
  
  protected void zz_doQueuedSets(String paramString, Object paramObject)
  {
    int i2 = Dispatch.H;
    Hashtable localHashtable = (Hashtable)this.k.get(paramString);
    if (localHashtable == null) {
      return;
    }
    Class localClass = paramObject.getClass();
    Method[] arrayOfMethod = localClass.getMethods();
    Enumeration localEnumeration = localHashtable.keys();
    if (i2 != 0) {}
    while (localEnumeration.hasMoreElements())
    {
      String str = localEnumeration.nextElement() + "";
      Object localObject = localHashtable.get(str);
      int i1 = 0;
      if (i2 != 0) {}
      while (i1 < arrayOfMethod.length)
      {
        if (arrayOfMethod[i1].getName().equals(str)) {
          try
          {
            arrayOfMethod[i1].invoke(paramObject, new Object[] { localObject });
          }
          catch (Exception localException)
          {
            Log.a(cj.translate(cj.UNEXPECTED_INVOKING, localException, str));
            if (i2 == 0) {
              break;
            }
          }
        }
        i1++;
      }
    }
  }
  
  public void removeNotify()
  {
    Log.b(a("\"cx\002t5Hz\031k65\016c<jp\t\"?h5") + this);
    super.removeNotify();
    if ((Beans.isDesignTime()) && (!h)) {
      return;
    }
    setVisible(false);
  }
  
  public void addNotify()
  {
    super.addNotify();
    Log.b(a("1bq#m$os\024\"3gy\001g4&z\003\"") + this);
    if ((!System.getProperty(a("?u;\003c=c")).equals(a("\003s{\"Q"))) && (!System.getProperty(a("?u;\003c=c")).equals(a("\034o{\030z"))))
    {
      if (this.g != null)
      {
        if ((i) && (this.c == 0L))
        {
          Log.b(a("1bq#m$os\024\"3gy\001k>a5\fv$gv\005A?ha\037m<Rz:k>bz\032"));
          NativeObjRef.attachControlToWindow(this.g, this, a());
          this.c = this.g.windowHandleOfCreatedControl;
          this.g.resizeControl(this.c, this.l, this.m, this.n, this.o);
          return;
        }
        setVisible(true);
      }
    }
    else if (this.g != null) {
      setVisible(true);
    }
    if ((Beans.isDesignTime()) && (!h)) {
      return;
    }
    if ((!System.getProperty(a("?u;\003c=c")).equals(a("\003s{\"Q"))) && (!System.getProperty(a("?u;\003c=c")).equals(a("\034o{\030z"))))
    {
      this.d = a();
      this.g = new NativeObjRef(this.f, this.d, 0, 0, this.n, this.o);
      this.c = this.g.windowHandleOfCreatedControl;
    }
  }
  
  public void paint(Graphics paramGraphics)
  {
    super.paint(paramGraphics);
    if ((Beans.isDesignTime()) && (!h))
    {
      Log.b(a("\002ce\fk>r|\003eptp\016vpq(") + this.n + a("|&}P") + this.o);
      paramGraphics.setColor(Color.white);
      paramGraphics.fillRect(0, 0, this.n, this.o);
      paramGraphics.setColor(new Color(153, 153, 255));
      paramGraphics.drawRect(0, 0, this.n - 1, this.o - 1);
      String str1 = getClass().getName();
      String str2 = str1.substring(str1.lastIndexOf('.') + 1, str1.length());
      TextLayout localTextLayout = new TextLayout(str2, paramGraphics.getFont(), ((Graphics2D)paramGraphics).getFontRenderContext());
      paramGraphics.drawString(str2, (int)(this.n - localTextLayout.getBounds().getWidth()) / 2, this.o / 2);
      return;
    }
    if (((!System.getProperty(a("?u;\003c=c")).equals(a("\003s{\"Q"))) && (!System.getProperty(a("?u;\003c=c")).equals(a("\034o{\030z")))) || (this.c != 0L)) {
      return;
    }
    addNotify();
    this.d = a();
    if (this.g == null)
    {
      this.g = new NativeObjRef(this.f, 0L, this.l, this.m, this.n, this.o);
      this.g.reparentControl(this, this.c, this.d);
      if (Dispatch.H == 0) {}
    }
    else
    {
      NativeObjRef.attachControlToWindow(this.g, this, this.d);
    }
    this.c = this.g.windowHandleOfCreatedControl;
    this.g.resizeControl(this.c, this.l, this.m, this.n, this.o);
  }
  
  public void setSize(int paramInt1, int paramInt2)
  {
    super.setSize(paramInt1, paramInt2);
    Log.b(a("#ca>k*c=") + paramInt1 + a("|&") + paramInt2 + a("y&v\fn<cqMm>&") + this);
    this.n = paramInt1;
    this.a = paramInt1;
    this.o = paramInt2;
    this.b = paramInt2;
    if (this.g != null)
    {
      if (this.c != 0L)
      {
        this.g.resizeControl(this.c, this.l, this.m, paramInt1, paramInt2);
        if (Dispatch.H == 0) {}
      }
    }
    else {
      Log.b(a("\"cf\004x5Ez\003v\"iyMl?r5\016c<jp\t\"2cv\fw#c5\003c$oc\bM2lG\bdp;(Ml%jy"));
    }
  }
  
  public void setSize(Dimension paramDimension)
  {
    super.setSize(paramDimension);
    Log.b(a("#ca>k*c=\tk=c{\036k?h<Ma1jy\bfpi{M") + this);
    this.n = paramDimension.width;
    this.a = paramDimension.width;
    this.o = paramDimension.height;
    this.b = paramDimension.height;
    if (this.g != null)
    {
      if (this.c != 0L)
      {
        this.g.resizeControl(this.c, this.l, this.m, this.n, this.o);
        if (Dispatch.H == 0) {}
      }
    }
    else {
      Log.b(a("\"cf\004x5Ez\003v\"iyMl?r5\016c<jp\t\"2cv\fw#c5\003c$oc\bM2lG\bdp;(Ml%jy"));
    }
  }
  
  public void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.setBounds(paramInt1, paramInt2, paramInt3, paramInt4);
    Log.b(a("#ca/m%hq\036*") + paramInt1 + "," + paramInt2 + "," + paramInt3 + "," + paramInt4 + a("y&v\fn<cqMm>&") + toString());
    this.l = paramInt1;
    this.m = paramInt2;
    this.n = paramInt3;
    this.a = paramInt3;
    this.o = paramInt4;
    this.b = paramInt4;
    if (this.g != null)
    {
      if (this.c != 0L)
      {
        this.g.resizeControl(this.c, paramInt1, paramInt2, paramInt3, paramInt4);
        if (Dispatch.H == 0) {}
      }
    }
    else {
      Log.b(a("\"cf\004x5Ez\003v\"iyMl?r5\016c<jp\t\"2cv\fw#c5\003c$oc\bM2lG\bdp;(Ml%jy"));
    }
  }
  
  public void setBounds(Rectangle paramRectangle)
  {
    super.setBounds(paramRectangle);
    Log.b(a("#ca/m%hq\036\"3gy\001g4&z\003\"") + this);
    this.l = paramRectangle.x;
    this.m = paramRectangle.y;
    this.n = paramRectangle.width;
    this.a = paramRectangle.width;
    this.o = paramRectangle.height;
    this.b = paramRectangle.height;
    if (this.g != null)
    {
      if (this.c != 0L)
      {
        this.g.resizeControl(this.c, this.l, this.m, this.n, this.o);
        if (Dispatch.H == 0) {}
      }
    }
    else {
      Log.b(a("\"cf\004x5Ez\003v\"iyMl?r5\016c<jp\t\"2cv\fw#c5\003c$oc\bM2lG\bdp;(Ml%jy"));
    }
  }
  
  protected Object getObjRef()
  {
    return this.g;
  }
  
  public abstract void release();
  
  public abstract Dispatch getJintegraDispatch();
  
  static
  {
    if (!Dispatch.a(true)) {
      throw new RuntimeException(cj.ATTEMPT_TO_USE_ACTIVEX_IN_NON_NATIVE_MODE);
    }
  }
  
  private static String a(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i1 = arrayOfChar.length;
    int i2 = 0;
    while (i2 < i1)
    {
      switch (i2 % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      6[21] = ((char)(0x6D ^ 0x2));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.jintegra.Ocx
 * JD-Core Version:    0.7.0.1
 */