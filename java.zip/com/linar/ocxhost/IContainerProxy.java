package com.linar.ocxhost;

import com.linar.jintegra.AuthInfo;
import com.linar.jintegra.AutomationException;
import com.linar.jintegra.Dispatch;
import com.linar.jintegra.InterfaceDesc;
import com.linar.jintegra.Log;
import com.linar.jintegra.MemberDesc;
import com.linar.jintegra.Param;
import com.linar.jintegra.Variant;
import java.io.IOException;
import java.io.Serializable;
import java.net.UnknownHostException;

public class IContainerProxy
  extends Dispatch
  implements IContainer, Serializable
{
  public static final Class targetClass;
  static final int I = 0;
  static Class J;
  static Class K;
  static Class L;
  public static int M;
  
  protected String getJintegraVersion()
  {
    return d("ru\030");
  }
  
  public IContainerProxy(String paramString1, String paramString2, AuthInfo paramAuthInfo)
    throws UnknownHostException, IOException
  {
    super(paramString1, d("q=K7m\":I~=p=\034~=r?\036~nwl\025~>soNgjw=\030c>s"), paramString2, paramAuthInfo);
  }
  
  public IContainerProxy() {}
  
  public IContainerProxy(Object paramObject)
    throws IOException
  {
    super(paramObject, d("q=K7m\":I~=p=\034~=r?\036~nwl\025~>soNgjw=\030c>s"));
  }
  
  protected IContainerProxy(Object paramObject, String paramString)
    throws IOException
  {
    super(paramObject, paramString);
  }
  
  public IContainerProxy(String paramString1, String paramString2, boolean paramBoolean)
    throws UnknownHostException, IOException
  {
    super(paramString1, d("q=K7m\":I~=p=\034~=r?\036~nwl\025~>soNgjw=\030c>s"), paramString2, null);
  }
  
  protected IContainerProxy(String paramString1, String paramString2, String paramString3, AuthInfo paramAuthInfo)
    throws IOException
  {
    super(paramString1, paramString2, paramString3, paramAuthInfo);
  }
  
  public void addListener(String paramString, Object paramObject1, Object paramObject2)
    throws IOException
  {
    super.addListener(paramString, paramObject1, paramObject2);
  }
  
  public void removeListener(String paramString, Object paramObject)
    throws IOException
  {
    super.removeListener(paramString, paramObject);
  }
  
  public Object getPropertyByName(String paramString)
    throws NoSuchFieldException, IOException, AutomationException
  {
    Variant[] arrayOfVariant = new Variant[0];
    return super.invoke(paramString, super.getDispatchIdOfName(paramString), 2L, arrayOfVariant).getVARIANT();
  }
  
  public Object getPropertyByName(String paramString, Object paramObject)
    throws NoSuchFieldException, IOException, AutomationException
  {
    Variant[] arrayOfVariant = { paramObject == null ? new Variant(d("13^"), 10, 2147614724L) : new Variant(d("13^"), 12, paramObject) };
    return super.invoke(paramString, super.getDispatchIdOfName(paramString), 2L, arrayOfVariant).getVARIANT();
  }
  
  public Object invokeMethodByName(String paramString, Object[] paramArrayOfObject)
    throws NoSuchMethodException, IOException, AutomationException
  {
    int j = M;
    Variant[] arrayOfVariant = new Variant[paramArrayOfObject.length];
    int i = 0;
    if (j != 0) {
      arrayOfVariant[i] = (paramArrayOfObject[i] == null ? new Variant("p" + i, 10, 2147614724L) : new Variant("p" + i, 12, paramArrayOfObject[i]));
    }
    for (;;)
    {
      i++;
      if (i < paramArrayOfObject.length) {
        break;
      }
      try
      {
        if (j != 0) {
          continue;
        }
        return super.invoke(paramString, super.getDispatchIdOfName(paramString), 1L, arrayOfVariant).getVARIANT();
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        throw new NoSuchMethodException(d("\0273H!ic2^sb,{@6x+4Iso\"7A6hc") + paramString);
      }
    }
  }
  
  public Object create(String paramString)
    throws IOException, AutomationException
  {
    Object[] arrayOfObject1 = { null };
    Object[] arrayOfObject2 = { paramString, arrayOfObject1 };
    vtblInvoke(d(" )H2x&"), 7, arrayOfObject2);
    return arrayOfObject1[0];
  }
  
  public void setVisible(boolean paramBoolean)
    throws IOException, AutomationException
  {
    int i = M;
    Object[] arrayOfObject1 = { null };
    Object[] arrayOfObject2 = { new Boolean(paramBoolean), arrayOfObject1 };
    vtblInvoke(d("0>Y\005e02O?i"), 8, arrayOfObject2);
    if (Log.r)
    {
      i++;
      M = i;
    }
  }
  
  public void move(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws IOException, AutomationException
  {
    int i = M;
    Object[] arrayOfObject1 = { null };
    Object[] arrayOfObject2 = { new Integer(paramInt1), new Integer(paramInt2), new Integer(paramInt3), new Integer(paramInt4), arrayOfObject1 };
    vtblInvoke(d(".4[6"), 9, arrayOfObject2);
    if (i != 0) {
      Log.r = !Log.r;
    }
  }
  
  public IContainer newContainer()
    throws IOException, AutomationException
  {
    IContainer[] arrayOfIContainer = { null };
    Object[] arrayOfObject = { arrayOfIContainer };
    vtblInvoke(d("->Z\020c-/L:b&)"), 10, arrayOfObject);
    return arrayOfIContainer[0];
  }
  
  static Class c(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }
  
  static
  {
    JIntegraInit.init();
    targetClass = J == null ? (IContainerProxy.J = c(d(" 4@}`*5L!\",8U;c0/\003\032O,5Y2e->_"))) : J;
    InterfaceDesc.add(d("q=K7m\":I~=p=\034~=r?\036~nwl\025~>soNgjw=\030c>s"), K == null ? (IContainerProxy.K = c(d(" 4@}`*5L!\",8U;c0/\003\032O,5Y2e->_\003~,#T"))) : K, null, 7, new MemberDesc[] { new MemberDesc(d(" )H2x&"), new Class[] { L == null ? (IContainerProxy.L = c(d("):[2\"/:C4\"\020/_:b$"))) : L }, new Param[] { new Param(d("3)B4E'"), 8, 2, 8, null, null), new Param(d("73H\020c-/_<`"), 9, 20, 8, null, null) }), new MemberDesc(d("0>Y\005e02O?i"), new Class[] { Boolean.TYPE }, new Param[] { new Param("v", 11, 2, 8, null, null), new Param("", 24, 8, -842150451, null, null) }), new MemberDesc(d(".4[6"), new Class[] { Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE }, new Param[] { new Param("x", 3, 2, 8, null, null), new Param("y", 3, 2, 8, null, null), new Param(d("42I'd"), 3, 2, 8, null, null), new Param(d("+>D4d7"), 3, 2, 8, null, null), new Param("", 24, 8, -842150451, null, null) }), new MemberDesc(d("->Z\020c-/L:b&)"), new Class[0], new Param[] { new Param(d("1-"), 29, 20, 4, d("q=K7m\":I~=p=\034~=r?\036~nwl\025~>soNgjw=\030c>s"), K == null ? (IContainerProxy.K = c(d(" 4@}`*5L!\",8U;c0/\003\032O,5Y2e->_\003~,#T"))) : K) }) });
  }
  
  private static String d(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    int j = 0;
    while (j < i)
    {
      switch (j % 5)
      {
      case 0: 
        break;
      case 1: 
        break;
      case 2: 
        break;
      case 3: 
        break;
      }
      91[45] = ((char)(0x53 ^ 0xC));
    }
    return new String(arrayOfChar);
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.ocxhost.IContainerProxy
 * JD-Core Version:    0.7.0.1
 */