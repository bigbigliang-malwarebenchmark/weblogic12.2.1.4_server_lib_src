package com.linar.ocxhost;

import com.linar.jintegra.AutomationException;
import java.io.IOException;

public abstract interface IContainer
{
  public static final int IID2ffdaaad_13f1_11d3_b478_204c4f4f5020 = 1;
  public static final int xxDummy = 0;
  public static final String IID = "2ffdaaad-13f1-11d3-b478-204c4f4f5020";
  public static final String DISPID_1_NAME = "create";
  public static final String DISPID_2_NAME = "setVisible";
  public static final String DISPID_3_NAME = "move";
  public static final String DISPID_4_NAME = "newContainer";
  
  public abstract Object create(String paramString)
    throws IOException, AutomationException;
  
  public abstract void setVisible(boolean paramBoolean)
    throws IOException, AutomationException;
  
  public abstract void move(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws IOException, AutomationException;
  
  public abstract IContainer newContainer()
    throws IOException, AutomationException;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.ocxhost.IContainer
 * JD-Core Version:    0.7.0.1
 */