package com.linar.ocxhost;

public class JIntegraInit
{
  static boolean a = false;
  
  public static void init()
  {
    if (a) {
      return;
    }
    a = true;
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.ocxhost.JIntegraInit
 * JD-Core Version:    0.7.0.1
 */