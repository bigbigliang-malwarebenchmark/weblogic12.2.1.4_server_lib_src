package com.linar.spi;

public abstract interface License
{
  public abstract boolean check(boolean paramBoolean, StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.spi.License
 * JD-Core Version:    0.7.0.1
 */