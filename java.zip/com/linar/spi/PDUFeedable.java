package com.linar.spi;

import java.io.IOException;
import java.io.InputStream;

public abstract interface PDUFeedable
{
  public abstract void newPDU(InputStream paramInputStream)
    throws IOException;
  
  public abstract void connectionClosed();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.spi.PDUFeedable
 * JD-Core Version:    0.7.0.1
 */