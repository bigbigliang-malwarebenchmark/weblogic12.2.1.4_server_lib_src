package com.linar.spi;

import java.io.OutputStream;
import java.net.InetAddress;

public abstract interface ConnectionHandler
{
  public abstract PDUFeedable newConnection(OutputStream paramOutputStream, InetAddress paramInetAddress, int paramInt);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.spi.ConnectionHandler
 * JD-Core Version:    0.7.0.1
 */