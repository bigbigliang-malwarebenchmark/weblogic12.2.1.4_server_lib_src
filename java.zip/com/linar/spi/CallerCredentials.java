package com.linar.spi;

public abstract interface CallerCredentials
{
  public abstract String getCallerDomain();
  
  public abstract String getCallerUser();
  
  public abstract boolean isCallerAuthenticated();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.spi.CallerCredentials
 * JD-Core Version:    0.7.0.1
 */