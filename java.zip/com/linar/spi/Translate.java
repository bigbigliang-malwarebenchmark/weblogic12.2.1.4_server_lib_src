package com.linar.spi;

public abstract interface Translate
{
  public abstract String textOf(String paramString1, String paramString2);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.spi.Translate
 * JD-Core Version:    0.7.0.1
 */