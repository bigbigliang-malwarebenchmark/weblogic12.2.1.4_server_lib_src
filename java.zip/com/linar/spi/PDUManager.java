package com.linar.spi;

import java.io.IOException;
import java.io.OutputStream;
import java.net.BindException;

public abstract interface PDUManager
{
  public abstract void init(int paramInt);
  
  public abstract String[] getLocalHostNames();
  
  public abstract int getLocalPort();
  
  public abstract void registerConnectionHandler(ConnectionHandler paramConnectionHandler);
  
  public abstract OutputStream openConnection(String paramString, int paramInt1, int paramInt2, int paramInt3, PDUFeedable paramPDUFeedable)
    throws BindException, IOException;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.linar.spi.PDUManager
 * JD-Core Version:    0.7.0.1
 */