package com.bea.common.security.saml2;

public abstract interface SingleSignOnServicesConfigSpi
{
  public abstract String getContactPersonGivenName();
  
  public abstract String getContactPersonSurName();
  
  public abstract String getContactPersonType();
  
  public abstract String getContactPersonCompany();
  
  public abstract String getContactPersonTelephoneNumber();
  
  public abstract String getContactPersonEmailAddress();
  
  public abstract String getOrganizationName();
  
  public abstract String getOrganizationURL();
  
  public abstract String getPublishedSiteURL();
  
  public abstract String getEntityID();
  
  public abstract String getErrorPath();
  
  public abstract boolean isServiceProviderEnabled();
  
  public abstract String getDefaultURL();
  
  public abstract boolean isServiceProviderArtifactBindingEnabled();
  
  public abstract boolean isServiceProviderPOSTBindingEnabled();
  
  public abstract String getServiceProviderPreferredBinding();
  
  public abstract boolean isSignAuthnRequests();
  
  public abstract boolean isWantAssertionsSigned();
  
  public abstract String getSSOSigningKeyAlias();
  
  public abstract String getSSOSigningKeyPassPhrase();
  
  public abstract byte[] getSSOSigningKeyPassPhraseEncrypted();
  
  public abstract boolean isForceAuthn();
  
  public abstract boolean isPassive();
  
  public abstract boolean isIdentityProviderEnabled();
  
  public abstract boolean isIdentityProviderArtifactBindingEnabled();
  
  public abstract boolean isIdentityProviderPOSTBindingEnabled();
  
  public abstract boolean isIdentityProviderRedirectBindingEnabled();
  
  public abstract String getIdentityProviderPreferredBinding();
  
  public abstract boolean isWantAuthnRequestsSigned();
  
  public abstract String getLoginURL();
  
  public abstract String getLoginReturnQueryParameter();
  
  public abstract boolean isRecipientCheckEnabled();
  
  public abstract boolean isPOSTOneUseCheckEnabled();
  
  public abstract String getTransportLayerSecurityKeyAlias();
  
  public abstract String getTransportLayerSecurityKeyPassPhrase();
  
  public abstract byte[] getTransportLayerSecurityKeyPassPhraseEncrypted();
  
  public abstract String getBasicAuthUsername();
  
  public abstract String getBasicAuthPassword();
  
  public abstract byte[] getBasicAuthPasswordEncrypted();
  
  public abstract boolean isWantArtifactRequestsSigned();
  
  public abstract boolean isWantTransportLayerSecurityClientAuthentication();
  
  public abstract boolean isWantBasicAuthClientAuthentication();
  
  public abstract int getAuthnRequestMaxCacheSize();
  
  public abstract int getAuthnRequestTimeout();
  
  public abstract int getArtifactMaxCacheSize();
  
  public abstract int getArtifactTimeout();
  
  public abstract boolean isReplicatedCacheEnabled();
  
  public abstract boolean isAssertionEncryptionEnabled();
  
  public abstract String getDataEncryptionAlgorithm();
  
  public abstract String getKeyEncryptionAlgorithm();
  
  public abstract String[] getMetadataEncryptionAlgorithms();
  
  public abstract String getAssertionEncryptionDecryptionKeyAlias();
  
  public abstract String getAssertionEncryptionDecryptionKeyPassPhrase();
  
  public abstract byte[] getAssertionEncryptionDecryptionKeyPassPhraseEncrypted();
  
  public abstract String[] getAllowedTargetHosts();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.saml2.SingleSignOnServicesConfigSpi
 * JD-Core Version:    0.7.0.1
 */