/*  1:   */ package com.bea.common.security.xacml;
/*  2:   */ 
/*  3:   */ public class InvalidXACMLPolicyException
/*  4:   */   extends XACMLException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 572382776770159353L;
/*  7:   */   
/*  8:   */   public InvalidXACMLPolicyException(String msg)
/*  9:   */   {
/* 10:13 */     super(msg);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public InvalidXACMLPolicyException(Throwable t)
/* 14:   */   {
/* 15:17 */     super(t);
/* 16:   */   }
/* 17:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.InvalidXACMLPolicyException
 * JD-Core Version:    0.7.0.1
 */