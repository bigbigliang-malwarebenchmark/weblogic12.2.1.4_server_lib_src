/*  1:   */ package com.bea.common.security.xacml;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.Collection;
/*  5:   */ import java.util.Iterator;
/*  6:   */ 
/*  7:   */ public class CollectionUtil
/*  8:   */ {
/*  9:   */   public static <X> boolean equals(Collection<X> one, Collection<X> two)
/* 10:   */   {
/* 11:32 */     if (one == two) {
/* 12:33 */       return true;
/* 13:   */     }
/* 14:36 */     if ((one == null) || (two == null) || (one.size() != two.size())) {
/* 15:37 */       return false;
/* 16:   */     }
/* 17:40 */     Collection<X> temp = new ArrayList(one);
/* 18:41 */     Iterator<X> it = two.iterator();
/* 19:42 */     while (it.hasNext()) {
/* 20:43 */       if (!temp.remove(it.next())) {
/* 21:44 */         return false;
/* 22:   */       }
/* 23:   */     }
/* 24:48 */     return temp.isEmpty();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public static <X> boolean equalsWithSequence(Collection<X> one, Collection<X> two)
/* 28:   */   {
/* 29:55 */     if (one == two) {
/* 30:56 */       return true;
/* 31:   */     }
/* 32:59 */     if ((one == null) || (two == null) || (one.size() != two.size())) {
/* 33:60 */       return false;
/* 34:   */     }
/* 35:62 */     Iterator<X> ite1 = one.iterator();
/* 36:63 */     Iterator<X> ite2 = two.iterator();
/* 37:64 */     while (ite1.hasNext()) {
/* 38:65 */       if (!ite1.next().equals(ite2.next())) {
/* 39:66 */         return false;
/* 40:   */       }
/* 41:   */     }
/* 42:68 */     return true;
/* 43:   */   }
/* 44:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.CollectionUtil
 * JD-Core Version:    0.7.0.1
 */