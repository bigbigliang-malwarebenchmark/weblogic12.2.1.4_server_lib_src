package com.bea.common.security.xacml.policy;

public abstract interface PolicySetMember {}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.policy.PolicySetMember
 * JD-Core Version:    0.7.0.1
 */