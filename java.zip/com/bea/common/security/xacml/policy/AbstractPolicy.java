/*   1:    */ package com.bea.common.security.xacml.policy;
/*   2:    */ 
/*   3:    */ import com.bea.common.security.utils.HashCodeUtil;
/*   4:    */ import com.bea.common.security.xacml.CollectionUtil;
/*   5:    */ import com.bea.common.security.xacml.DocumentParseException;
/*   6:    */ import com.bea.common.security.xacml.URI;
/*   7:    */ import com.bea.common.security.xacml.attr.AttributeRegistry;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.Collections;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Map;
/*  14:    */ import org.w3c.dom.NamedNodeMap;
/*  15:    */ import org.w3c.dom.Node;
/*  16:    */ import org.w3c.dom.NodeList;
/*  17:    */ 
/*  18:    */ public abstract class AbstractPolicy
/*  19:    */   extends PolicySchemaObject
/*  20:    */   implements PolicySetMember
/*  21:    */ {
/*  22:    */   public static final String VERSION_DEFAULT = "1.0";
/*  23:    */   private String description;
/*  24:    */   private Target target;
/*  25:    */   private List<CombinerParameters> combinerParameters;
/*  26:    */   private URI id;
/*  27:    */   private String version;
/*  28:    */   private URI combiningAlgId;
/*  29:    */   private Obligations obligations;
/*  30:    */   
/*  31:    */   public AbstractPolicy(URI id, Target target, URI combiningAlgId)
/*  32:    */   {
/*  33: 61 */     this(id, target, combiningAlgId, null);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public AbstractPolicy(URI id, Target target, URI combiningAlgId, String description)
/*  37:    */   {
/*  38: 79 */     this(id, target, combiningAlgId, description, "1.0");
/*  39:    */   }
/*  40:    */   
/*  41:    */   public AbstractPolicy(URI id, Target target, URI combiningAlgId, String description, String version)
/*  42:    */   {
/*  43: 99 */     this(id, target, combiningAlgId, description, version, null, null);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public AbstractPolicy(URI id, Target target, URI combiningAlgId, String description, String version, List<CombinerParameters> combinerParameters, Obligations obligations)
/*  47:    */   {
/*  48:124 */     this.description = description;
/*  49:125 */     this.target = target;
/*  50:126 */     this.combinerParameters = (combinerParameters != null ? 
/*  51:127 */       Collections.unmodifiableList(combinerParameters) : null);
/*  52:128 */     this.id = id;
/*  53:129 */     this.version = version;
/*  54:130 */     this.combiningAlgId = combiningAlgId;
/*  55:131 */     this.obligations = obligations;
/*  56:    */   }
/*  57:    */   
/*  58:    */   protected AbstractPolicy(AttributeRegistry registry, Node root, String policyPrefix, String combiningName)
/*  59:    */     throws DocumentParseException, com.bea.common.security.xacml.URISyntaxException
/*  60:    */   {
/*  61:155 */     NamedNodeMap attrs = root.getAttributes();
/*  62:    */     try
/*  63:    */     {
/*  64:159 */       this.id = new URI(attrs.getNamedItem(policyPrefix + "Id").getNodeValue());
/*  65:    */     }
/*  66:    */     catch (java.net.URISyntaxException use)
/*  67:    */     {
/*  68:161 */       throw new com.bea.common.security.xacml.URISyntaxException(use);
/*  69:    */     }
/*  70:165 */     Node versionNode = attrs.getNamedItem("Version");
/*  71:166 */     if (versionNode != null) {
/*  72:167 */       this.version = versionNode.getNodeValue();
/*  73:    */     } else {
/*  74:170 */       this.version = "1.0";
/*  75:    */     }
/*  76:    */     try
/*  77:    */     {
/*  78:175 */       this.combiningAlgId = new URI(attrs.getNamedItem(combiningName).getNodeValue());
/*  79:    */     }
/*  80:    */     catch (java.net.URISyntaxException use)
/*  81:    */     {
/*  82:177 */       throw new com.bea.common.security.xacml.URISyntaxException(use);
/*  83:    */     }
/*  84:180 */     this.combinerParameters = new ArrayList();
/*  85:    */     
/*  86:    */ 
/*  87:183 */     NodeList children = root.getChildNodes();
/*  88:184 */     for (int i = 0; i < children.getLength(); i++)
/*  89:    */     {
/*  90:185 */       Node child = children.item(i);
/*  91:186 */       String cname = getLocalName(child);
/*  92:188 */       if (cname.equals("Description"))
/*  93:    */       {
/*  94:189 */         Node dchild = child.getFirstChild();
/*  95:190 */         if (dchild != null) {
/*  96:191 */           this.description = dchild.getNodeValue();
/*  97:    */         }
/*  98:    */       }
/*  99:193 */       else if (cname.equals("Target"))
/* 100:    */       {
/* 101:194 */         this.target = new Target(registry, child);
/* 102:    */       }
/* 103:195 */       else if (cname.equals("Obligations"))
/* 104:    */       {
/* 105:196 */         this.obligations = new Obligations(registry, child);
/* 106:    */       }
/* 107:197 */       else if (cname.equals("CombinerParameters"))
/* 108:    */       {
/* 109:198 */         this.combinerParameters.add(new CombinerParameters(registry, child));
/* 110:    */       }
/* 111:    */     }
/* 112:203 */     this.combinerParameters = (this.combinerParameters.isEmpty() ? null : Collections.unmodifiableList(this.combinerParameters));
/* 113:    */   }
/* 114:    */   
/* 115:    */   protected abstract String getPolicyPrefix();
/* 116:    */   
/* 117:    */   protected abstract String getCombiningName();
/* 118:    */   
/* 119:    */   public abstract IdReference getReference();
/* 120:    */   
/* 121:    */   public void encodeAttributes(PrintStream ps)
/* 122:    */   {
/* 123:225 */     ps.print(' ');
/* 124:226 */     ps.print(getPolicyPrefix());
/* 125:227 */     ps.print("Id=\"");
/* 126:228 */     ps.print(this.id);
/* 127:229 */     ps.print("\"");
/* 128:230 */     if ((this.version != null) && (!"1.0".equals(this.version)))
/* 129:    */     {
/* 130:231 */       ps.print(" Version=\"");
/* 131:232 */       ps.print(this.version);
/* 132:233 */       ps.print("\"");
/* 133:    */     }
/* 134:235 */     ps.print(" ");
/* 135:236 */     ps.print(getCombiningName());
/* 136:237 */     ps.print("=\"");
/* 137:238 */     ps.print(this.combiningAlgId);
/* 138:239 */     ps.print("\"");
/* 139:    */   }
/* 140:    */   
/* 141:    */   protected void encodeDescription(PrintStream ps)
/* 142:    */   {
/* 143:246 */     if (this.description != null)
/* 144:    */     {
/* 145:247 */       ps.print("<Description>");
/* 146:248 */       if ((this.description.startsWith("<![CDATA[")) && (this.description.endsWith("]]>"))) {
/* 147:249 */         ps.print(this.description);
/* 148:    */       } else {
/* 149:251 */         ps.print(escapeXML(this.description));
/* 150:    */       }
/* 151:253 */       ps.print("</Description>");
/* 152:    */     }
/* 153:    */   }
/* 154:    */   
/* 155:    */   protected void encodeTarget(Map<String, String> nsMap, PrintStream ps)
/* 156:    */   {
/* 157:261 */     if (this.target != null) {
/* 158:262 */       this.target.encode(nsMap, ps);
/* 159:    */     }
/* 160:    */   }
/* 161:    */   
/* 162:    */   protected void encodeCombinerParameters(Map<String, String> nsMap, PrintStream ps)
/* 163:    */   {
/* 164:271 */     if (this.combinerParameters != null)
/* 165:    */     {
/* 166:272 */       Iterator<CombinerParameters> it = this.combinerParameters.iterator();
/* 167:273 */       while (it.hasNext())
/* 168:    */       {
/* 169:274 */         CombinerParameters cp = (CombinerParameters)it.next();
/* 170:275 */         cp.encode(nsMap, ps);
/* 171:    */       }
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   protected void encodeObligations(Map<String, String> nsMap, PrintStream ps)
/* 176:    */   {
/* 177:284 */     if (this.obligations != null) {
/* 178:285 */       this.obligations.encode(nsMap, ps);
/* 179:    */     }
/* 180:    */   }
/* 181:    */   
/* 182:    */   public boolean equals(Object other)
/* 183:    */   {
/* 184:293 */     if (this == other) {
/* 185:294 */       return true;
/* 186:    */     }
/* 187:296 */     if (!(other instanceof AbstractPolicy)) {
/* 188:297 */       return false;
/* 189:    */     }
/* 190:299 */     AbstractPolicy o = (AbstractPolicy)other;
/* 191:301 */     if (((this.target == o.target) || ((this.target != null) && (this.target.equals(o.target)))) && ((this.id == o.id) || ((this.id != null) && 
/* 192:302 */       (this.id.equals(o.id)))) && 
/* 193:303 */       (CollectionUtil.equals(this.combinerParameters, o.combinerParameters)) && ((this.version == o.version) || ((this.version != null) && 
/* 194:    */       
/* 195:305 */       (this.version.equals(o.version))) || ((this.version == null) && 
/* 196:306 */       ("1.0".equals(o.version))) || ((o.version == null) && 
/* 197:307 */       ("1.0".equals(this.version))))) {
/* 198:307 */       if (this.combiningAlgId != o.combiningAlgId)
/* 199:    */       {
/* 200:307 */         if (this.combiningAlgId != null) {
/* 201:309 */           if (!this.combiningAlgId.equals(o.combiningAlgId)) {}
/* 202:    */         }
/* 203:    */       }
/* 204:309 */       else if (this.obligations != o.obligations) {
/* 205:309 */         if (this.obligations == null) {
/* 206:    */           break label237;
/* 207:    */         }
/* 208:    */       }
/* 209:    */     }
/* 210:    */     label237:
/* 211:301 */     return 
/* 212:    */     
/* 213:    */ 
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:309 */       this.obligations
/* 220:    */       
/* 221:311 */       .equals(o.obligations);
/* 222:    */   }
/* 223:    */   
/* 224:    */   public int internalHashCode()
/* 225:    */   {
/* 226:318 */     int result = 23;
/* 227:    */     
/* 228:    */ 
/* 229:321 */     result = HashCodeUtil.hash(result, this.target);
/* 230:322 */     result = HashCodeUtil.hash(result, this.id);
/* 231:323 */     result = HashCodeUtil.hash(result, this.combinerParameters);
/* 232:324 */     result = HashCodeUtil.hash(result, this.version != null ? this.version : "1.0");
/* 233:    */     
/* 234:326 */     result = HashCodeUtil.hash(result, this.combiningAlgId);
/* 235:327 */     result = HashCodeUtil.hash(result, this.obligations);
/* 236:328 */     return result;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public String getDescription()
/* 240:    */   {
/* 241:338 */     return this.description;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public Target getTarget()
/* 245:    */   {
/* 246:348 */     return this.target;
/* 247:    */   }
/* 248:    */   
/* 249:    */   public List<CombinerParameters> getCombinerParameters()
/* 250:    */   {
/* 251:358 */     return this.combinerParameters;
/* 252:    */   }
/* 253:    */   
/* 254:    */   public URI getId()
/* 255:    */   {
/* 256:368 */     return this.id;
/* 257:    */   }
/* 258:    */   
/* 259:    */   public String getVersion()
/* 260:    */   {
/* 261:378 */     return this.version == null ? "1.0" : this.version;
/* 262:    */   }
/* 263:    */   
/* 264:    */   public URI getCombiningAlgId()
/* 265:    */   {
/* 266:388 */     return this.combiningAlgId;
/* 267:    */   }
/* 268:    */   
/* 269:    */   public Obligations getObligations()
/* 270:    */   {
/* 271:398 */     return this.obligations;
/* 272:    */   }
/* 273:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.policy.AbstractPolicy
 * JD-Core Version:    0.7.0.1
 */