/*   1:    */ package com.bea.common.security.xacml.policy;
/*   2:    */ 
/*   3:    */ import com.bea.common.security.utils.HashCodeUtil;
/*   4:    */ import com.bea.common.security.xacml.CollectionUtil;
/*   5:    */ import com.bea.common.security.xacml.DocumentParseException;
/*   6:    */ import com.bea.common.security.xacml.SchemaObject;
/*   7:    */ import com.bea.common.security.xacml.URI;
/*   8:    */ import com.bea.common.security.xacml.URISyntaxException;
/*   9:    */ import com.bea.common.security.xacml.attr.AttributeRegistry;
/*  10:    */ import java.io.PrintStream;
/*  11:    */ import java.util.ArrayList;
/*  12:    */ import java.util.Collections;
/*  13:    */ import java.util.Iterator;
/*  14:    */ import java.util.List;
/*  15:    */ import java.util.Map;
/*  16:    */ import org.w3c.dom.Node;
/*  17:    */ import org.w3c.dom.NodeList;
/*  18:    */ 
/*  19:    */ public class PolicySet
/*  20:    */   extends AbstractPolicy
/*  21:    */ {
/*  22:    */   private static final long serialVersionUID = -6991240254829029111L;
/*  23:    */   private List<PolicyCombinerParameters> policyCombinerParameters;
/*  24:    */   private List<PolicySetCombinerParameters> policySetCombinerParameters;
/*  25:    */   private List<PolicySetMember> policiesPolicySetsAndReferences;
/*  26:    */   private PolicySetDefaults defaults;
/*  27:    */   
/*  28:    */   public PolicySet(URI id, Target target, URI combiningAlgId, List<PolicySetMember> policiesPolicySetsAndReferences)
/*  29:    */   {
/*  30: 54 */     super(id, target, combiningAlgId);
/*  31: 55 */     this.policiesPolicySetsAndReferences = (policiesPolicySetsAndReferences != null ? 
/*  32: 56 */       Collections.unmodifiableList(policiesPolicySetsAndReferences) : null);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public PolicySet(URI id, Target target, URI combiningAlgId, String description, List<PolicySetMember> policiesPolicySetsAndReferences)
/*  36:    */   {
/*  37: 77 */     super(id, target, combiningAlgId, description);
/*  38: 78 */     this.policiesPolicySetsAndReferences = (policiesPolicySetsAndReferences != null ? 
/*  39: 79 */       Collections.unmodifiableList(policiesPolicySetsAndReferences) : null);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public PolicySet(URI id, Target target, URI combiningAlgId, String description, String version, List<PolicySetMember> policiesPolicySetsAndReferences)
/*  43:    */   {
/*  44:103 */     super(id, target, combiningAlgId, description, version);
/*  45:104 */     this.policiesPolicySetsAndReferences = (policiesPolicySetsAndReferences != null ? 
/*  46:105 */       Collections.unmodifiableList(policiesPolicySetsAndReferences) : null);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public PolicySet(URI id, Target target, URI combiningAlgId, String description, String version, PolicySetDefaults defaults, List<CombinerParameters> combinerParameters, Obligations obligations, List<PolicySetMember> policiesPolicySetsAndReferences)
/*  50:    */   {
/*  51:136 */     super(id, target, combiningAlgId, description, version, combinerParameters, obligations);
/*  52:    */     
/*  53:138 */     this.policiesPolicySetsAndReferences = (policiesPolicySetsAndReferences != null ? 
/*  54:139 */       Collections.unmodifiableList(policiesPolicySetsAndReferences) : null);
/*  55:    */     
/*  56:141 */     this.defaults = defaults;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public PolicySet(URI id, Target target, URI combiningAlgId, String description, String version, PolicySetDefaults defaults, List<CombinerParameters> combinerParameters, Obligations obligations, List<PolicySetMember> policiesPolicySetsAndReferences, List<PolicyCombinerParameters> policyCombinerParameters, List<PolicySetCombinerParameters> policySetCombinerParameters)
/*  60:    */   {
/*  61:177 */     super(id, target, combiningAlgId, description, version, combinerParameters, obligations);
/*  62:    */     
/*  63:179 */     this.policiesPolicySetsAndReferences = (policiesPolicySetsAndReferences != null ? 
/*  64:180 */       Collections.unmodifiableList(policiesPolicySetsAndReferences) : null);
/*  65:    */     
/*  66:182 */     this.policyCombinerParameters = (policyCombinerParameters != null ? 
/*  67:183 */       Collections.unmodifiableList(policyCombinerParameters) : null);
/*  68:    */     
/*  69:185 */     this.policySetCombinerParameters = (policySetCombinerParameters != null ? 
/*  70:186 */       Collections.unmodifiableList(policySetCombinerParameters) : null);
/*  71:    */     
/*  72:188 */     this.defaults = defaults;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public PolicySet(AttributeRegistry registry, Node root)
/*  76:    */     throws DocumentParseException, URISyntaxException
/*  77:    */   {
/*  78:206 */     super(registry, root, "PolicySet", "PolicyCombiningAlgId");
/*  79:    */     
/*  80:208 */     this.policyCombinerParameters = new ArrayList();
/*  81:209 */     this.policySetCombinerParameters = new ArrayList();
/*  82:210 */     this.policiesPolicySetsAndReferences = new ArrayList();
/*  83:    */     
/*  84:212 */     NodeList nodes = root.getChildNodes();
/*  85:214 */     for (int i = 0; i < nodes.getLength(); i++)
/*  86:    */     {
/*  87:215 */       Node node = nodes.item(i);
/*  88:216 */       String cname = getLocalName(node);
/*  89:217 */       if (cname.equals("PolicySetCombinerParameters")) {
/*  90:218 */         this.policySetCombinerParameters.add(new PolicySetCombinerParameters(registry, node));
/*  91:220 */       } else if (cname.equals("PolicyCombinerParameters")) {
/*  92:221 */         this.policyCombinerParameters.add(new PolicyCombinerParameters(registry, node));
/*  93:223 */       } else if (cname.equals("PolicySet")) {
/*  94:224 */         this.policiesPolicySetsAndReferences.add(new PolicySet(registry, node));
/*  95:225 */       } else if (cname.equals("Policy")) {
/*  96:226 */         this.policiesPolicySetsAndReferences.add(new Policy(registry, node));
/*  97:227 */       } else if (cname.equals("PolicySetIdReference")) {
/*  98:228 */         this.policiesPolicySetsAndReferences.add(new PolicySetIdReference(node));
/*  99:229 */       } else if (cname.equals("PolicyIdReference")) {
/* 100:230 */         this.policiesPolicySetsAndReferences.add(new PolicyIdReference(node));
/* 101:231 */       } else if (cname.equals("PolicySetDefaults")) {
/* 102:232 */         this.defaults = new PolicySetDefaults(node);
/* 103:    */       }
/* 104:    */     }
/* 105:236 */     this.policyCombinerParameters = (this.policyCombinerParameters.isEmpty() ? null : Collections.unmodifiableList(this.policyCombinerParameters));
/* 106:    */     
/* 107:238 */     this.policySetCombinerParameters = (this.policySetCombinerParameters.isEmpty() ? null : Collections.unmodifiableList(this.policySetCombinerParameters));
/* 108:    */     
/* 109:    */ 
/* 110:241 */     this.policiesPolicySetsAndReferences = (this.policiesPolicySetsAndReferences.isEmpty() ? null : Collections.unmodifiableList(this.policiesPolicySetsAndReferences));
/* 111:    */   }
/* 112:    */   
/* 113:    */   protected String getPolicyPrefix()
/* 114:    */   {
/* 115:248 */     return "PolicySet";
/* 116:    */   }
/* 117:    */   
/* 118:    */   protected String getCombiningName()
/* 119:    */   {
/* 120:255 */     return "PolicyCombiningAlgId";
/* 121:    */   }
/* 122:    */   
/* 123:    */   public IdReference getReference()
/* 124:    */   {
/* 125:262 */     return new PolicySetIdReference(getId(), getVersion());
/* 126:    */   }
/* 127:    */   
/* 128:    */   public String getElementName()
/* 129:    */   {
/* 130:269 */     return "PolicySet";
/* 131:    */   }
/* 132:    */   
/* 133:    */   public boolean hasChildren()
/* 134:    */   {
/* 135:276 */     return true;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void encodeChildren(Map<String, String> nsMap, PrintStream ps)
/* 139:    */   {
/* 140:283 */     encodeDescription(ps);
/* 141:284 */     if (this.defaults != null) {
/* 142:285 */       this.defaults.encode(nsMap, ps);
/* 143:    */     }
/* 144:287 */     encodeTarget(nsMap, ps);
/* 145:288 */     encodeCombinerParameters(nsMap, ps);
/* 146:    */     Iterator<PolicyCombinerParameters> it;
/* 147:289 */     if (this.policyCombinerParameters != null) {
/* 148:291 */       for (it = this.policyCombinerParameters.iterator(); it.hasNext();)
/* 149:    */       {
/* 150:292 */         PolicyCombinerParameters cp = (PolicyCombinerParameters)it.next();
/* 151:293 */         cp.encode(nsMap, ps);
/* 152:    */       }
/* 153:    */     }
/* 154:    */     Iterator<PolicySetCombinerParameters> it;
/* 155:296 */     if (this.policySetCombinerParameters != null) {
/* 156:298 */       for (it = this.policySetCombinerParameters.iterator(); it.hasNext();)
/* 157:    */       {
/* 158:299 */         PolicySetCombinerParameters cp = (PolicySetCombinerParameters)it.next();
/* 159:300 */         cp.encode(nsMap, ps);
/* 160:    */       }
/* 161:    */     }
/* 162:    */     Iterator<PolicySetMember> it;
/* 163:303 */     if (this.policiesPolicySetsAndReferences != null) {
/* 164:305 */       for (it = this.policiesPolicySetsAndReferences.iterator(); it.hasNext();)
/* 165:    */       {
/* 166:306 */         PolicySetMember psm = (PolicySetMember)it.next();
/* 167:307 */         ((SchemaObject)psm).encode(nsMap, ps);
/* 168:    */       }
/* 169:    */     }
/* 170:310 */     encodeObligations(nsMap, ps);
/* 171:    */   }
/* 172:    */   
/* 173:    */   public boolean equals(Object other)
/* 174:    */   {
/* 175:317 */     if ((!super.equals(other)) || (!(other instanceof PolicySet))) {
/* 176:318 */       return false;
/* 177:    */     }
/* 178:320 */     PolicySet o = (PolicySet)other;
/* 179:321 */     if (CollectionUtil.equals(this.policyCombinerParameters, o.policyCombinerParameters)) {
/* 180:323 */       if (CollectionUtil.equals(this.policySetCombinerParameters, o.policySetCombinerParameters)) {
/* 181:325 */         if (CollectionUtil.equalsWithSequence(this.policiesPolicySetsAndReferences, o.policiesPolicySetsAndReferences)) {
/* 182:325 */           if (this.defaults != o.defaults) {
/* 183:325 */             if (this.defaults == null) {
/* 184:    */               break label100;
/* 185:    */             }
/* 186:    */           }
/* 187:    */         }
/* 188:    */       }
/* 189:    */     }
/* 190:    */     label100:
/* 191:321 */     return 
/* 192:    */     
/* 193:    */ 
/* 194:    */ 
/* 195:325 */       this.defaults
/* 196:    */       
/* 197:    */ 
/* 198:328 */       .equals(o.defaults);
/* 199:    */   }
/* 200:    */   
/* 201:    */   public int internalHashCode()
/* 202:    */   {
/* 203:335 */     int result = super.internalHashCode();
/* 204:    */     
/* 205:    */ 
/* 206:338 */     result = HashCodeUtil.hash(result, this.policyCombinerParameters);
/* 207:339 */     result = HashCodeUtil.hash(result, this.policySetCombinerParameters);
/* 208:340 */     result = HashCodeUtil.hash(result, this.policiesPolicySetsAndReferences);
/* 209:341 */     result = HashCodeUtil.hash(result, this.defaults);
/* 210:342 */     return result;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public PolicySetDefaults getDefaults()
/* 214:    */   {
/* 215:352 */     return this.defaults;
/* 216:    */   }
/* 217:    */   
/* 218:    */   public List<PolicyCombinerParameters> getPolicyCombinerParameters()
/* 219:    */   {
/* 220:362 */     return this.policyCombinerParameters;
/* 221:    */   }
/* 222:    */   
/* 223:    */   public List<PolicySetCombinerParameters> getPolicySetCombinerParameters()
/* 224:    */   {
/* 225:372 */     return this.policySetCombinerParameters;
/* 226:    */   }
/* 227:    */   
/* 228:    */   public List<PolicySetMember> getPoliciesPolicySetsAndReferences()
/* 229:    */   {
/* 230:384 */     return this.policiesPolicySetsAndReferences;
/* 231:    */   }
/* 232:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.policy.PolicySet
 * JD-Core Version:    0.7.0.1
 */