/*  1:   */ package com.bea.common.security.xacml.policy;
/*  2:   */ 
/*  3:   */ import com.bea.common.security.xacml.SchemaObject;
/*  4:   */ 
/*  5:   */ public abstract class PolicySchemaObject
/*  6:   */   extends SchemaObject
/*  7:   */ {
/*  8:   */   public static final String NAMESPACE = "urn:oasis:names:tc:xacml:2.0:policy:schema:os";
/*  9:   */   public static final String NAMESPACE_PREFIX = "xacml";
/* 10:   */   
/* 11:   */   public String getNamespace()
/* 12:   */   {
/* 13:39 */     return "urn:oasis:names:tc:xacml:2.0:policy:schema:os";
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String getDesiredNamespacePrefix()
/* 17:   */   {
/* 18:46 */     return "xacml";
/* 19:   */   }
/* 20:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.policy.PolicySchemaObject
 * JD-Core Version:    0.7.0.1
 */