/*  1:   */ package com.bea.common.security.xacml;
/*  2:   */ 
/*  3:   */ public class XACMLException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = -7179861862235798635L;
/*  7:   */   
/*  8:   */   protected XACMLException() {}
/*  9:   */   
/* 10:   */   protected XACMLException(Throwable cause)
/* 11:   */   {
/* 12:38 */     super(cause);
/* 13:   */   }
/* 14:   */   
/* 15:   */   protected XACMLException(String msg)
/* 16:   */   {
/* 17:48 */     super(msg);
/* 18:   */   }
/* 19:   */   
/* 20:   */   protected XACMLException(String msg, Throwable cause)
/* 21:   */   {
/* 22:60 */     super(msg, cause);
/* 23:   */   }
/* 24:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.XACMLException
 * JD-Core Version:    0.7.0.1
 */