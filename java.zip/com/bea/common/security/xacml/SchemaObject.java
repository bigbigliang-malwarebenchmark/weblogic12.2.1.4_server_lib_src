/*   1:    */ package com.bea.common.security.xacml;
/*   2:    */ 
/*   3:    */ import java.io.ByteArrayOutputStream;
/*   4:    */ import java.io.OutputStream;
/*   5:    */ import java.io.PrintStream;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.io.UnsupportedEncodingException;
/*   8:    */ import java.util.HashMap;
/*   9:    */ import java.util.Map;
/*  10:    */ import org.w3c.dom.Node;
/*  11:    */ 
/*  12:    */ public abstract class SchemaObject
/*  13:    */   implements Serializable
/*  14:    */ {
/*  15: 32 */   private transient int hash = 0;
/*  16:    */   
/*  17:    */   public void encode(OutputStream out)
/*  18:    */   {
/*  19: 38 */     encode(new HashMap(), out);
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void encode(Map<String, String> nsMap, OutputStream out)
/*  23:    */   {
/*  24: 51 */     boolean topLevel = nsMap.isEmpty();
/*  25: 52 */     String ns = getNamespace();
/*  26: 53 */     boolean writeNS = !nsMap.containsKey(ns);
/*  27:    */     String prefix;
/*  28: 55 */     if (writeNS)
/*  29:    */     {
/*  30: 56 */       String prefix = topLevel ? null : getDesiredNamespacePrefix();
/*  31: 57 */       nsMap.put(ns, prefix);
/*  32:    */     }
/*  33:    */     else
/*  34:    */     {
/*  35: 59 */       prefix = (String)nsMap.get(ns);
/*  36:    */     }
/*  37: 62 */     PrintStream ps = getPrintStream(out);
/*  38: 63 */     if (topLevel)
/*  39:    */     {
/*  40: 64 */       ps.print("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
/*  41: 65 */       ps.println();
/*  42:    */     }
/*  43: 67 */     ps.print('<');
/*  44: 68 */     if (prefix != null)
/*  45:    */     {
/*  46: 69 */       ps.print(prefix);
/*  47: 70 */       ps.print(':');
/*  48:    */     }
/*  49: 72 */     ps.print(getElementName());
/*  50: 74 */     if (writeNS)
/*  51:    */     {
/*  52: 75 */       ps.print(" xmlns");
/*  53: 76 */       if (prefix != null)
/*  54:    */       {
/*  55: 77 */         ps.print(':');
/*  56: 78 */         ps.print(prefix);
/*  57:    */       }
/*  58: 80 */       ps.print("=\"");
/*  59: 81 */       ps.print(ns);
/*  60: 82 */       ps.print('"');
/*  61:    */     }
/*  62: 85 */     encodeAttributes(ps);
/*  63: 87 */     if ((hasChildren()) || (hasBody()))
/*  64:    */     {
/*  65: 88 */       ps.print('>');
/*  66: 90 */       if (hasChildren()) {
/*  67: 91 */         encodeChildren(nsMap, ps);
/*  68:    */       }
/*  69: 94 */       if (hasBody()) {
/*  70: 95 */         encodeBody(ps);
/*  71:    */       }
/*  72: 98 */       ps.print("</");
/*  73: 99 */       if (prefix != null)
/*  74:    */       {
/*  75:100 */         ps.print(prefix);
/*  76:101 */         ps.print(':');
/*  77:    */       }
/*  78:103 */       ps.print(getElementName());
/*  79:104 */       ps.print('>');
/*  80:    */     }
/*  81:    */     else
/*  82:    */     {
/*  83:106 */       ps.print("/>");
/*  84:    */     }
/*  85:108 */     if (topLevel) {
/*  86:109 */       ps.flush();
/*  87:    */     }
/*  88:    */   }
/*  89:    */   
/*  90:    */   public abstract String getElementName();
/*  91:    */   
/*  92:    */   public void encodeAttributes(PrintStream ps) {}
/*  93:    */   
/*  94:    */   public boolean hasChildren()
/*  95:    */   {
/*  96:128 */     return false;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void encodeChildren(Map<String, String> nsMap, PrintStream ps) {}
/* 100:    */   
/* 101:    */   public boolean hasBody()
/* 102:    */   {
/* 103:141 */     return false;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void encodeBody(PrintStream ps) {}
/* 107:    */   
/* 108:    */   public abstract String getNamespace();
/* 109:    */   
/* 110:    */   public abstract String getDesiredNamespacePrefix();
/* 111:    */   
/* 112:    */   public int hashCode()
/* 113:    */   {
/* 114:164 */     if (this.hash == 0) {
/* 115:165 */       this.hash = internalHashCode();
/* 116:    */     }
/* 117:167 */     return this.hash;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public abstract int internalHashCode();
/* 121:    */   
/* 122:    */   protected PrintStream getPrintStream(OutputStream out)
/* 123:    */   {
/* 124:179 */     if ((out instanceof PrintStream)) {
/* 125:180 */       return (PrintStream)out;
/* 126:    */     }
/* 127:    */     try
/* 128:    */     {
/* 129:188 */       out = new PrintStream(out, false, "UTF8");
/* 130:    */     }
/* 131:    */     catch (UnsupportedEncodingException uee)
/* 132:    */     {
/* 133:191 */       out = new PrintStream(out);
/* 134:    */     }
/* 135:194 */     return (PrintStream)out;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public String toString()
/* 139:    */   {
/* 140:201 */     ByteArrayOutputStream os = new ByteArrayOutputStream();
/* 141:202 */     encode(os);
/* 142:    */     try
/* 143:    */     {
/* 144:206 */       return new String(os.toByteArray(), "UTF8");
/* 145:    */     }
/* 146:    */     catch (UnsupportedEncodingException uee) {}
/* 147:210 */     return new String(os.toByteArray());
/* 148:    */   }
/* 149:    */   
/* 150:    */   protected String getLocalName(Node node)
/* 151:    */   {
/* 152:218 */     String name = node.getLocalName();
/* 153:219 */     if (name == null)
/* 154:    */     {
/* 155:220 */       name = node.getNodeName();
/* 156:221 */       if (name != null)
/* 157:    */       {
/* 158:222 */         int idx = name.indexOf(':');
/* 159:223 */         if (idx >= 0) {
/* 160:224 */           return name.substring(idx + 1);
/* 161:    */         }
/* 162:    */       }
/* 163:    */     }
/* 164:229 */     return name;
/* 165:    */   }
/* 166:    */   
/* 167:    */   protected String escapeXML(String string)
/* 168:    */   {
/* 169:240 */     if ((string == null) || (string.trim().length() == 0)) {
/* 170:241 */       return string;
/* 171:    */     }
/* 172:242 */     StringBuilder sb = new StringBuilder();
/* 173:243 */     for (int i = 0; i < string.length(); i++) {
/* 174:244 */       switch (string.charAt(i))
/* 175:    */       {
/* 176:    */       case '"': 
/* 177:246 */         sb.append("&quot;");
/* 178:247 */         break;
/* 179:    */       case '\'': 
/* 180:249 */         sb.append("&apos;");
/* 181:250 */         break;
/* 182:    */       case '&': 
/* 183:252 */         sb.append("&amp;");
/* 184:253 */         break;
/* 185:    */       case '<': 
/* 186:255 */         sb.append("&lt;");
/* 187:256 */         break;
/* 188:    */       case '>': 
/* 189:258 */         sb.append("&gt;");
/* 190:259 */         break;
/* 191:    */       default: 
/* 192:261 */         sb.append(string.charAt(i));
/* 193:    */       }
/* 194:    */     }
/* 195:264 */     return sb.toString();
/* 196:    */   }
/* 197:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.SchemaObject
 * JD-Core Version:    0.7.0.1
 */