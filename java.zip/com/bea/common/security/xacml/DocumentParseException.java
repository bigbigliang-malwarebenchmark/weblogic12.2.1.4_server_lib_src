/*  1:   */ package com.bea.common.security.xacml;
/*  2:   */ 
/*  3:   */ public class DocumentParseException
/*  4:   */   extends XACMLException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 6914789966923511546L;
/*  7:   */   
/*  8:   */   public DocumentParseException(Throwable cause)
/*  9:   */   {
/* 10:32 */     super(cause);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public DocumentParseException(String msg)
/* 14:   */   {
/* 15:42 */     super(msg);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public DocumentParseException(String msg, Throwable cause)
/* 19:   */   {
/* 20:54 */     super(msg, cause);
/* 21:   */   }
/* 22:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.DocumentParseException
 * JD-Core Version:    0.7.0.1
 */