/*  1:   */ package com.bea.common.security.xacml;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ import java.net.URISyntaxException;
/*  5:   */ 
/*  6:   */ public class URI
/*  7:   */   implements Comparable<URI>, Serializable
/*  8:   */ {
/*  9:   */   private static final long serialVersionUID = 1L;
/* 10:16 */   private String uri_as_string = null;
/* 11:17 */   private java.net.URI uri = null;
/* 12:   */   private static final String IDDNAME_SCHEME = "iddname:";
/* 13:   */   private static final String URN_SCHEME = "urn:";
/* 14:   */   private static final String STANDARD_XACML_TYPE = "http://www.w3.org";
/* 15:21 */   private static Boolean useURIOnly = Boolean.valueOf(Boolean.getBoolean("weblogic.security.xacml.useURIOnly"));
/* 16:   */   
/* 17:   */   public URI(String str)
/* 18:   */     throws URISyntaxException
/* 19:   */   {
/* 20:24 */     if (str == null) {
/* 21:26 */       throw new NullPointerException("URI string value must not be null");
/* 22:   */     }
/* 23:29 */     if (useURIOnly.booleanValue())
/* 24:   */     {
/* 25:31 */       this.uri = new java.net.URI(str);
/* 26:32 */       return;
/* 27:   */     }
/* 28:35 */     if (str.startsWith("iddname:")) {
/* 29:37 */       this.uri_as_string = str;
/* 30:38 */     } else if (str.startsWith("urn:")) {
/* 31:40 */       this.uri_as_string = str;
/* 32:41 */     } else if (str.startsWith("http://www.w3.org")) {
/* 33:43 */       this.uri_as_string = str;
/* 34:   */     } else {
/* 35:46 */       this.uri = new java.net.URI(str);
/* 36:   */     }
/* 37:   */   }
/* 38:   */   
/* 39:   */   public int hashCode()
/* 40:   */   {
/* 41:52 */     return this.uri == null ? this.uri_as_string.hashCode() : this.uri.hashCode();
/* 42:   */   }
/* 43:   */   
/* 44:   */   public boolean equals(Object obj)
/* 45:   */   {
/* 46:57 */     if (this == obj) {
/* 47:58 */       return true;
/* 48:   */     }
/* 49:60 */     if (obj == null) {
/* 50:61 */       return false;
/* 51:   */     }
/* 52:63 */     if (getClass() != obj.getClass()) {
/* 53:64 */       return false;
/* 54:   */     }
/* 55:67 */     URI other = (URI)obj;
/* 56:   */     
/* 57:69 */     return this.uri == null ? this.uri_as_string.equals(other.uri_as_string) : this.uri.equals(other.uri);
/* 58:   */   }
/* 59:   */   
/* 60:   */   public String toString()
/* 61:   */   {
/* 62:74 */     return this.uri == null ? this.uri_as_string : this.uri.toString();
/* 63:   */   }
/* 64:   */   
/* 65:   */   public int compareTo(URI value)
/* 66:   */   {
/* 67:79 */     return this.uri == null ? this.uri_as_string.compareToIgnoreCase(value.uri_as_string) : this.uri
/* 68:80 */       .compareTo(value.uri);
/* 69:   */   }
/* 70:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.URI
 * JD-Core Version:    0.7.0.1
 */