/*  1:   */ package com.bea.common.security.xacml;
/*  2:   */ 
/*  3:   */ public class FunctionException
/*  4:   */   extends XACMLException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 6558797020325961991L;
/*  7:   */   
/*  8:   */   public FunctionException(String msg)
/*  9:   */   {
/* 10:14 */     super(msg);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public FunctionException(Throwable th)
/* 14:   */   {
/* 15:18 */     super(th);
/* 16:   */   }
/* 17:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.FunctionException
 * JD-Core Version:    0.7.0.1
 */