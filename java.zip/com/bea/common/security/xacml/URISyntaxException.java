/*  1:   */ package com.bea.common.security.xacml;
/*  2:   */ 
/*  3:   */ public class URISyntaxException
/*  4:   */   extends XACMLException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 6136776534657235034L;
/*  7:   */   
/*  8:   */   public URISyntaxException(java.net.URISyntaxException cause)
/*  9:   */   {
/* 10:33 */     super(cause);
/* 11:   */   }
/* 12:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.URISyntaxException
 * JD-Core Version:    0.7.0.1
 */