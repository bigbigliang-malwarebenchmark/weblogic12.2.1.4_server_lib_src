/*   1:    */ package com.bea.common.security.xacml;
/*   2:    */ 
/*   3:    */ import com.bea.common.security.xacml.attr.AttributeRegistry;
/*   4:    */ import com.bea.common.security.xacml.policy.AbstractPolicy;
/*   5:    */ import com.bea.common.security.xacml.policy.Policy;
/*   6:    */ import com.bea.common.security.xacml.policy.PolicySet;
/*   7:    */ import java.io.InputStream;
/*   8:    */ import java.io.StringReader;
/*   9:    */ import javax.xml.parsers.DocumentBuilder;
/*  10:    */ import javax.xml.parsers.DocumentBuilderFactory;
/*  11:    */ import javax.xml.parsers.ParserConfigurationException;
/*  12:    */ import javax.xml.transform.dom.DOMSource;
/*  13:    */ import javax.xml.transform.stream.StreamSource;
/*  14:    */ import javax.xml.validation.Schema;
/*  15:    */ import javax.xml.validation.SchemaFactory;
/*  16:    */ import javax.xml.validation.Validator;
/*  17:    */ import org.w3c.dom.Document;
/*  18:    */ import org.w3c.dom.Node;
/*  19:    */ import org.xml.sax.InputSource;
/*  20:    */ import org.xml.sax.SAXException;
/*  21:    */ import weblogic.utils.XXEUtils;
/*  22:    */ 
/*  23:    */ public class PolicyUtils
/*  24:    */ {
/*  25:    */   private static final String DISALLOW_DOCTYPE_DECL = "http://apache.org/xml/features/disallow-doctype-decl";
/*  26:    */   private static Validator XACML_SCHEMA_VALIDATOR;
/*  27:    */   
/*  28:    */   private static Validator getValidator()
/*  29:    */     throws SAXException
/*  30:    */   {
/*  31: 44 */     if (XACML_SCHEMA_VALIDATOR == null)
/*  32:    */     {
/*  33: 45 */       SchemaFactory sf = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
/*  34: 46 */       Schema schema = sf.newSchema(new StreamSource(PolicyUtils.class
/*  35: 47 */         .getClassLoader().getResourceAsStream("com/bea/common/security/xacml/access_control-xacml-2.0-policy-schema-os.xsd")));
/*  36:    */       
/*  37: 49 */       XACML_SCHEMA_VALIDATOR = XXEUtils.createValidator(schema);
/*  38:    */     }
/*  39: 51 */     return XACML_SCHEMA_VALIDATOR;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static void checkXACMLSchema(String policyString)
/*  43:    */     throws DocumentParseException, IOException
/*  44:    */   {
/*  45:    */     try
/*  46:    */     {
/*  47: 61 */       DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
/*  48: 62 */       dbFactory.setIgnoringComments(true);
/*  49: 63 */       dbFactory.setNamespaceAware(true);
/*  50: 64 */       dbFactory.setValidating(false);
/*  51: 65 */       dbFactory.setExpandEntityReferences(false);
/*  52: 66 */       dbFactory.setXIncludeAware(false);
/*  53: 67 */       dbFactory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/*  54: 68 */       dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
/*  55:    */       
/*  56: 70 */       DocumentBuilder db = dbFactory.newDocumentBuilder();
/*  57: 71 */       Document doc = db.parse(new InputSource(new StringReader(policyString)));
/*  58: 72 */       getValidator().validate(new DOMSource(doc));
/*  59:    */     }
/*  60:    */     catch (ParserConfigurationException e)
/*  61:    */     {
/*  62: 74 */       throw new DocumentParseException(e);
/*  63:    */     }
/*  64:    */     catch (SAXException e)
/*  65:    */     {
/*  66: 76 */       throw new DocumentParseException(e);
/*  67:    */     }
/*  68:    */     catch (java.io.IOException e)
/*  69:    */     {
/*  70: 78 */       throw new IOException(e);
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   private static Node getRootNode(InputStream str, DocumentBuilderFactory dbFactory, boolean checkSchema)
/*  75:    */     throws IOException, ParserConfigurationException, SAXException
/*  76:    */   {
/*  77:    */     try
/*  78:    */     {
/*  79: 86 */       dbFactory.setIgnoringComments(true);
/*  80: 87 */       dbFactory.setNamespaceAware(true);
/*  81: 88 */       dbFactory.setValidating(false);
/*  82: 89 */       dbFactory.setExpandEntityReferences(false);
/*  83: 90 */       dbFactory.setXIncludeAware(false);
/*  84: 91 */       dbFactory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/*  85: 92 */       dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
/*  86:    */       
/*  87: 94 */       DocumentBuilder db = dbFactory.newDocumentBuilder();
/*  88: 95 */       Document doc = db.parse(str);
/*  89: 96 */       if (checkSchema) {
/*  90: 97 */         getValidator().validate(new DOMSource(doc));
/*  91:    */       }
/*  92: 98 */       return doc.getDocumentElement();
/*  93:    */     }
/*  94:    */     catch (java.io.IOException io)
/*  95:    */     {
/*  96:102 */       throw new IOException(io);
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   private static Node getRootNode(String str, DocumentBuilderFactory dbFactory, boolean checkSchema)
/* 101:    */     throws IOException, ParserConfigurationException, SAXException
/* 102:    */   {
/* 103:    */     try
/* 104:    */     {
/* 105:110 */       dbFactory.setIgnoringComments(true);
/* 106:111 */       dbFactory.setNamespaceAware(true);
/* 107:112 */       dbFactory.setValidating(false);
/* 108:113 */       dbFactory.setExpandEntityReferences(false);
/* 109:114 */       dbFactory.setXIncludeAware(false);
/* 110:115 */       dbFactory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/* 111:116 */       dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
/* 112:    */       
/* 113:118 */       DocumentBuilder db = dbFactory.newDocumentBuilder();
/* 114:119 */       Document doc = db.parse(new InputSource(new StringReader(str)));
/* 115:120 */       if (checkSchema) {
/* 116:121 */         getValidator().validate(new DOMSource(doc));
/* 117:    */       }
/* 118:122 */       return doc.getDocumentElement();
/* 119:    */     }
/* 120:    */     catch (java.io.IOException io)
/* 121:    */     {
/* 122:126 */       throw new IOException(io);
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   public static AbstractPolicy read(AttributeRegistry attrReg, InputStream data, DocumentBuilderFactory dbFactory)
/* 127:    */     throws URISyntaxException, DocumentParseException, IOException
/* 128:    */   {
/* 129:136 */     return read(attrReg, data, dbFactory, false);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public static AbstractPolicy read(AttributeRegistry attrReg, InputStream data, DocumentBuilderFactory dbFactory, boolean checkSchema)
/* 133:    */     throws URISyntaxException, DocumentParseException, IOException
/* 134:    */   {
/* 135:    */     try
/* 136:    */     {
/* 137:146 */       Node root = getRootNode(data, dbFactory, checkSchema);
/* 138:147 */       if (root.getNodeName().equals("Policy")) {
/* 139:148 */         return new Policy(attrReg, root);
/* 140:    */       }
/* 141:149 */       if (root.getNodeName().equals("PolicySet")) {
/* 142:150 */         return new PolicySet(attrReg, root);
/* 143:    */       }
/* 144:152 */       throw new DocumentParseException("Expecting Policy or PolicySet, but found: " + root.getNodeName());
/* 145:    */     }
/* 146:    */     catch (ParserConfigurationException pce)
/* 147:    */     {
/* 148:155 */       throw new DocumentParseException(pce);
/* 149:    */     }
/* 150:    */     catch (SAXException se)
/* 151:    */     {
/* 152:157 */       throw new DocumentParseException(se);
/* 153:    */     }
/* 154:    */   }
/* 155:    */   
/* 156:    */   public static AbstractPolicy read(AttributeRegistry attrReg, String data, DocumentBuilderFactory dbFactory)
/* 157:    */     throws URISyntaxException, DocumentParseException, IOException
/* 158:    */   {
/* 159:167 */     return read(attrReg, data, dbFactory, false);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public static AbstractPolicy read(AttributeRegistry attrReg, String data, DocumentBuilderFactory dbFactory, boolean checkSchema)
/* 163:    */     throws URISyntaxException, DocumentParseException, IOException
/* 164:    */   {
/* 165:    */     try
/* 166:    */     {
/* 167:177 */       Node root = getRootNode(data, dbFactory, checkSchema);
/* 168:178 */       if (root.getNodeName().equals("Policy")) {
/* 169:179 */         return new Policy(attrReg, root);
/* 170:    */       }
/* 171:180 */       if (root.getNodeName().equals("PolicySet")) {
/* 172:181 */         return new PolicySet(attrReg, root);
/* 173:    */       }
/* 174:183 */       throw new DocumentParseException("Expecting Policy or PolicySet, but found: " + root.getNodeName());
/* 175:    */     }
/* 176:    */     catch (ParserConfigurationException pce)
/* 177:    */     {
/* 178:186 */       throw new DocumentParseException(pce);
/* 179:    */     }
/* 180:    */     catch (SAXException se)
/* 181:    */     {
/* 182:188 */       throw new DocumentParseException(se);
/* 183:    */     }
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static Policy readPolicy(AttributeRegistry attrReg, InputStream policy, DocumentBuilderFactory dbFactory)
/* 187:    */     throws URISyntaxException, DocumentParseException, IOException
/* 188:    */   {
/* 189:198 */     return readPolicy(attrReg, policy, dbFactory, false);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public static Policy readPolicy(AttributeRegistry attrReg, InputStream policy, DocumentBuilderFactory dbFactory, boolean checkSchema)
/* 193:    */     throws URISyntaxException, DocumentParseException, IOException
/* 194:    */   {
/* 195:    */     try
/* 196:    */     {
/* 197:208 */       Node root = getRootNode(policy, dbFactory, checkSchema);
/* 198:209 */       if (!root.getNodeName().equals("Policy")) {
/* 199:210 */         throw new DocumentParseException("The given policy is not a valid XACML policy.");
/* 200:    */       }
/* 201:212 */       return new Policy(attrReg, root);
/* 202:    */     }
/* 203:    */     catch (ParserConfigurationException pce)
/* 204:    */     {
/* 205:214 */       throw new DocumentParseException(pce);
/* 206:    */     }
/* 207:    */     catch (SAXException se)
/* 208:    */     {
/* 209:216 */       throw new DocumentParseException(se);
/* 210:    */     }
/* 211:    */   }
/* 212:    */   
/* 213:    */   public static Policy readPolicy(AttributeRegistry attrReg, String policy, DocumentBuilderFactory dbFactory)
/* 214:    */     throws URISyntaxException, DocumentParseException, IOException
/* 215:    */   {
/* 216:226 */     return readPolicy(attrReg, policy, dbFactory, false);
/* 217:    */   }
/* 218:    */   
/* 219:    */   public static Policy readPolicy(AttributeRegistry attrReg, String policy, DocumentBuilderFactory dbFactory, boolean checkSchema)
/* 220:    */     throws URISyntaxException, DocumentParseException, IOException
/* 221:    */   {
/* 222:    */     try
/* 223:    */     {
/* 224:236 */       Node root = getRootNode(policy, dbFactory, checkSchema);
/* 225:237 */       if (!root.getNodeName().equals("Policy")) {
/* 226:238 */         throw new DocumentParseException("The given policy is not a valid XACML policy.");
/* 227:    */       }
/* 228:240 */       return new Policy(attrReg, root);
/* 229:    */     }
/* 230:    */     catch (ParserConfigurationException pce)
/* 231:    */     {
/* 232:242 */       throw new DocumentParseException(pce);
/* 233:    */     }
/* 234:    */     catch (SAXException se)
/* 235:    */     {
/* 236:244 */       throw new DocumentParseException(se);
/* 237:    */     }
/* 238:    */   }
/* 239:    */   
/* 240:    */   public static PolicySet readPolicySet(AttributeRegistry attrReg, InputStream policySet, DocumentBuilderFactory dbFactory)
/* 241:    */     throws URISyntaxException, DocumentParseException
/* 242:    */   {
/* 243:254 */     return readPolicySet(attrReg, policySet, dbFactory, false);
/* 244:    */   }
/* 245:    */   
/* 246:    */   public static PolicySet readPolicySet(AttributeRegistry attrReg, InputStream policySet, DocumentBuilderFactory dbFactory, boolean checkSchema)
/* 247:    */     throws URISyntaxException, DocumentParseException
/* 248:    */   {
/* 249:    */     try
/* 250:    */     {
/* 251:264 */       Node root = getRootNode(policySet, dbFactory, checkSchema);
/* 252:265 */       if (!root.getNodeName().equals("PolicySet")) {
/* 253:266 */         throw new DocumentParseException("The given policy set is not a valid XACML policy set.");
/* 254:    */       }
/* 255:268 */       return new PolicySet(attrReg, root);
/* 256:    */     }
/* 257:    */     catch (IOException io)
/* 258:    */     {
/* 259:270 */       throw new DocumentParseException(io);
/* 260:    */     }
/* 261:    */     catch (ParserConfigurationException pce)
/* 262:    */     {
/* 263:272 */       throw new DocumentParseException(pce);
/* 264:    */     }
/* 265:    */     catch (SAXException se)
/* 266:    */     {
/* 267:274 */       throw new DocumentParseException(se);
/* 268:    */     }
/* 269:    */   }
/* 270:    */   
/* 271:    */   public static PolicySet readPolicySet(AttributeRegistry attrReg, String policySet, DocumentBuilderFactory dbFactory)
/* 272:    */     throws URISyntaxException, DocumentParseException
/* 273:    */   {
/* 274:284 */     return readPolicySet(attrReg, policySet, dbFactory, false);
/* 275:    */   }
/* 276:    */   
/* 277:    */   public static PolicySet readPolicySet(AttributeRegistry attrReg, String policySet, DocumentBuilderFactory dbFactory, boolean checkSchema)
/* 278:    */     throws URISyntaxException, DocumentParseException
/* 279:    */   {
/* 280:    */     try
/* 281:    */     {
/* 282:294 */       Node root = getRootNode(policySet, dbFactory, checkSchema);
/* 283:295 */       if (!root.getNodeName().equals("PolicySet")) {
/* 284:296 */         throw new DocumentParseException("The given policy set is not a valid XACML policy set.");
/* 285:    */       }
/* 286:298 */       return new PolicySet(attrReg, root);
/* 287:    */     }
/* 288:    */     catch (IOException io)
/* 289:    */     {
/* 290:300 */       throw new DocumentParseException(io);
/* 291:    */     }
/* 292:    */     catch (ParserConfigurationException pce)
/* 293:    */     {
/* 294:302 */       throw new DocumentParseException(pce);
/* 295:    */     }
/* 296:    */     catch (SAXException se)
/* 297:    */     {
/* 298:304 */       throw new DocumentParseException(se);
/* 299:    */     }
/* 300:    */   }
/* 301:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.PolicyUtils
 * JD-Core Version:    0.7.0.1
 */