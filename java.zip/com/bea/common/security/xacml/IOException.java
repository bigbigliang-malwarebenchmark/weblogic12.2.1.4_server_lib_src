/*  1:   */ package com.bea.common.security.xacml;
/*  2:   */ 
/*  3:   */ public class IOException
/*  4:   */   extends XACMLException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = -5283891001627598227L;
/*  7:   */   
/*  8:   */   public IOException(java.io.IOException cause)
/*  9:   */   {
/* 10:16 */     super(cause);
/* 11:   */   }
/* 12:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.IOException
 * JD-Core Version:    0.7.0.1
 */