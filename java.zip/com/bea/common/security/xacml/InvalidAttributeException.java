/*  1:   */ package com.bea.common.security.xacml;
/*  2:   */ 
/*  3:   */ public class InvalidAttributeException
/*  4:   */   extends DocumentParseException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 3763098578632913456L;
/*  7:   */   
/*  8:   */   public InvalidAttributeException(Throwable cause)
/*  9:   */   {
/* 10:32 */     super(cause);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public InvalidAttributeException(String msg)
/* 14:   */   {
/* 15:42 */     super(msg);
/* 16:   */   }
/* 17:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.xacml.InvalidAttributeException
 * JD-Core Version:    0.7.0.1
 */