package com.bea.common.security.legacy;

public abstract interface ServiceConfigCustomizer
{
  public abstract void renameService(String paramString);
  
  public abstract void removeService();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.legacy.ServiceConfigCustomizer
 * JD-Core Version:    0.7.0.1
 */