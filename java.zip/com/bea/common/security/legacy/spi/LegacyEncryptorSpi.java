package com.bea.common.security.legacy.spi;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

public abstract interface LegacyEncryptorSpi
{
  public abstract boolean isEncrypted(String paramString);
  
  public abstract boolean isEncrypted(char[] paramArrayOfChar);
  
  public abstract boolean isEncrypted(byte[] paramArrayOfByte);
  
  public abstract String encryptString(String paramString)
    throws BadPaddingException, IllegalBlockSizeException;
  
  public abstract String decryptString(String paramString)
    throws BadPaddingException, IllegalBlockSizeException;
  
  public abstract String encryptChar(char[] paramArrayOfChar)
    throws BadPaddingException, IllegalBlockSizeException;
  
  public abstract char[] decryptChar(String paramString)
    throws BadPaddingException, IllegalBlockSizeException;
  
  public abstract byte[] encryptBytes(byte[] paramArrayOfByte)
    throws BadPaddingException, IllegalBlockSizeException;
  
  public abstract byte[] decryptBytes(byte[] paramArrayOfByte)
    throws BadPaddingException, IllegalBlockSizeException;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.legacy.spi.LegacyEncryptorSpi
 * JD-Core Version:    0.7.0.1
 */