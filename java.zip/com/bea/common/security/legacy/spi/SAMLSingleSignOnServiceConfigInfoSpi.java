package com.bea.common.security.legacy.spi;

import java.util.Properties;

public abstract interface SAMLSingleSignOnServiceConfigInfoSpi
{
  public abstract boolean isV1Config();
  
  public abstract boolean isV2Config();
  
  public abstract boolean isSourceSiteEnabled();
  
  public abstract boolean isITSArtifactEnabled();
  
  public abstract boolean isITSPostEnabled();
  
  public abstract String getSourceIdHex();
  
  public abstract byte[] getSourceIdBytes();
  
  public abstract String[] getIntersiteTransferURIs();
  
  public abstract boolean isITSRequiresSSL();
  
  public abstract String[] getAssertionRetrievalURIs();
  
  public abstract boolean isARSRequiresSSL();
  
  public abstract boolean isARSRequiresTwoWaySSL();
  
  public abstract String getAssertionStoreClassName();
  
  public abstract Properties getAssertionStoreProperties();
  
  public abstract String getSigningKeyAlias();
  
  public abstract String getSigningKeyPassPhrase();
  
  public abstract boolean isDestinationSiteEnabled();
  
  public abstract boolean isACSArtifactEnabled();
  
  public abstract boolean isACSPostEnabled();
  
  public abstract String[] getAssertionConsumerURIs();
  
  public abstract boolean isACSRequiresSSL();
  
  public abstract boolean isPOSTRecipientCheckEnabled();
  
  public abstract boolean isPOSTOneUseCheckEnabled();
  
  public abstract String getUsedAssertionCacheClassName();
  
  public abstract Properties getUsedAssertionCacheProperties();
  
  public abstract String getSSLClientIdentityAlias();
  
  public abstract String getSSLClientIdentityPassPhrase();
  
  public abstract void close();
  
  public abstract String[] getAllowedTargetHosts();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.legacy.spi.SAMLSingleSignOnServiceConfigInfoSpi
 * JD-Core Version:    0.7.0.1
 */