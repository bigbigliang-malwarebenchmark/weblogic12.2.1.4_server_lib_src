package com.bea.common.security.service;

import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginException;
import weblogic.security.service.ContextHandler;

public abstract interface IdentityAssertionCallbackService
{
  public abstract Identity assertIdentity(CallbackHandler paramCallbackHandler, ContextHandler paramContextHandler)
    throws LoginException;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.service.IdentityAssertionCallbackService
 * JD-Core Version:    0.7.0.1
 */