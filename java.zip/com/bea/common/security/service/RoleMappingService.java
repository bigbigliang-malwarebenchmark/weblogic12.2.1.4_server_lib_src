package com.bea.common.security.service;

import java.util.Map;
import weblogic.security.service.ContextHandler;
import weblogic.security.spi.Resource;

public abstract interface RoleMappingService
{
  public abstract Map getRoles(Identity paramIdentity, Resource paramResource, ContextHandler paramContextHandler);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.service.RoleMappingService
 * JD-Core Version:    0.7.0.1
 */