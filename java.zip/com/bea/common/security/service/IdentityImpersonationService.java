package com.bea.common.security.service;

import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginException;
import weblogic.security.service.ContextHandler;

public abstract interface IdentityImpersonationService
{
  public abstract Identity impersonateIdentity(String paramString, ContextHandler paramContextHandler)
    throws LoginException;
  
  public abstract Identity impersonateIdentity(CallbackHandler paramCallbackHandler, boolean paramBoolean, ContextHandler paramContextHandler)
    throws LoginException;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.service.IdentityImpersonationService
 * JD-Core Version:    0.7.0.1
 */