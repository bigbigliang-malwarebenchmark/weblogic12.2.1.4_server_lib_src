package com.bea.common.security.service;

import weblogic.security.service.ContextHandler;
import weblogic.security.spi.Resource;

public abstract interface CredentialMappingService
{
  public abstract Object[] getCredentials(Identity paramIdentity1, Identity paramIdentity2, Resource paramResource, ContextHandler paramContextHandler, String paramString);
  
  public abstract Object[] getCredentials(Identity paramIdentity, String paramString1, Resource paramResource, ContextHandler paramContextHandler, String paramString2);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.service.CredentialMappingService
 * JD-Core Version:    0.7.0.1
 */