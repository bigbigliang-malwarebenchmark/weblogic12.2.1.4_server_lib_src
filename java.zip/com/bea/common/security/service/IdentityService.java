package com.bea.common.security.service;

import javax.security.auth.Subject;

public abstract interface IdentityService
{
  public abstract Identity getIdentityFromSubject(Subject paramSubject);
  
  public abstract Identity getAnonymousIdentity();
  
  public abstract Identity getCurrentIdentity();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.service.IdentityService
 * JD-Core Version:    0.7.0.1
 */