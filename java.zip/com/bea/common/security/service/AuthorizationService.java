package com.bea.common.security.service;

import java.util.Map;
import weblogic.security.service.ContextHandler;
import weblogic.security.spi.Direction;
import weblogic.security.spi.Resource;

public abstract interface AuthorizationService
{
  public abstract boolean isAccessAllowed(Identity paramIdentity, Map paramMap, Resource paramResource, ContextHandler paramContextHandler, Direction paramDirection);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.service.AuthorizationService
 * JD-Core Version:    0.7.0.1
 */