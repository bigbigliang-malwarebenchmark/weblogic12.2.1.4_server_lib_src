package com.bea.common.security.service;

import javax.security.auth.callback.CallbackHandler;
import weblogic.security.service.ContextHandler;
import weblogic.security.spi.IdentityAssertionException;

public abstract interface IdentityAssertionTokenService
{
  public abstract boolean isTokenTypeSupported(String paramString);
  
  public abstract CallbackHandler assertIdentity(String paramString, Object paramObject, ContextHandler paramContextHandler)
    throws IdentityAssertionException;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.service.IdentityAssertionTokenService
 * JD-Core Version:    0.7.0.1
 */