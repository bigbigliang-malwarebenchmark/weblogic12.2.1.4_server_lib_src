package com.bea.common.security.service;

import weblogic.security.spi.AuditEvent;

public abstract interface AuditService
{
  public abstract boolean isAuditEnabled();
  
  public abstract void writeEvent(AuditEvent paramAuditEvent);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.security.service.AuditService
 * JD-Core Version:    0.7.0.1
 */