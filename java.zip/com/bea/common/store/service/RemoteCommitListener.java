package com.bea.common.store.service;

public abstract interface RemoteCommitListener
{
  public abstract void afterCommit(RemoteCommitEvent paramRemoteCommitEvent);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.store.service.RemoteCommitListener
 * JD-Core Version:    0.7.0.1
 */