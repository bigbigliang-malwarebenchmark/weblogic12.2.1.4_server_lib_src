package com.bea.common.store.service;

import java.util.Collection;

public abstract interface RemoteCommitEvent
{
  public abstract Collection getDeletedObjectIds();
  
  public abstract Collection getAddedObjectIds();
  
  public abstract Collection getUpdatedObjectIds();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.common.store.service.RemoteCommitEvent
 * JD-Core Version:    0.7.0.1
 */