package com.bea.httppubsub;

public abstract interface MessageFilter
{
  public abstract boolean handleMessage(EventMessage paramEventMessage);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.MessageFilter
 * JD-Core Version:    0.7.0.1
 */