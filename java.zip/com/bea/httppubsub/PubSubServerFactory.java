package com.bea.httppubsub;

import com.bea.httppubsub.descriptor.WeblogicPubsubBean;
import java.util.Hashtable;

public abstract interface PubSubServerFactory
{
  public abstract PubSubServer lookupPubSubServer(String paramString);
  
  public abstract PubSubServer createPubSubServer(String paramString, WeblogicPubsubBean paramWeblogicPubsubBean);
  
  public abstract PubSubServer createPubSubServer(Hashtable paramHashtable);
  
  public abstract void removePubSubServer(PubSubServer paramPubSubServer);
  
  public abstract void removeAllPubSubServers();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.PubSubServerFactory
 * JD-Core Version:    0.7.0.1
 */