/*  1:   */ package com.bea.httppubsub;
/*  2:   */ 
/*  3:   */ import java.util.EventObject;
/*  4:   */ 
/*  5:   */ public class DeliveredMessageEvent
/*  6:   */   extends EventObject
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = -1880058676699690387L;
/*  9:   */   private final EventMessage message;
/* 10:   */   
/* 11:   */   public DeliveredMessageEvent(LocalClient client, EventMessage message)
/* 12:   */   {
/* 13:26 */     super(client);
/* 14:27 */     this.message = message;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public LocalClient getLocalClient()
/* 18:   */   {
/* 19:35 */     return (LocalClient)getSource();
/* 20:   */   }
/* 21:   */   
/* 22:   */   public EventMessage getMessage()
/* 23:   */   {
/* 24:43 */     return this.message;
/* 25:   */   }
/* 26:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.DeliveredMessageEvent
 * JD-Core Version:    0.7.0.1
 */