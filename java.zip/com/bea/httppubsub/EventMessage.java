package com.bea.httppubsub;

import java.io.Serializable;

public abstract interface EventMessage
  extends BayeuxMessage, Serializable
{
  public abstract String getPayLoad();
  
  public abstract void setPayLoad(String paramString);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.EventMessage
 * JD-Core Version:    0.7.0.1
 */