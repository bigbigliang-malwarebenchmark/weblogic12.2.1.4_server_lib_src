/*  1:   */ package com.bea.httppubsub;
/*  2:   */ 
/*  3:   */ import java.util.Set;
/*  4:   */ 
/*  5:   */ public abstract class LocalClient
/*  6:   */   implements Client
/*  7:   */ {
/*  8:   */   public AuthenticatedUser getAuthenticatedUser()
/*  9:   */   {
/* 10:24 */     return new LocalClient.1(this);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public void setAuthenticatedUser(AuthenticatedUser user) {}
/* 14:   */   
/* 15:   */   public Set<String> getChannelSubscriptions()
/* 16:   */   {
/* 17:78 */     return null;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getBrowserId()
/* 21:   */   {
/* 22:87 */     return null;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public abstract void registerMessageListener(DeliveredMessageListener paramDeliveredMessageListener);
/* 26:   */   
/* 27:   */   public abstract void unregisterMessageListener(DeliveredMessageListener paramDeliveredMessageListener);
/* 28:   */   
/* 29:   */   public abstract void setCommentFilterRequired(boolean paramBoolean);
/* 30:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.LocalClient
 * JD-Core Version:    0.7.0.1
 */