package com.bea.httppubsub;

import java.io.Serializable;

public abstract interface BayeuxMessage
  extends Serializable
{
  public abstract Client getClient();
  
  public abstract BayeuxMessage.TYPE getType();
  
  public abstract String getChannel();
  
  public abstract String toJSONRequestString();
  
  public abstract String toJSONResponseString();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.BayeuxMessage
 * JD-Core Version:    0.7.0.1
 */