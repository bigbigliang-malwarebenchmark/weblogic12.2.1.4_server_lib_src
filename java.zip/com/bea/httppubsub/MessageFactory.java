package com.bea.httppubsub;

public abstract interface MessageFactory
{
  public abstract EventMessage createEventMessage(LocalClient paramLocalClient, String paramString1, String paramString2);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.MessageFactory
 * JD-Core Version:    0.7.0.1
 */