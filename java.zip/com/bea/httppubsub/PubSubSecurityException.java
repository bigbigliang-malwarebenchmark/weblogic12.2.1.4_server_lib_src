/*  1:   */ package com.bea.httppubsub;
/*  2:   */ 
/*  3:   */ public class PubSubSecurityException
/*  4:   */   extends PubSubServerException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 6780906306372233378L;
/*  7:   */   
/*  8:   */   public PubSubSecurityException(Throwable cause)
/*  9:   */   {
/* 10:16 */     super(cause);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public PubSubSecurityException(String message, Throwable cause)
/* 14:   */   {
/* 15:20 */     super(message, cause);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public PubSubSecurityException(String message)
/* 19:   */   {
/* 20:24 */     super(message);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public PubSubSecurityException() {}
/* 24:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.PubSubSecurityException
 * JD-Core Version:    0.7.0.1
 */