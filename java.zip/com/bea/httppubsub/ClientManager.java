package com.bea.httppubsub;

public abstract interface ClientManager
{
  public abstract void init();
  
  public abstract void destroy();
  
  public abstract Client createClient();
  
  public abstract LocalClient createLocalClient();
  
  public abstract Client findClient(String paramString);
  
  public abstract void addClient(Client paramClient);
  
  public abstract void removeClient(Client paramClient);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.ClientManager
 * JD-Core Version:    0.7.0.1
 */