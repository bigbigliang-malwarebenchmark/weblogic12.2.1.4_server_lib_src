/*   1:    */ package com.bea.httppubsub;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import java.util.Map;
/*   5:    */ 
/*   6:    */ public final class FactoryFinder
/*   7:    */ {
/*   8:    */   public static final String PUBSUBSERVER_FACTORY = "com.bea.httppubsub.PubSubServerFactory";
/*   9:    */   public static final String PUBSUBCONFIG_FACTORY = "com.bea.httppubsub.PubSubConfigFactory";
/*  10:    */   private static final String DEFAULT_PUBSUBSERVER_FACTORY = "com.bea.httppubsub.internal.PubSubServerFactoryImpl";
/*  11:    */   private static final String DEFAULT_PUBSUBCONFIG_FACTORY = "com.bea.httppubsub.internal.PubSubConfigFactoryImpl";
/*  12: 44 */   private static Map<String, Object> factories = new HashMap();
/*  13:    */   
/*  14:    */   static
/*  15:    */   {
/*  16:    */     try
/*  17:    */     {
/*  18: 47 */       setFactory("com.bea.httppubsub.PubSubServerFactory", "com.bea.httppubsub.internal.PubSubServerFactoryImpl");
/*  19: 48 */       setFactory("com.bea.httppubsub.PubSubConfigFactory", "com.bea.httppubsub.internal.PubSubConfigFactoryImpl");
/*  20:    */     }
/*  21:    */     catch (Exception e)
/*  22:    */     {
/*  23: 50 */       throw new RuntimeException(e);
/*  24:    */     }
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static Object getFactory(String factoryName)
/*  28:    */     throws PubSubServerException
/*  29:    */   {
/*  30: 73 */     if (factoryName == null) {
/*  31: 74 */       throw new NullPointerException("The parameter factoryName is null");
/*  32:    */     }
/*  33: 75 */     if (!validateFactoryName(factoryName)) {
/*  34: 76 */       throw new IllegalArgumentException("The parameter factoryName is invalid");
/*  35:    */     }
/*  36: 77 */     return factories.get(factoryName);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static void setFactory(String factoryName, String implName)
/*  40:    */     throws PubSubServerException
/*  41:    */   {
/*  42: 97 */     if ((factoryName == null) || (implName == null)) {
/*  43: 98 */       throw new NullPointerException("The parameter factoryName or implName is null");
/*  44:    */     }
/*  45:100 */     if (!validateFactoryName(factoryName)) {
/*  46:101 */       throw new IllegalArgumentException("The parameter factoryName is invalid");
/*  47:    */     }
/*  48:103 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*  49:    */     try
/*  50:    */     {
/*  51:106 */       Class clz = cl.loadClass(implName);
/*  52:107 */       factories.put(factoryName, clz.newInstance());
/*  53:    */     }
/*  54:    */     catch (ClassNotFoundException cnfe)
/*  55:    */     {
/*  56:    */       try
/*  57:    */       {
/*  58:112 */         Class clz = FactoryFinder.class.getClassLoader().loadClass(implName);
/*  59:113 */         factories.put(factoryName, clz.newInstance());
/*  60:    */       }
/*  61:    */       catch (Exception e)
/*  62:    */       {
/*  63:115 */         throw new PubSubServerException("FactoryFinder can't load factory " + factoryName + "'s implementation class " + implName);
/*  64:    */       }
/*  65:    */     }
/*  66:    */     catch (Exception e)
/*  67:    */     {
/*  68:119 */       throw new PubSubServerException("FactoryFinder can't load factory " + factoryName + "'s implementation class " + implName);
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   private static boolean validateFactoryName(String factoryname)
/*  73:    */   {
/*  74:125 */     return ("com.bea.httppubsub.PubSubServerFactory".equals(factoryname)) || 
/*  75:126 */       ("com.bea.httppubsub.PubSubConfigFactory".equals(factoryname));
/*  76:    */   }
/*  77:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.FactoryFinder
 * JD-Core Version:    0.7.0.1
 */