package com.bea.httppubsub;

import com.bea.httppubsub.bayeux.messages.AbstractBayeuxMessage;
import java.io.IOException;
import java.util.List;

public abstract interface PubSubServer
{
  public abstract String getName();
  
  public abstract Channel findChannel(String paramString);
  
  public abstract Channel findOrCreateChannel(Client paramClient, String paramString)
    throws PubSubSecurityException;
  
  public abstract void deleteChannel(Client paramClient, String paramString)
    throws PubSubSecurityException;
  
  public abstract void publishToChannel(LocalClient paramLocalClient, String paramString1, String paramString2)
    throws PubSubSecurityException;
  
  public abstract void subscribeToChannel(LocalClient paramLocalClient, String paramString)
    throws PubSubSecurityException;
  
  public abstract void unsubscribeToChannel(LocalClient paramLocalClient, String paramString);
  
  public abstract boolean routeMessages(List<AbstractBayeuxMessage> paramList, Transport paramTransport)
    throws PubSubServerException, IOException;
  
  public abstract ClientManager getClientManager();
  
  public abstract MessageFactory getMessageFactory();
  
  public abstract int getConnectionIdleTimeout();
  
  public abstract int getClientTimeout();
  
  public abstract int getReconnectInterval(boolean paramBoolean);
  
  public abstract boolean isMultiFrameSupported();
  
  public abstract int getPersistentClientTimeout();
  
  public abstract String[] getSupportedConnectionTypes();
  
  public abstract boolean isAllowPublishDirectly();
  
  public abstract PubSubContext getContext();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.PubSubServer
 * JD-Core Version:    0.7.0.1
 */