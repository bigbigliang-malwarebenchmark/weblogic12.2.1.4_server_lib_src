package com.bea.httppubsub;

import java.io.Serializable;
import java.util.Set;

public abstract interface Client
  extends Serializable
{
  public abstract String getId();
  
  public abstract long getLastAccessTime();
  
  public abstract Set<String> getChannelSubscriptions();
  
  public abstract long getPublishedMessageCount();
  
  public abstract void updateLastAccessTime();
  
  public abstract AuthenticatedUser getAuthenticatedUser();
  
  public abstract String getBrowserId();
  
  public abstract boolean isMultiFrame();
  
  public abstract void setMultiFrame(boolean paramBoolean);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.Client
 * JD-Core Version:    0.7.0.1
 */