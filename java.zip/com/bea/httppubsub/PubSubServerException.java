/*  1:   */ package com.bea.httppubsub;
/*  2:   */ 
/*  3:   */ public class PubSubServerException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1068834620601960861L;
/*  7:   */   
/*  8:   */   public PubSubServerException() {}
/*  9:   */   
/* 10:   */   public PubSubServerException(String message)
/* 11:   */   {
/* 12:18 */     super(message);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public PubSubServerException(String message, Throwable cause)
/* 16:   */   {
/* 17:22 */     super(message, cause);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public PubSubServerException(Throwable cause)
/* 21:   */   {
/* 22:26 */     super(cause);
/* 23:   */   }
/* 24:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.PubSubServerException
 * JD-Core Version:    0.7.0.1
 */