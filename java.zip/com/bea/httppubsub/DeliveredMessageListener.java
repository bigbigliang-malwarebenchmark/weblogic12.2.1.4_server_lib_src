package com.bea.httppubsub;

import java.util.EventListener;

public abstract interface DeliveredMessageListener
  extends EventListener
{
  public abstract void onPublish(DeliveredMessageEvent paramDeliveredMessageEvent);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.httppubsub.DeliveredMessageListener
 * JD-Core Version:    0.7.0.1
 */