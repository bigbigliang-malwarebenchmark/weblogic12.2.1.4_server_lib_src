package com.bea.core.security.managers;

import com.bea.common.security.service.AuditService;
import com.bea.common.security.service.AuthorizationService;
import com.bea.common.security.service.CredentialMappingService;
import com.bea.common.security.service.IdentityService;
import com.bea.common.security.service.JAASAuthenticationService;
import com.bea.common.security.service.RoleMappingService;

public abstract interface ManagerService
  extends Manager
{
  public abstract void setIdentityService(IdentityService paramIdentityService);
  
  public abstract void setAuthorizationService(AuthorizationService paramAuthorizationService);
  
  public abstract void setAuditService(AuditService paramAuditService);
  
  public abstract void setRoleMappingService(RoleMappingService paramRoleMappingService);
  
  public abstract void setJAASService(JAASAuthenticationService paramJAASAuthenticationService);
  
  public abstract void setCredentialMappingService(CredentialMappingService paramCredentialMappingService);
  
  public abstract void initialize();
  
  public abstract void destroy();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.managers.ManagerService
 * JD-Core Version:    0.7.0.1
 */