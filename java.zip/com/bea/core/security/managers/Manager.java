package com.bea.core.security.managers;

import java.util.Map;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginException;
import weblogic.security.acl.internal.AuthenticatedSubject;
import weblogic.security.service.ContextHandler;
import weblogic.security.spi.AuditEvent;
import weblogic.security.spi.Direction;
import weblogic.security.spi.Resource;

public abstract interface Manager
{
  public abstract AuthenticatedSubject getCurrentIdentity();
  
  public abstract boolean isAccessAllowed(AuthenticatedSubject paramAuthenticatedSubject, Map paramMap, Resource paramResource, ContextHandler paramContextHandler, Direction paramDirection);
  
  public abstract void writeEvent(AuditEvent paramAuditEvent);
  
  public abstract Map getRoles(AuthenticatedSubject paramAuthenticatedSubject, Resource paramResource, ContextHandler paramContextHandler);
  
  public abstract AuthenticatedSubject authenticate(CallbackHandler paramCallbackHandler, ContextHandler paramContextHandler)
    throws LoginException;
  
  public abstract Object[] getCredentials(AuthenticatedSubject paramAuthenticatedSubject1, AuthenticatedSubject paramAuthenticatedSubject2, Resource paramResource, ContextHandler paramContextHandler, String paramString);
  
  public abstract Object[] getCredentials(AuthenticatedSubject paramAuthenticatedSubject, String paramString1, Resource paramResource, ContextHandler paramContextHandler, String paramString2);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.managers.Manager
 * JD-Core Version:    0.7.0.1
 */