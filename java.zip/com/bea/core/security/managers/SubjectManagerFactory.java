/*  1:   */ package com.bea.core.security.managers;
/*  2:   */ 
/*  3:   */ import com.bea.core.security.managers.internal.SubjectManagerFactoryImpl;
/*  4:   */ import weblogic.security.subject.SubjectManager;
/*  5:   */ 
/*  6:   */ public abstract class SubjectManagerFactory
/*  7:   */ {
/*  8:13 */   private static final SubjectManagerFactory INSTANCE = new SubjectManagerFactoryImpl();
/*  9:   */   
/* 10:   */   public static SubjectManagerFactory getInstance()
/* 11:   */   {
/* 12:21 */     return INSTANCE;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public abstract SubjectManager getSubjectManager();
/* 16:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.managers.SubjectManagerFactory
 * JD-Core Version:    0.7.0.1
 */