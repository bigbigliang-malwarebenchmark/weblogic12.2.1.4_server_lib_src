package com.bea.core.security.managers;

public class NotInitializedException
  extends Exception
{
  private static final long serialVersionUID = -2606648028039064551L;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.managers.NotInitializedException
 * JD-Core Version:    0.7.0.1
 */