/*  1:   */ package com.bea.core.security.managers.internal;
/*  2:   */ 
/*  3:   */ import com.bea.core.security.managers.ManagerFactory;
/*  4:   */ import com.bea.core.security.managers.ManagerService;
/*  5:   */ 
/*  6:   */ public class ManagerFactoryImpl
/*  7:   */   extends ManagerFactory
/*  8:   */ {
/*  9:   */   public ManagerService getManagerService()
/* 10:   */   {
/* 11:17 */     return new ManagerImpl();
/* 12:   */   }
/* 13:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.managers.internal.ManagerFactoryImpl
 * JD-Core Version:    0.7.0.1
 */