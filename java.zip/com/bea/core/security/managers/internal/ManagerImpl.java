/*   1:    */ package com.bea.core.security.managers.internal;
/*   2:    */ 
/*   3:    */ import com.bea.common.security.service.AuditService;
/*   4:    */ import com.bea.common.security.service.AuthorizationService;
/*   5:    */ import com.bea.common.security.service.CredentialMappingService;
/*   6:    */ import com.bea.common.security.service.Identity;
/*   7:    */ import com.bea.common.security.service.IdentityService;
/*   8:    */ import com.bea.common.security.service.JAASAuthenticationService;
/*   9:    */ import com.bea.common.security.service.RoleMappingService;
/*  10:    */ import com.bea.core.security.managers.CEO;
/*  11:    */ import com.bea.core.security.managers.ManagerService;
/*  12:    */ import java.util.HashMap;
/*  13:    */ import java.util.Map;
/*  14:    */ import javax.security.auth.Subject;
/*  15:    */ import javax.security.auth.callback.CallbackHandler;
/*  16:    */ import javax.security.auth.login.LoginException;
/*  17:    */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*  18:    */ import weblogic.security.service.ContextHandler;
/*  19:    */ import weblogic.security.spi.AuditEvent;
/*  20:    */ import weblogic.security.spi.Direction;
/*  21:    */ import weblogic.security.spi.Resource;
/*  22:    */ 
/*  23:    */ public class ManagerImpl
/*  24:    */   implements ManagerService
/*  25:    */ {
/*  26:    */   private IdentityService identityService;
/*  27:    */   private AuthorizationService authorizationService;
/*  28:    */   private AuditService auditService;
/*  29:    */   private RoleMappingService roleMapper;
/*  30:    */   private JAASAuthenticationService jaasService;
/*  31:    */   private CredentialMappingService credMapService;
/*  32:    */   
/*  33:    */   public void setIdentityService(IdentityService service)
/*  34:    */   {
/*  35: 50 */     this.identityService = service;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setAuthorizationService(AuthorizationService service)
/*  39:    */   {
/*  40: 58 */     this.authorizationService = service;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void setAuditService(AuditService service)
/*  44:    */   {
/*  45: 66 */     this.auditService = service;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void setRoleMappingService(RoleMappingService service)
/*  49:    */   {
/*  50: 74 */     this.roleMapper = service;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void setJAASService(JAASAuthenticationService service)
/*  54:    */   {
/*  55: 82 */     this.jaasService = service;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void setCredentialMappingService(CredentialMappingService service)
/*  59:    */   {
/*  60: 90 */     this.credMapService = service;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void initialize()
/*  64:    */   {
/*  65: 97 */     CEO.setManager(this);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void destroy() {}
/*  69:    */   
/*  70:    */   private Identity AStoID(AuthenticatedSubject as)
/*  71:    */   {
/*  72:108 */     Subject subject = as.getSubject();
/*  73:109 */     if (subject == null) {
/*  74:109 */       return null;
/*  75:    */     }
/*  76:111 */     return this.identityService.getIdentityFromSubject(subject);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public AuthenticatedSubject getCurrentIdentity()
/*  80:    */   {
/*  81:115 */     Identity identity = this.identityService.getCurrentIdentity();
/*  82:116 */     if (identity == null) {
/*  83:116 */       return new AuthenticatedSubject();
/*  84:    */     }
/*  85:118 */     return new AuthenticatedSubject(identity.getSubject());
/*  86:    */   }
/*  87:    */   
/*  88:    */   public boolean isAccessAllowed(AuthenticatedSubject aSubject, Map roles, Resource resource, ContextHandler handler, Direction direction)
/*  89:    */   {
/*  90:126 */     Identity identity = AStoID(aSubject);
/*  91:127 */     if (identity == null) {
/*  92:127 */       return false;
/*  93:    */     }
/*  94:129 */     return this.authorizationService.isAccessAllowed(identity, roles, resource, handler, direction);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void writeEvent(AuditEvent event)
/*  98:    */   {
/*  99:133 */     this.auditService.writeEvent(event);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Map getRoles(AuthenticatedSubject aSubject, Resource resource, ContextHandler handler)
/* 103:    */   {
/* 104:137 */     Identity identity = AStoID(aSubject);
/* 105:138 */     if (identity == null) {
/* 106:138 */       return new HashMap();
/* 107:    */     }
/* 108:140 */     return this.roleMapper.getRoles(identity, resource, handler);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public AuthenticatedSubject authenticate(CallbackHandler callbackHandler, ContextHandler contextHandler)
/* 112:    */     throws LoginException
/* 113:    */   {
/* 114:146 */     Identity identity = this.jaasService.authenticate(callbackHandler, contextHandler);
/* 115:    */     
/* 116:148 */     Subject subject = identity.getSubject();
/* 117:149 */     return new AuthenticatedSubject(subject);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public Object[] getCredentials(AuthenticatedSubject requestor, AuthenticatedSubject initiator, Resource resource, ContextHandler handler, String credType)
/* 121:    */   {
/* 122:157 */     Identity rId = AStoID(requestor);
/* 123:158 */     Identity iId = AStoID(initiator);
/* 124:160 */     if ((rId == null) || (iId == null)) {
/* 125:161 */       return new Object[0];
/* 126:    */     }
/* 127:164 */     return this.credMapService.getCredentials(rId, iId, resource, handler, credType);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public Object[] getCredentials(AuthenticatedSubject requestor, String initiator, Resource resource, ContextHandler handler, String credType)
/* 131:    */   {
/* 132:172 */     Identity rId = AStoID(requestor);
/* 133:174 */     if (rId == null) {
/* 134:175 */       return new Object[0];
/* 135:    */     }
/* 136:178 */     return this.credMapService.getCredentials(rId, initiator, resource, handler, credType);
/* 137:    */   }
/* 138:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.managers.internal.ManagerImpl
 * JD-Core Version:    0.7.0.1
 */