/*   1:    */ package com.bea.core.security.managers.internal;
/*   2:    */ 
/*   3:    */ import com.bea.core.security.managers.NotSupportedException;
/*   4:    */ import java.security.Principal;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.Set;
/*   7:    */ import javax.security.auth.Subject;
/*   8:    */ import weblogic.kernel.AuditableThread;
/*   9:    */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*  10:    */ import weblogic.security.subject.AbstractSubject;
/*  11:    */ import weblogic.security.subject.SubjectManager;
/*  12:    */ 
/*  13:    */ public class WLSClientSubjectManagerImpl
/*  14:    */   extends SubjectManager
/*  15:    */ {
/*  16: 22 */   private final WLSClientStackService stackService = new WLSClientStackService();
/*  17: 24 */   private static final Principal KERNEL_PRINCIPAL = new WLSClientSubjectManagerImpl.1();
/*  18:    */   private static final AbstractSubject KERNEL_ID;
/*  19:    */   
/*  20:    */   static
/*  21:    */   {
/*  22: 31 */     Set<Principal> principals = new HashSet();
/*  23: 32 */     principals.add(KERNEL_PRINCIPAL);
/*  24: 33 */     KERNEL_ID = new AuthenticatedSubject(true, principals);
/*  25:    */   }
/*  26:    */   
/*  27:    */   protected AbstractSubject createAbstractSubject(Subject subject)
/*  28:    */   {
/*  29: 40 */     throw new NotSupportedException();
/*  30:    */   }
/*  31:    */   
/*  32:    */   protected AbstractSubject getKernelIdentity()
/*  33:    */   {
/*  34: 47 */     return KERNEL_ID;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public AbstractSubject getCurrentSubject(AbstractSubject kernelID)
/*  38:    */   {
/*  39: 54 */     AbstractSubject currentIdentity = this.stackService.peekIdentity();
/*  40: 56 */     if (currentIdentity == null) {
/*  41: 57 */       return new AuthenticatedSubject(new Subject());
/*  42:    */     }
/*  43: 60 */     return currentIdentity;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public AbstractSubject getCurrentSubject(AbstractSubject kernelID, AuditableThread auditableThread)
/*  47:    */   {
/*  48: 68 */     throw new NotSupportedException();
/*  49:    */   }
/*  50:    */   
/*  51:    */   public int getSize()
/*  52:    */   {
/*  53: 75 */     return this.stackService.getSize();
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void popSubject(AbstractSubject kernelIdentity)
/*  57:    */   {
/*  58: 82 */     this.stackService.popIdentity();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void pushSubject(AbstractSubject kernelIdentity, AbstractSubject userIdentity)
/*  62:    */   {
/*  63: 90 */     if (userIdentity == null) {
/*  64: 90 */       return;
/*  65:    */     }
/*  66: 92 */     this.stackService.pushIdentity(userIdentity);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public AbstractSubject getAnonymousSubject()
/*  70:    */   {
/*  71: 96 */     return AuthenticatedSubject.ANON;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public String toString()
/*  75:    */   {
/*  76:100 */     return "WLSClientSubjectManagerImpl(" + System.identityHashCode(this) + ")";
/*  77:    */   }
/*  78:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.managers.internal.WLSClientSubjectManagerImpl
 * JD-Core Version:    0.7.0.1
 */