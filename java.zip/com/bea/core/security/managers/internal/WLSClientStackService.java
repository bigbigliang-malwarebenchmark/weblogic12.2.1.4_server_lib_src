/*  1:   */ package com.bea.core.security.managers.internal;
/*  2:   */ 
/*  3:   */ import weblogic.kernel.ThreadLocalStack;
/*  4:   */ import weblogic.security.subject.AbstractSubject;
/*  5:   */ 
/*  6:   */ public class WLSClientStackService
/*  7:   */ {
/*  8:10 */   private static final ThreadLocalStack threadSubject = new ThreadLocalStack(true);
/*  9:   */   
/* 10:   */   public AbstractSubject peekIdentity()
/* 11:   */   {
/* 12:20 */     if (getSize() <= 0) {
/* 13:20 */       return null;
/* 14:   */     }
/* 15:22 */     AbstractSubject obj = (AbstractSubject)threadSubject.get();
/* 16:   */     
/* 17:24 */     return obj;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void pushIdentity(AbstractSubject userIdentity)
/* 21:   */   {
/* 22:29 */     if (userIdentity == null) {
/* 23:30 */       throw new IllegalArgumentException("Illegal null Subject passed as a parameter.");
/* 24:   */     }
/* 25:32 */     threadSubject.push(userIdentity);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public AbstractSubject popIdentity()
/* 29:   */   {
/* 30:38 */     if (getSize() <= 0) {
/* 31:38 */       return null;
/* 32:   */     }
/* 33:40 */     return (AbstractSubject)threadSubject.pop();
/* 34:   */   }
/* 35:   */   
/* 36:   */   public int getSize()
/* 37:   */   {
/* 38:48 */     return threadSubject.getSize();
/* 39:   */   }
/* 40:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.managers.internal.WLSClientStackService
 * JD-Core Version:    0.7.0.1
 */