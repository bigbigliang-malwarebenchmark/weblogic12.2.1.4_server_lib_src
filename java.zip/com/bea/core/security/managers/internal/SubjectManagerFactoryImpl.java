/*  1:   */ package com.bea.core.security.managers.internal;
/*  2:   */ 
/*  3:   */ import com.bea.core.security.Environment;
/*  4:   */ import com.bea.core.security.managers.SubjectManagerFactory;
/*  5:   */ import weblogic.security.subject.SubjectManager;
/*  6:   */ 
/*  7:   */ public class SubjectManagerFactoryImpl
/*  8:   */   extends SubjectManagerFactory
/*  9:   */ {
/* 10:16 */   private final SubjectManager subjectManager = Environment.getEnvironment().getSubjectManager();
/* 11:   */   
/* 12:   */   public SubjectManager getSubjectManager()
/* 13:   */   {
/* 14:22 */     return this.subjectManager;
/* 15:   */   }
/* 16:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.managers.internal.SubjectManagerFactoryImpl
 * JD-Core Version:    0.7.0.1
 */