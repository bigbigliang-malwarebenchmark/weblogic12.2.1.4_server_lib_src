/*  1:   */ package com.bea.core.security.managers.internal;
/*  2:   */ 
/*  3:   */ import java.util.LinkedList;
/*  4:   */ import weblogic.security.subject.AbstractSubject;
/*  5:   */ 
/*  6:   */ public class WLSStackService
/*  7:   */ {
/*  8:13 */   private static ThreadLocal<LinkedList<AbstractSubject>> stack = new WLSStackService.1();
/*  9:   */   
/* 10:   */   public AbstractSubject peekIdentity()
/* 11:   */   {
/* 12:21 */     LinkedList<AbstractSubject> subjectStack = (LinkedList)stack.get();
/* 13:23 */     if (subjectStack.size() <= 0) {
/* 14:23 */       return null;
/* 15:   */     }
/* 16:25 */     return (AbstractSubject)subjectStack.getLast();
/* 17:   */   }
/* 18:   */   
/* 19:   */   public AbstractSubject popIdentity()
/* 20:   */   {
/* 21:29 */     LinkedList<AbstractSubject> subjectStack = (LinkedList)stack.get();
/* 22:31 */     if (subjectStack.size() <= 0) {
/* 23:31 */       return null;
/* 24:   */     }
/* 25:33 */     return (AbstractSubject)subjectStack.removeLast();
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void pushIdentity(AbstractSubject identity)
/* 29:   */   {
/* 30:37 */     if (identity == null) {
/* 31:37 */       throw new IllegalArgumentException();
/* 32:   */     }
/* 33:39 */     LinkedList<AbstractSubject> subjectStack = (LinkedList)stack.get();
/* 34:   */     
/* 35:41 */     subjectStack.addLast(identity);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public int getSize()
/* 39:   */   {
/* 40:48 */     return ((LinkedList)stack.get()).size();
/* 41:   */   }
/* 42:   */   
/* 43:   */   public String toString()
/* 44:   */   {
/* 45:55 */     StringBuffer sb = new StringBuffer();
/* 46:   */     
/* 47:57 */     LinkedList<AbstractSubject> ids = (LinkedList)stack.get();
/* 48:   */     
/* 49:59 */     int lcv = 0;
/* 50:60 */     for (AbstractSubject id : ids) {
/* 51:61 */       sb.append("\t" + lcv++ + ". " + id + "\n");
/* 52:   */     }
/* 53:64 */     return 
/* 54:65 */       "SecurityStackService(" + System.identityHashCode(this) + ",\n" + sb.toString() + ")";
/* 55:   */   }
/* 56:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.managers.internal.WLSStackService
 * JD-Core Version:    0.7.0.1
 */