/*  1:   */ package com.bea.core.security.managers;
/*  2:   */ 
/*  3:   */ public abstract class ManagerFactory
/*  4:   */ {
/*  5:   */   private static ManagerFactory INSTANCE;
/*  6:   */   
/*  7:   */   public static ManagerFactory getInstance()
/*  8:   */   {
/*  9:32 */     return INSTANCE;
/* 10:   */   }
/* 11:   */   
/* 12:   */   public static void setInstance(ManagerFactory factory)
/* 13:   */   {
/* 14:40 */     INSTANCE = factory;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public abstract ManagerService getManagerService();
/* 18:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.managers.ManagerFactory
 * JD-Core Version:    0.7.0.1
 */