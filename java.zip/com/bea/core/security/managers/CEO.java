/*  1:   */ package com.bea.core.security.managers;
/*  2:   */ 
/*  3:   */ public class CEO
/*  4:   */ {
/*  5:   */   private static Manager manager;
/*  6:   */   
/*  7:   */   public static Manager getManager()
/*  8:   */     throws NotInitializedException
/*  9:   */   {
/* 10:29 */     if (manager == null) {
/* 11:30 */       throw new NotInitializedException();
/* 12:   */     }
/* 13:33 */     return manager;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public static void setManager(Manager paramManager)
/* 17:   */   {
/* 18:37 */     manager = paramManager;
/* 19:   */   }
/* 20:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.managers.CEO
 * JD-Core Version:    0.7.0.1
 */