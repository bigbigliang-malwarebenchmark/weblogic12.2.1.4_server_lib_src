/*  1:   */ package com.bea.core.security;
/*  2:   */ 
/*  3:   */ import com.bea.core.security.managers.internal.WLSClientSubjectManagerImpl;
/*  4:   */ import weblogic.security.subject.SubjectManager;
/*  5:   */ 
/*  6:   */ public class WLSClientEnvironmentImpl
/*  7:   */   extends Environment
/*  8:   */ {
/*  9:15 */   private SubjectManager subjectManager = new WLSClientSubjectManagerImpl();
/* 10:   */   
/* 11:   */   public SubjectManager getSubjectManager()
/* 12:   */   {
/* 13:18 */     return this.subjectManager;
/* 14:   */   }
/* 15:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.security.WLSClientEnvironmentImpl
 * JD-Core Version:    0.7.0.1
 */