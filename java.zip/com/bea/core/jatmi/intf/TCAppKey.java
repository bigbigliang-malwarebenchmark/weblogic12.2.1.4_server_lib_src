package com.bea.core.jatmi.intf;

import weblogic.wtc.jatmi.TPException;
import weblogic.wtc.jatmi.UserRec;

public abstract interface TCAppKey
{
  public static final int UIDMASK = 131071;
  public static final int GIDMASK = 16383;
  public static final int GIDSHIFT = 17;
  public static final int TPSYSADM_KEY = -2147483648;
  public static final int TPSYSOP_KEY = -1073741824;
  
  public abstract void init(String paramString, boolean paramBoolean, int paramInt)
    throws TPException;
  
  public abstract void uninit()
    throws TPException;
  
  public abstract UserRec getTuxedoUserRecord(TCAuthenticatedUser paramTCAuthenticatedUser);
  
  public abstract void doCache(boolean paramBoolean);
  
  public abstract boolean isCached();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.jatmi.intf.TCAppKey
 * JD-Core Version:    0.7.0.1
 */