package com.bea.core.jatmi.intf;

public abstract interface TCAuthenticatedUser
{
  public abstract void setAsCurrentUser();
  
  public abstract Object[] getPrincipals();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.core.jatmi.intf.TCAuthenticatedUser
 * JD-Core Version:    0.7.0.1
 */