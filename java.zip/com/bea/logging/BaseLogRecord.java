/*   1:    */ package com.bea.logging;
/*   2:    */ 
/*   3:    */ import java.util.Date;
/*   4:    */ import java.util.Map.Entry;
/*   5:    */ import java.util.Properties;
/*   6:    */ import java.util.Set;
/*   7:    */ import java.util.logging.Level;
/*   8:    */ import java.util.logging.LogRecord;
/*   9:    */ import weblogic.i18n.logging.CatalogMessage;
/*  10:    */ import weblogic.i18n.logging.LogMessage;
/*  11:    */ import weblogic.i18n.logging.Severities;
/*  12:    */ 
/*  13:    */ public class BaseLogRecord
/*  14:    */   extends LogRecord
/*  15:    */   implements BaseLogEntry
/*  16:    */ {
/*  17:    */   private static final long serialVersionUID = -4414913723445251798L;
/*  18:    */   private ThrowableWrapper throwableWrapper;
/*  19: 25 */   private int severity = 64;
/*  20: 26 */   private String id = MsgIdPrefixConverter.getDefaultMsgId();
/*  21: 27 */   private String subSystem = "Default";
/*  22: 28 */   private String threadId = "";
/*  23: 29 */   private String userId = "";
/*  24: 30 */   private String transactionId = "";
/*  25: 31 */   private String serverName = "";
/*  26: 32 */   private String diagnosticContextId = "";
/*  27: 33 */   private String machineName = "";
/*  28: 34 */   private Properties supplementalAttrs = new Properties();
/*  29:    */   private transient String formattedDate;
/*  30:    */   private transient String diagnosticVolume;
/*  31: 38 */   private transient boolean gatherable = false;
/*  32:    */   private String severityString;
/*  33:    */   private boolean excludePartition;
/*  34:    */   
/*  35:    */   private BaseLogRecord(Level level, String msg)
/*  36:    */   {
/*  37: 45 */     super(level, msg);
/*  38: 46 */     this.threadId = Thread.currentThread().getName();
/*  39: 47 */     String loggerName = getLoggerName();
/*  40: 48 */     if (loggerName != null) {
/*  41: 49 */       this.subSystem = loggerName;
/*  42:    */     }
/*  43:    */   }
/*  44:    */   
/*  45:    */   public BaseLogRecord(int severityLevel, String msg)
/*  46:    */   {
/*  47: 60 */     this(LogLevel.getLevel(severityLevel), msg);
/*  48: 61 */     setSeverity(severityLevel);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public BaseLogRecord(int severity, String msg, Throwable throwable)
/*  52:    */   {
/*  53: 72 */     this(severity, msg);
/*  54: 73 */     setThrown(throwable);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public BaseLogRecord(LogMessage logMessage)
/*  58:    */   {
/*  59: 82 */     this(logMessage.getSeverity(), logMessage.getMessage());
/*  60: 83 */     setSeverity(logMessage.getSeverity());
/*  61: 84 */     String msgIdPrefix = logMessage.getMessageIdPrefix();
/*  62: 85 */     if ((msgIdPrefix != null) && (msgIdPrefix.length() > 0))
/*  63:    */     {
/*  64: 86 */       String msgId = logMessage.getMessageId();
/*  65: 87 */       if ((msgId != null) && (msgId.length() > 0))
/*  66:    */       {
/*  67: 88 */         msgIdPrefix = MsgIdPrefixConverter.convertMsgIdPrefix(msgIdPrefix);
/*  68: 89 */         this.id = (msgIdPrefix + "-" + msgId);
/*  69:    */       }
/*  70:    */     }
/*  71:    */     else
/*  72:    */     {
/*  73: 92 */       setId(logMessage.getMessageId());
/*  74:    */     }
/*  75: 95 */     boolean stackTraceEnabled = true;
/*  76: 97 */     if ((logMessage instanceof CatalogMessage))
/*  77:    */     {
/*  78: 98 */       CatalogMessage catMsg = (CatalogMessage)logMessage;
/*  79: 99 */       setParameters(catMsg.getArguments());
/*  80:100 */       stackTraceEnabled = catMsg.isStackTraceEnabled();
/*  81:101 */       setDiagnosticVolume(catMsg.getDiagnosticVolume());
/*  82:102 */       setExcludePartition(catMsg.isExcludePartition());
/*  83:    */     }
/*  84:105 */     Properties msgSuppAttrs = logMessage.getSupplementalAttributes();
/*  85:106 */     if ((msgSuppAttrs != null) && (!msgSuppAttrs.isEmpty()))
/*  86:    */     {
/*  87:107 */       Set<Map.Entry<Object, Object>> entries = msgSuppAttrs.entrySet();
/*  88:108 */       for (Map.Entry<Object, Object> entry : entries) {
/*  89:109 */         this.supplementalAttrs.put(entry.getKey(), entry.getValue());
/*  90:    */       }
/*  91:    */     }
/*  92:113 */     this.subSystem = logMessage.getSubsystem();
/*  93:114 */     setLoggerName(this.subSystem);
/*  94:    */     
/*  95:116 */     Throwable th = logMessage.getThrowable();
/*  96:118 */     if (stackTraceEnabled) {
/*  97:119 */       setThrown(th);
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   public BaseLogRecord(LogRecord rec)
/* 102:    */   {
/* 103:128 */     super(rec.getLevel(), rec.getMessage());
/* 104:129 */     setLoggerName(rec.getLoggerName());
/* 105:130 */     setMillis(rec.getMillis());
/* 106:131 */     if ((rec instanceof BaseLogRecord))
/* 107:    */     {
/* 108:132 */       BaseLogRecord src = (BaseLogRecord)rec;
/* 109:133 */       this.throwableWrapper = src.throwableWrapper;
/* 110:134 */       setSeverity(src.severity);
/* 111:135 */       this.id = src.id;
/* 112:136 */       this.subSystem = src.subSystem;
/* 113:137 */       this.threadId = src.threadId;
/* 114:138 */       this.userId = src.userId;
/* 115:139 */       this.transactionId = src.transactionId;
/* 116:140 */       this.serverName = src.serverName;
/* 117:141 */       this.diagnosticContextId = src.diagnosticContextId;
/* 118:142 */       this.machineName = src.machineName;
/* 119:143 */       this.formattedDate = src.formattedDate;
/* 120:144 */       this.diagnosticVolume = src.diagnosticVolume;
/* 121:145 */       this.gatherable = src.gatherable;
/* 122:    */     }
/* 123:    */     else
/* 124:    */     {
/* 125:147 */       this.severity = LogLevel.getSeverity(rec.getLevel());
/* 126:148 */       Throwable th = rec.getThrown();
/* 127:149 */       if (th != null) {
/* 128:150 */         this.throwableWrapper = new ThrowableWrapper(th);
/* 129:    */       }
/* 130:152 */       this.threadId = ("ThreadId:" + rec.getThreadID());
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   public long getTimestamp()
/* 135:    */   {
/* 136:161 */     return getMillis();
/* 137:    */   }
/* 138:    */   
/* 139:    */   public String getLogMessage()
/* 140:    */   {
/* 141:169 */     return getMessage();
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void ensureFormattedDateInitialized(DateFormatter df)
/* 145:    */   {
/* 146:178 */     if (this.formattedDate == null) {
/* 147:179 */       this.formattedDate = df.formatDate(new Date(getTimestamp()));
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public String getFormattedDate()
/* 152:    */   {
/* 153:188 */     ensureFormattedDateInitialized(DateFormatter.getDefaultInstance());
/* 154:189 */     return this.formattedDate;
/* 155:    */   }
/* 156:    */   
/* 157:    */   public void setThrown(Throwable th)
/* 158:    */   {
/* 159:197 */     if (th != null) {
/* 160:199 */       this.throwableWrapper = new ThrowableWrapper(th);
/* 161:    */     } else {
/* 162:201 */       this.throwableWrapper = null;
/* 163:    */     }
/* 164:    */   }
/* 165:    */   
/* 166:    */   public Throwable getThrown()
/* 167:    */   {
/* 168:209 */     if (this.throwableWrapper != null) {
/* 169:210 */       return this.throwableWrapper.getThrowable();
/* 170:    */     }
/* 171:212 */     return null;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public int getSeverity()
/* 175:    */   {
/* 176:221 */     return this.severity;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public String getId()
/* 180:    */   {
/* 181:229 */     return this.id;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public void setId(String messageId)
/* 185:    */   {
/* 186:238 */     if ((messageId == null) || (messageId.length() == 0)) {
/* 187:239 */       messageId = MsgIdPrefixConverter.getDefaultMsgId();
/* 188:    */     }
/* 189:241 */     this.id = messageId;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public String getSubsystem()
/* 193:    */   {
/* 194:249 */     return this.subSystem;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public ThrowableWrapper getThrowableWrapper()
/* 198:    */   {
/* 199:256 */     return this.throwableWrapper;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public void setThrowableWrapper(ThrowableWrapper throwableInfo)
/* 203:    */   {
/* 204:263 */     this.throwableWrapper = throwableInfo;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void setThreadName(String tid)
/* 208:    */   {
/* 209:270 */     if (tid != null) {
/* 210:271 */       this.threadId = tid;
/* 211:    */     }
/* 212:    */   }
/* 213:    */   
/* 214:    */   public String getThreadName()
/* 215:    */   {
/* 216:280 */     return this.threadId;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public void setUserId(String uid)
/* 220:    */   {
/* 221:287 */     if (uid != null) {
/* 222:288 */       this.userId = uid;
/* 223:    */     }
/* 224:    */   }
/* 225:    */   
/* 226:    */   public String getUserId()
/* 227:    */   {
/* 228:297 */     return this.userId;
/* 229:    */   }
/* 230:    */   
/* 231:    */   public void setTransactionId(String txid)
/* 232:    */   {
/* 233:304 */     if (txid != null) {
/* 234:305 */       this.transactionId = txid;
/* 235:    */     }
/* 236:    */   }
/* 237:    */   
/* 238:    */   public String getTransactionId()
/* 239:    */   {
/* 240:314 */     return this.transactionId;
/* 241:    */   }
/* 242:    */   
/* 243:    */   public String getServerName()
/* 244:    */   {
/* 245:322 */     return this.serverName;
/* 246:    */   }
/* 247:    */   
/* 248:    */   public void setServerName(String name)
/* 249:    */   {
/* 250:329 */     if (name != null) {
/* 251:330 */       this.serverName = name;
/* 252:    */     }
/* 253:    */   }
/* 254:    */   
/* 255:    */   public String getDiagnosticContextId()
/* 256:    */   {
/* 257:339 */     return this.diagnosticContextId;
/* 258:    */   }
/* 259:    */   
/* 260:    */   public void setDiagnosticContextId(String id)
/* 261:    */   {
/* 262:347 */     if (id != null) {
/* 263:348 */       this.diagnosticContextId = id;
/* 264:    */     }
/* 265:    */   }
/* 266:    */   
/* 267:    */   public String getMachineName()
/* 268:    */   {
/* 269:357 */     return this.machineName;
/* 270:    */   }
/* 271:    */   
/* 272:    */   public void setMachineName(String machineName)
/* 273:    */   {
/* 274:364 */     if (machineName != null) {
/* 275:365 */       this.machineName = machineName;
/* 276:    */     }
/* 277:    */   }
/* 278:    */   
/* 279:    */   public void setLoggerName(String loggerName)
/* 280:    */   {
/* 281:373 */     if (loggerName != null)
/* 282:    */     {
/* 283:374 */       super.setLoggerName(loggerName);
/* 284:375 */       this.subSystem = loggerName;
/* 285:    */     }
/* 286:    */   }
/* 287:    */   
/* 288:    */   public void setLevel(Level level)
/* 289:    */   {
/* 290:383 */     super.setLevel(level);
/* 291:384 */     setSeverity(LogLevel.getSeverity(level));
/* 292:    */   }
/* 293:    */   
/* 294:    */   public void setDiagnosticVolume(String diagnosticVolume)
/* 295:    */   {
/* 296:391 */     this.diagnosticVolume = diagnosticVolume;
/* 297:392 */     if ((diagnosticVolume != null) && (!diagnosticVolume.equalsIgnoreCase("off"))) {
/* 298:393 */       this.gatherable = true;
/* 299:    */     }
/* 300:    */   }
/* 301:    */   
/* 302:    */   public String getDiagnosticVolume()
/* 303:    */   {
/* 304:400 */     return this.diagnosticVolume;
/* 305:    */   }
/* 306:    */   
/* 307:    */   public boolean isGatherable()
/* 308:    */   {
/* 309:407 */     return this.gatherable;
/* 310:    */   }
/* 311:    */   
/* 312:    */   public Properties getSupplementalAttributes()
/* 313:    */   {
/* 314:416 */     return this.supplementalAttrs;
/* 315:    */   }
/* 316:    */   
/* 317:    */   private void setSeverity(int severityLevel)
/* 318:    */   {
/* 319:424 */     this.severity = severityLevel;
/* 320:425 */     this.severityString = Severities.severityNumToString(this.severity);
/* 321:426 */     this.supplementalAttrs.put(LoggingSupplementalAttribute.SUPP_ATTR_SEVERITY_VALUE
/* 322:427 */       .getAttributeName(), 
/* 323:428 */       Integer.valueOf(this.severity));
/* 324:    */   }
/* 325:    */   
/* 326:    */   public String getSeverityString()
/* 327:    */   {
/* 328:432 */     return this.severityString;
/* 329:    */   }
/* 330:    */   
/* 331:    */   public String getPartitionId()
/* 332:    */   {
/* 333:436 */     return this.supplementalAttrs.getProperty(LoggingSupplementalAttribute.SUPP_ATTR_PARTITION_ID.getAttributeName());
/* 334:    */   }
/* 335:    */   
/* 336:    */   public String getPartitionName()
/* 337:    */   {
/* 338:440 */     return this.supplementalAttrs.getProperty(LoggingSupplementalAttribute.SUPP_ATTR_PARTITION_NAME.getAttributeName());
/* 339:    */   }
/* 340:    */   
/* 341:    */   public boolean isExcludePartition()
/* 342:    */   {
/* 343:444 */     return this.excludePartition;
/* 344:    */   }
/* 345:    */   
/* 346:    */   public void setExcludePartition(boolean value)
/* 347:    */   {
/* 348:448 */     this.excludePartition = value;
/* 349:    */   }
/* 350:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.logging.BaseLogRecord
 * JD-Core Version:    0.7.0.1
 */