/*   1:    */ package com.bea.logging;
/*   2:    */ 
/*   3:    */ import java.util.logging.Level;
/*   4:    */ 
/*   5:    */ public class LogLevel
/*   6:    */   extends Level
/*   7:    */ {
/*   8:    */   public static final int OFF_INT = 2147483647;
/*   9:    */   public static final int EMERGENCY_INT = 1090;
/*  10:    */   public static final int ALERT_INT = 1060;
/*  11:    */   public static final int CRITICAL_INT = 1030;
/*  12:    */   public static final int ERROR_INT = 980;
/*  13: 41 */   public static final int WARNING_INT = Level.WARNING.intValue();
/*  14:    */   public static final int NOTICE_INT = 880;
/*  15: 49 */   public static final int INFO_INT = Level.INFO.intValue();
/*  16:    */   public static final int DEBUG_INT = 495;
/*  17:    */   public static final int TRACE_INT = 295;
/*  18: 62 */   public static final LogLevel OFF = new LogLevel("Off", 2147483647, 0);
/*  19: 68 */   public static final LogLevel EMERGENCY = new LogLevel("Emergency", 1090, 1);
/*  20: 74 */   public static final LogLevel CRITICAL = new LogLevel("Critical", 1030, 4);
/*  21: 80 */   public static final LogLevel ERROR = new LogLevel("Error", 980, 8);
/*  22: 86 */   public static final LogLevel ALERT = new LogLevel("Alert", 1060, 2);
/*  23: 92 */   public static final LogLevel NOTICE = new LogLevel("Notice", 880, 32);
/*  24: 98 */   public static final LogLevel DEBUG = new LogLevel("Debug", 495, 128);
/*  25:104 */   public static final LogLevel WARNING = new LogLevel("Warning", WARNING_INT, 16);
/*  26:110 */   public static final LogLevel INFO = new LogLevel("Info", INFO_INT, 64);
/*  27:116 */   public static final LogLevel TRACE = new LogLevel("Trace", 295, 256);
/*  28:    */   public static final String LOGGING_TEXT_PROPS = "weblogic.i18n.logging.LoggingTextLocalizer";
/*  29:    */   private static final long serialVersionUID = 1796084591280954044L;
/*  30:    */   private final int severity;
/*  31:    */   private String localizedName;
/*  32:    */   
/*  33:    */   protected LogLevel(String name, int value, int severity)
/*  34:    */   {
/*  35:134 */     super(name, value, "weblogic.i18n.logging.LoggingTextLocalizer");
/*  36:135 */     this.severity = severity;
/*  37:136 */     this.localizedName = super.getLocalizedName();
/*  38:    */   }
/*  39:    */   
/*  40:    */   @Deprecated
/*  41:    */   protected String getHeader(Level level)
/*  42:    */   {
/*  43:147 */     return level.getLocalizedName();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public int getSeverity()
/*  47:    */   {
/*  48:155 */     return this.severity;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public String getLocalizedName()
/*  52:    */   {
/*  53:163 */     return this.localizedName;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public boolean equals(Object obj)
/*  57:    */   {
/*  58:171 */     if ((obj != null) && ((obj instanceof LogLevel)))
/*  59:    */     {
/*  60:172 */       LogLevel other = (LogLevel)obj;
/*  61:173 */       return (intValue() == other.intValue()) && (getName().equals(other.getName()));
/*  62:    */     }
/*  63:175 */     return false;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public int hashCode()
/*  67:    */   {
/*  68:182 */     return intValue();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static Level getLevel(int severity)
/*  72:    */   {
/*  73:190 */     switch (severity)
/*  74:    */     {
/*  75:    */     case 0: 
/*  76:192 */       return OFF;
/*  77:    */     case 1: 
/*  78:194 */       return EMERGENCY;
/*  79:    */     case 2: 
/*  80:196 */       return ALERT;
/*  81:    */     case 4: 
/*  82:198 */       return CRITICAL;
/*  83:    */     case 32: 
/*  84:200 */       return NOTICE;
/*  85:    */     case 8: 
/*  86:202 */       return ERROR;
/*  87:    */     case 16: 
/*  88:204 */       return WARNING;
/*  89:    */     case 64: 
/*  90:206 */       return INFO;
/*  91:    */     case 128: 
/*  92:208 */       return DEBUG;
/*  93:    */     case 256: 
/*  94:210 */       return TRACE;
/*  95:    */     }
/*  96:213 */     return INFO;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static int getSeverity(Level level)
/* 100:    */   {
/* 101:221 */     int levelValue = level.intValue();
/* 102:222 */     if (levelValue == 2147483647) {
/* 103:223 */       return 0;
/* 104:    */     }
/* 105:224 */     if (levelValue >= 1090) {
/* 106:225 */       return 1;
/* 107:    */     }
/* 108:226 */     if (levelValue >= 1060) {
/* 109:227 */       return 2;
/* 110:    */     }
/* 111:228 */     if (levelValue >= 1030) {
/* 112:229 */       return 4;
/* 113:    */     }
/* 114:230 */     if (levelValue >= 980) {
/* 115:231 */       return 8;
/* 116:    */     }
/* 117:232 */     if (levelValue >= WARNING_INT) {
/* 118:233 */       return 16;
/* 119:    */     }
/* 120:234 */     if (levelValue >= 880) {
/* 121:235 */       return 32;
/* 122:    */     }
/* 123:236 */     if (levelValue >= INFO_INT) {
/* 124:237 */       return 64;
/* 125:    */     }
/* 126:238 */     if (levelValue >= 495) {
/* 127:239 */       return 128;
/* 128:    */     }
/* 129:241 */     return 256;
/* 130:    */   }
/* 131:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.logging.LogLevel
 * JD-Core Version:    0.7.0.1
 */