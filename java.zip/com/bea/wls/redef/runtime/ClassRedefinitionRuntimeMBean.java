package com.bea.wls.redef.runtime;

import weblogic.management.ManagementException;
import weblogic.management.runtime.RuntimeMBean;

public abstract interface ClassRedefinitionRuntimeMBean
  extends RuntimeMBean
{
  public abstract int getClassRedefinitionCount();
  
  public abstract int getFailedClassRedefinitionCount();
  
  public abstract int getProcessedClassesCount();
  
  public abstract long getTotalClassRedefinitionTime();
  
  public abstract ClassRedefinitionTaskRuntimeMBean redefineClasses()
    throws ManagementException;
  
  public abstract ClassRedefinitionTaskRuntimeMBean redefineClasses(String paramString, String[] paramArrayOfString)
    throws ManagementException;
  
  public abstract ClassRedefinitionTaskRuntimeMBean[] getClassRedefinitionTasks();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.wls.redef.runtime.ClassRedefinitionRuntimeMBean
 * JD-Core Version:    0.7.0.1
 */