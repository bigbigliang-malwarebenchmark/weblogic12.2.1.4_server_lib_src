package com.bea.wls.redef.runtime;

import weblogic.management.runtime.TaskRuntimeMBean;

public abstract interface ClassRedefinitionTaskRuntimeMBean
  extends TaskRuntimeMBean
{
  public abstract int getCandidateClassesCount();
  
  public abstract int getProcessedClassesCount();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.wls.redef.runtime.ClassRedefinitionTaskRuntimeMBean
 * JD-Core Version:    0.7.0.1
 */