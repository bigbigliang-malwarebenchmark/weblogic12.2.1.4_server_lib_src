package com.bea.objectweb.asm;

public abstract class ModuleVisitor
{
  protected final int api;
  protected ModuleVisitor mv;
  
  public ModuleVisitor(int paramInt)
  {
    this(paramInt, null);
  }
  
  public ModuleVisitor(int paramInt, ModuleVisitor paramModuleVisitor)
  {
    if (paramInt != 393216) {
      throw new IllegalArgumentException();
    }
    this.api = paramInt;
    this.mv = paramModuleVisitor;
  }
  
  public void visitRequire(String paramString, int paramInt)
  {
    if (this.mv != null) {
      this.mv.visitRequire(paramString, paramInt);
    }
  }
  
  public void visitExport(String paramString, String... paramVarArgs)
  {
    if (this.mv != null) {
      this.mv.visitExport(paramString, paramVarArgs);
    }
  }
  
  public void visitUse(String paramString)
  {
    if (this.mv != null) {
      this.mv.visitUse(paramString);
    }
  }
  
  public void visitProvide(String paramString1, String paramString2)
  {
    if (this.mv != null) {
      this.mv.visitProvide(paramString1, paramString2);
    }
  }
  
  public void visitEnd()
  {
    if (this.mv != null) {
      this.mv.visitEnd();
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.objectweb.asm.ModuleVisitor
 * JD-Core Version:    0.7.0.1
 */