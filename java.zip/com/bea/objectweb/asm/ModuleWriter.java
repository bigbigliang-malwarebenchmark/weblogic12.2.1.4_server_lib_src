package com.bea.objectweb.asm;

final class ModuleWriter
  extends ModuleVisitor
{
  private final ClassWriter a;
  private int b;
  private int c;
  private ByteVector d;
  private int e;
  private ByteVector f;
  private int g;
  private ByteVector h;
  private int i;
  private ByteVector j;
  
  ModuleWriter(ClassWriter paramClassWriter)
  {
    super(393216);
    this.a = paramClassWriter;
    this.b = 8;
  }
  
  public void visitRequire(String paramString, int paramInt)
  {
    if (this.d == null) {
      this.d = new ByteVector();
    }
    if ((paramInt & 0x1) != 0) {
      paramInt = paramInt & 0xFFFFFFFE | 0x20;
    }
    this.d.putShort(this.a.newUTF8(paramString)).putShort(paramInt);
    this.c += 1;
    this.b += 4;
  }
  
  public void visitExport(String paramString, String... paramVarArgs)
  {
    if (this.f == null) {
      this.f = new ByteVector();
    }
    this.f.putShort(this.a.newUTF8(paramString));
    if (paramVarArgs == null)
    {
      this.f.putShort(0);
      this.b += 4;
    }
    else
    {
      this.f.putShort(paramVarArgs.length);
      String[] arrayOfString = paramVarArgs;
      int k = arrayOfString.length;
      for (int m = 0; m < k; m++)
      {
        String str = arrayOfString[m];
        this.f.putShort(this.a.newUTF8(str));
      }
      this.b += 4 + 2 * paramVarArgs.length;
    }
    this.e += 1;
  }
  
  public void visitUse(String paramString)
  {
    if (this.h == null) {
      this.h = new ByteVector();
    }
    this.h.putShort(this.a.newClass(paramString));
    this.g += 1;
    this.b += 2;
  }
  
  public void visitProvide(String paramString1, String paramString2)
  {
    if (this.j == null) {
      this.j = new ByteVector();
    }
    this.j.putShort(this.a.newClass(paramString1)).putShort(this.a.newClass(paramString2));
    this.i += 1;
    this.b += 4;
  }
  
  public void visitEnd() {}
  
  int a()
  {
    return this.b;
  }
  
  void a(ByteVector paramByteVector)
  {
    paramByteVector.putInt(this.b);
    paramByteVector.putShort(this.c);
    if (this.d != null) {
      paramByteVector.putByteArray(this.d.a, 0, this.d.b);
    }
    paramByteVector.putShort(this.e);
    if (this.f != null) {
      paramByteVector.putByteArray(this.f.a, 0, this.f.b);
    }
    paramByteVector.putShort(this.g);
    if (this.h != null) {
      paramByteVector.putByteArray(this.h.a, 0, this.h.b);
    }
    paramByteVector.putShort(this.i);
    if (this.j != null) {
      paramByteVector.putByteArray(this.j.a, 0, this.j.b);
    }
  }
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.objectweb.asm.ModuleWriter
 * JD-Core Version:    0.7.0.1
 */