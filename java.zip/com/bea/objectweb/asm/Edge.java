package com.bea.objectweb.asm;

class Edge
{
  int a;
  Label b;
  Edge c;
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.objectweb.asm.Edge
 * JD-Core Version:    0.7.0.1
 */