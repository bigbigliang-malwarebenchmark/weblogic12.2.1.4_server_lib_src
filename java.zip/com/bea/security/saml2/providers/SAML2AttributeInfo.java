/*   1:    */ package com.bea.security.saml2.providers;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collection;
/*   5:    */ 
/*   6:    */ public class SAML2AttributeInfo
/*   7:    */ {
/*   8:    */   public static final String ATTR_NAME_FORMAT_BASIC = "urn:oasis:names:tc:SAML:2.0:attrname-format:basic";
/*   9:    */   private String attributeName;
/*  10: 25 */   private String attributeNameFormat = "urn:oasis:names:tc:SAML:2.0:attrname-format:basic";
/*  11:    */   private String attributeFriendlyName;
/*  12:    */   private Collection<String> attributeValues;
/*  13:    */   
/*  14:    */   public SAML2AttributeInfo() {}
/*  15:    */   
/*  16:    */   public SAML2AttributeInfo(String attributeName, Collection<String> attributeValues)
/*  17:    */   {
/*  18: 49 */     this.attributeName = attributeName;
/*  19: 50 */     addAttributeValues(attributeValues);
/*  20:    */   }
/*  21:    */   
/*  22:    */   public SAML2AttributeInfo(String attributeName, String attributeValue)
/*  23:    */   {
/*  24: 60 */     this.attributeName = attributeName;
/*  25: 61 */     addAttributeValue(attributeValue);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public SAML2AttributeInfo(String attributeName, String attributeNameFormat, String attributeFriendlyName, Collection<String> attributeValues)
/*  29:    */   {
/*  30: 74 */     this.attributeName = attributeName;
/*  31: 75 */     this.attributeFriendlyName = attributeFriendlyName;
/*  32: 76 */     this.attributeNameFormat = attributeNameFormat;
/*  33: 77 */     addAttributeValues(attributeValues);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public String getAttributeName()
/*  37:    */   {
/*  38: 87 */     return this.attributeName;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setAttributeName(String attributeName)
/*  42:    */   {
/*  43: 97 */     this.attributeName = attributeName;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public String getAttributeNameFormat()
/*  47:    */   {
/*  48:108 */     return this.attributeNameFormat;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setAttributeNameFormat(String attributeNameFormat)
/*  52:    */   {
/*  53:118 */     this.attributeNameFormat = attributeNameFormat;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public String getAttributeFriendlyName()
/*  57:    */   {
/*  58:128 */     return this.attributeFriendlyName;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void setAttributeFriendlyName(String attributeFriendlyName)
/*  62:    */   {
/*  63:138 */     this.attributeFriendlyName = attributeFriendlyName;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void addAttributeValue(String attributeValue)
/*  67:    */   {
/*  68:148 */     if (this.attributeValues == null) {
/*  69:149 */       this.attributeValues = new ArrayList();
/*  70:    */     }
/*  71:151 */     this.attributeValues.add(attributeValue);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void addAttributeValues(Collection<String> attributeValues)
/*  75:    */   {
/*  76:161 */     if ((attributeValues != null) && (attributeValues.size() > 0))
/*  77:    */     {
/*  78:162 */       if (this.attributeValues == null) {
/*  79:163 */         this.attributeValues = new ArrayList();
/*  80:    */       }
/*  81:165 */       for (String s : attributeValues) {
/*  82:166 */         this.attributeValues.add(s);
/*  83:    */       }
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   public Collection<String> getAttributeValues()
/*  88:    */   {
/*  89:178 */     return this.attributeValues;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public String toString()
/*  93:    */   {
/*  94:186 */     StringBuilder builder = new StringBuilder();
/*  95:    */     
/*  96:188 */     int attrValueSize = this.attributeValues == null ? 0 : this.attributeValues.size();
/*  97:189 */     builder.append("    attrName=").append(this.attributeName).append(", attrNameFormat=").append(this.attributeNameFormat)
/*  98:190 */       .append(", attrFridentlyName=").append(this.attributeFriendlyName)
/*  99:191 */       .append(", NumOfAttrValues=").append(attrValueSize).append("\n");
/* 100:193 */     if (attrValueSize < 1) {
/* 101:194 */       return builder.toString();
/* 102:    */     }
/* 103:196 */     for (String value : this.attributeValues) {
/* 104:197 */       builder.append("      value=").append(value).append("\n");
/* 105:    */     }
/* 106:200 */     return builder.toString();
/* 107:    */   }
/* 108:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.SAML2AttributeInfo
 * JD-Core Version:    0.7.0.1
 */