/*   1:    */ package com.bea.security.saml2.providers;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ 
/*   5:    */ public class SAML2NameMapperInfo
/*   6:    */ {
/*   7:    */   public static final String NAME_FORMAT_UNSPECIFIED = "urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified";
/*   8:    */   public static final String NAME_FORMAT_KERBEROS = "urn:oasis:names:tc:SAML:2.0:nameid-format:kerberos";
/*   9:    */   public static final String NAME_FORMAT_ENTITY = "urn:oasis:names:tc:SAML:2.0:nameid-format:entity";
/*  10:    */   public static final String NAME_FORMAT_PERSISTENT = "urn:oasis:names:tc:SAML:2.0:nameid-format:persistent";
/*  11:    */   public static final String NAME_FORMAT_TRANSIENT = "urn:oasis:names:tc:SAML:2.0:nameid-format:transient";
/*  12:    */   public static final String ATTR_NAME_FORMAT_BASIC = "urn:oasis:names:tc:SAML:2.0:attrname-format:basic";
/*  13:    */   public static final String BEA_GROUP_ATTR_NAMESPACE = "urn:bea:security:saml2:groups";
/*  14:    */   public static final String BEA_GROUP_ATTR_NAME = "Groups";
/*  15:    */   public static final String BEA_GROUP_ATTR_NAMEFORMAT = "urn:oasis:names:tc:SAML:2.0:attrname-format:basic";
/*  16: 66 */   private String nameQualifier = null;
/*  17: 67 */   private String nameFormat = "urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified";
/*  18: 68 */   private String name = null;
/*  19: 70 */   private String groupAttrNamespace = "urn:bea:security:saml2:groups";
/*  20: 71 */   private String groupAttrName = "Groups";
/*  21: 72 */   private String groupAttrNameFormat = "urn:oasis:names:tc:SAML:2.0:attrname-format:basic";
/*  22: 73 */   private Collection groups = null;
/*  23:    */   
/*  24:    */   public SAML2NameMapperInfo() {}
/*  25:    */   
/*  26:    */   public SAML2NameMapperInfo(String name, Collection groups)
/*  27:    */   {
/*  28: 89 */     this.name = name;
/*  29: 90 */     this.groups = groups;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public SAML2NameMapperInfo(String nameQualifier, String name, Collection groups)
/*  33:    */   {
/*  34:102 */     this.nameQualifier = nameQualifier;
/*  35:103 */     this.name = name;
/*  36:104 */     this.groups = groups;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public SAML2NameMapperInfo(String nameQualifier, String nameFormat, String name, Collection groups)
/*  40:    */   {
/*  41:117 */     this.nameQualifier = nameQualifier;
/*  42:118 */     this.nameFormat = nameFormat;
/*  43:119 */     this.name = name;
/*  44:120 */     this.groups = groups;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public SAML2NameMapperInfo(String nameQualifier, String nameFormat, String name, String groupAttrName, String groupAttrNameFormat, Collection groups)
/*  48:    */   {
/*  49:136 */     this.nameQualifier = nameQualifier;
/*  50:137 */     this.nameFormat = nameFormat;
/*  51:138 */     this.name = name;
/*  52:139 */     this.groupAttrName = groupAttrName;
/*  53:140 */     this.groupAttrNameFormat = groupAttrNameFormat;
/*  54:141 */     this.groups = groups;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public String getGroupAttrName()
/*  58:    */   {
/*  59:150 */     return this.groupAttrName;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setGroupAttrName(String groupAttrName)
/*  63:    */   {
/*  64:159 */     this.groupAttrName = groupAttrName;
/*  65:    */   }
/*  66:    */   
/*  67:    */   @Deprecated
/*  68:    */   public String getGroupAttrNamespace()
/*  69:    */   {
/*  70:170 */     return this.groupAttrNamespace;
/*  71:    */   }
/*  72:    */   
/*  73:    */   @Deprecated
/*  74:    */   public void setGroupAttrNamespace(String groupAttrNamespace)
/*  75:    */   {
/*  76:181 */     this.groupAttrNamespace = groupAttrNamespace;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public String getGroupAttrNameFormat()
/*  80:    */   {
/*  81:190 */     return this.groupAttrNameFormat;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void setGroupAttrNameFormat(String groupAttrNameFormat)
/*  85:    */   {
/*  86:199 */     this.groupAttrNameFormat = groupAttrNameFormat;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public Collection getGroups()
/*  90:    */   {
/*  91:207 */     return this.groups;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setGroups(Collection groups)
/*  95:    */   {
/*  96:215 */     this.groups = groups;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public String getName()
/* 100:    */   {
/* 101:223 */     return this.name;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void setName(String name)
/* 105:    */   {
/* 106:231 */     this.name = name;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public String getNameFormat()
/* 110:    */   {
/* 111:240 */     return this.nameFormat;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setNameFormat(String nameFormat)
/* 115:    */   {
/* 116:249 */     this.nameFormat = nameFormat;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public String getNameQualifier()
/* 120:    */   {
/* 121:257 */     return this.nameQualifier;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void setNameQualifier(String nameQualifier)
/* 125:    */   {
/* 126:265 */     this.nameQualifier = nameQualifier;
/* 127:    */   }
/* 128:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.SAML2NameMapperInfo
 * JD-Core Version:    0.7.0.1
 */