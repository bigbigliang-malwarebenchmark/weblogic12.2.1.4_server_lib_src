package com.bea.security.saml2.providers.registry;

public abstract interface WSSSPPartner
  extends WSSPartner, SPPartner
{}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.registry.WSSSPPartner
 * JD-Core Version:    0.7.0.1
 */