package com.bea.security.saml2.providers.registry;

public abstract interface MetadataPartner
  extends Partner
{
  public abstract String getEntityID();
  
  public abstract void setEntityID(String paramString);
  
  public abstract String getContactPersonGivenName();
  
  public abstract void setContactPersonGivenName(String paramString);
  
  public abstract String getContactPersonSurName();
  
  public abstract void setContactPersonSurName(String paramString);
  
  public abstract String getContactPersonType();
  
  public abstract void setContactPersonType(String paramString);
  
  public abstract String getContactPersonCompany();
  
  public abstract void setContactPersonCompany(String paramString);
  
  public abstract String getContactPersonTelephoneNumber();
  
  public abstract void setContactPersonTelephoneNumber(String paramString);
  
  public abstract String getContactPersonEmailAddress();
  
  public abstract void setContactPersonEmailAddress(String paramString);
  
  public abstract String getOrganizationName();
  
  public abstract void setOrganizationName(String paramString);
  
  public abstract String getOrganizationURL();
  
  public abstract void setOrganizationURL(String paramString);
  
  public abstract String getErrorURL();
  
  public abstract void setErrorURL(String paramString);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.registry.MetadataPartner
 * JD-Core Version:    0.7.0.1
 */