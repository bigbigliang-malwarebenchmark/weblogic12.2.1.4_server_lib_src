package com.bea.security.saml2.providers.registry;

import java.security.cert.X509Certificate;

public abstract interface WebSSOPartner
  extends MetadataPartner, BindingClientPartner
{
  public abstract IndexedEndpoint[] getArtifactResolutionService();
  
  public abstract X509Certificate getSSOSigningCert();
  
  public abstract void setSSOSigningCert(X509Certificate paramX509Certificate);
  
  public abstract void setArtifactResolutionService(IndexedEndpoint[] paramArrayOfIndexedEndpoint);
  
  public abstract boolean isArtifactBindingUsePOSTMethod();
  
  public abstract void setArtifactBindingUsePOSTMethod(boolean paramBoolean);
  
  public abstract String getArtifactBindingPostForm();
  
  public abstract void setArtifactBindingPostForm(String paramString);
  
  public abstract boolean isWantArtifactRequestSigned();
  
  public abstract void setWantArtifactRequestSigned(boolean paramBoolean);
  
  public abstract String getPostBindingPostForm();
  
  public abstract void setPostBindingPostForm(String paramString);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.registry.WebSSOPartner
 * JD-Core Version:    0.7.0.1
 */