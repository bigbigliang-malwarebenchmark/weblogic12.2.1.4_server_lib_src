package com.bea.security.saml2.providers.registry;

import java.security.cert.X509Certificate;

public abstract interface BindingClientPartner
  extends Partner
{
  public abstract X509Certificate getTransportLayerClientCert();
  
  public abstract void setTransportLayerClientCert(X509Certificate paramX509Certificate);
  
  public abstract String getClientUsername();
  
  public abstract void setClientUsername(String paramString);
  
  public abstract String getClientPasswordEncrypted();
  
  public abstract boolean isClientPasswordSet();
  
  public abstract void setClientPassword(String paramString);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.registry.BindingClientPartner
 * JD-Core Version:    0.7.0.1
 */