package com.bea.security.saml2.providers.registry;

import java.security.cert.X509Certificate;
import java.util.List;

public abstract interface WebSSOSPPartner
  extends WebSSOPartner, SPPartner
{
  public abstract boolean isWantAuthnRequestsSigned();
  
  public abstract void setWantAuthnRequestsSigned(boolean paramBoolean);
  
  public abstract IndexedEndpoint[] getAssertionConsumerService();
  
  public abstract void setAssertionConsumerService(IndexedEndpoint[] paramArrayOfIndexedEndpoint);
  
  public abstract X509Certificate getAssertionEncryptionCert();
  
  public abstract void setAssertionEncryptionCert(X509Certificate paramX509Certificate);
  
  public abstract List<String> getEncryptionAlgorithms();
  
  public abstract void setEncryptionAlgorithms(List<String> paramList);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.registry.WebSSOSPPartner
 * JD-Core Version:    0.7.0.1
 */