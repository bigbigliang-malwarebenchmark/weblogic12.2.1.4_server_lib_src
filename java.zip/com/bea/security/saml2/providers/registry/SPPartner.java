package com.bea.security.saml2.providers.registry;

public abstract interface SPPartner
  extends Partner
{
  public abstract String getServiceProviderNameMapperClassname();
  
  public abstract void setServiceProviderNameMapperClassname(String paramString);
  
  public abstract int getTimeToLive();
  
  public abstract void setTimeToLive(int paramInt);
  
  public abstract int getTimeToLiveOffset();
  
  public abstract void setTimeToLiveOffset(int paramInt);
  
  public abstract boolean isIncludeOneTimeUseCondition();
  
  public abstract void setIncludeOneTimeUseCondition(boolean paramBoolean);
  
  public abstract boolean isGenerateAttributes();
  
  public abstract void setGenerateAttributes(boolean paramBoolean);
  
  public abstract boolean isKeyinfoIncluded();
  
  public abstract void setKeyinfoIncluded(boolean paramBoolean);
  
  public abstract boolean isWantAssertionsSigned();
  
  public abstract void setWantAssertionsSigned(boolean paramBoolean);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.registry.SPPartner
 * JD-Core Version:    0.7.0.1
 */