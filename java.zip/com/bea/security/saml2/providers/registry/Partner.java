package com.bea.security.saml2.providers.registry;

import java.io.Serializable;

public abstract interface Partner
  extends Serializable
{
  public static final String ASSERTION_TYPE_BEARER = "urn:oasis:names:tc:SAML:2.0:cm:bearer";
  public static final String ASSERTION_TYPE_HOLDER_OF_KEY = "urn:oasis:names:tc:SAML:2.0:cm:holder-of-key";
  public static final String ASSERTION_TYPE_SENDER_VOUCHES = "urn:oasis:names:tc:SAML:2.0:cm:sender-vouches";
  
  public abstract void setName(String paramString);
  
  public abstract String getName();
  
  public abstract boolean isEnabled();
  
  public abstract boolean isNameModified();
  
  public abstract void setEnabled(boolean paramBoolean);
  
  public abstract String getDescription();
  
  public abstract void setDescription(String paramString);
  
  public abstract String[] getAudienceURIs();
  
  public abstract void setAudienceURIs(String[] paramArrayOfString);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.registry.Partner
 * JD-Core Version:    0.7.0.1
 */