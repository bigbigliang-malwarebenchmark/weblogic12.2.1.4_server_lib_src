package com.bea.security.saml2.providers.registry;

public abstract interface IdPPartner
  extends Partner
{
  public abstract String getIdentityProviderNameMapperClassname();
  
  public abstract void setIdentityProviderNameMapperClassname(String paramString);
  
  public abstract String getIssuerURI();
  
  public abstract void setIssuerURI(String paramString);
  
  public abstract boolean isVirtualUserEnabled();
  
  public abstract void setVirtualUserEnabled(boolean paramBoolean);
  
  public abstract boolean isProcessAttributes();
  
  public abstract void setProcessAttributes(boolean paramBoolean);
  
  public abstract boolean isWantAssertionsSigned();
  
  public abstract void setWantAssertionsSigned(boolean paramBoolean);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.registry.IdPPartner
 * JD-Core Version:    0.7.0.1
 */