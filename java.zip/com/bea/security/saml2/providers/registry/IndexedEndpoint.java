package com.bea.security.saml2.providers.registry;

public abstract interface IndexedEndpoint
  extends Endpoint
{
  public abstract int getIndex();
  
  public abstract void setIndex(int paramInt);
  
  public abstract boolean isDefault();
  
  public abstract void setDefault(boolean paramBoolean);
  
  public abstract boolean isDefaultSet();
  
  public abstract void unsetDefault();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.registry.IndexedEndpoint
 * JD-Core Version:    0.7.0.1
 */