package com.bea.security.saml2.providers.registry;

public abstract interface WSSPartner
  extends Partner
{
  public abstract String getConfirmationMethod();
  
  public abstract void setConfirmationMethod(String paramString);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.registry.WSSPartner
 * JD-Core Version:    0.7.0.1
 */