package com.bea.security.saml2.providers.registry;

import java.security.cert.X509Certificate;

public abstract interface WSSIdPPartner
  extends WSSPartner, IdPPartner
{
  public abstract X509Certificate getAssertionSigningCert();
  
  public abstract void setAssertionSigningCert(X509Certificate paramX509Certificate);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.registry.WSSIdPPartner
 * JD-Core Version:    0.7.0.1
 */