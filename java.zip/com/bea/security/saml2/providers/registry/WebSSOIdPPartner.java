package com.bea.security.saml2.providers.registry;

public abstract interface WebSSOIdPPartner
  extends WebSSOPartner, IdPPartner
{
  public abstract boolean isWantAuthnRequestsSigned();
  
  public abstract void setWantAuthnRequestsSigned(boolean paramBoolean);
  
  public abstract String[] getRedirectURIs();
  
  public abstract void setRedirectURIs(String[] paramArrayOfString);
  
  public abstract Endpoint[] getSingleSignOnService();
  
  public abstract void setSingleSignOnService(Endpoint[] paramArrayOfEndpoint);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.registry.WebSSOIdPPartner
 * JD-Core Version:    0.7.0.1
 */