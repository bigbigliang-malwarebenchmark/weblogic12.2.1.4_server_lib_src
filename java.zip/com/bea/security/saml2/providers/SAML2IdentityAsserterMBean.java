package com.bea.security.saml2.providers;

import javax.management.InvalidAttributeValueException;
import weblogic.descriptor.DescriptorBean;
import weblogic.management.commo.StandardInterface;
import weblogic.management.security.ExportMBean;
import weblogic.management.security.ImportMBean;
import weblogic.management.security.authentication.IdentityAsserterMBean;
import weblogic.management.security.authentication.IdentityDomainAuthenticatorMBean;
import weblogic.management.security.authentication.ServletAuthenticationFilterMBean;

public abstract interface SAML2IdentityAsserterMBean
  extends StandardInterface, DescriptorBean, IdentityAsserterMBean, SAML2IdPPartnerRegistryMBean, ImportMBean, ExportMBean, ServletAuthenticationFilterMBean, IdentityDomainAuthenticatorMBean
{
  public abstract String getProviderClassName();
  
  public abstract String getDescription();
  
  public abstract String getVersion();
  
  public abstract String[] getSupportedImportFormats();
  
  public abstract String[] getSupportedImportConstraints();
  
  public abstract String[] getSupportedExportFormats();
  
  public abstract String[] getSupportedExportConstraints();
  
  public abstract String[] getSupportedTypes();
  
  public abstract String[] getActiveTypes();
  
  public abstract boolean getBase64DecodingRequired();
  
  public abstract String getNameMapperClassName();
  
  public abstract void setNameMapperClassName(String paramString)
    throws InvalidAttributeValueException;
  
  public abstract boolean getReplicatedCacheEnabled();
  
  public abstract void setReplicatedCacheEnabled(boolean paramBoolean)
    throws InvalidAttributeValueException;
  
  public abstract boolean isLoginTokenAssociatonEnabled();
  
  public abstract void setLoginTokenAssociatonEnabled(boolean paramBoolean)
    throws InvalidAttributeValueException;
  
  public abstract String getName();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.SAML2IdentityAsserterMBean
 * JD-Core Version:    0.7.0.1
 */