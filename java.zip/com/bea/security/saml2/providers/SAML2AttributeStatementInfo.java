/*   1:    */ package com.bea.security.saml2.providers;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collection;
/*   5:    */ 
/*   6:    */ public class SAML2AttributeStatementInfo
/*   7:    */ {
/*   8:    */   private Collection<SAML2AttributeInfo> attributes;
/*   9:    */   
/*  10:    */   public SAML2AttributeStatementInfo() {}
/*  11:    */   
/*  12:    */   public SAML2AttributeStatementInfo(Collection<SAML2AttributeInfo> attrs)
/*  13:    */   {
/*  14: 30 */     addAttributeInfo(attrs);
/*  15:    */   }
/*  16:    */   
/*  17:    */   public void addAttributeInfo(SAML2AttributeInfo attr)
/*  18:    */   {
/*  19: 40 */     if (isValid(attr))
/*  20:    */     {
/*  21: 41 */       if (this.attributes == null) {
/*  22: 42 */         this.attributes = new ArrayList();
/*  23:    */       }
/*  24: 44 */       this.attributes.add(attr);
/*  25:    */     }
/*  26:    */   }
/*  27:    */   
/*  28:    */   public void addAttributeInfo(Collection<SAML2AttributeInfo> attrs)
/*  29:    */   {
/*  30: 56 */     if ((attrs != null) && (attrs.size() > 0))
/*  31:    */     {
/*  32: 57 */       if (this.attributes == null) {
/*  33: 58 */         this.attributes = new ArrayList();
/*  34:    */       }
/*  35: 60 */       for (SAML2AttributeInfo attr : attrs) {
/*  36: 61 */         if (isValid(attr)) {
/*  37: 62 */           this.attributes.add(attr);
/*  38:    */         }
/*  39:    */       }
/*  40:    */     }
/*  41:    */   }
/*  42:    */   
/*  43:    */   public Collection<SAML2AttributeInfo> getAttributeInfo()
/*  44:    */   {
/*  45: 76 */     return this.attributes;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public String toString()
/*  49:    */   {
/*  50: 84 */     StringBuilder builder = new StringBuilder();
/*  51:    */     
/*  52: 86 */     int size = this.attributes == null ? 0 : this.attributes.size();
/*  53: 87 */     builder.append("SAML2AttributeStatement - NumOfAttrs: ").append(size).append("\n");
/*  54: 88 */     if (size < 1) {
/*  55: 89 */       return builder.toString();
/*  56:    */     }
/*  57: 91 */     for (SAML2AttributeInfo attr : this.attributes) {
/*  58: 92 */       builder.append(attr).append("\n");
/*  59:    */     }
/*  60: 95 */     return builder.toString();
/*  61:    */   }
/*  62:    */   
/*  63:    */   private boolean isValid(SAML2AttributeInfo attr)
/*  64:    */   {
/*  65: 99 */     String attrName = attr == null ? null : attr.getAttributeName();
/*  66:100 */     return (attrName != null) && (attrName.trim().length() > 0);
/*  67:    */   }
/*  68:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.SAML2AttributeStatementInfo
 * JD-Core Version:    0.7.0.1
 */