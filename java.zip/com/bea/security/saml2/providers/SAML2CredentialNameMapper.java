package com.bea.security.saml2.providers;

import javax.security.auth.Subject;
import weblogic.security.service.ContextHandler;

public abstract interface SAML2CredentialNameMapper
{
  public abstract void setNameQualifier(String paramString);
  
  public abstract SAML2NameMapperInfo mapSubject(Subject paramSubject, ContextHandler paramContextHandler);
  
  public abstract SAML2NameMapperInfo mapName(String paramString, ContextHandler paramContextHandler);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.SAML2CredentialNameMapper
 * JD-Core Version:    0.7.0.1
 */