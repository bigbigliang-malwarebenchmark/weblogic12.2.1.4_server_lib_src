package com.bea.security.saml2.providers;

import java.util.Collection;
import javax.security.auth.Subject;
import weblogic.security.service.ContextHandler;

public abstract interface SAML2CredentialAttributeMapper
{
  public abstract Collection<SAML2AttributeStatementInfo> mapAttributes(Subject paramSubject, ContextHandler paramContextHandler);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.SAML2CredentialAttributeMapper
 * JD-Core Version:    0.7.0.1
 */