package com.bea.security.saml2.providers;

import weblogic.security.service.ContextHandler;

public abstract interface SAML2IdentityAsserterNameMapper
{
  public abstract String mapNameInfo(SAML2NameMapperInfo paramSAML2NameMapperInfo, ContextHandler paramContextHandler);
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.SAML2IdentityAsserterNameMapper
 * JD-Core Version:    0.7.0.1
 */