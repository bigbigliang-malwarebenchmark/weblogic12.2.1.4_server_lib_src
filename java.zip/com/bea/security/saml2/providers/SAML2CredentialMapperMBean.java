package com.bea.security.saml2.providers;

import javax.management.InvalidAttributeValueException;
import weblogic.descriptor.DescriptorBean;
import weblogic.management.commo.StandardInterface;
import weblogic.management.security.ApplicationVersionerMBean;
import weblogic.management.security.ExportMBean;
import weblogic.management.security.IdentityDomainAwareProviderMBean;
import weblogic.management.security.ImportMBean;
import weblogic.management.security.credentials.CredentialMapperMBean;

public abstract interface SAML2CredentialMapperMBean
  extends StandardInterface, DescriptorBean, CredentialMapperMBean, SAML2SPPartnerRegistryMBean, ImportMBean, ExportMBean, ApplicationVersionerMBean, IdentityDomainAwareProviderMBean
{
  public abstract String getProviderClassName();
  
  public abstract String getDescription();
  
  public abstract String getVersion();
  
  public abstract String[] getSupportedImportFormats();
  
  public abstract String[] getSupportedImportConstraints();
  
  public abstract String[] getSupportedExportFormats();
  
  public abstract String[] getSupportedExportConstraints();
  
  public abstract String getIssuerURI();
  
  public abstract void setIssuerURI(String paramString)
    throws InvalidAttributeValueException;
  
  public abstract String getNameQualifier();
  
  public abstract void setNameQualifier(String paramString)
    throws InvalidAttributeValueException;
  
  public abstract String getSigningKeyAlias();
  
  public abstract void setSigningKeyAlias(String paramString)
    throws InvalidAttributeValueException;
  
  public abstract String getSigningKeyPassPhrase();
  
  public abstract void setSigningKeyPassPhrase(String paramString)
    throws InvalidAttributeValueException;
  
  public abstract int getDefaultTimeToLive();
  
  public abstract void setDefaultTimeToLive(int paramInt)
    throws InvalidAttributeValueException;
  
  public abstract int getDefaultTimeToLiveOffset();
  
  public abstract void setDefaultTimeToLiveOffset(int paramInt)
    throws InvalidAttributeValueException;
  
  public abstract boolean getGenerateAttributes();
  
  public abstract void setGenerateAttributes(boolean paramBoolean)
    throws InvalidAttributeValueException;
  
  public abstract String getNameMapperClassName();
  
  public abstract void setNameMapperClassName(String paramString)
    throws InvalidAttributeValueException;
  
  public abstract int getCredCacheSize();
  
  public abstract void setCredCacheSize(int paramInt)
    throws InvalidAttributeValueException;
  
  public abstract int getCredCacheMinViableTTL();
  
  public abstract void setCredCacheMinViableTTL(int paramInt)
    throws InvalidAttributeValueException;
  
  public abstract String getName();
  
  public abstract void setSigningKeyPassPhraseEncrypted(byte[] paramArrayOfByte);
  
  public abstract byte[] getSigningKeyPassPhraseEncrypted();
}


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.saml2.providers.SAML2CredentialMapperMBean
 * JD-Core Version:    0.7.0.1
 */