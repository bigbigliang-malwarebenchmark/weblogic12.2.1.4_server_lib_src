/*  1:   */ package com.bea.security.utils.random;
/*  2:   */ 
/*  3:   */ public final class SecureRandomData
/*  4:   */   extends AbstractRandomData
/*  5:   */ {
/*  6:22 */   private static SecureRandomData theSRD = new SecureRandomData();
/*  7:25 */   private static final String PROVIDER = null;
/*  8:26 */   private static final String ALGORITHM = null;
/*  9:   */   private static final int INITIAL_SEED_SIZE = 80;
/* 10:   */   private static final int INCREMENTAL_SEED_SIZE = 4;
/* 11:   */   private static final int SEEDING_INTERVAL_MILLIS = 60000;
/* 12:   */   
/* 13:   */   private SecureRandomData()
/* 14:   */   {
/* 15:34 */     super(PROVIDER, ALGORITHM, 80, 4, 60000);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static SecureRandomData getInstance()
/* 19:   */   {
/* 20:41 */     return theSRD;
/* 21:   */   }
/* 22:   */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.utils.random.SecureRandomData
 * JD-Core Version:    0.7.0.1
 */