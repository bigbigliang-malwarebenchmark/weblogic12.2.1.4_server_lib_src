/*   1:    */ package com.bea.security.utils.random;
/*   2:    */ 
/*   3:    */ import java.security.ProviderException;
/*   4:    */ import java.security.SecureRandom;
/*   5:    */ 
/*   6:    */ public abstract class AbstractRandomData
/*   7:    */ {
/*   8: 32 */   private String provider = null;
/*   9: 33 */   private String algorithm = null;
/*  10: 36 */   private int initialSeedSize = 0;
/*  11: 37 */   private int incrementalSeedSize = 0;
/*  12: 38 */   private int seedingIntervalMillis = 0;
/*  13: 41 */   private SecureRandom random = null;
/*  14: 44 */   private long lastSeedTime = 0L;
/*  15:    */   private static AbstractRandomData.EntropyConfig entropyCfg;
/*  16:    */   
/*  17:    */   private AbstractRandomData() {}
/*  18:    */   
/*  19:    */   protected AbstractRandomData(String provider, String algorithm, int initialSeedSize, int incrementalSeedSize, int seedingIntervalMillis)
/*  20:    */   {
/*  21: 58 */     this.provider = provider;
/*  22: 59 */     this.algorithm = algorithm;
/*  23: 60 */     this.initialSeedSize = initialSeedSize;
/*  24: 61 */     this.incrementalSeedSize = incrementalSeedSize;
/*  25: 62 */     this.seedingIntervalMillis = seedingIntervalMillis;
/*  26:    */   }
/*  27:    */   
/*  28:    */   private final synchronized void ensureInittedAndSeeded()
/*  29:    */   {
/*  30: 67 */     int seedSize = this.incrementalSeedSize;
/*  31: 69 */     if (this.random == null)
/*  32:    */     {
/*  33:    */       try
/*  34:    */       {
/*  35: 71 */         if ((this.algorithm != null) && (this.provider != null)) {
/*  36: 72 */           this.random = SecureRandom.getInstance(this.algorithm, this.provider);
/*  37: 73 */         } else if (this.algorithm != null) {
/*  38: 74 */           this.random = SecureRandom.getInstance(this.algorithm);
/*  39:    */         } else {
/*  40: 76 */           this.random = new SecureRandom();
/*  41:    */         }
/*  42:    */       }
/*  43:    */       catch (Exception e)
/*  44:    */       {
/*  45: 80 */         this.random = null;
/*  46: 81 */         throw new ProviderException("AbstractRandomData: Unable to instantiate SecureRandom");
/*  47:    */       }
/*  48: 85 */       seedSize = this.initialSeedSize;
/*  49: 86 */       this.lastSeedTime = 0L;
/*  50:    */     }
/*  51: 89 */     if (seedSize > 0)
/*  52:    */     {
/*  53: 90 */       long currentTime = System.currentTimeMillis();
/*  54: 91 */       if (currentTime >= this.lastSeedTime + this.seedingIntervalMillis)
/*  55:    */       {
/*  56: 92 */         byte[] seed = this.random.generateSeed(seedSize);
/*  57: 93 */         this.random.setSeed(seed);
/*  58: 94 */         this.lastSeedTime = currentTime;
/*  59:    */       }
/*  60:    */     }
/*  61:    */   }
/*  62:    */   
/*  63:    */   public final byte[] getRandomBytes(int howMany)
/*  64:    */   {
/*  65:100 */     byte[] bytes = new byte[howMany];
/*  66:101 */     getRandomBytes(bytes);
/*  67:102 */     return bytes;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public final synchronized void getRandomBytes(byte[] bytes)
/*  71:    */   {
/*  72:106 */     ensureInittedAndSeeded();
/*  73:107 */     this.random.nextBytes(bytes);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public final synchronized int getRandomInt()
/*  77:    */   {
/*  78:112 */     ensureInittedAndSeeded();
/*  79:113 */     return this.random.nextInt();
/*  80:    */   }
/*  81:    */   
/*  82:    */   public final synchronized long getRandomLong()
/*  83:    */   {
/*  84:117 */     ensureInittedAndSeeded();
/*  85:118 */     return this.random.nextLong();
/*  86:    */   }
/*  87:    */   
/*  88:    */   public final synchronized long getRandomNonNegativeLong()
/*  89:    */   {
/*  90:122 */     ensureInittedAndSeeded();
/*  91:123 */     return this.random.nextLong() & 0xFFFFFFFF;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public final synchronized double getRandomDouble()
/*  95:    */   {
/*  96:127 */     ensureInittedAndSeeded();
/*  97:128 */     return this.random.nextDouble();
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static String getJavaEntropyConfiguration()
/* 101:    */   {
/* 102:142 */     return getEntropCfgObj().toString();
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static boolean isJavaEntropyBlocking()
/* 106:    */   {
/* 107:151 */     return getEntropCfgObj().isBlocking();
/* 108:    */   }
/* 109:    */   
/* 110:    */   private static synchronized AbstractRandomData.EntropyConfig getEntropCfgObj()
/* 111:    */   {
/* 112:156 */     if (entropyCfg != null) {
/* 113:157 */       return entropyCfg;
/* 114:    */     }
/* 115:159 */     entropyCfg = new AbstractRandomData.EntropyConfig();
/* 116:    */     
/* 117:161 */     return entropyCfg;
/* 118:    */   }
/* 119:    */ }


/* Location:           E:\bigbigliang\1\
 * Qualified Name:     com.bea.security.utils.random.AbstractRandomData
 * JD-Core Version:    0.7.0.1
 */